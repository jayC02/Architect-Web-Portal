# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, type_into
from automation.common.uploads import dismiss_gdpr_modal_if_present


LOGIN_BUTTON_ID = "MainContent_UclLogin_LoginWizard_BtnLogin"
EBUILDING_STANDARDS_NAME = "ctl00$sideBar$ctl11"


class PortalLoginError(RuntimeError):
    """Sign-in did not complete; no proposal/application action was performed."""


def submit_login_and_wait_for_home(driver, timeout=30, authenticated_control_name=EBUILDING_STANDARDS_NAME):
    def current_state(current_driver):
        for control in current_driver.find_elements(By.NAME, authenticated_control_name):
            try:
                if control.is_displayed() and control.is_enabled():
                    return "authenticated", control
            except StaleElementReferenceException:
                continue
        for control in current_driver.find_elements(By.ID, LOGIN_BUTTON_ID):
            try:
                if control.is_displayed() and control.is_enabled():
                    return "login", control
            except StaleElementReferenceException:
                continue
        return False

    wait = WebDriverWait(
        driver,
        timeout,
        ignored_exceptions=(StaleElementReferenceException,),
    )
    def signed_in_or_rejected(current_driver):
        state = current_state(current_driver)
        if state and state[0] == "authenticated":
            return state[1]
        # WebForms and ASP.NET login controls render validation messages with
        # these semantic/class/id conventions. Never copy page text (which may
        # contain account details) into the exception or callback.
        for message in current_driver.find_elements(By.CSS_SELECTOR,
                "[role='alert'], .validation-summary-errors, [id*='FailureText'], "
                "[id*='LoginError'], [id*='ErrorMessage'], [id*='ValidationSummary']"):
            try:
                text = (message.text or "").lower()
                if message.is_displayed() and any(word in text for word in (
                        "password", "credentials", "invalid login", "incorrect login",
                        "unable to log", "unable to sign", "account is locked", "account has been locked")):
                    raise PortalLoginError("eDevelopment did not accept the saved login. Update the saved email and password before restarting.")
            except StaleElementReferenceException:
                continue
        return False

    try:
        for _attempt in range(3):
            state, control = wait.until(current_state)
            if state == "authenticated":
                return control
            try:
                control.click()
            except StaleElementReferenceException:
                # Navigation may replace the clicked control. Re-check before
                # attempting another click; a successful login needs no retry.
                continue
            return wait.until(signed_in_or_rejected)
        raise PortalLoginError("Sign-in did not reach the authenticated eDevelopment home page.")
    except TimeoutException as error:
        raise PortalLoginError("Sign-in did not complete. Check the saved eDevelopment login and portal availability before restarting.") from error


def login_to_ebuilding(driver, username, password):
    driver.get("https://www.edevelopment.scot/eDevelopmentClient/default.aspx")
    print("Opened eDevelopment main page.")

    click_when_clickable(driver, By.ID, "Banner_btnLogin")
    print("Clicked initial login button.")

    type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxEmail", username, clear_first=False)
    print("Entered email.")

    type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxPassword", password, clear_first=False)
    print("Entered password.")

    submit_login_and_wait_for_home(driver)
    print("Clicked final login button.")

    dismiss_gdpr_modal_if_present(driver)

    click_when_clickable(driver, By.NAME, "ctl00$sideBar$ctl11")
    print("Clicked 'eBuilding Standards' button.")

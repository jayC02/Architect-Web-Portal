"""Building Warrant automation workflow."""

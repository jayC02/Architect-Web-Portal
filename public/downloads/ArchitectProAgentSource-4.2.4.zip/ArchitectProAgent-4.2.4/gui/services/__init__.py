"""GUI service helpers."""


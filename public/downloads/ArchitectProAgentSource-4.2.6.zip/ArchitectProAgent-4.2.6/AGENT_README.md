# Architect Pro Agent 4.2.6

For future updates, click **Update Agent** in the Agent window or Architect Pro Settings. The Agent downloads and verifies the update, installs it over the existing version and restarts. No uninstall or reconnect is required. Finish or stop an active application before updating.

Download and run `ArchitectProAgentSetup-4.2.6.exe` on the computer that handles applications. The installer closes older Agents in this installation, updates the existing shortcuts and launches the new version automatically. It keeps the same installation identity, portal connection, saved eDevelopment login and application-data folder. No uninstall, connection reset or password re-entry is needed when the saved credentials remain valid. Finish or cancel running automation before installing. After the portal deployment, `https://www.architectpro.co.uk/agent/download` always downloads the current release.

Version 4.2.6 fixes manual upgrade handover between versioned installations. Older executables are registered with Windows Restart Manager even though their files are kept in separate folders. Only the new release launches after installation. An existing desktop shortcut is updated, and an existing choice not to start with Windows is preserved. Installer preparation and launch are verified with disposable Qt processes and an isolated Inno installer; real Agent credentials and installations are not used by the verification.

Version 4.2.5 fixes Building Warrant supporting-document preparation. The workflow uses the document list supplied with the current portal job throughout, instead of rereading a missing or stale legacy local list after completing the application details. Document failures report the specific operation in the Agent and portal while preserving the original technical cause locally. A partial application must be reviewed in eBuilding Standards before another attempt is started.

Version 4.2.4 fixes recovery from failed eDevelopment sign-in, including empty Selenium timeouts. Rejected credentials are submitted once, failed sign-in offers login correction and a fresh restart, and updating credentials keeps the recovery screen available.

Version 4.2.3 adds Cancel job for stuck claims in the Agent and responds to cancellation from the website queue. Running automation stops at a safe boundary before the next job starts. The website keeps the prepared application. Update progress and the installed Agent version are visible in the window. Each release installs into its own program subfolder, so files still locked from an older release cannot block the upgrade.

Version 4.2.2 fixes loading the next queued application after a previous one finishes. A failed preparation download is reported and releases the claim instead of indefinitely holding the queue. The portal update also restores opening prepared applications for review after the Agent releases them.

1. In Architect Pro Settings, choose Download & connect Agent (or Reinstall / update), install it, and complete the browser connection if prompted.
2. Open Agent Settings and save your eDevelopment login.
3. Prepare and queue Planning or Building Warrant applications in the website. Keep the Agent running in the Windows notification area: it processes one job at a time.
4. When the application is ready for review, check it in the council portal and submit it yourself. Closing the Agent window keeps the app running in the notification area; Quit stops it.

The website queue shows running applications and authorised jobs waiting for the Agent. Remove withdraws a waiting job without deleting its prepared application. Cancel job stops a claimed or running attempt; the queue shows Cancelling until a running Agent releases it. If the Agent is offline, reopen it to finish stopping the run. You can also use Cancel job in the Agent, including after a preparation download fails. Review the retained application before running a fresh attempt.

The release includes the current Planning and Building Warrant fee entry, queue processing, immutable application snapshots and browser-review handoff code. Architect-entered Planning fees and calculated Building Warrant fees are checked in the council fee field before review.

Source: `ArchitectProAgentSource-4.2.6.zip`. Install dependencies from `requirements.txt` and run `python Gui.py`; Windows and Google Chrome are required. `python Scripts/build_agent_release.py` builds a versioned installer and source archive; Inno Setup 6 is required for the installer. `python Scripts/verify_agent_upgrade.py` verifies upgrade handover without changing the installed Agent. Runtime passwords, enrollment credentials and project caches are not part of the source archive.

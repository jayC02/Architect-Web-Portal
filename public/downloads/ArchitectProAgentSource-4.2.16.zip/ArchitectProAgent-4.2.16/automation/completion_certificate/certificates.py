"""The Completion Certificate's two certificate registers.

``CertificatesRegister`` lists certificates of construction;
``CertificatesRegister1`` lists Notice of Finalisation of Design Details
(Form Q) certificates. Both use the same controls.

A register always shows one entry at a time with a ``current/total`` pager. On
a new form it holds a single blank entry; on a rerun it may hold saved ones.
Saved entries are corrected in place. Add, Validation Check and the pager
buttons are each clicked once and never repeated on an uncertain result, and
Remove is never clicked.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import re

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.building_warrant.certificates import CertificateValidationError, check_certificate_validation
from automation.common.actions import click_when_clickable, get_when_clickable, wait_dom_ready
from automation.completion_certificate.fields import PREFIX, current_value, portal_date, set_text
from automation.completion_certificate.navigation import wait_for_step

MAX_ENTRIES = 20
CERTIFIER_DATE_ID = "txtCertifierSignatureDate"
APPROVED_BODY_DATE_ID = "txtApprovedBodySignatureDate"
PAGER_SCRIPT = """
// ARCHPRO_REGISTER_PAGER: the "current/total" text beside this register's pager buttons.
const add = document.getElementById(arguments[0]);
return add && add.parentElement ? add.parentElement.textContent : '';
"""


@dataclass(frozen=True)
class RegisterSpec:
    prefix: str
    scheme: str
    part1: tuple
    certifier_part2: str
    approved_body_part2: str
    label: str


CONSTRUCTION = RegisterSpec(
    prefix=PREFIX + "CertificatesRegister_", scheme="Construction", part1=("NIC1", "SEL1", "SNP1"),
    certifier_part2="C", approved_body_part2="CB", label="certificate of construction",
)
DESIGN = RegisterSpec(
    prefix=PREFIX + "CertificatesRegister1_", scheme="Design", part1=("BRE1", "BRE2", "RIA1", "RIA2", "SER1"),
    certifier_part2="D", approved_body_part2="DB", label="Form Q certificate",
)


class CompletionCertificateValidationError(CertificateValidationError):
    """The portal rejected one register entry on its Validation Check."""

    def __init__(self, spec, index, portal_message):
        self.portal_message = " ".join(str(portal_message).split())[:320]
        ValueError.__init__(
            self,
            f"Certificate validation failed for {spec.label} {index}: {self.portal_message} "
            "Correct it on the completion certificate page in Architect Pro and run it again.",
        )


class RegisterStateError(RuntimeError):
    """The register holds entries the Agent must not remove. Needs a person to look."""

    confirmation_required = True
    retryable = False


def _text(value):
    return str(value or "").strip()


def validate_entries(entries, spec):
    """Refuse incomplete or mismatched entries before anything is typed into the portal."""
    if not isinstance(entries, (list, tuple)) or not 1 <= len(entries) <= MAX_ENTRIES:
        raise ValueError(f"Add between one and {MAX_ENTRIES} {spec.label} entries in Architect Pro.")
    for index, entry in enumerate(entries, start=1):
        problem = f"Complete {spec.label} {index} in Architect Pro"
        if not isinstance(entry, Mapping):
            raise ValueError(f"{problem}.")
        if not _text(entry.get("certificateNumber")):
            raise ValueError(f"{problem}: the certificate number is missing.")
        for key, part2, who in (
            ("certifierRegistration", spec.certifier_part2, "certifier"),
            ("approvedBodyRegistration", spec.approved_body_part2, "approved body"),
        ):
            registration = entry.get(key)
            if not isinstance(registration, Mapping):
                raise ValueError(f"{problem}: the {who} registration number is missing.")
            if _text(registration.get("part1")) not in spec.part1:
                raise ValueError(f"{problem}: choose the {who} registration prefix ({', '.join(spec.part1)}).")
            if _text(registration.get("part2")) != part2 or not _text(registration.get("number")):
                raise ValueError(f"{problem}: the {who} registration number is incomplete.")
        for key, who in (("certifierSignatureDate", "certifier"), ("approvedBodySignatureDate", "approved body")):
            try:
                portal_date(entry.get(key))
            except ValueError as exc:
                raise ValueError(f"{problem}: the {who} date of signature is missing or invalid.") from exc


def pager(driver, spec):
    """(current, total) from the register's pager, e.g. ``1/1``."""
    text = driver.execute_script(PAGER_SCRIPT, spec.prefix + "btnAddCertificate") or ""
    match = re.search(r"\b(\d+)\s*/\s*(\d+)\b", str(text))
    if not match:
        raise RuntimeError(
            f"The portal has changed on the {spec.label} screen: its entry counter was not found."
        )
    return int(match.group(1)), int(match.group(2))


def _wait_for_pager(driver, spec, expected, timeout, failure):
    def reached(current):
        try:
            return pager(current, spec) == expected
        except (RuntimeError, StaleElementReferenceException):
            return False

    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(reached)
    except TimeoutException as exc:
        raise RuntimeError(failure) from exc


def _selected_text(driver, element_id):
    try:
        return Select(driver.find_element(By.ID, element_id)).first_selected_option.text.strip()
    except (NoSuchElementException, StaleElementReferenceException):
        return None


def _option_texts(driver, element_id):
    try:
        return [option.text.strip() for option in Select(driver.find_element(By.ID, element_id)).options]
    except (NoSuchElementException, StaleElementReferenceException):
        return []


def select_option(driver, element_id, value, spec, timeout=30):
    """Choose ``value`` in a dropdown whose options may still be loading after a postback."""
    if _selected_text(driver, element_id) == value:
        return False
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(
            lambda current: value in _option_texts(current, element_id)
        )
    except TimeoutException as exc:
        offered = [option for option in _option_texts(driver, element_id) if option and set(option) != {"."}]
        raise RuntimeError(
            f"The portal does not offer {value!r} on the {spec.label} screen. "
            f"It offers: {', '.join(offered) or 'no options'}. Correct the entry in Architect Pro."
        ) from exc
    for _attempt in range(3):
        try:
            Select(get_when_clickable(driver, By.ID, element_id, timeout=timeout)).select_by_visible_text(value)
            break
        except StaleElementReferenceException:
            continue
    wait_dom_ready(driver, timeout)
    # The choice may post back and replace the dropdown: observe the new one.
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(
        lambda current: _selected_text(current, element_id) == value
    )
    return True


def _fill_entry(driver, entry, spec, index, timeout):
    prefix = spec.prefix
    certifier = entry["certifierRegistration"]
    approved_body = entry["approvedBodyRegistration"]
    select_option(driver, prefix + "ddlSchemeType", spec.scheme, spec, timeout)
    texts = (
        (prefix + "txtCertificateNumber", _text(entry["certificateNumber"])),
        (prefix + "txtCertifierRegNo", _text(certifier["number"])),
        (CERTIFIER_DATE_ID, portal_date(entry["certifierSignatureDate"])),
        (prefix + "txtApprovedBodyRegNo", _text(approved_body["number"])),
        (APPROVED_BODY_DATE_ID, portal_date(entry["approvedBodySignatureDate"])),
    )
    set_text(driver, texts[0][0], texts[0][1], timeout)
    select_option(driver, prefix + "ddlCertifierRegNo1", _text(certifier["part1"]), spec, timeout)
    select_option(driver, prefix + "ddlCertifierRegNo2", spec.certifier_part2, spec, timeout)
    set_text(driver, texts[1][0], texts[1][1], timeout)
    set_text(driver, texts[2][0], texts[2][1], timeout)
    select_option(driver, prefix + "ddlApprovedBodyRegNo1", _text(approved_body["part1"]), spec, timeout)
    select_option(driver, prefix + "ddlApprovedBodyRegNo2", spec.approved_body_part2, spec, timeout)
    set_text(driver, texts[3][0], texts[3][1], timeout)
    set_text(driver, texts[4][0], texts[4][1], timeout)
    # A dropdown postback can drop text typed before it: put back anything lost, then insist.
    for element_id, value in texts:
        set_text(driver, element_id, value, timeout)
    lost = [element_id for element_id, value in texts if current_value(driver, element_id) != value]
    if lost:
        raise RuntimeError(
            f"The portal did not keep the details entered for {spec.label} {index}. Review it in the portal."
        )
    try:
        check_certificate_validation(driver, timeout=timeout)
    except CertificateValidationError as exc:
        raise CompletionCertificateValidationError(spec, index, exc.portal_message) from exc
    except RuntimeError as exc:
        raise RuntimeError(
            f"The portal did not confirm the validation result for {spec.label} {index}. "
            "Review it in the portal before retrying; Validation Check was not repeated."
        ) from exc


def fill_register(driver, entries, spec, timeout=30):
    """Enter and validate every entry of one register, in order."""
    validate_entries(entries, spec)
    wait_for_step(driver, spec.prefix + "ddlSchemeType", screen_name=f"{spec.label} details", timeout=timeout)
    current, total = pager(driver, spec)
    if total > len(entries):
        raise RegisterStateError(
            f"The portal already holds {total} {spec.label} entries but this job has {len(entries)}. "
            "Remove the extra entries in the portal, then run it again. Nothing was changed."
        )
    if current != 1:
        click_when_clickable(driver, By.ID, spec.prefix + "btnFirstCertificate", timeout=timeout)
        _wait_for_pager(driver, spec, (1, total), timeout,
                        f"The portal did not return to the first {spec.label}. Review it in the portal.")
    for index, entry in enumerate(entries, start=1):
        if index > 1:
            _current, total = pager(driver, spec)
            if index <= total:
                # A saved entry from an earlier run: step to it and correct it in place.
                click_when_clickable(driver, By.ID, spec.prefix + "btnNextCertificate", timeout=timeout)
                _wait_for_pager(driver, spec, (index, total), timeout,
                                f"The portal did not open {spec.label} {index}. Review it in the portal.")
            else:
                click_when_clickable(driver, By.ID, spec.prefix + "btnAddCertificate", timeout=timeout)
                _wait_for_pager(
                    driver, spec, (index, index), timeout,
                    f"The portal did not confirm the added {spec.label} {index}. "
                    "Review the register in the portal; Add was not repeated.",
                )
        _fill_entry(driver, entry, spec, index, timeout)

"""Navigation for the Completion Certificate wizard.

The shared Next button is never a page marker: after every Next the workflow
waits for a control that only exists on the destination screen, and it never
clicks Next a second time when that control does not appear.
"""

from __future__ import annotations

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable
from automation.completion_certificate.fields import PREFIX

NEXT_BUTTON_ID = PREFIX + "StepNavigationTemplateContainerID_btnNext"
MAIN_DETAILS_BUTTON_ID = "MainContent_FormSections_btnMainDetails"
SUPPORTING_DOCUMENTATION_BUTTON_ID = "MainContent_FormSections_btnSupportingDocumentation"


def _displayed(elements):
    for element in elements:
        try:
            if element.is_displayed():
                return True
        except StaleElementReferenceException:
            continue
    return False


def _visible(driver, element_id):
    """Whether a control is on screen.

    A styled radio button can hide its input and draw the circle on its label,
    so a radio whose label is showing counts as on screen too.
    """
    if _displayed(driver.find_elements(By.ID, element_id)):
        return True
    return bool(driver.find_elements(By.ID, element_id)) and _displayed(
        driver.find_elements(By.XPATH, f"//label[@for='{element_id}']")
    )


def wait_for_step(driver, expected_ids, *, screen_name, timeout=30):
    """Wait for any of ``expected_ids`` to be visible and return the one found."""
    ids = (expected_ids,) if isinstance(expected_ids, str) else tuple(expected_ids)

    def destination(current):
        for element_id in ids:
            if _visible(current, element_id):
                return element_id
        return False

    try:
        return WebDriverWait(driver, timeout, poll_frequency=0.15).until(destination)
    except TimeoutException as exc:
        raise RuntimeError(
            f"The portal did not confirm the {screen_name} screen. "
            "Review the completion certificate in the portal before continuing; Next was not repeated."
        ) from exc


def click_next(driver, *, expected_ids=None, screen_name, timeout=30):
    click_when_clickable(driver, By.ID, NEXT_BUTTON_ID, timeout=timeout)
    if expected_ids:
        return wait_for_step(driver, expected_ids, screen_name=screen_name, timeout=timeout)
    return None


def ensure_step(driver, expected_ids, *, screen_name, inline_timeout=2, timeout=30):
    """Reach a screen or follow-up that may already be showing.

    A Yes/No answer can reveal its follow-up in place or only after Next, and
    the mapping does not record which. Look first; click Next once if needed.
    """
    try:
        return wait_for_step(driver, expected_ids, screen_name=screen_name, timeout=inline_timeout)
    except RuntimeError:
        return click_next(driver, expected_ids=expected_ids, screen_name=screen_name, timeout=timeout)


def open_main_details(driver, timeout=120):
    """From the form's summary page, open Main Details and wait for the wizard."""

    def state(current):
        if _visible(current, NEXT_BUTTON_ID):
            return "wizard"
        if _visible(current, MAIN_DETAILS_BUTTON_ID):
            return "summary"
        return False

    try:
        found = WebDriverWait(driver, timeout, poll_frequency=0.2).until(state)
    except TimeoutException as exc:
        raise RuntimeError(
            "The Completion Certificate form did not open. Review the proposal in the portal before retrying."
        ) from exc
    if found == "summary":
        click_when_clickable(driver, By.ID, MAIN_DETAILS_BUTTON_ID, timeout=15)
        wait_for_step(driver, NEXT_BUTTON_ID, screen_name="Main Details", timeout=30)

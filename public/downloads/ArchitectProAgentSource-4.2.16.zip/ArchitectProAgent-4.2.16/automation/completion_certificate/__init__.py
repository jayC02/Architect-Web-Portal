"""Completion Certificate (Main Details) automation for an existing building warrant."""

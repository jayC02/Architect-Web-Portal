"""Entry helpers for the Completion Certificate wizard.

The portal keeps answers from an earlier run. Every helper here therefore
compares what is already on the page with the reviewed value and only changes
it when it differs, so a rerun steps through saved screens without disturbing
them and still corrects anything that no longer matches.
"""

from __future__ import annotations

from datetime import date
import re

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, get_when_present, type_into, wait_dom_ready

PREFIX = "MainContent_CompletionCertificateAppWizard_"


def portal_date(iso):
    """ISO ``yyyy-mm-dd`` to the portal's ``dd/mm/yyyy``."""
    text = str(iso or "")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        raise ValueError(f"Invalid date: {iso!r}")
    try:
        return date.fromisoformat(text).strftime("%d/%m/%Y")
    except ValueError as exc:
        raise ValueError(f"Invalid date: {iso!r}") from exc


def _same_text(left, right):
    return str(left or "").replace("\r\n", "\n") == str(right or "").replace("\r\n", "\n")


def current_value(driver, element_id):
    return get_when_present(driver, By.ID, element_id).get_attribute("value") or ""


def set_text(driver, element_id, value, timeout=30):
    """Make a text field hold ``value``. Returns True when it had to be changed."""
    desired = str(value or "")
    if _same_text(current_value(driver, element_id), desired):
        return False
    type_into(driver, By.ID, element_id, desired, timeout=timeout)

    def retained(current):
        try:
            return _same_text(current.find_element(By.ID, element_id).get_attribute("value"), desired)
        except (NoSuchElementException, StaleElementReferenceException):
            return False

    WebDriverWait(driver, timeout, poll_frequency=0.15).until(retained)
    return True


def is_selected(driver, radio_id):
    try:
        return bool(driver.find_element(By.ID, radio_id).is_selected())
    except (NoSuchElementException, StaleElementReferenceException):
        return False


def choose(driver, radio_id, timeout=30):
    """Select a radio by clicking its label. Returns True when it had to be changed."""
    get_when_present(driver, By.ID, radio_id, timeout=timeout)
    if is_selected(driver, radio_id):
        return False
    click_when_clickable(driver, By.XPATH, f"//label[@for='{radio_id}']", timeout=timeout)
    wait_dom_ready(driver, timeout)
    # Some answers post back and replace the control: observe the new one.
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda current: is_selected(current, radio_id))
    return True


def choose_yes_no(driver, answer, yes_id, no_id, timeout=30):
    if not isinstance(answer, bool):
        raise ValueError("A reviewed Yes or No answer is required.")
    return choose(driver, yes_id if answer else no_id, timeout=timeout)

"""Completion Certificate workflow entry point.

Signs in, opens the building warrant's existing proposal, opens (or adds) its
Completion Certificate form and completes Main Details. Supporting documents,
the declaration and submission are not part of this workflow: it stops with
the form ready for the architect's review.
"""

from __future__ import annotations

from collections.abc import Mapping

from automation.building_warrant.login import login_to_ebuilding
from automation.common.proposal_creation import BUILDING_WARRANT, ProposalStateStore, SeleniumProposalPortal
from automation.common.runtime import clear_checkpoint, record_checkpoint
from automation.completion_certificate.details import complete_main_details, validate_completion
from automation.completion_certificate.navigation import open_main_details
from automation.completion_certificate.proposal import open_completion_form, open_source_proposal


def main(
    *,
    user_inputs=None,
    password=None,
    driver=None,
    document_mapping=None,          # accepted for the shared workflow signature; this job has no documents
    progress=None,
    cancellation_token=None,
    address_resolution_callback=None,   # unused: the proposal already exists
    applicant_title_resolution_callback=None,
    proposal_selection_callback=None,
    portal=None,
    state_store=None,
    login=login_to_ebuilding,
    timeout=30,
    inline_timeout=2,
):
    def stage(name, status, message):
        if progress:
            progress(name, status, message)
        if cancellation_token:
            cancellation_token.raise_if_cancelled()

    inputs = dict(user_inputs or {})
    completion = inputs.get("Completion")
    # Everything that can be refused is refused before the portal is touched.
    validate_completion(completion)
    if not isinstance(completion, Mapping):
        raise ValueError("Prepare this completion certificate again in Architect Pro.")
    username = str(inputs.get("Email") or "").strip()
    if not username or not password:
        raise RuntimeError("The saved eDevelopment login is missing. Save it in the Agent before running.")
    if driver is None:
        raise RuntimeError("The completion certificate workflow needs the Agent's managed browser.")
    clear_checkpoint()

    stage("login", "running", "Logging in")
    login(driver, username, password)
    record_checkpoint("login_complete", "login", "Signed in to eBuilding Standards.")
    stage("login", "completed", "Logged in")

    stage("proposal", "running", "Finding the warrant proposal")
    portal = portal or SeleniumProposalPortal(driver, BUILDING_WARRANT)
    state_store = state_store or ProposalStateStore()
    reference = open_source_proposal(
        portal, inputs, state_store=state_store, wait_for_user=proposal_selection_callback,
    )
    record_checkpoint("proposal_opened", "proposal", f"Proposal {reference} opened." if reference else "Proposal opened.")
    stage("proposal", "completed", "Proposal opened")

    stage("completion_form", "running", "Opening the completion certificate")
    outcome = open_completion_form(portal)
    open_main_details(driver)
    record_checkpoint("completion_form_opened", "completion_form", f"Completion Certificate form {outcome}.")
    stage("completion_form", "completed", "Completion certificate opened")

    stage("main_details", "running", "Completing main details")
    complete_main_details(
        driver, inputs, completion, applicant_title_resolution_callback,
        timeout=timeout, inline_timeout=inline_timeout,
    )
    stage("main_details", "completed", "Main details completed")
    return None

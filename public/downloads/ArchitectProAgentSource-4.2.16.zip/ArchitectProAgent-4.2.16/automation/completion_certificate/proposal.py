"""Find the building warrant's proposal and open its Completion Certificate form.

Nothing here creates a proposal. The only creating action is adding the
Completion Certificate form to an existing proposal, and that is done once:
if its result is uncertain the run stops, and the next run reuses the form.
"""

from __future__ import annotations

import re

from automation.common.proposal_creation import (
    BUILDING_WARRANT,
    ProposalCreationUncertain,
    SavedProposalNotFoundError,
    _normalise_address_words,
)

COMPLETION_FORM = "Completion Certificate"


class ProposalSelectionRequired(RuntimeError):
    """The proposal could not be identified and nobody is available to choose it."""


class CompletionFormError(RuntimeError):
    """The portal is not in a state the Agent may change. Needs a person to look."""

    confirmation_required = True
    retryable = False


def _contains_words(haystack, needle):
    if not needle:
        return False
    return any(haystack[index:index + len(needle)] == needle for index in range(len(haystack) - len(needle) + 1))


def site_matches(site_address, site_postcode, portal_text):
    """Formatting-insensitive check that the portal page is for this site.

    The first address line must appear as whole words (so 12 is not 112) and
    the postcode must appear, whatever the case, commas or spacing.
    """
    first_line = str(site_address or "").split(",")[0]
    line_words = _normalise_address_words(first_line)
    page_words = _normalise_address_words(portal_text)
    postcode = re.sub(r"\s+", "", str(site_postcode or "")).upper()
    if not postcode:
        match = re.search(r"([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})\s*$", str(site_address or "").upper())
        postcode = "".join(match.groups()) if match else ""
    if not line_words or not postcode:
        return False
    return _contains_words(page_words, line_words) and postcode in re.sub(r"\s+", "", str(portal_text or "").upper())


def portal_summary_address(body_text):
    """Best-effort address shown on the Proposal Summary, for messages only."""
    lines = [line.strip() for line in str(body_text or "").splitlines() if line.strip()]
    for heading in ("Site Location", "Summary"):
        for index, line in enumerate(lines[:-1]):
            if line == heading:
                for candidate in lines[index + 1:index + 4]:
                    if candidate.lower() != "need help":
                        return candidate
    return "an address that could not be read"


def portal_summary_reference(body_text):
    match = re.search(r"Proposal Reference\s*:?\s*(\d+)", str(body_text or ""), re.I)
    return match.group(1) if match else ""


def open_source_proposal(portal, user_inputs, *, state_store, wait_for_user=None):
    """Open the warrant's proposal and return its Proposal Reference.

    Order: the reference this Agent saved; then a single proposal named after
    the site; otherwise the architect opens it in the browser.
    """
    project_id = str(user_inputs.get("Project ID") or "").strip()
    site_address = str(user_inputs.get("Site Address") or "").strip()
    site_postcode = str(user_inputs.get("Site Postcode") or "").strip()

    opened = False
    found_by_name = None
    saved = state_store.find_for_project(project_id, BUILDING_WARRANT, site_address)
    if saved and saved.get("proposalReference"):
        try:
            portal.open_existing_proposal(str(saved["proposalReference"]), str(saved.get("proposalName") or ""))
            opened = True
        except SavedProposalNotFoundError:
            opened = False  # deleted or created on another computer: look for it by name

    if not opened:
        matches = portal.proposals_named(site_address)
        if len(matches) == 1:
            found_by_name = matches[0]
            portal.open_existing_proposal(found_by_name[0], found_by_name[1])
            opened = True

    if not opened:
        if wait_for_user is None:
            raise ProposalSelectionRequired(
                "Architect Pro could not identify this warrant's proposal in My Proposals. "
                "Open the correct proposal in the portal to continue."
            )
        portal.show_proposal_list()
        wait_for_user("Open the correct proposal in My Proposals to continue.")

    portal.wait_for_summary()
    summary = portal.summary_text()
    if not site_matches(site_address, site_postcode, summary):
        raise CompletionFormError(
            f"The open proposal is for {portal_summary_address(summary)}, but this completion certificate is for "
            f"{site_address}. Nothing was changed. Open the correct proposal and run it again."
        )
    reference = portal_summary_reference(summary)
    if reference and (found_by_name or not saved or str(saved.get("proposalReference")) != reference):
        state_store.remember_for_project(
            project_id, BUILDING_WARRANT, site_address, reference, found_by_name[1] if found_by_name else "",
        )
    return reference


def open_completion_form(portal):
    """Open the proposal's single Completion Certificate form, adding it if absent."""
    drafts = portal.draft_form_count(COMPLETION_FORM)
    if drafts > 1:
        raise CompletionFormError(
            f"This proposal has {drafts} Completion Certificate forms. Delete the duplicates in the portal, "
            "leaving one, then run it again."
        )
    if drafts == 1:
        portal.open_draft_form(COMPLETION_FORM)
        return "reused"
    if portal.submitted_forms_include(COMPLETION_FORM):
        raise CompletionFormError(
            "A Completion Certificate has already been submitted for this proposal. Nothing was changed."
        )
    portal.add_standard_form(COMPLETION_FORM)
    if portal.wait_for_draft_form(COMPLETION_FORM) != 1:
        raise ProposalCreationUncertain(
            "Add additional forms",
            "The Completion Certificate form could not be confirmed on the proposal. "
            "Review the proposal in the portal; Add was not repeated.",
            retryable=False,
            confirmation_required=True,
        )
    portal.open_draft_form(COMPLETION_FORM)
    return "created"

# -*- coding: utf-8 -*-
import os
import re

from selenium.common.exceptions import (
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import is_detached_node_error


class DocumentPreparationError(RuntimeError):
    """A known document step failed; keep the raw Selenium/file error in its cause."""

    def __init__(self, operation):
        self.operation = operation
        super().__init__(
            f"Supporting documents stopped while {operation.lower()}. "
            "Review the existing eBuilding Standards draft before continuing."
        )


def safe_document_text(value, limit=500):
    """Only bounded portal messages/filenames go into callbacks, never tracebacks."""
    value = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+", r"\1[REDACTED]", str(value or ""))
    value = re.sub(
        r"(?i)(password|passwd|token|cookie|authorization)(\s*[:=]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)",
        r"\1\2[REDACTED]", value,
    )
    return " ".join(value.split())[:limit]


class DocumentUploadError(DocumentPreparationError):
    """An observed document failure with safe, durable, actionable evidence."""

    def __init__(self, filename, operation, reason_code, reason, *, portal_message="", uploaded_count=0):
        self.operation = operation
        self.filename = safe_document_text(os.path.basename(str(filename).replace("\\", "/")), 255)
        self.reason_code = reason_code
        self.reason = safe_document_text(reason)
        self.portal_message = safe_document_text(portal_message)
        self.uploaded_count = uploaded_count
        message = f"Could not upload '{self.filename}': {self.reason}" if self.filename else f"Document preparation stopped: {self.reason}"
        RuntimeError.__init__(self, message[:500])

    def diagnostic(self):
        return {
            "filename": self.filename,
            "operation": self.operation[:200],
            "reasonCode": self.reason_code,
            "reason": self.reason,
            "portalMessage": self.portal_message or None,
            "uploadedCount": self.uploaded_count,
        }

    def next_action(self, portal_name):
        actions = {
            "DUPLICATE_DOCUMENT": "Compare this file with the document already attached. Keep the correct copy; replace an older revision manually rather than upload another copy.",
            "FILE_TOO_LARGE": "Reduce or split this PDF to meet the size limit stated by the portal, then attach the corrected file.",
            "PDF_PROTECTED": "Export an unprotected PDF from the original document, then attach the corrected file.",
            "FILE_TYPE_REJECTED": "Export the document in a file format accepted by the portal, then attach the corrected file.",
            "TITLE_INVALID": "Correct the document title or description using the portal's stated character and length rules, then save this file.",
            "LOCAL_FILE_MISSING": "Download this document again from Architect Pro and attach it to the existing draft.",
            "PORTAL_CONTROL_UNAVAILABLE": "Check the indicated document field in the portal. The expected control was unavailable; complete this step manually in the existing draft.",
            "UPLOAD_UNCONFIRMED": "Check whether this file is already attached. Upload it only if it is absent; its previous upload outcome could not be confirmed.",
            "PORTAL_VALIDATION_REJECTED": "Correct the fields identified in the portal message, then save this file in the existing draft.",
            "PORTAL_ERROR_UNSPECIFIED": "The portal did not identify the cause. Check whether this file is already attached before trying again. Keep the correct copy; if the same general error persists, complete the document step in the portal or contact portal support.",
        }
        section = "Location Plan" if "location plan" in self.operation.lower() else "Supporting Documents"
        return f"Open {section} in the existing {portal_name} draft. {actions.get(self.reason_code, actions['PORTAL_VALIDATION_REJECTED'])}"[:500]


def rejected_document_error(filename, portal_message, *, operation="Saving supporting document"):
    message = safe_document_text(portal_message)
    lower = message.lower()
    generic = lower.rstrip(" .") == "an issue which requires your attention has occurred on this page"
    if generic:
        code = "PORTAL_ERROR_UNSPECIFIED"
    elif any(word in lower for word in ("already exists", "already been uploaded", "already been attached", "duplicate", "must be unique")):
        code = "DUPLICATE_DOCUMENT"
    elif any(word in lower for word in ("file size", "filesize", "too large", "maximum size", "size limit")):
        code = "FILE_TOO_LARGE"
    elif any(word in lower for word in ("encrypted", "password protected", "password-protected")):
        code = "PDF_PROTECTED"
    elif any(word in lower for word in ("file type", "file format", "extension", "content type")):
        code = "FILE_TYPE_REJECTED"
    elif any(word in lower for word in ("title", "description", "drawing reference")):
        code = "TITLE_INVALID"
    else:
        code = "PORTAL_VALIDATION_REJECTED"
    reason = (f"The portal displayed a general error after Save without identifying the cause: {message}"
              if generic else f"The portal rejected the document: {message}")
    return DocumentUploadError(filename, operation, code, reason[:500], portal_message=message)


def show_browser_completion_toast(driver):
    """
    Inject a small, non-blocking completion toast into the current page.
    Idempotent: if already present, it will not create a duplicate.
    """
    driver.execute_script(
        """
        (function () {
            const existing = document.getElementById('bw-automation-complete-toast');
            if (existing) {
                return;
            }

            const toast = document.createElement('div');
            toast.id = 'bw-automation-complete-toast';
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            toast.style.cssText = [
                'position:fixed',
                'right:16px',
                'bottom:16px',
                'z-index:2147483647',
                'max-width:380px',
                'min-width:280px',
                'padding:12px 14px',
                'border-radius:10px',
                'background:#1f2937',
                'color:#f9fafb',
                'box-shadow:0 10px 26px rgba(0,0,0,0.28)',
                'font-family:Arial, Helvetica, sans-serif',
                'font-size:13px',
                'line-height:1.4',
                'pointer-events:auto',
                'opacity:0',
                'transform:translateY(8px)',
                'transition:opacity .2s ease, transform .2s ease'
            ].join(';');

            const title = document.createElement('div');
            title.textContent = 'Automation complete';
            title.style.cssText = 'font-weight:700;font-size:14px;margin:0 28px 6px 0;';

            const message = document.createElement('div');
            message.textContent = 'Complete any final manual steps here. Then return to the GUI if you want to prepare another application.';
            message.style.cssText = 'margin:0;opacity:0.95;';

            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.textContent = '×';
            closeBtn.setAttribute('aria-label', 'Dismiss notification');
            closeBtn.style.cssText = [
                'position:absolute',
                'top:6px',
                'right:8px',
                'width:22px',
                'height:22px',
                'border:none',
                'border-radius:999px',
                'background:transparent',
                'color:#e5e7eb',
                'cursor:pointer',
                'font-size:16px',
                'line-height:20px',
                'padding:0'
            ].join(';');

            function removeToast() {
                if (!toast || !toast.parentNode) return;
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(8px)';
                window.setTimeout(function () {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 180);
            }

            closeBtn.addEventListener('click', removeToast);

            toast.appendChild(title);
            toast.appendChild(message);
            toast.appendChild(closeBtn);

            document.body.appendChild(toast);

            window.requestAnimationFrame(function () {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });

            window.setTimeout(removeToast, 12000);
        })();
        """
    )


def dismiss_gdpr_modal_if_present(driver, timeout=2):
    """
    Safely closes the GDPR modal if it appears.
    Returns quickly when the modal is not present.
    Safe to call multiple times.
    """
    modal_selector = ".gdprModalWrapper.show"

    try:
        # Fast check first: if modal is not already present/visible, leave immediately.
        modals = driver.find_elements(By.CSS_SELECTOR, modal_selector)
        visible_modals = [m for m in modals if m.is_displayed()]
        if not visible_modals:
            return

        # Modal is present, now handle it properly.
        possible_xpaths = [
            "//button[contains(.,'Accept')]",
            "//button[contains(.,'I Agree')]",
            "//button[contains(.,'Agree')]",
            "//button[contains(.,'OK')]",
            "//a[contains(.,'Accept')]"
        ]

        clicked = False
        for xp in possible_xpaths:
            try:
                btn = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable((By.XPATH, xp))
                )
                btn.click()
                clicked = True
                break
            except Exception:
                continue

        # If we clicked something, wait briefly for the modal to disappear.
        if clicked:
            WebDriverWait(driver, timeout).until(
                EC.invisibility_of_element_located((By.CSS_SELECTOR, modal_selector))
            )
            print("Dismissed GDPR modal.")

    except Exception:
        # Stay non-fatal: this helper should never block the main flow.
        pass


def get_visible_portal_error(driver):
    """Return visible ASP.NET-style validation text if the portal exposes it."""
    if hasattr(driver, "execute_script"):
        try:
            messages = driver.execute_script("""
                return Array.from(window.Page_Validators || []).filter(v => {
                    const control = document.getElementById(v.controltovalidate);
                    return v.isvalid === false && v.enabled !== false && document.contains(v)
                        && (!control || control.getClientRects().length > 0);
                }).map(v => v.errormessage || v.textContent || '').filter(Boolean);
            """)
            if isinstance(messages, list) and messages:
                return " ".join(str(value) for value in messages if value).strip()
        except WebDriverException as exc:
            if not is_detached_node_error(exc):
                raise
    selectors = [
        "#MainContent_validationSummary",
        ".alert-error",
        ".validation-summary-errors",
        ".field-validation-error",
        "[id*='ValidationSummary']",
        "[id*='validationSummary']",
        "[aria-invalid='true'][role='alert']",
        "[role='alert']",
    ]
    messages = []
    for selector in selectors:
        try:
            for element in driver.find_elements(By.CSS_SELECTOR, selector):
                if element.is_displayed():
                    # Alerts also carry success/information notices. These are
                    # not evidence that an upload was rejected.
                    classes = str(element.get_attribute("class") or "").lower() if hasattr(element, "get_attribute") else ""
                    if any(name in classes for name in ("alert-success", "alert-info")):
                        continue
                    text = element.text.strip()
                    if text and text not in messages:
                        messages.append(text)
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    detailed = [message for message in messages if message.lower().rstrip(" .") !=
                "an issue which requires your attention has occurred on this page"]
    return " ".join((detailed or messages)[:10])


def wait_for_supporting_doc_upload_result(
    driver,
    pdf_file,
    timeout=30,
):
    """
    Wait for the supporting-doc upload to either return to the add-document
    state or show an obvious validation error.
    """
    add_doc_ids = (
        "MainContent_SupportingDocumentationWizard_btnAddDocumentation",
        "MainContent_btnAddDocumentation",
    )

    def upload_finished_or_failed(d):
        error_text = get_visible_portal_error(d)
        if error_text:
            return ("error", error_text)
        try:
            # An Add button can coexist with an unsaved editor. It does not
            # establish success until the upload editor has closed.
            for editor_id in ("MainContent_fuAttachFile", "MainContent_SupportingDocumentationWizard_fuAttachFile"):
                if any(element.is_displayed() for element in d.find_elements(By.ID, editor_id)):
                    return False
            for add_doc_id in add_doc_ids:
                add_buttons = d.find_elements(By.ID, add_doc_id)
                for add_btn in add_buttons:
                    if add_btn.is_displayed() and add_btn.is_enabled():
                        return ("ready", add_btn)
        except StaleElementReferenceException:
            return False
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                return False
            raise
        return False

    try:
        result_type, result_value = WebDriverWait(driver, timeout).until(upload_finished_or_failed)
    except TimeoutException as exc:
        error_text = get_visible_portal_error(driver)
        if error_text:
            raise rejected_document_error(pdf_file, error_text) from exc
        raise DocumentUploadError(
            pdf_file, "Waiting for supporting document upload confirmation", "UPLOAD_UNCONFIRMED",
            f"The portal did not return to the saved-document list within {timeout} seconds. The file may already be attached; its upload outcome is unknown.",
        ) from exc
    if result_type == "error":
        raise rejected_document_error(pdf_file, result_value)
    return result_value

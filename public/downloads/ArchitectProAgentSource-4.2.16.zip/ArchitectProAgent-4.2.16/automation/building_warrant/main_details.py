# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, get_when_clickable, type_into


WORK_TYPE_IDS = {
    "Construct": "MainContent_BuildingWarrantAppWizard_W1",
    "Convert": "MainContent_BuildingWarrantAppWizard_W2",
    "Provide Services": "MainContent_BuildingWarrantAppWizard_W3",
    "Demolish": "MainContent_BuildingWarrantAppWizard_W4",
}


def proposed_work_types(user_inputs):
    aliases = {
        "Domestic alteration / extension": "Construct",
        "New build": "Construct",
        "Conversion / change of use": "Convert",
        "Demolition": "Demolish",
    }
    raw = user_inputs.get("Proposed Work Types")
    if raw is None:
        raw = [user_inputs.get("Proposed Work") or "Construct"]
    if not isinstance(raw, (list, tuple)) or not raw:
        raise ValueError("Choose at least one proposed work type before running the warrant.")
    values = list(dict.fromkeys(aliases.get(str(value).strip(), str(value).strip()) for value in raw))
    if any(value not in WORK_TYPE_IDS for value in values):
        raise ValueError("The prepared warrant contains an unrecognised proposed work type.")
    return values


def fill_description_and_proposed_work(driver, user_inputs, timeout=30):
    desc_work = str(user_inputs.get("Description of Work") or "").strip()
    if not desc_work:
        raise ValueError("Description of Work is required before running the warrant.")
    selected = proposed_work_types(user_inputs)
    description_id = "MainContent_BuildingWarrantAppWizard_txtDescWork"
    type_into(driver, By.ID, description_id, desc_work, timeout=timeout)
    WebDriverWait(driver, timeout).until(
        lambda current: current.find_element(By.ID, description_id).get_attribute("value") == desc_work
    )
    print(f"Entered Description of Work: {desc_work}")
    for work_type, element_id in WORK_TYPE_IDS.items():
        wanted = work_type in selected
        field = get_when_clickable(driver, By.ID, element_id, timeout=timeout)
        if field.is_selected() != wanted:
            click_when_clickable(driver, By.XPATH, f"//label[@for='{element_id}']", timeout=timeout)
        WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(
            lambda current, field_id=element_id, checked=wanted:
                current.find_element(By.ID, field_id).is_selected() == checked
        )
    return selected

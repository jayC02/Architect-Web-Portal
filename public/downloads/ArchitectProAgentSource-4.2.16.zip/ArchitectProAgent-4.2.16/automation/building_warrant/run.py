# -*- coding: utf-8 -*-
import os
import time
from decimal import Decimal, InvalidOperation

from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import (
    click_when_clickable,
    click_yes_no_answer,
    get_when_present,
    js_click_by_id,
    select_by_text,
    select_option_by_id,
    set_text_value,
    type_into,
    wait_dom_ready,
    yes_no_answer,
)
from automation.common.documents import (
    extract_title_and_description,
    get_document_type_from_pdf,
    get_paper_size_from_pdf,
    load_supporting_docs_upload_list,
)
from automation.common.driver import create_chrome_driver, get_local_chromedriver_path
from automation.common.forms import normalise_applicant_title, select_applicant_title
from automation.common.runtime import (
    clear_checkpoint,
    CONTINUE_FLAG_FILE,
    record_checkpoint,
    SCRIPT_DIR,
    SUPPORTING_DOCS_JSON,
    USER_INPUTS_JSON,
    load_required_json,
    wait_for_continue,
)
from automation.common.declaration import complete_declaration, open_fee_and_handoff
from automation.common.proposal_creation import BUILDING_WARRANT, create_proposal_and_resume
from automation.common.uploads import (
    DocumentPreparationError,
    DocumentUploadError,
    dismiss_gdpr_modal_if_present,
    get_visible_portal_error,
    wait_for_supporting_doc_upload_result,
)
from automation.building_warrant.agent import fill_agent_details
from automation.building_warrant.applicant import fill_applicant_details
from automation.building_warrant.login import login_to_ebuilding
from automation.building_warrant.main_details import fill_description_and_proposed_work, proposed_work_types
from automation.building_warrant.navigation import (
    click_next,
    ensure_follow_up,
    wait_for_form_summary_then_open_main_details,
)
from automation.building_warrant.certificates import fill_design_certificate, validate_design_certificate
from automation.building_warrant.follow_ups import validate_follow_ups, fill_conversion_descriptions, fill_demolition_period, fill_construction_certificate, fill_text_follow_up
from automation.building_warrant.relaxation import fill_relaxation_directions, relaxation_directions
from automation.building_warrant.owner import fill_owner_details, validate_owner
from automation.building_warrant.sustainability import complete_sustainability, validate_sustainability, enter_verified_text
from automation.building_warrant.fee import (
    enter_calculated_fee,
    require_calculated_fee_minor_units,
)


########################################################################
# Main Script
########################################################################

def main(
    *,
    user_inputs=None,
    password=None,
    driver=None,
    document_mapping=None,
    progress=None,
    cancellation_token=None,
    address_resolution_callback=None,
    applicant_title_resolution_callback=None,
):
    def stage(name, status, message):
        if progress:
            progress(name, status, message)
        if cancellation_token:
            cancellation_token.raise_if_cancelled()

    document_operation = None
    confirmed_document_count = 0

    def document_step(operation):
        nonlocal document_operation
        document_operation = operation
        stage("documents", "running", operation)

    clear_checkpoint()
    # -----------------------------------------------------
    # A) Load user inputs from JSON (written by the GUI)
    # -----------------------------------------------------
    if user_inputs is None:
        user_inputs = load_required_json(
            USER_INPUTS_JSON,
            required_keys=["Email", "PDF Folder Path"]
        )

    # Unpack relevant fields
    username             = user_inputs.get("Email", "")
    password             = password if password is not None else os.environ.get("BUILDING_PORTAL_RUNTIME_PASSWORD", "")
    proposed_use         = str(user_inputs.get("Proposed Use") or "").strip()
    current_use          = str(user_inputs.get("Current Use") or "").strip()
    estimated_work_value = str(user_inputs.get("Estimated Work Value") or "").strip()
    pdf_folder_path      = user_inputs.get("PDF Folder Path", "")
    calculated_fee_minor_units = require_calculated_fee_minor_units(user_inputs)
    try:
        estimated_value = Decimal(estimated_work_value)
    except InvalidOperation as exc:
        raise ValueError("Enter the estimated value of work in Architect Pro before running the warrant.") from exc
    if not estimated_value.is_finite() or estimated_value <= 0:
        raise ValueError("Enter an estimated value of work greater than zero before running the warrant.")
    description = str(user_inputs.get("Description of Work") or "").strip()
    if not description:
        raise ValueError("Description of Work is required before running the warrant.")
    proposed_work_types(user_inputs)
    if yes_no_answer(user_inputs, "Declaration Authorised", "No") != "Yes":
        raise ValueError("Review the information and authorise the portal declaration in Architect Pro before running this warrant.")
    validate_design_certificate(user_inputs)
    validate_follow_ups(user_inputs)
    if yes_no_answer(user_inputs, "Work Started", "No") == "Yes":
        raise ValueError("Prepare this warrant again in Architect Pro to apply Work started = No and recalculate its fee.")
    validate_owner(user_inputs)
    validate_sustainability(user_inputs)
    for answer_key, field, limit, default in (
        ("Fire Rescue Enforcing Authority", "Fire Authority Name", 20, "Yes"),
        ("Other Historical Importance", "Historical Building Details", 750, "No"),
        ("Dangerous Building Notice", "Dangerous Building References", 750, "No"),
    ):
        answer = yes_no_answer(user_inputs, answer_key, default)
        required = answer == ("No" if answer_key == "Fire Rescue Enforcing Authority" else "Yes")
        if required:
            value = str(user_inputs.get(field) or "").strip()
            if not value or len(value) > limit:
                raise ValueError(f"Complete {field} in Architect Pro (maximum {limit} characters) before running this warrant.")
    relaxation_directions(user_inputs)
    for fixed_key in ("Application Staged", "Limited Life Building", "Public Inspection Restricted"):
        if yes_no_answer(user_inputs, fixed_key, "No") != "No":
            raise ValueError(f"Prepare this warrant again in Architect Pro to apply {fixed_key} = No.")

    if not username or not password:
        raise RuntimeError("Email or runtime password is missing.")
    if not pdf_folder_path or not os.path.isdir(pdf_folder_path):
        raise RuntimeError(f"Invalid PDF folder path in user_inputs.json: '{pdf_folder_path}'")
        
    upload_entries, location_plan_file, effective_pdf_folder, bucket_labels = load_supporting_docs_upload_list(pdf_folder_path, mapping_data=document_mapping)

    if not location_plan_file:
        raise FileNotFoundError("No Location Plan PDF found in the 'Location Plan' bucket.")

    location_plan_path = os.path.join(effective_pdf_folder, location_plan_file)
    if not os.path.exists(location_plan_path):
        raise FileNotFoundError(f"Location Plan PDF not found on disk: {location_plan_path}")

    print(f"Location plan chosen: {location_plan_path}")
    
    location_plan_paper_size = get_paper_size_from_pdf(location_plan_path)
    location_plan_doc_type   = "OS Extract"
    print("Location plan detected:", location_plan_paper_size, location_plan_doc_type)

    # -----------------------------------------------------
    # B) Initialize WebDriver
    # -----------------------------------------------------
    chrome_options = webdriver.ChromeOptions()

    # ✅ Keep Chrome open after the script finishes
    chrome_options.add_experimental_option("detach", True)
    # Conservative startup optimisations (no behavioural flow changes).
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--no-first-run")
    chrome_options.add_argument("--disable-notifications")

    if driver is None:
        driver = create_chrome_driver(chrome_options)
        driver.maximize_window()
        print("Initialized Chrome WebDriver.")

    try:
        # -------------------------------------------------
        # Step 0: Open main page, log in with user’s creds
        # -------------------------------------------------
        stage("login", "running", "Logging in")
        login_to_ebuilding(driver, username, password)
        record_checkpoint("login_complete", "login", "Signed in to eBuilding Standards.")
        stage("login", "completed", "Logged in")

        stage("proposal", "running", "Opening proposal")
        create_proposal_and_resume(
            driver,
            user_inputs,
            lambda: wait_for_form_summary_then_open_main_details(driver, timeout=120),
            application_type=BUILDING_WARRANT,
            address_resolver=address_resolution_callback,
        )
        record_checkpoint("application_selected", "main_details", "Building Warrant application selected.")
        stage("proposal", "completed", "Proposal opened")
        stage("main_details", "running", "Completing application details")

        print("Attempting to click 'Next' on the Main Details page...")
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbWorkCompletedNo", screen_name="work completed")
        print("Clicked 'Next' on Main Details.")

        # ----------------------------------------------------------------
        # Steps 10… (Detailed yes/no and text filling)
        # ----------------------------------------------------------------

        # Step 10: Tick "No" for 'Work Completed'
        print("Ticking 'No' for 'Work Completed'.")
        no_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_rbWorkCompletedNo']"))
        )
        no_radio_label.click()

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbWorkStartedNo", screen_name="work started")
        print("Confirmed 'No' for Work Completed. Next clicked.")

        # The fee and the portal answer must use the same saved work-started value.
        click_yes_no_answer(
            driver, {"Work Started": "No"}, "Work Started",
            "MainContent_BuildingWarrantAppWizard_rbWorkStartedYes",
            "MainContent_BuildingWarrantAppWizard_rbWorkStartedNo", default="No",
        )

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_ApplicantOrAgent_rbAgent", screen_name="applicant or agent")

        # Step 12: Select 'Agent'
        print("Selecting 'Agent' radio button.")
        agent_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_ApplicantOrAgent_rbAgent']"))
        )
        agent_radio_label.click()

        # Step 13: Use Registered Account details => Yes
        print("Selecting 'Registered Account' radio button.")
        registered_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_ApplicantOrAgent_rbAccountYes']"))
        )
        registered_radio_label.click()

        # Next
        click_next(driver, timeout=30, expected_ids="MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentFirstName", screen_name="agent details")
        
        fill_agent_details(driver, user_inputs)
        record_checkpoint("agent_complete", "agent_details")

        # Step 14: Another 'Next' (skipping some manual step)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantFirstName", screen_name="applicant details")
        print("Clicked 'Next' again.")
        
        fill_applicant_details(driver, user_inputs, applicant_title_resolution_callback)
        record_checkpoint("applicant_complete", "applicant_details")

        # Step 14: Another 'Next' (skipping some manual step)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbApplicantOwnerYes", screen_name="applicant ownership")
        print("Clicked 'Next' again.")        
        
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerYes"))
)
        # Step 15: "Are you the applicant owner?"
        applicant_owner = click_yes_no_answer(
            driver,
            user_inputs,
            "Applicant Is Owner",
            "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerYes",
            "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerNo",
            default="Yes",
        )

        if applicant_owner == "No":
            ensure_follow_up(driver, "MainContent_BuildingWarrantAppWizard_OwnerDetails_ddlOwnerTitle", screen_name="property owner details")
            fill_owner_details(driver, user_inputs)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbIncludeConstructionYes", screen_name="construction work")

        # Step 16: "Include Construction?"
        include_construction = click_yes_no_answer(
            driver,
            user_inputs,
            "Includes New Building Or Extension",
            "MainContent_BuildingWarrantAppWizard_rbIncludeConstructionYes",
            "MainContent_BuildingWarrantAppWizard_rbIncludeConstructionNo",
            default="Yes",
        )

        # Next
        click_next(driver, expected_ids=("MainContent_BuildingWarrantAppWizard_txtProposedUse" if include_construction == "Yes" else "MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingYes"), screen_name="proposed use" if include_construction == "Yes" else "existing building work")

        if include_construction == "Yes":
            # Step 17: Proposed Use (from JSON)
            print("Entering the reviewed description for construction work.")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtProposedUse", description)

            # Next
            click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingYes", screen_name="existing building work")

        # Step 18: "Work to existing building?"
        existing_work = click_yes_no_answer(
            driver,
            user_inputs,
            "Includes Existing Building Work",
            "MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingNo",
            default="Yes",
        )

        # Next
        destination = click_next(driver, expected_ids=("MainContent_BuildingWarrantAppWizard_txtCurrentUse", "MainContent_BuildingWarrantAppWizard_rbConversionRegsYes", "MainContent_BuildingWarrantAppWizard_txtDescWork", "MainContent_BuildingWarrantAppWizard_W1"), screen_name="existing use or proposed work")

        if existing_work == "Yes":
            # Step 19: Current Use
            print(f"Entering Current Use: {current_use}")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtCurrentUse", current_use)

            # Step 20: Proposed Use (Existing)
            print(f"Entering Proposed Use (Existing) same as Proposed Use: {proposed_use}")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtProposedUseExisting", proposed_use)

            # Next
            destination = click_next(driver, expected_ids=("MainContent_BuildingWarrantAppWizard_rbConversionRegsYes", "MainContent_BuildingWarrantAppWizard_txtDescWork", "MainContent_BuildingWarrantAppWizard_W1"), screen_name="conversion or proposed work")

        # Step 21: Conversion Regs
        if destination == "MainContent_BuildingWarrantAppWizard_rbConversionRegsYes":
            conversion = click_yes_no_answer(
                driver,
                user_inputs,
                "Conversion Regulations",
                "MainContent_BuildingWarrantAppWizard_rbConversionRegsYes",
                "MainContent_BuildingWarrantAppWizard_rbConversionRegsNo",
                default="No",
            )
            if conversion == "Yes":
                fill_conversion_descriptions(driver, user_inputs)
            click_next(driver, expected_ids=("MainContent_BuildingWarrantAppWizard_txtDescWork", "MainContent_BuildingWarrantAppWizard_W1"), screen_name="proposed work")
        elif yes_no_answer(user_inputs, "Conversion Regulations", "No") == "Yes":
            raise RuntimeError("The portal skipped the conversion question for a warrant containing conversion work. Review the current draft.")

        fill_description_and_proposed_work(driver, user_inputs)

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbApplicationStagedYes", screen_name="staged application")

        # Step 23: "Application to be staged?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Application Staged",
            "MainContent_BuildingWarrantAppWizard_rbApplicationStagedYes",
            "MainContent_BuildingWarrantAppWizard_rbApplicationStagedNo",
            default="No",
        )

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbDemolitionOfBuildingYes", screen_name="demolition")

        # Step 24: "Demolition?"
        demolition = click_yes_no_answer(
            driver,
            user_inputs,
            "Includes Demolition",
            "MainContent_BuildingWarrantAppWizard_rbDemolitionOfBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbDemolitionOfBuildingNo",
            default="No",
        )

        if demolition == "Yes":
            fill_demolition_period(driver, user_inputs)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbIntendedLifeYes", screen_name="intended life")

        # Step 25: "Limited Life Building?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Limited Life Building",
            "MainContent_BuildingWarrantAppWizard_rbIntendedLifeYes",
            "MainContent_BuildingWarrantAppWizard_rbIntendedLifeNo",
            default="No",
        )

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbUnderFireRescueYes", screen_name="Fire and Rescue authority")

        # Step 26: "Under Fire Authority?"
        fire_authority = click_yes_no_answer(
            driver,
            user_inputs,
            "Fire Rescue Enforcing Authority",
            "MainContent_BuildingWarrantAppWizard_rbUnderFireRescueYes",
            "MainContent_BuildingWarrantAppWizard_rbUnderFireRescueNo",
            default="Yes",
        )

        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_txtFireAuthority" if fire_authority == "No" else "MainContent_BuildingWarrantAppWizard_rbListedBuildingYes", screen_name="fire-authority name" if fire_authority == "No" else "listed building or conservation area")
        if fire_authority == "No":
            enter_verified_text(driver, "txtFireAuthority", str(user_inputs["Fire Authority Name"]).strip())
            click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbListedBuildingYes", screen_name="listed building or conservation area")

        # Step 27: "Listed Building?"
        listed = click_yes_no_answer(
            driver,
            user_inputs,
            "Listed Or Conservation Area",
            "MainContent_BuildingWarrantAppWizard_rbListedBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbListedBuildingNo",
            default="No",
        )

        if listed == "Yes":
            fill_text_follow_up(driver, "txtListedBuildingCategory", "listed", str(user_inputs["Listing Category"]).strip(), "listing category")
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbHistoricalYes", screen_name="historical importance")

        # Step 28: "Historical Building?"
        historical = click_yes_no_answer(
            driver,
            user_inputs,
            "Other Historical Importance",
            "MainContent_BuildingWarrantAppWizard_rbHistoricalYes",
            "MainContent_BuildingWarrantAppWizard_rbHistoricalNo",
            default="No",
        )

        # Next
        if historical == "Yes":
            ensure_follow_up(driver, "MainContent_BuildingWarrantAppWizard_txtHistoricalBuildingDetails", screen_name="historical-importance details")
            enter_verified_text(driver, "txtHistoricalBuildingDetails", str(user_inputs["Historical Building Details"]).strip())
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbRelaxationDirectionYes", screen_name="relaxation directions")

        # Step 29: "Relaxation Direction?"
        relaxation = click_yes_no_answer(
            driver,
            user_inputs,
            "Relaxation Direction",
            "MainContent_BuildingWarrantAppWizard_rbRelaxationDirectionYes",
            "MainContent_BuildingWarrantAppWizard_rbRelaxationDirectionNo",
            default="No",
        )

        # Next
        if relaxation == "Yes":
            fill_relaxation_directions(driver, user_inputs)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_txtBuildingRegComplianceNotice", screen_name="building notices")

        for notice_id in (
            "txtBuildingRegComplianceNotice", "txtBuildingWarrantEnforcementNotice", "txtDefectiveBuildingsNotice",
        ):
            type_into(driver, By.ID, f"MainContent_BuildingWarrantAppWizard_{notice_id}", "N/A")

        # Step 33: "Dangerous Building?"
        dangerous = click_yes_no_answer(
            driver,
            user_inputs,
            "Dangerous Building Notice",
            "MainContent_BuildingWarrantAppWizard_rbDangerousBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbDangerousBuildingNo",
            default="No",
        )

        # Next
        if dangerous == "Yes":
            ensure_follow_up(driver, "MainContent_BuildingWarrantAppWizard_txtDangerousBuildingRefNum", screen_name="dangerous-building references")
            enter_verified_text(driver, "txtDangerousBuildingRefNum", str(user_inputs["Dangerous Building References"]).strip())
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_txtEstimatedValue", screen_name="estimated value")

        # Step 34: "Estimated Work Value" => from JSON
        print(f"Entering Estimated Work Value: {estimated_work_value}")
        type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtEstimatedValue", estimated_work_value)
        WebDriverWait(driver, 30).until(
            lambda current: current.find_element(By.ID, "MainContent_BuildingWarrantAppWizard_txtEstimatedValue").get_attribute("value") == estimated_work_value
        )

        # Next
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_CertificatesRegisterQuestion_rbCertificatesAccompanyNo", screen_name="design certificate")

        # Step 35: "Certificates of Design?"
        cert_design_answer = click_yes_no_answer(
            driver,
            user_inputs,
            "Approved Certifier Design",
            "MainContent_BuildingWarrantAppWizard_CertificatesRegisterQuestion_rbCertificatesAccompanyYes",
            "MainContent_BuildingWarrantAppWizard_CertificatesRegisterQuestion_rbCertificatesAccompanyNo",
            default="No",
        )

        # Next
        click_next(driver, expected_ids=("MainContent_BuildingWarrantAppWizard_rbUploadCertificateOfDesignWithApplicationNo" if cert_design_answer == "Yes" else "MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyNo"), screen_name="design certificate timing" if cert_design_answer == "Yes" else "construction certificate")

        if cert_design_answer == "Yes":
            fill_design_certificate(driver, user_inputs)
            click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyNo", screen_name="construction certificate")
        else:
            print("Approved Certifier Design is No. Skipping design certificate details.")
        
        # "Certificates of Construction?"
        construction_certificate = click_yes_no_answer(
            driver,
            user_inputs,
            "Approved Certifier Construction",
            "MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyYes",
            "MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyNo",
            default="No",
        )

        if construction_certificate == "Yes":
            fill_construction_certificate(driver, user_inputs)
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbNewBuildingConstructionNo", screen_name="new building construction")

        complete_sustainability(driver, user_inputs)

        # Step 39: "STAS?"
        stas = click_yes_no_answer(
            driver,
            user_inputs,
            "STAS",
            "MainContent_BuildingWarrantAppWizard_rbSTASYes",
            "MainContent_BuildingWarrantAppWizard_rbSTASNo",
            default="No",
        )

        if stas == "Yes":
            fill_text_follow_up(driver, "txtSTAS", "STAS approval reference", str(user_inputs["STAS Reference"]).strip(), "STAS approval reference")
        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_rbPublicInspectionNo", screen_name="public inspection")

        # Step 40: Public inspection restriction
        click_yes_no_answer(
            driver,
            user_inputs,
            "Public Inspection Restricted",
            "MainContent_BuildingWarrantAppWizard_rbPublicInspectionYes",
            "MainContent_BuildingWarrantAppWizard_rbPublicInspectionNo",
            default="No",
        )

        click_next(driver, expected_ids="MainContent_BuildingWarrantAppWizard_FinishNavigationTemplateContainerID_btnNext", screen_name="Main Details finish")

        # Step 41: Next => Main Details Complete
        final_next_main = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_FinishNavigationTemplateContainerID_btnNext"))
        )
        final_next_main.click()

        # Step 42: Email Notification => Click
        email_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnEmailNotification"))
        )
        email_button.click()
        print("Clicked Email Notification button.")
        record_checkpoint("main_details_complete", "main_details")
        stage("main_details", "completed", "Application details complete")
        stage("documents", "running", "Uploading supporting documents")

        document_step("Confirming document email notifications")
        # Step 43: "No" for Email? or Uncheck? Adapt as needed:
        email_checkbox = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "MainContent_cbUseEmail"))
        )
        if email_checkbox.is_selected():
            click_when_clickable(driver, By.XPATH, "//label[@for='MainContent_cbUseEmail']")
        WebDriverWait(driver, 30).until(lambda current: not current.find_element(By.ID, "MainContent_cbUseEmail").is_selected())

        confirm_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_btnConfirm"))
        )
        confirm_button.click()
        print("Confirmed email choice.")

        # Step 44: Checklist
        document_step("Completing the document checklist")
        checklist_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnChecklist"))
        )
        checklist_button.click()
        print("Clicked Checklist button.")

        checklist_answers = {
            "BlockLocation": bool(location_plan_file),
            "SupportingDocs": bool(upload_entries),
            # This checklist acknowledgement records the confirmed notification
            # section above, rather than opting into notifications a second time.
            "EmailNotification": checklist_button.is_displayed(),
        }
        for question, answer in checklist_answers.items():
            click_yes_no_answer(
                driver, {question: answer}, question,
                f"MainContent_BuildingWarrantChecklistWizard_rb{question}Yes",
                f"MainContent_BuildingWarrantChecklistWizard_rb{question}No",
            )

        # Next
        checklist_next = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantChecklistWizard_StepNavigationTemplateContainerID_btnNext"))
        )
        checklist_next.click()

        # Finish the Checklist wizard (next button)
        checklist_finish = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantChecklistWizard_FinishNavigationTemplateContainerID_btnNext"))
        )
        checklist_finish.click()
        record_checkpoint("document_checklist_complete", "checklist")
        
        if upload_entries:
             # Click supporting documentation button
            document_step("Opening supporting documents")
            supporting_next = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnSupportingDocumentation"))
            )
            supporting_next.click()
        
            #Select Yes fir supporting documentation
            yes_radio_label = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbYes']"))
            )
            yes_radio_label.click()
            print("Selected Yes for supporting documents.")

            # Select continue for supporting documentation
            supporting_yes_next = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnContinueOptions"))
            )
            supporting_yes_next.click()
        
            # Select continue for supporting documentation
            add_doc = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAddDocumentation"))
            )
            add_doc.click()
        
            #Select Yes fir supporting documentation
            upload_radio_label = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbUploaded']"))
            )
            upload_radio_label.click()
        
            # Select continue for supporting documentation
            attach_yes_next = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAttachmentContinue"))
            )
            attach_yes_next.click()
    
            # Keep the job's validated document list. The portal adapter supplies it
            # in memory and never writes the legacy supporting_docs.json file.

            for pdf_file, bucket_key in upload_entries:
                document_step("Entering supporting document details")
                attach_path = os.path.join(effective_pdf_folder, pdf_file)
                print(f"Uploading supporting document '{pdf_file}' from category '{bucket_key}'.")

                # Title (keep your existing logic if you want)
                base_no_ext = os.path.splitext(os.path.basename(pdf_file))[0]

                if bucket_key != "other":
                    # Description comes directly from bucket
                    description = bucket_labels.get(bucket_key, bucket_key)
                else:
                    # Only infer for "other"
                    _, description = extract_title_and_description(pdf_file, attach_path)

                title = base_no_ext

                type_into(driver, By.ID, "MainContent_SupportingDocumentationWizard_edtUniqueDrawingReferenceNumber", title)

                type_into(driver, By.ID, "MainContent_SupportingDocumentationWizard_edtDescription", description)

                # Paper Size
                paper_size = get_paper_size_from_pdf(attach_path)
                select_by_text(driver, By.ID, "MainContent_SupportingDocumentationWizard_lbPaperSize", paper_size)

                # Doc Type
                doc_type = get_document_type_from_pdf(attach_path)
                select_by_text(driver, By.ID, "MainContent_SupportingDocumentationWizard_lbDocumentType", doc_type)

                # Attach
                attach_input = WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located((By.ID, "MainContent_SupportingDocumentationWizard_fuAttachFile"))
                )
                attach_input.send_keys(attach_path)

                # "Read and Understood" if required
                try:
                    read_label = WebDriverWait(driver, 20).until(
                        EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbReadAndUnderstood']"))
                    )
                    read_label.click()
                except Exception:
                    pass

                # Upload
                document_step("Waiting for supporting document upload confirmation")
                upload_btn = WebDriverWait(driver, 30).until(
                    EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnSaveDocEdit"))
                )
                upload_btn.click()
                wait_for_supporting_doc_upload_result(driver, pdf_file, timeout=30)
                confirmed_document_count += 1
                print(f"Uploaded '{pdf_file}' successfully.")
            
                #Add documentation
                document_step("Opening the next supporting document")
                click_when_clickable(
                    driver,
                    By.ID,
                    "MainContent_SupportingDocumentationWizard_btnAddDocumentation"
                )
            
                #Upload Yes
                upload_radio_label = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbUploaded']"))
                )
                upload_radio_label.click()
            
                # Select continue for supporting documentation
                attach_yes_next = WebDriverWait(driver, 30).until(
                    EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAttachmentContinue"))
                )
                attach_yes_next.click()
            
                # Wait for page to refresh
                WebDriverWait(driver, 30).until(
                    EC.url_to_be("https://www.ebuildingstandards.scot/eBuildingStandardsClient/CustomPages/Applications/SupportingDocumentation.aspx")
                )

            print("All PDFs uploaded. Automation steps complete.")
            record_checkpoint("supporting_documents_uploaded", "supporting_documents")
            print("Supporting documents confirmed. Continuing with the location plan and authorised declaration.")
        
            # Cancel
            document_step("Saving the supporting documents section")
            cancel_btn = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnCancelDocEdit"))
            )
            cancel_btn.click()
        
            # Scroll down so buttons become visible
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

            # Finish documentation section
            addmore_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbFinished']"))
            )
            addmore_radio_label.click()

            # Click "Save" button
            save_button = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnDocSave"))
            )
            save_button.click()
            print("💾 Saved and exited documentation section.")
        
        else:
            document_step("Confirming no additional supporting documents")
            supporting_section = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnSupportingDocumentation"))
            )
            supporting_section.click()
            click_yes_no_answer(
                driver, {"Supporting Documents": False}, "Supporting Documents",
                "MainContent_SupportingDocumentationWizard_rbYes",
                "MainContent_SupportingDocumentationWizard_rbNo",
            )
            click_when_clickable(driver, By.ID, "MainContent_SupportingDocumentationWizard_btnContinueOptions")
            WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnBlock/LocationPlan"))
            )
            record_checkpoint("supporting_documents_not_required", "supporting_documents")

        # Enter into the "Block/Location Plan" section
        document_step("Opening the location plan section")
        dismiss_gdpr_modal_if_present(driver)
        wait_dom_ready(driver)

        print("Clicking Block/Location Plan...")
        js_click_by_id(driver, "MainContent_FormSections_btnBlock/LocationPlan", timeout=30)
        print("Clicked Block/Location Plan.")

        # Click the "Attach Location plan" option
        location_plan_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_rbAttachBlockPlan']"))
        )
        location_plan_label.click()

        # Click the "Continue" button
        continue_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnContinueAddBlockPlan"))
        )
        continue_button.click()

        #Click uploaded location plan option
        location_plan_label_uploaded = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_rbUploaded']"))
        )
        location_plan_label_uploaded.click()

        continue_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnContinueBlockPlanOptions"))
        )
        continue_button.click()

        # Upload the Location Plan file
        file_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file']"))
        )

        # In case it's hidden/overlaid
        driver.execute_script(
            "arguments[0].style.display='block'; arguments[0].style.visibility='visible';",
            file_input
        )

        file_input.send_keys(location_plan_path)
        print("Location Plan file selected in file input.")
        
        # Paper size
        paper_size_dropdown = Select(WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_ddlPaperSizeUploadBlockPlan"))
        ))
        paper_size_dropdown.select_by_visible_text(location_plan_paper_size)

        # Doc type
        doc_type_dropdown = Select(WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_ddlDocTypeUploadBlockPlan"))
        ))
        doc_type_dropdown.select_by_visible_text(location_plan_doc_type)


        annotated_checkbox = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_cbFileAnnotated']"))
        )
        annotated_checkbox.click()

        upload_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnUploadUploadBlockPlan"))
        )
        document_step("Waiting for location plan upload confirmation")
        upload_button.click()

        confirm_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnConfirmSavedBlockPlan"))
        )
        confirm_button.click()
        record_checkpoint("location_plan_uploaded", "location_plan")
        stage("documents", "completed", "Documents uploaded")
        document_operation = None
        
        stage("declaration", "running", "Completing declaration")
        complete_declaration(
            driver,
            BUILDING_WARRANT,
            user_inputs=user_inputs,
            progress=progress,
        )
        stage("declaration", "completed", "Declaration completed")
        record_checkpoint("declaration_complete", "declaration")
        stage("final_review", "running", "Finalising application")
        # complete_declaration only returns after the Form Summary controls have
        # been reacquired following the final ASP.NET postback.
        fee_handoff = open_fee_and_handoff(
            driver,
            BUILDING_WARRANT,
            declaration_complete=True,
            progress=progress,
        )
        enter_calculated_fee(driver, calculated_fee_minor_units)
        stage("final_review", "completed", "Calculated application fee confirmed")
        record_checkpoint("application_prepared", "final_review")
        print("Building Warrant automated preparation complete on the fee page.")
        return fee_handoff
        


    except Exception as e:
        print("ERROR encountered:", repr(e), flush=True)
        if cancellation_token and cancellation_token.cancelled:
            cancellation_token.raise_if_cancelled()
        if isinstance(e, DocumentUploadError):
            e.uploaded_count = confirmed_document_count
        if document_operation and not isinstance(e, DocumentPreparationError):
            raise DocumentPreparationError(document_operation) from e
        raise

# Standard Python entrypoint
if __name__ == "__main__":
    main()

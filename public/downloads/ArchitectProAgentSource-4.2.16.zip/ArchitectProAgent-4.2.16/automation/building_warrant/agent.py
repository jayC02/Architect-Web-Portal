# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, get_when_present, type_into


def fill_agent_details(driver, user_inputs, prefix="MainContent_BuildingWarrantAppWizard_"):
    """Fill the Agent Details screen. ``prefix`` selects the portal wizard."""
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located(
            (By.ID, prefix + "AgentDetails_txtAgentFirstName")
        )
    )

    click_when_clickable(
        driver,
        By.ID,
        prefix + "StepNavigationTemplateContainerID_btnClearPage",
        timeout=10,
    )

    agent_field_ids = {
        "Agent First Name": prefix + "AgentDetails_txtAgentFirstName",
        "Agent Last Name": prefix + "AgentDetails_txtAgentSurname",
        "Agent Telephone Number": prefix + "AgentDetails_txtAgentTelNo",
        "Agent Email Address": prefix + "AgentDetails_txtAgentEmailAddress",
        "Agent Building Number": prefix + "AgentDetails_txtAgentBuildingNo",
        "Agent Address 1": prefix + "AgentDetails_txtAgentAddress1",
        "Agent Town/City": prefix + "AgentDetails_txtAgentTown",
        "Agent Country": prefix + "AgentDetails_txtAgentCountry",
        "Agent Postcode": prefix + "AgentDetails_txtAgentPostcode",
    }

    for field, element_id in agent_field_ids.items():
        try:
            value = user_inputs.get(field, "")
            if value.strip():
                type_into(driver, By.ID, element_id, value.strip())
                print(f"Filled: {field}")
            else:
                get_when_present(driver, By.ID, element_id)
                print(f"Skipping {field} (blank value)")
        except Exception as e:
            print(f"Could not locate Agent field '{field}': {str(e)}")

    print("Selecting 'Yes' for 'Applicant is owner'.")
    applicant_owner_label = WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable(
            (
                By.XPATH,
                f"//label[@for='{prefix}AgentDetails_rblIndividualOrOrganisation_0']",
            )
        )
    )
    applicant_owner_label.click()

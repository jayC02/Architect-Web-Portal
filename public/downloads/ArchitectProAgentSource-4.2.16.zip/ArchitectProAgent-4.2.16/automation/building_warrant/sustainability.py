"""Captured new-building screens, including separate domestic/non-domestic grids."""
from collections.abc import Mapping

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, click_yes_no_answer, type_into, yes_no_answer
from automation.building_warrant.navigation import click_next

PREFIX = "MainContent_BuildingWarrantAppWizard_"
LEVEL_IDS = {
    "bronze_active": "bronzeActiveCheckBox", "silver": "silverCheckBox",
    "silver_active": "silverActiveCheckBox", "gold": "goldActiveCheckBox", "platinum": "platinumActiveCheckBox",
}


def validate_sustainability(user_inputs):
    if yes_no_answer(user_inputs, "New Building Construction", "No") != "Yes":
        return {}
    answers = user_inputs.get("Sustainability")
    if not isinstance(answers, Mapping) or type(answers.get("higherLevels")) is not bool:
        raise ValueError("Confirm higher levels of sustainability in Architect Pro before running this new-building warrant.")
    if not answers["higherLevels"]:
        return answers
    for key in ("multipleBuildings", "domesticUse", "nonDomesticUse"):
        if type(answers.get(key)) is not bool:
            raise ValueError(f"Complete the sustainability {key} answer in Architect Pro before running this warrant.")
    if answers["multipleBuildings"]:
        count = answers.get("buildingCount")
        if type(count) is not int or not 2 <= count <= 2147483647:
            raise ValueError("Enter a whole sustainability building count of at least two in Architect Pro.")
    if not (answers["domesticUse"] or answers["nonDomesticUse"]):
        raise ValueError("Select domestic use, non-domestic use, or both for sustainability in Architect Pro.")
    for use, levels in (("domesticUse", "domesticLevels"), ("nonDomesticUse", "nonDomesticLevels")):
        if not answers[use]:
            continue
        selections = answers.get(levels)
        if not isinstance(selections, (list, tuple)) or len(selections) != 8:
            raise ValueError(f"Choose all eight {levels} sustainability levels in Architect Pro.")
        for row, level in enumerate(selections):
            if level not in (LEVEL_IDS if row == 0 else ("silver", "gold")):
                raise ValueError(f"Choose a valid {levels} sustainability level for aspect {row + 1} in Architect Pro.")
    return answers


def enter_verified_text(driver, suffix, value):
    element_id = PREFIX + suffix
    type_into(driver, By.ID, element_id, value)
    def matches(current):
        try:
            return current.find_element(By.ID, element_id).get_attribute("value") == str(value)
        except (NoSuchElementException, StaleElementReferenceException):
            return False
    WebDriverWait(driver, 30).until(matches)


def _answer(driver, value, suffix):
    click_yes_no_answer(driver, {suffix: value}, suffix, PREFIX + suffix + "Yes", PREFIX + suffix + "No")


def _matrix_id(use, level, row):
    return PREFIX + f"Sustainability{use}Levels_dg{use}Sustainability_{LEVEL_IDS[level]}_{row}"


def fill_matrix(driver, use, selections):
    for row, level in enumerate(selections):
        element_id = _matrix_id(use, level, row)
        def selected(current):
            try:
                return current.find_element(By.ID, element_id).is_selected()
            except (NoSuchElementException, StaleElementReferenceException):
                return False
        if not selected(driver):
            click_when_clickable(driver, By.XPATH, f"//label[@for='{element_id}']")
        WebDriverWait(driver, 30).until(selected)


def complete_sustainability(driver, user_inputs):
    answers = validate_sustainability(user_inputs)
    new_building = yes_no_answer(user_inputs, "New Building Construction", "No") == "Yes"
    _answer(driver, new_building, "rbNewBuildingConstruction")
    click_next(driver, expected_ids=PREFIX + ("rbHigherLevelsSustainabiityNo" if new_building else "rbSTASNo"), screen_name="higher sustainability levels" if new_building else "STAS")
    if not new_building:
        return
    _answer(driver, answers["higherLevels"], "rbHigherLevelsSustainabiity")
    click_next(driver, expected_ids=PREFIX + ("rbCoverMultipleBuildingsNo" if answers["higherLevels"] else "rbSTASNo"), screen_name="multiple buildings" if answers["higherLevels"] else "STAS")
    if not answers["higherLevels"]:
        return
    _answer(driver, answers["multipleBuildings"], "rbCoverMultipleBuildings")
    count_inputs = driver.find_elements(By.ID, PREFIX + "txtNumBuildings")
    if answers["multipleBuildings"]:
        enter_verified_text(driver, "txtNumBuildings", str(answers["buildingCount"]))
    elif any(element.is_displayed() for element in count_inputs):
        enter_verified_text(driver, "txtNumBuildings", "")
    click_next(driver, expected_ids=PREFIX + "rbDomesticUseNo", screen_name="domestic use")
    _answer(driver, answers["domesticUse"], "rbDomesticUse")
    domestic_marker = _matrix_id("Domestic", "silver", 0)
    non_domestic_marker = _matrix_id("NonDomestic", "silver", 0)
    non_domestic_question = PREFIX + "rbNonDomesticUseNo"
    stas = PREFIX + "rbSTASNo"
    targets = (non_domestic_question, domestic_marker, non_domestic_marker, stas)
    state = click_next(driver, expected_ids=targets, screen_name="sustainability use or levels")
    completed = set()
    non_domestic_answered = False
    for _transition in range(6):
        if state == non_domestic_question:
            if non_domestic_answered:
                raise RuntimeError("The portal repeated the non-domestic-use question. Next was not repeated.")
            _answer(driver, answers["nonDomesticUse"], "rbNonDomesticUse")
            non_domestic_answered = True
        elif state == domestic_marker:
            if not answers["domesticUse"] or "Domestic" in completed:
                raise RuntimeError("The portal showed an unexpected domestic sustainability matrix. Review the current draft.")
            fill_matrix(driver, "Domestic", answers["domesticLevels"])
            completed.add("Domestic")
        elif state == non_domestic_marker:
            if not non_domestic_answered or not answers["nonDomesticUse"] or "NonDomestic" in completed:
                raise RuntimeError("The portal showed an unexpected non-domestic sustainability matrix. Review the current draft.")
            fill_matrix(driver, "NonDomestic", answers["nonDomesticLevels"])
            completed.add("NonDomestic")
        elif state == stas:
            expected = ({"Domestic"} if answers["domesticUse"] else set()) | ({"NonDomestic"} if answers["nonDomesticUse"] else set())
            if not non_domestic_answered or completed != expected:
                raise RuntimeError("The portal skipped a required sustainability question or matrix. Review the current draft before continuing.")
            return
        else:
            raise RuntimeError("The portal has changed on the sustainability screens. Review the current draft.")
        # During an ASP.NET postback the old controls can remain visible briefly.
        # Never accept the current screen as confirmation that Next advanced.
        destination_ids = tuple(marker for marker in targets if marker != state)
        state = click_next(driver, expected_ids=destination_ids, screen_name="remaining sustainability use or levels")
    raise RuntimeError("The portal repeated sustainability screens. Review the current draft; Next was not repeated.")

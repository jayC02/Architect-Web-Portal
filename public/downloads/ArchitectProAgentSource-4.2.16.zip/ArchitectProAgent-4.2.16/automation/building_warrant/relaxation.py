"""Captured reference/date fields, with observed Add controls for multiple directions."""
from collections.abc import Mapping
from datetime import date
import re

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import type_into, yes_no_answer
from automation.building_warrant.follow_ups import ensure_follow_up_field

REFERENCE_SUFFIX = 'RelaxationDirections_txtReferenceNumber'
DATE_ID = 'txtRelaxDirDate'
ADD_BUTTON_SCRIPT = r"""
// ARCHPRO_RELAXATION_ADD: discover an observed Add control near these actual inputs.
const reference = arguments[0];
const date = document.getElementById('txtRelaxDirDate');
let scope = reference.parentElement;
while (scope && date && !scope.contains(date)) scope = scope.parentElement;
const visible = el => el.getClientRects().length > 0 && !el.disabled;
while (scope) {
  const buttons = Array.from(scope.querySelectorAll('button,input[type=submit],input[type=button],a[role=button]'));
  const matches = buttons.filter(el => visible(el) && /^add(?:\s+(?:new(?:\s+direction)?|(?:relaxation\s+)?direction))?$/i.test((el.value || el.textContent || '').trim()));
  if (matches.length) return matches;
  scope = scope.parentElement;
}
return [];
"""


def relaxation_directions(user_inputs):
    if yes_no_answer(user_inputs, 'Relaxation Direction') != 'Yes':
        return []
    directions = user_inputs.get('Relaxation Directions')
    if not directions:
        directions = [{'reference': user_inputs.get('Relaxation Reference'), 'date': user_inputs.get('Relaxation Date')}]
    if not isinstance(directions, (list, tuple)) or not 1 <= len(directions) <= 20:
        raise ValueError('Enter between one and twenty relaxation directions in Architect Pro.')
    result = []
    for entry in directions:
        if not isinstance(entry, Mapping):
            raise ValueError('Complete the relaxation-direction references and dates in Architect Pro.')
        reference = str(entry.get('reference') or '').strip()
        if not reference or len(reference) > 750:
            raise ValueError('Complete each relaxation-direction reference in Architect Pro (maximum 750 characters).')
        raw_date = str(entry.get('date') or '').strip()
        try:
            if not re.fullmatch(r'\d{4}-\d{2}-\d{2}', raw_date):
                raise ValueError()
            formatted_date = date.fromisoformat(raw_date).strftime('%d/%m/%Y')
        except ValueError as exc:
            raise ValueError('Complete a valid relaxation-direction date in Architect Pro.') from exc
        result.append({'reference': reference, 'date': formatted_date})
    return result


def _row_count(driver, reference, formatted_date):
    count = 0
    for row in driver.find_elements(By.CSS_SELECTOR, 'tr,li,[role="row"]'):
        try:
            text = ' '.join(row.text.split())
            if row.is_displayed() and re.search(r'(?<!\w)' + re.escape(reference) + r'(?!\w)', text) and formatted_date in text:
                count += 1
        except StaleElementReferenceException:
            continue
    return count


def fill_relaxation_directions(driver, user_inputs):
    directions = relaxation_directions(user_inputs)
    reference_id = ensure_follow_up_field(driver, REFERENCE_SUFFIX, 'reference number', 'relaxation directions')
    for entry in directions:
        type_into(driver, By.ID, reference_id, entry['reference'])
        type_into(driver, By.ID, DATE_ID, entry['date'])
        WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
            lambda current: current.find_element(By.ID, reference_id).get_attribute('value') == entry['reference']
            and current.find_element(By.ID, DATE_ID).get_attribute('value') == entry['date']
        )
        if len(directions) == 1:
            return
        reference_field = driver.find_element(By.ID, reference_id)
        buttons = driver.execute_script(ADD_BUTTON_SCRIPT, reference_field) or []
        if len(buttons) != 1:
            raise RuntimeError('The portal has changed on the relaxation-directions screen: one unambiguous Add direction button was not found.')
        previous_count = _row_count(driver, entry['reference'], entry['date'])
        buttons[0].click()
        try:
            WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
                lambda current: _row_count(current, entry['reference'], entry['date']) > previous_count
            )
        except TimeoutException as exc:
            raise RuntimeError('The portal did not confirm the added relaxation direction. Review the current draft; Add was not repeated.') from exc

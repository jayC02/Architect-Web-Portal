"""Property owner details from the frozen client copy or reviewed manual fields."""
from collections.abc import Mapping

from automation.common.actions import yes_no_answer
from automation.common.forms import resolve_applicant_title, select_applicant_title
from automation.building_warrant.sustainability import enter_verified_text

PREFIX = "MainContent_BuildingWarrantAppWizard_OwnerDetails_"
FIELDS = {
    "firstName": ("txtOwnerFirstName", 100), "lastName": ("txtOwnerLastName", 100),
    "company": ("txtOwnerCompany", 160), "telephone": ("txtOwnerTelephoneNumber", 40),
    "extension": ("txtOwnerExtensionNumber", 20), "mobile": ("txtOwnerMobileNumber", 40),
    "fax": ("txtOwnerFaxNumber", 40), "email": ("txtOwnerEmailAddr", 160),
    "buildingName": ("txtOwnerBuildingName", 160), "buildingNumber": ("txtOwnerBuildingNo", 40),
    "addressLine1": ("txtOwnerAddress1", 160), "addressLine2": ("txtOwnerAddress2", 160),
    "townCity": ("txtOwnerTown", 100), "country": ("txtOwnerCountry", 100), "postcode": ("txtOwnerPostcode", 20),
}


def validate_owner(user_inputs):
    if yes_no_answer(user_inputs, "Applicant Is Owner", "Yes") == "Yes":
        return {}
    owner = user_inputs.get("Owner Details")
    if not isinstance(owner, Mapping):
        raise ValueError("Confirm whether the property owner is the saved client, or enter their details in Architect Pro.")
    for key in ("title", "firstName", "lastName", "telephone", "email", "addressLine1", "townCity", "country", "postcode"):
        if not str(owner.get(key) or "").strip():
            raise ValueError(f"Complete the property owner's {key} in Architect Pro before running this warrant.")
    if not str(owner.get("buildingName") or "").strip() and not str(owner.get("buildingNumber") or "").strip():
        raise ValueError("Enter a building name or number for the property owner in Architect Pro.")
    for key, (_, limit) in FIELDS.items():
        if len(str(owner.get(key) or "").strip()) > limit:
            raise ValueError(f"The property owner's {key} exceeds the supported {limit} characters.")
    resolve_applicant_title(owner["title"], owner.get("otherTitle", ""))
    return owner


def fill_owner_details(driver, user_inputs):
    owner = validate_owner(user_inputs)
    select_applicant_title(driver, PREFIX + "ddlOwnerTitle", owner["title"], PREFIX + "txtOwnerFirstName",
                           other_title=owner.get("otherTitle", ""), other_title_element_ids=(PREFIX + "txtOwnerOtherTitle",))
    for key, (suffix, _limit) in FIELDS.items():
        enter_verified_text(driver, "OwnerDetails_" + suffix, str(owner.get(key) or "").strip())

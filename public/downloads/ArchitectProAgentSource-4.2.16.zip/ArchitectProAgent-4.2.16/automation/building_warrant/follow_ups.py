"""Captured warrant follow-ups shared by validation and the production runner."""
from collections.abc import Mapping

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_when_clickable, get_when_clickable, type_into, yes_no_answer
from automation.building_warrant.navigation import click_next, ensure_follow_up
from automation.building_warrant.sustainability import enter_verified_text

PREFIX = "MainContent_BuildingWarrantAppWizard_"
CONVERSION_IDS = tuple(f"C{number}" for number in range(1, 11))
CONVERSION_LABELS = (
    'A building to create a dwelling or dwellings or a part thereof',
    'A building ancillary to a dwelling to increase the area of human occupation',
    'A building which alters the number of dwellings in a building',
    'A domestic building to any other type of building',
    'A residential building to any other type of building',
    'A residential building which involves a significant alteration of the characteristics of the persons',
    'A building so that it becomes a residential building',
    'An exempt building',
    'A building to allow access by the public where previously there was none',
    'A building to accommodate parts in different occupation where previously it was not so occupied',
)
CONSTRUCTION_FIELDS = {
    "certifierName": "txtCertificateName", "registrationNumber": "txtCertificateNumber",
    "approvedBody": "txtApprovedBodyName", "approvedBodyRegistrationNumber": "txtApprovedBodyNumber",
    "workTypeDetails": "txtWorkTypeDetails",
}


def _observed_field_id(driver, expected_id, question):
    """Use a captured ID first, then the actual label's for= binding."""
    def usable(field):
        if not field.is_displayed():
            return False
        if '_txt' in expected_id:
            return field.tag_name.lower() in ('input', 'textarea') and str(field.get_attribute('type') or '').lower() not in ('radio', 'checkbox', 'submit', 'button', 'hidden')
        return True
    try:
        direct = [field for field in driver.find_elements(By.ID, expected_id) if usable(field)]
        if direct:
            return expected_id
        query = f"//label[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'{question.lower()}')]"
        matches = []
        for label in driver.find_elements(By.XPATH, query):
            if not label.is_displayed():
                continue
            element_id = label.get_attribute('for')
            if element_id and any(usable(field) for field in driver.find_elements(By.ID, element_id)):
                matches.append(element_id)
        return matches[0] if len(set(matches)) == 1 else False
    except StaleElementReferenceException:
        return False


def ensure_follow_up_field(driver, suffix, question, screen_name, *, inline_timeout=2, timeout=30):
    find = lambda current: _observed_field_id(current, PREFIX + suffix, question)
    try:
        return WebDriverWait(driver, inline_timeout).until(find)
    except TimeoutException:
        click_next(driver)
    try:
        return WebDriverWait(driver, timeout).until(find)
    except TimeoutException as exc:
        raise RuntimeError(f"The portal has changed on the {screen_name} screen. The expected field and its question label were not found; Next was not repeated.") from exc


def fill_text_follow_up(driver, suffix, question, value, screen_name):
    element_id = ensure_follow_up_field(driver, suffix, question, screen_name)
    type_into(driver, By.ID, element_id, value)
    WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
        lambda current: current.find_element(By.ID, element_id).get_attribute('value') == value
    )


def validate_follow_ups(user_inputs):
    if yes_no_answer(user_inputs, "Conversion Regulations") == "Yes":
        descriptions = user_inputs.get("Conversion Descriptions")
        if not isinstance(descriptions, (list, tuple)) or not descriptions or any(value not in CONVERSION_IDS for value in descriptions):
            raise ValueError("Select at least one valid conversion description in Architect Pro before running this warrant.")
    if yes_no_answer(user_inputs, "Includes Demolition") == "Yes":
        weeks = user_inputs.get("Demolition Weeks")
        if isinstance(weeks, bool) or not str(weeks or "").isdigit() or not 1 <= int(weeks) <= 99:
            raise ValueError("Enter the demolition period as a whole number of weeks from 1 to 99 in Architect Pro.")
    for answer_key, key, limit in (("Listed Or Conservation Area", "Listing Category", 750), ("STAS", "STAS Reference", 20)):
        if yes_no_answer(user_inputs, answer_key) == "Yes":
            value = str(user_inputs.get(key) or "").strip()
            if not value or len(value) > limit:
                raise ValueError(f"Complete {key} in Architect Pro (maximum {limit} characters) before running this warrant.")
    if yes_no_answer(user_inputs, "Approved Certifier Construction") == "Yes":
        details = user_inputs.get("Construction Certificate")
        if not isinstance(details, Mapping) or str(details.get("schemeType")) not in ("1", "2"):
            raise ValueError("Choose the construction-certification scheme in Architect Pro before running this warrant.")
        for key in CONSTRUCTION_FIELDS:
            value = str(details.get(key) or "").strip()
            limit = 750 if key == "workTypeDetails" else 160
            if not value or len(value) > limit:
                raise ValueError(f"Complete construction certificate {key} in Architect Pro (maximum {limit} characters).")


def fill_conversion_descriptions(driver, user_inputs, timeout=30):
    ensure_follow_up_field(driver, 'C1', CONVERSION_LABELS[0], 'conversion descriptions')
    wanted = set(user_inputs["Conversion Descriptions"])
    for suffix in CONVERSION_IDS:
        element_id = _observed_field_id(driver, PREFIX + suffix, CONVERSION_LABELS[int(suffix[1:]) - 1])
        if not element_id:
            raise RuntimeError("The portal has changed on the conversion descriptions screen; a captured description could not be found.")
        field = get_when_clickable(driver, By.ID, element_id, timeout=timeout)
        expected = suffix in wanted
        if field.is_selected() != expected:
            click_when_clickable(driver, By.XPATH, f"//label[@for='{element_id}']", timeout=timeout)
        WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(
            lambda current, key=element_id, checked=expected: current.find_element(By.ID, key).is_selected() == checked
        )


def fill_demolition_period(driver, user_inputs):
    fill_text_follow_up(driver, 'txtWeeks', 'weeks', str(int(user_inputs['Demolition Weeks'])), 'demolition period')
    # Older drafts may retain a month count. Only act on an observed control.
    for field in driver.find_elements(By.CSS_SELECTOR, f"input[id^='{PREFIX}'][id*='month' i]"):
        if field.is_displayed() and field.is_enabled():
            element_id = field.get_attribute("id")
            if element_id:
                type_into(driver, By.ID, element_id, "")
                WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
                    lambda current, key=element_id: current.find_element(By.ID, key).get_attribute("value") == ""
                )


def fill_construction_certificate(driver, user_inputs):
    details = user_inputs["Construction Certificate"]
    scheme_id = PREFIX + "CertificatesInformation_ddlSchemeType"
    ensure_follow_up(driver, scheme_id, screen_name="construction-certificate details")
    selected = str(details["schemeType"])
    for _attempt in range(3):
        try:
            dropdown = Select(get_when_clickable(driver, By.ID, scheme_id))
            if dropdown.first_selected_option.get_attribute("value") != selected:
                dropdown.select_by_value(selected)
            break
        except StaleElementReferenceException:
            continue
    WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
        lambda current: Select(current.find_element(By.ID, scheme_id)).first_selected_option.get_attribute("value") == selected
    )
    for key, suffix in CONSTRUCTION_FIELDS.items():
        enter_verified_text(driver, "CertificatesInformation_" + suffix, str(details[key]).strip())

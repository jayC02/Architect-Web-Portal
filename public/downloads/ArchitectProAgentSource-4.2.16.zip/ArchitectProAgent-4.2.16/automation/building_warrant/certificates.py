"""Postback-safe design certification and observed portal validation results."""
import re

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_yes_no_answer, get_when_clickable, type_into, wait_dom_ready, yes_no_answer
from automation.building_warrant.navigation import click_next
from automation.building_warrant.sustainability import enter_verified_text

PREFIX = "MainContent_BuildingWarrantAppWizard_"
REGISTER = PREFIX + "CertificatesRegister1_"
UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
LOWER = "abcdefghijklmnopqrstuvwxyz"
VALIDATION_BUTTON = (
    f"//input[(@type='submit' or @type='button' or @type='image') and (contains(translate(@value,'{UPPER}','{LOWER}'),'validation check') "
    f"or contains(translate(@alt,'{UPPER}','{LOWER}'),'validation check'))] | "
    f"//button[contains(translate(normalize-space(.),'{UPPER}','{LOWER}'),'validation check')] | "
    f"//a[contains(translate(normalize-space(.),'{UPPER}','{LOWER}'),'validation check')]"
)
VALIDATION_MESSAGES = (
    "[role='alert'],[role='status'],.alert,.validation-summary-errors,.field-validation-error,"
    "span[id*='valid' i],div[id*='valid' i],p[id*='valid' i],"
    "span[id*='result' i],div[id*='result' i],span[id*='message' i],div[id*='message' i]"
)


class CertificateValidationError(ValueError):
    def __init__(self, portal_message):
        # The existing callback errorSummary is limited to 500 characters.
        # Leave room for the actionable explanation instead of losing it at transport.
        self.portal_message = " ".join(str(portal_message).split())[:320]
        super().__init__(f"Certificate validation failed: {self.portal_message} Correct the saved certifier details in Architect Pro and prepare the warrant again.")


def validate_design_certificate(user_inputs):
    if yes_no_answer(user_inputs, "Approved Certifier Design") != "Yes":
        return
    for key in ("Registration Number (A) Part 1", "Registration Number (A) Part 2", "Name of Certifier",
                "Registration Number (B) Part 1", "Registration Number (B) Part 2", "Name of Approved Body"):
        if not str(user_inputs.get(key) or "").strip():
            raise ValueError(f"Complete {key} in Architect Pro before running this warrant.")
    with_application = yes_no_answer(user_inputs, "Design Certificate With Application", "No") == "Yes"
    following = yes_no_answer(user_inputs, "Design Certificate Following Application", "Yes") == "Yes"
    if not with_application and not following:
        raise ValueError("Choose when the design certificate will be provided in Architect Pro before running this warrant.")


def _select_text(driver, element_id, value, timeout=30):
    for _attempt in range(3):
        try:
            dropdown = Select(get_when_clickable(driver, By.ID, element_id, timeout=timeout))
            options = [option.text.strip() for option in dropdown.options]
            if value not in options:
                raise RuntimeError(f"The portal has changed on the design-certificate screen: option {value!r} is unavailable.")
            if dropdown.first_selected_option.text.strip() != value:
                dropdown.select_by_visible_text(value)
            break
        except StaleElementReferenceException:
            continue
    wait_dom_ready(driver, timeout)
    WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(
        lambda current: Select(current.find_element(By.ID, element_id)).first_selected_option.text.strip() == value
    )


def _messages(driver):
    found = []
    for element in driver.find_elements(By.CSS_SELECTOR, VALIDATION_MESSAGES):
        try:
            text = " ".join(element.text.split())
            if not element.is_displayed() or not text:
                continue
            invalid = re.search(
                r"\b(invalid|unsuccessful|failed|failure|error|incorrect|unable|cannot)\b"
                r"|\b(?:not|never)\b.{0,40}\b(valid|validated|verified|registered|found|match|successful)\b"
                r"|\b(no|zero)\s+(matching|valid|registered)\b|\bcould\s+not\b",
                text, re.I,
            )
            valid = re.search(r"\b(valid|validated|verified|successful|successfully)\b", text, re.I)
            if invalid or valid:
                found.append((element.id, text, not bool(invalid)))
        except StaleElementReferenceException:
            continue
    return found


def check_certificate_validation(driver, timeout=30):
    def visible_button(current):
        for button in current.find_elements(By.XPATH, VALIDATION_BUTTON):
            try:
                if button.is_displayed() and button.is_enabled():
                    return button
            except StaleElementReferenceException:
                continue
        return False
    try:
        button = WebDriverWait(driver, timeout).until(visible_button)
    except TimeoutException as exc:
        raise RuntimeError("The portal has changed on the design-certificate screen: the Validation Check button was not found.") from exc
    previous = {(element_id, text) for element_id, text, _success in _messages(driver)}
    button.click()  # A validation request is never blindly clicked twice.
    def fresh_result(current):
        replaced = EC.staleness_of(button)(current)
        messages = _messages(current)
        fresh = [(text, success) for element_id, text, success in messages if replaced or (element_id, text) not in previous]
        # A positive panel must not mask an adjacent field-level rejection.
        if fresh:
            failures = [text for _element_id, text, success in messages if not success]
            if failures:
                return failures[0], False
            return fresh[0]
        return False
    try:
        message, success = WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(fresh_result)
    except TimeoutException as exc:
        raise RuntimeError("The portal did not confirm the design-certificate validation result. Review the saved certifier details before retrying; Validation Check was not repeated.") from exc
    if not success:
        raise CertificateValidationError(message)
    return message


def fill_design_certificate(driver, user_inputs):
    validate_design_certificate(user_inputs)
    for key, suffix, default in (
        ("Design Certificate With Application", "rbUploadCertificateOfDesignWithApplication", "No"),
        ("Design Certificate Following Application", "rbUploadCertificateOfDesignFollowingApplication", "Yes"),
    ):
        click_yes_no_answer(driver, user_inputs, key, PREFIX + suffix + "Yes", PREFIX + suffix + "No", default=default)
    click_next(driver, expected_ids=REGISTER + "ddlSchemeType", screen_name="design-certificate details")
    for suffix, value in (
        ("ddlSchemeType", "Design"),
        ("ddlCertifierRegNo1", str(user_inputs["Registration Number (A) Part 1"]).strip()),
        ("ddlCertifierRegNo2", "D"),
    ):
        _select_text(driver, REGISTER + suffix, value)
    enter_verified_text(driver, "CertificatesRegister1_txtCertifierRegNo", str(user_inputs["Registration Number (A) Part 2"]).strip())
    type_into(driver, By.ID, "txtCertifierName", str(user_inputs["Name of Certifier"]).strip())
    for suffix, value in (
        ("ddlApprovedBodyRegNo1", str(user_inputs["Registration Number (B) Part 1"]).strip()),
        ("ddlApprovedBodyRegNo2", "DB"),
    ):
        _select_text(driver, REGISTER + suffix, value)
    enter_verified_text(driver, "CertificatesRegister1_txtApprovedBodyRegNo", str(user_inputs["Registration Number (B) Part 2"]).strip())
    type_into(driver, By.ID, "txtCertificateANameOfApprovedBody", str(user_inputs["Name of Approved Body"]).strip())
    for element_id, value in (("txtCertifierName", user_inputs["Name of Certifier"]), ("txtCertificateANameOfApprovedBody", user_inputs["Name of Approved Body"])):
        WebDriverWait(driver, 30, ignored_exceptions=(StaleElementReferenceException,)).until(
            lambda current, key=element_id, expected=str(value).strip(): current.find_element(By.ID, key).get_attribute("value") == expected
        )
    check_certificate_validation(driver)

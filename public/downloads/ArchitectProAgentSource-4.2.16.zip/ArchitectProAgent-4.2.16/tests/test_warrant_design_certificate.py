"""The actual warrant runner must validate the certificate, not click a textbox."""
import pytest
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.by import By

from automation.building_warrant import certificates, run as warrant
from test_warrant_mapping_navigation import Element, Portal, P, job_for, runtime, run_through_main, prepare_workflow, MultipleRelaxationsPortal, MainDetailsFinished

REG = 'CertificatesRegister1_'
DETAILS = {
    'Registration Number (A) Part 1': 'BRE1', 'Registration Number (A) Part 2': '123',
    'Name of Certifier': 'Design Certifier', 'Registration Number (B) Part 1': 'SER1',
    'Registration Number (B) Part 2': '456', 'Name of Approved Body': 'Approved Design Body',
    'Approved Certifier Design': 'Yes', 'Declaration Authorised': 'Yes',
    'Design Certificate With Application': 'Yes', 'Design Certificate Following Application': 'No',
}


class Option:
    def __init__(self, text): self.text = text


class Dropdown:
    options_by_suffix = {
        'ddlSchemeType': ['Design'], 'ddlCertifierRegNo1': ['BRE1', 'SER1'], 'ddlCertifierRegNo2': ['D'],
        'ddlApprovedBodyRegNo1': ['BRE1', 'SER1'], 'ddlApprovedBodyRegNo2': ['DB'],
    }
    def __init__(self, element): self.element = element
    @property
    def options(self): return [Option(text) for text in self.options_by_suffix[self.element.key.rsplit('_', 1)[-1]]]
    @property
    def first_selected_option(self): return Option(self.element.driver.values.get(self.element.key, ''))
    def select_by_visible_text(self, text): self.element.driver.values[self.element.key] = text


class ValidationButton:
    def __init__(self, driver): self.driver, self.epoch = driver, driver.validation_epoch
    def is_displayed(self): return True
    def is_enabled(self):
        if self.epoch != self.driver.validation_epoch: raise StaleElementReferenceException()
        return True
    def click(self):
        self.driver.validation_clicks += 1
        if self.driver.fresh_result: self.driver.validation_epoch += 1


class Message:
    def __init__(self, driver): self.id, self.text = f'message-{driver.validation_epoch}', driver.validation_text
    def is_displayed(self): return True


class DesignPortal(Portal):
    pages = {**Portal.pages,
        'design_timing': ['rbUploadCertificateOfDesignWithApplicationYes', 'rbUploadCertificateOfDesignWithApplicationNo',
                          'rbUploadCertificateOfDesignFollowingApplicationYes', 'rbUploadCertificateOfDesignFollowingApplicationNo'],
        'design_details': [REG + key for key in ('ddlSchemeType', 'ddlCertifierRegNo1', 'ddlCertifierRegNo2', 'txtCertifierRegNo',
                                                'ddlApprovedBodyRegNo1', 'ddlApprovedBodyRegNo2', 'txtApprovedBodyRegNo')]}
    def __init__(self, validation_text='Certificate and approved body successfully validated'):
        super().__init__()
        self.validation_epoch, self.validation_clicks = 0, 0
        self.validation_text, self.fresh_result, self.has_button = validation_text, True, True
    def visible(self):
        result = super().visible()
        if self.page == 'design_details': result.update({'txtCertifierName', 'txtCertificateANameOfApprovedBody'})
        return result
    def find_elements(self, by, key):
        if self.page == 'design_details' and by == By.XPATH and key == certificates.VALIDATION_BUTTON:
            return [ValidationButton(self)] if self.has_button else []
        if self.page == 'design_details' and by == By.CSS_SELECTOR and key == certificates.VALIDATION_MESSAGES:
            return [Message(self)] if self.validation_epoch else []
        return super().find_elements(by, key)
    def advance(self):
        if self.page in ('design', 'design_timing', 'design_details'):
            self.next_clicks += 1
            self.page = ('design_timing' if P + 'CertificatesRegisterQuestion_rbCertificatesAccompanyYes' in self.checked else 'construction_cert') if self.page == 'design' else 'design_details' if self.page == 'design_timing' else 'construction_cert'
            self.path.append(self.page)
        else: super().advance()


def test_actual_runner_uses_saved_timing_and_certifier_and_waits_for_validation(monkeypatch):
    monkeypatch.setattr(certificates, 'Select', Dropdown)
    driver = run_through_main(monkeypatch, job_for(), extra=DETAILS, driver=DesignPortal())
    assert driver.validation_clicks == 1
    assert driver.values['txtCertifierName'] == DETAILS['Name of Certifier']
    assert driver.values['txtCertificateANameOfApprovedBody'] == DETAILS['Name of Approved Body']
    assert driver.values[P + REG + 'ddlCertifierRegNo1'] == 'BRE1'
    assert driver.values[P + REG + 'ddlCertifierRegNo2'] == 'D'
    assert driver.values[P + REG + 'ddlApprovedBodyRegNo2'] == 'DB'
    assert P + 'rbUploadCertificateOfDesignWithApplicationYes' in driver.checked
    assert P + 'rbUploadCertificateOfDesignFollowingApplicationNo' in driver.checked
    assert driver.page == 'email'


@pytest.mark.parametrize('portal_message', [
    'Invalid certifier registration number',
    'The certificate could not be validated',
    'The approved body is not currently registered',
    'No matching certificate registration was found',
])
def test_portal_validation_failure_stops_actual_runner_before_documents(monkeypatch, portal_message):
    monkeypatch.setattr(certificates, 'Select', Dropdown)
    prepare_workflow(monkeypatch)
    inputs = runtime(job_for()).mutable_inputs()
    inputs.update(DETAILS)
    driver = DesignPortal(portal_message)
    with pytest.raises(certificates.CertificateValidationError) as result:
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={})
    assert result.value.portal_message == portal_message
    assert driver.page == 'design_details'
    assert driver.validation_clicks == 1


def test_old_green_message_does_not_count_as_a_fresh_validation():
    driver = DesignPortal()
    driver.page, driver.validation_epoch, driver.fresh_result = 'design_details', 1, False
    with pytest.raises(RuntimeError, match='Validation Check was not repeated'):
        certificates.check_certificate_validation(driver, timeout=0)
    assert driver.validation_clicks == 1


def test_missing_validation_button_reports_changed_screen_instead_of_clicking_name():
    driver = DesignPortal()
    driver.page, driver.has_button = 'design_details', False
    with pytest.raises(RuntimeError, match='Validation Check button was not found'):
        certificates.check_certificate_validation(driver, timeout=0)
    assert driver.validation_clicks == 0


def test_missing_saved_registration_is_rejected_before_login(monkeypatch):
    inputs = runtime(job_for()).mutable_inputs()
    inputs.update({**DETAILS, 'Registration Number (A) Part 1': ''})
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError, match='Registration Number'):
        warrant.main(user_inputs=inputs, password='test-only', driver=DesignPortal(), document_mapping={})
    assert calls == []


def test_certificate_failure_reaches_existing_callback_as_correctable_retry():
    from automation.runner import run_automation
    from gui.services.desktop_callback_contract import map_runner_result_callback

    class ManagedDriver:
        def start(self): return object()
        def close(self, **_kwargs): pass

    def failed_validation(**kwargs):
        kwargs['progress']('main_details', 'running', 'Checking certificate')
        raise certificates.CertificateValidationError('Invalid certifier registration number')

    result = run_automation({
        'job_id': 'warrant-certificate-test', 'application_type': 'BUILDING_WARRANT',
        'user_inputs': {'Email': 'agent@example.test'}, 'document_mapping': {},
    }, password='test-only', driver_factory=lambda _mode: ManagedDriver(),
        workflow_registry={'BUILDING_WARRANT': failed_validation})
    payload = map_runner_result_callback(result)
    assert result.error_code == 'CERTIFICATE_VALIDATION_FAILED'
    assert result.retry_safe is True
    assert payload['status'] == 'FAILED_RETRYABLE'
    assert payload['result']['recoveryAction'] == 'retry'
    assert 'Invalid certifier registration number' in payload['result']['errorSummary']
    assert 'Correct the saved certifier details' in payload['result']['errorSummary']
    assert 'Stacktrace' not in payload['result']['errorSummary']
    assert payload['result']['recoveryFields'] == ['registrationAPart1', 'registrationAPart2', 'certifierName', 'registrationBPart1', 'registrationBPart2', 'approvedBody']


def test_certificate_message_fits_the_existing_web_callback_contract():
    error = certificates.CertificateValidationError('Portal validation failed ' * 100)
    assert len(str(error)) <= 500
    assert 'Correct the saved certifier details' in str(error)


def test_positive_validation_panel_never_masks_a_field_level_rejection():
    class MixedPortal(DesignPortal):
        def find_elements(self, by, key):
            found = super().find_elements(by, key)
            if by == By.CSS_SELECTOR and key == certificates.VALIDATION_MESSAGES and self.validation_epoch:
                error = Message(self)
                error.id, error.text = 'field-error', 'Invalid approved body registration'
                return [*found, error]
            return found
    driver = MixedPortal()
    driver.page = 'design_details'
    with pytest.raises(certificates.CertificateValidationError, match='Invalid approved body registration'):
        certificates.check_certificate_validation(driver, timeout=0)


def test_every_saved_follow_up_passes_the_actual_v2_adapter_and_native_runner(monkeypatch):
    class CompletePortal(DesignPortal, MultipleRelaxationsPortal):
        pass
    job = job_for(('new_build', 'conversion_change_of_use', 'demolition'))
    record = job['dataSnapshot']['buildingWarrant']
    record.update({
        'conversionDescriptions': ['C1', 'C10'], 'demolitionWeeks': 4,
        'listingCategory': 'Category B', 'stasReference': 'STAS-100',
        'constructionCertificate': {'schemeType': '2', 'certifierName': 'Construction Certifier',
            'registrationNumber': 'CC-100', 'approvedBody': 'Construction Body',
            'approvedBodyRegistrationNumber': 'CB-100', 'workTypeDetails': 'Electrical work'},
        'designCertificateWithApplication': True, 'designCertificateFollowingApplication': False,
        'relaxationDirections': [{'reference': 'RD-1', 'date': '2026-11-01'}, {'reference': 'RD-2', 'date': '2026-11-02'}],
        'sustainability': {'higherLevels': False},
    })
    record['unusualAnswers'].update({'listedBuildingOrConservationArea': True, 'coveredBySTAS': True,
        'approvedCertifierOfConstruction': True, 'certifierOfConstructionCertificateAvailable': True,
        'certifierOfDesignCertificateAvailable': True, 'scottishMinistersRelaxationDirection': True,
        'declarationAuthorised': True})
    inputs = runtime(job).mutable_inputs()
    for snapshot_key, runtime_key in [
        ('conversionDescriptions', 'Conversion Descriptions'), ('demolitionWeeks', 'Demolition Weeks'),
        ('listingCategory', 'Listing Category'), ('stasReference', 'STAS Reference'),
        ('constructionCertificate', 'Construction Certificate'), ('relaxationDirections', 'Relaxation Directions'),
    ]:
        assert inputs[runtime_key] == record[snapshot_key]
    assert inputs['Design Certificate With Application'] == 'Yes'
    assert inputs['Design Certificate Following Application'] == 'No'
    assert inputs['Declaration Authorised'] == 'Yes'
    assert inputs['Approved Certifier Design'] == 'Yes'
    prepare_workflow(monkeypatch)
    monkeypatch.setattr(certificates, 'Select', Dropdown)
    driver = CompletePortal()
    def progress(stage, status, _message):
        if stage == 'documents' and status == 'running': raise MainDetailsFinished()
    with pytest.raises(MainDetailsFinished):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={}, progress=progress)
    assert driver.values[P + 'txtWeeks'] == '4'
    assert driver.values[P + 'txtListedBuildingCategory'] == 'Category B'
    assert driver.values[P + 'txtSTAS'] == 'STAS-100'
    assert driver.values[P + 'CertificatesInformation_txtCertificateName'] == 'Construction Certifier'
    assert driver.relaxation_rows == [{'reference': 'RD-1', 'date': '01/11/2026'}, {'reference': 'RD-2', 'date': '02/11/2026'}]
    assert driver.validation_clicks == 1
    assert driver.page == 'email'

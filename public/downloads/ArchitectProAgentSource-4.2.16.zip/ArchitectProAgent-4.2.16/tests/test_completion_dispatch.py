import pytest

from automation import runner
from automation.models import COMPLETION_TYPES, PLANNING_TYPES, WARRANT_TYPES, RuntimeJob
from automation.progress import USER_STAGE_LABELS, workflow_key, workflow_stages


def test_runtime_job_accepts_completion():
    job = RuntimeJob.from_mapping({
        "job_id": "job_12345678",
        "application_type": "COMPLETION_CERTIFICATE",
        "user_inputs": {"Site Address": "112 Ralston Avenue"},
    })
    assert job.application_type == "COMPLETION_CERTIFICATE"
    assert job.site_label == "112 Ralston Avenue"


def test_runtime_job_still_rejects_unknown_types():
    with pytest.raises(ValueError):
        RuntimeJob.from_mapping({"job_id": "job_12345678", "application_type": "SOMETHING_ELSE"})


def test_completion_types_are_distinct():
    assert COMPLETION_TYPES == {"COMPLETION_CERTIFICATE", "Completion Certificate"}
    assert not COMPLETION_TYPES & (PLANNING_TYPES | WARRANT_TYPES)


def test_stage_profile():
    assert workflow_key("COMPLETION_CERTIFICATE") == "completion_certificate"
    assert workflow_stages("COMPLETION_CERTIFICATE") == (
        "validation", "browser", "login", "proposal", "completion_form", "main_details", "final_review",
    )
    assert USER_STAGE_LABELS["completion_form"] == "Opening the completion certificate"
    for stage in workflow_stages("COMPLETION_CERTIFICATE"):
        assert stage in USER_STAGE_LABELS


def test_existing_stage_profiles_unchanged():
    assert workflow_key("BUILDING_WARRANT") == "building_warrant"
    assert workflow_key("HOUSEHOLDER_PLANNING") == "planning"
    assert "documents" in workflow_stages("BUILDING_WARRANT")
    assert "ownership" in workflow_stages("HOUSEHOLDER_PLANNING")


def test_dispatch_by_type():
    from automation.building_warrant.run import main as warrant
    from automation.completion_certificate.run import main as completion
    from automation.householder.run import main as planning

    assert runner._workflow_for("COMPLETION_CERTIFICATE") is completion
    assert runner._workflow_for("BUILDING_WARRANT") is warrant
    assert runner._workflow_for("HOUSEHOLDER_PLANNING") is planning


def test_unknown_type_is_not_treated_as_warrant():
    with pytest.raises(ValueError):
        runner._workflow_for("SOMETHING_ELSE")

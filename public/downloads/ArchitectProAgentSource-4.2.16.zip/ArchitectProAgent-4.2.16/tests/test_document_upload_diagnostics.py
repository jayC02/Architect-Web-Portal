"""Regression coverage for evidence, safe recovery, and uncertain upload outcomes."""
from types import SimpleNamespace

import pytest
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, WebDriverException

from automation.common import uploads
from automation.householder import documents
from automation.runner import run_automation
from gui.services.desktop_callback_contract import map_runner_result_callback
from tests.test_automation_runner import FakeManagedDriver, job


class Element:
    text = ""

    def __init__(self, *, text="", classes="", limit=None):
        self.text, self.classes, self.limit = text, classes, limit

    def is_displayed(self):
        return True

    def is_enabled(self):
        return True

    def get_attribute(self, name):
        return self.classes if name == "class" else self.limit


class Driver:
    def __init__(self, *, error="", editor=False, notice=None):
        self.error, self.editor, self.notice = error, editor, notice
        self.ready = Element()

    def execute_script(self, _script):
        return [self.error] if self.error else []

    def find_elements(self, by, locator):
        if by == uploads.By.ID and locator == "MainContent_fuAttachFile":
            return [Element()] if self.editor else []
        if by == uploads.By.ID and locator == "MainContent_btnAddDocumentation":
            return [self.ready]
        if locator == "[role='alert']" and self.notice:
            return [self.notice]
        return []


@pytest.mark.parametrize("message,code", [
    ("A document with this title already exists.", "DUPLICATE_DOCUMENT"),
    ("File size exceeds the maximum size allowed.", "FILE_TOO_LARGE"),
    ("This PDF is password protected.", "PDF_PROTECTED"),
    ("Unsupported file extension.", "FILE_TYPE_REJECTED"),
    ("The document title contains invalid characters.", "TITLE_INVALID"),
    ("Please complete the required confirmation.", "PORTAL_VALIDATION_REJECTED"),
])
def test_rejection_survives_runner_and_callback_without_generic_replacement(message, code):
    managed = FakeManagedDriver()

    def workflow(**kwargs):
        kwargs["progress"]("documents", "running", "Uploading documents")
        uploads.wait_for_supporting_doc_upload_result(Driver(error=message), "ground-floor.pdf", timeout=0)

    result = run_automation(job("HOUSEHOLDER_PLANNING"), password="test-only",
                            driver_factory=lambda _mode: managed,
                            workflow_registry={"HOUSEHOLDER_PLANNING": workflow})
    callback = map_runner_result_callback(result)
    assert callback["status"] == "FAILED_FINAL"
    assert callback["result"]["retrySafe"] is False
    assert callback["result"]["documentFailure"]["filename"] == "ground-floor.pdf"
    assert callback["result"]["documentFailure"]["reasonCode"] == code
    assert callback["result"]["documentFailure"]["portalMessage"] == message
    assert message in callback["error"]
    assert "ePlanning" in callback["result"]["nextAction"]
    assert "eBuilding" not in str(callback)


def test_duplicate_rejection_explains_comparison_and_never_retries_save():
    error = uploads.rejected_document_error("plan.pdf", "This title already exists")
    assert "replace an older revision manually" in error.next_action("ePlanning")
    calls = []

    def save():
        calls.append("save")
        raise StaleElementReferenceException("replaced immediately after click")

    with pytest.raises(uploads.DocumentUploadError):
        documents._document_step(Driver(), "plan.pdf", "Saving supporting document", save)
    assert calls == ["save"]


def test_ready_button_with_unsaved_editor_is_not_upload_confirmation():
    with pytest.raises(uploads.DocumentUploadError) as raised:
        uploads.wait_for_supporting_doc_upload_result(Driver(editor=True), "plan.pdf", timeout=0)
    assert raised.value.reason_code == "UPLOAD_UNCONFIRMED"
    assert "outcome is unknown" in raised.value.reason
    assert "only if it is absent" in raised.value.next_action("ePlanning")


@pytest.mark.parametrize("classes", ["alert alert-success", "alert alert-info"])
def test_success_and_information_alerts_do_not_reject_a_saved_document(classes):
    driver = Driver(notice=Element(text="Upload complete", classes=classes))
    assert uploads.wait_for_supporting_doc_upload_result(driver, "plan.pdf", timeout=0) is driver.ready


def test_field_preparation_reacquires_after_replacement_and_is_bounded():
    calls = []

    def field():
        calls.append("field")
        if len(calls) < 3:
            raise StaleElementReferenceException("ASP.NET replaced dropdown")
        return "Drawing"

    assert documents._document_step(Driver(), "plan.pdf", "Selecting document type", field, retry_detached=True) == "Drawing"
    assert len(calls) == 3
    calls.clear()

    def unavailable():
        calls.append("field")
        raise StaleElementReferenceException("ASP.NET kept replacing dropdown")

    with pytest.raises(uploads.DocumentUploadError) as raised:
        documents._document_step(Driver(), "plan.pdf", "Selecting document type", unavailable, retry_detached=True)
    assert len(calls) == 3
    assert raised.value.operation == "Selecting document type"


def test_unrelated_browser_disconnect_keeps_its_own_failure_category():
    def disconnected():
        raise WebDriverException("Chrome renderer disconnected")

    with pytest.raises(WebDriverException, match="disconnected"):
        documents._document_step(Driver(), "plan.pdf", "Selecting document type", disconnected, retry_detached=True)


def test_distinct_long_titles_stay_distinct_with_portal_character_limit():
    driver = SimpleNamespace(find_elements=lambda *_args: [Element(limit="30")])
    first = documents._fit_document_field(driver, "title", "D_2023_034_021_working_Ground_floor_A", unique=True)
    second = documents._fit_document_field(driver, "title", "D_2023_034_021_working_Ground_floor_B", unique=True)
    assert len(first) == len(second) == 30
    assert first != second
    assert first[0].isalpha()


def test_diagnostic_counts_only_confirmed_documents_and_stops_the_batch(monkeypatch):
    calls = []

    def upload(_driver, filename, *_args):
        calls.append(filename)
        if filename == "second.pdf":
            raise uploads.rejected_document_error(filename, "File size exceeds maximum size")

    monkeypatch.setattr(documents, "_upload_supporting_document_entry", upload)
    monkeypatch.setattr(documents, "choose_next_supporting_document_upload", lambda _driver: None)
    with pytest.raises(uploads.DocumentUploadError) as raised:
        documents.upload_supporting_document_entries(Driver(), [("first.pdf", "plans"), ("second.pdf", "plans"), ("third.pdf", "plans")], "unused", {})
    assert calls == ["first.pdf", "second.pdf"]
    assert raised.value.diagnostic()["uploadedCount"] == 1


def test_document_evidence_redacts_secrets_and_discards_local_path():
    error = uploads.rejected_document_error(r"C:\private\project\plan.pdf", "Rejected. token=secret Bearer private-token")
    diagnostic = error.diagnostic()
    assert diagnostic["filename"] == "plan.pdf"
    assert "private-token" not in str(diagnostic)
    assert "token=secret" not in str(diagnostic)
    assert "C:\\private" not in str(diagnostic)


def test_portal_validation_that_arrives_at_timeout_is_still_preserved(monkeypatch):
    class ExpiredWait:
        def __init__(self, *_args):
            pass

        def until(self, _predicate):
            raise TimeoutException()

    monkeypatch.setattr(uploads, "WebDriverWait", ExpiredWait)
    with pytest.raises(uploads.DocumentUploadError) as raised:
        uploads.wait_for_supporting_doc_upload_result(Driver(error="This title already exists"), "plan.pdf")
    assert raised.value.reason_code == "DUPLICATE_DOCUMENT"


def test_incident_generic_banner_does_not_invent_a_duplicate_or_file_problem():
    message = "An issue which requires your attention has occurred on this page."
    error = uploads.rejected_document_error("2023 034 - 021 - (working) Ground floor.pdf", message)
    assert error.reason_code == "PORTAL_ERROR_UNSPECIFIED"
    assert "without identifying the cause" in str(error)
    assert error.portal_message == message
    assert "already attached" in error.next_action("ePlanning")


def test_field_error_is_read_even_when_generic_banner_is_found_first():
    class DetailedDriver(Driver):
        def find_elements(self, _by, locator):
            if locator == "#MainContent_validationSummary":
                return [Element(text="An issue which requires your attention has occurred on this page.")]
            if locator == ".field-validation-error":
                return [Element(text="A document with this title already exists.")]
            return []

    assert uploads.get_visible_portal_error(DetailedDriver()) == "A document with this title already exists."

from selenium.webdriver.common.by import By

from automation.building_warrant.follow_ups import fill_text_follow_up


def test_changed_text_field_id_uses_its_visible_question_label_without_advancing():
    class Field:
        tag_name = 'textarea'
        def __init__(self): self.value = 'Old category'
        def is_displayed(self): return True
        def is_enabled(self): return True
        def get_attribute(self, key): return self.value if key == 'value' else None
        def clear(self): self.value = ''
        def send_keys(self, value): self.value += value

    class Label:
        def is_displayed(self): return True
        def get_attribute(self, key): return 'changed_listing_category' if key == 'for' else None

    class Page:
        def __init__(self): self.field = Field()
        def find_elements(self, by, key):
            if by == By.XPATH and 'listed' in key: return [Label()]
            if by == By.ID and key == 'changed_listing_category': return [self.field]
            return []
        def find_element(self, by, key): return self.find_elements(by, key)[0]
        def execute_script(self, *_args): pass

    page = Page()
    fill_text_follow_up(page, 'txtListedBuildingCategory', 'listed', 'Category B', 'listing category')
    assert page.field.value == 'Category B'

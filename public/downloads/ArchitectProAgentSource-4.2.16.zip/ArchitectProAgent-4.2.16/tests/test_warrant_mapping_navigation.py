"""Exercise saved snapshot -> real runtime adapter -> actual warrant main flow."""
import json
from pathlib import Path
import re

import pytest
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

from automation.building_warrant import certificates, main_details, navigation, owner, run as warrant
from automation.portal_adapter import runtime_job_from_portal

P = "MainContent_BuildingWarrantAppWizard_"
FIXTURE = Path(__file__).parent / 'fixtures' / 'automation-job-v2-building-warrant.json'


def job_for(keys=('domestic_alteration_extension',)):
    snapshot = json.loads(FIXTURE.read_text(encoding='utf-8'))
    record = snapshot['buildingWarrant']
    record['typeOfWorkKeys'] = list(keys)
    record.pop('typeOfWorkLabels', None)
    record['unusualAnswers']['declarationAuthorised'] = True
    record['feeCalculation'] = {'calculationStatus': 'CALCULATED', 'scheduleVersion': 'BUILDING_STANDARDS_2026', 'totalFeeMinorUnits': 76000}
    return {'id': snapshot['metadata']['jobId'], 'projectId': snapshot['metadata']['projectId'],
            'type': 'BUILDING_WARRANT', 'dataSnapshot': snapshot}


def runtime(job):
    return runtime_job_from_portal(job, [{'id': 'location', 'type': 'LOCATION_PLAN',
        'localName': 'location.pdf', 'localPath': 'C:/test/location.pdf'}], [], login_email='agent@example.test')


@pytest.mark.parametrize(('key', 'flags', 'works'), [
    ('domestic_alteration_extension', ('Yes', 'Yes', 'No', 'No', 'No'), ['Construct']),
    ('new_build', ('No', 'Yes', 'Yes', 'No', 'No'), ['Construct']),
    ('conversion_change_of_use', ('Yes', 'No', 'No', 'Yes', 'No'), ['Convert']),
    ('demolition', ('No', 'No', 'No', 'No', 'Yes'), ['Demolish']),
])
def test_real_runtime_contains_derived_work_answers(key, flags, works):
    values = runtime(job_for((key,))).user_inputs
    assert tuple(values[field] for field in ('Includes Existing Building Work', 'Includes New Building Or Extension',
        'New Building Construction', 'Conversion Regulations', 'Includes Demolition')) == flags
    assert values['Proposed Work Types'] == works


def test_multiple_saved_work_types_survive_actual_adapter():
    values = runtime(job_for(('new_build', 'conversion_change_of_use', 'demolition'))).user_inputs
    assert values['Proposed Work Types'] == ['Construct', 'Convert', 'Demolish']
    assert values['Includes Existing Building Work'] == 'Yes'
    assert values['New Building Construction'] == 'Yes'
    assert values['Conversion Regulations'] == 'Yes'
    assert values['Includes Demolition'] == 'Yes'


@pytest.mark.parametrize(('field', 'runtime_key'), [
    ('applicationIsStaged', 'Application Staged'),
    ('intendedLifeFiveYearsOrLess', 'Limited Life Building'),
    ('fireAndRescueServiceEnforcingAuthority', 'Fire Rescue Enforcing Authority'),
    ('listedBuildingOrConservationArea', 'Listed Or Conservation Area'),
    ('otherHistoricalImportance', 'Other Historical Importance'),
    ('scottishMinistersRelaxationDirection', 'Relaxation Direction'),
    ('dangerousBuildingNotice', 'Dangerous Building Notice'),
    ('approvedCertifierOfConstruction', 'Approved Certifier Construction'),
    ('coveredBySTAS', 'STAS'), ('restrictPublicInspection', 'Public Inspection Restricted'),
])
@pytest.mark.parametrize('answer', [False, True])
def test_explicit_answers_override_defaults_in_actual_runtime(field, runtime_key, answer):
    job = job_for()
    job['dataSnapshot']['buildingWarrant']['unusualAnswers'][field] = answer
    assert runtime(job).user_inputs[runtime_key] == ('Yes' if answer else 'No')


@pytest.mark.parametrize('available', [False, True])
@pytest.mark.parametrize('has_certifier', [False, True])
def test_design_choice_uses_availability_and_attached_certifier(available, has_certifier):
    job = job_for()
    record = job['dataSnapshot']['buildingWarrant']
    record['unusualAnswers']['certifierOfDesignCertificateAvailable'] = available
    if not has_certifier:
        record['certifier'] = None
    assert runtime(job).user_inputs['Approved Certifier Design'] == ('Yes' if available and has_certifier else 'No')


@pytest.mark.parametrize(('field', 'runtime_key'), [
    ('discussedWithPlanningAuthority', 'Householder Discussed With Planning Authority'),
    ('treesOnOrAdjacentToSite', 'Householder Trees On Site'),
    ('newOrAlteredVehicleAccess', 'Householder New Or Altered Vehicle Access'),
    ('soleOwner', 'Householder Sole Owner'),
    ('agriculturalHolding', 'Householder Agricultural Holding'),
])
@pytest.mark.parametrize('answer', [False, True])
def test_all_planning_choices_survive_the_actual_runtime_adapter(field, runtime_key, answer):
    job = job_for()
    job['type'] = job['dataSnapshot']['metadata']['applicationType'] = 'HOUSEHOLDER_PLANNING'
    job['dataSnapshot']['buildingWarrant'] = None
    job['dataSnapshot']['planning'] = {'recordId': 'planning_fixture', 'description': 'Alter dwelling', 'feeMinorUnits': 0,
        'answers': {field: answer, 'currentParkingSpaces': 0, 'proposedParkingSpaces': 0}}
    values = runtime(job).user_inputs
    assert values[runtime_key] == ('Yes' if answer else 'No')
    assert str(values['Householder Current Parking Spaces']) == '0'
    assert str(values['Householder Proposed Parking Spaces']) == '0'
    assert values['Calculated Fee Minor Units'] == 0


class Element:
    def __init__(self, driver, key):
        self.driver, self.key = driver, key

    def is_displayed(self): return self.key in self.driver.visible()
    def is_enabled(self): return True
    @property
    def tag_name(self): return 'select' if self.key.endswith('ddlSchemeType') else 'input'
    def get_dom_attribute(self, _name): return None
    def find_elements(self, by, value):
        if self.tag_name != 'select': return []
        options = [Option(self.driver, self.key, '', ''), Option(self.driver, self.key, '1', 'Drainage Heating and Plumbing'), Option(self.driver, self.key, '2', 'Electrical Installations to BS 7671')]
        if by == By.TAG_NAME: return options
        match = re.search(r'value\s*=\s*[\"\']([^\"\']+)', value)
        return [option for option in options if option.value == match.group(1)] if match else []
    def is_selected(self): return self.key in self.driver.checked
    def get_attribute(self, name): return self.driver.values.get(self.key, '') if name == 'value' else self.key if name == 'id' else None
    def clear(self): self.driver.values[self.key] = ''
    def send_keys(self, value): self.driver.values[self.key] = self.driver.values.get(self.key, '') + str(value)

    def click(self):
        if self.key.endswith('btnNext'):
            self.driver.advance()
        elif self.key == 'MainContent_FormSections_btnEmailNotification':
            self.driver.page = 'email'
        elif re.fullmatch(P + r'(?:W[1-4]|C(?:[1-9]|10))', self.key):
            self.driver.checkbox_clicks.append(self.key)
            self.driver.checked.symmetric_difference_update({self.key})
        else:
            self.driver.checked.add(self.key)


class Option:
    def __init__(self, driver, key, value, text): self.driver, self.key, self.value, self.text = driver, key, value, text
    def get_attribute(self, name): return self.value if name == 'value' else None
    def is_selected(self): return self.driver.values.get(self.key, '') == self.value
    def is_enabled(self): return True
    def click(self): self.driver.values[self.key] = self.value


class Portal:
    """Independent captured page order; no catch-all 'every field exists' fake."""
    pages = {
        'welcome': [], 'completed': ['rbWorkCompletedNo'], 'started': ['rbWorkStartedNo', 'rbWorkStartedYes'],
        'agent': ['ApplicantOrAgent_rbAgent', 'ApplicantOrAgent_rbAccountYes'],
        'agent_details': ['AgentDetails_txtAgentFirstName'], 'applicant_details': ['ApplicantDetails_txtApplicantFirstName'],
        'owner': ['rbApplicantOwnerYes', 'rbApplicantOwnerNo'],
        'owner_details': [],
        'construction': ['rbIncludeConstructionYes', 'rbIncludeConstructionNo'],
        'construction_use': ['txtProposedUse'], 'existing': ['rbWorkExistingBuildingYes', 'rbWorkExistingBuildingNo'],
        'existing_use': ['txtCurrentUse', 'txtProposedUseExisting'], 'conversion': ['rbConversionRegsYes', 'rbConversionRegsNo'],
        'conversion_descriptions': [f'C{i}' for i in range(1, 11)],
        'proposed': ['txtDescWork', 'W1', 'W2', 'W3', 'W4'], 'staged': ['rbApplicationStagedYes', 'rbApplicationStagedNo'],
        'demolition': ['rbDemolitionOfBuildingYes', 'rbDemolitionOfBuildingNo'], 'demolition_weeks': ['txtWeeks', 'txtMonths'], 'life': ['rbIntendedLifeYes', 'rbIntendedLifeNo'],
        'fire': ['rbUnderFireRescueYes', 'rbUnderFireRescueNo'], 'fire_name': ['txtFireAuthority'], 'listed': ['rbListedBuildingYes', 'rbListedBuildingNo'],
        'listing_category': ['txtListedBuildingCategory'],
        'historical': ['rbHistoricalYes', 'rbHistoricalNo'], 'relaxation': ['rbRelaxationDirectionYes', 'rbRelaxationDirectionNo'],
        'notices': ['txtBuildingRegComplianceNotice', 'txtBuildingWarrantEnforcementNotice', 'txtDefectiveBuildingsNotice', 'rbDangerousBuildingYes', 'rbDangerousBuildingNo'],
        'value': ['txtEstimatedValue'], 'design': ['CertificatesRegisterQuestion_rbCertificatesAccompanyYes', 'CertificatesRegisterQuestion_rbCertificatesAccompanyNo'],
        'construction_cert': ['rbCertificateAccompanyYes', 'rbCertificateAccompanyNo'],
        'construction_cert_details': ['CertificatesInformation_ddlSchemeType', 'CertificatesInformation_txtCertificateName', 'CertificatesInformation_txtCertificateNumber', 'CertificatesInformation_txtApprovedBodyName', 'CertificatesInformation_txtApprovedBodyNumber', 'CertificatesInformation_txtWorkTypeDetails'],
        'new_build': ['rbNewBuildingConstructionYes', 'rbNewBuildingConstructionNo'],
        'higher': ['rbHigherLevelsSustainabiityYes', 'rbHigherLevelsSustainabiityNo'],
        'multiple': ['rbCoverMultipleBuildingsYes', 'rbCoverMultipleBuildingsNo', 'txtNumBuildings'],
        'domestic': ['rbDomesticUseYes', 'rbDomesticUseNo'],
        'domestic_matrix': [], 'non_domestic': ['rbNonDomesticUseYes', 'rbNonDomesticUseNo'], 'non_domestic_matrix': [],
        'stas': ['rbSTASYes', 'rbSTASNo'], 'stas_reference': ['txtSTAS'], 'inspection': ['rbPublicInspectionYes', 'rbPublicInspectionNo'],
        'finish': [], 'summary': [], 'email': [],
    }

    def __init__(self):
        self.page = 'welcome'
        self.checked, self.values = set(), {}
        self.path, self.checkbox_clicks = ['welcome'], []
        self.next_clicks = 0

    def visible(self):
        result = {P + key for key in self.pages[self.page]}
        if self.page == 'owner_details':
            result.update(re.findall(r'(?:id)="([^"]+)"', FIXTURE.with_name('warrant-owner-details.html').read_text(encoding='utf-8')))
        if self.page == 'historical' and P + 'rbHistoricalYes' in self.checked: result.add(P + 'txtHistoricalBuildingDetails')
        if self.page == 'notices' and P + 'rbDangerousBuildingYes' in self.checked: result.add(P + 'txtDangerousBuildingRefNum')
        if self.page == 'relaxation' and P + 'rbRelaxationDirectionYes' in self.checked:
            result.update({P + 'RelaxationDirections_txtReferenceNumber', 'txtRelaxDirDate'})
        if self.page in ('domestic_matrix', 'non_domestic_matrix'):
            filename = 'warrant-domestic-sustainability.html' if self.page == 'domestic_matrix' else 'warrant-non-domestic-sustainability.html'
            result.update(re.findall(r'<input id="([^"]+)"', FIXTURE.with_name(filename).read_text(encoding='utf-8')))
        if self.page == 'finish': result.add(P + 'FinishNavigationTemplateContainerID_btnNext')
        elif self.page == 'summary': result.add('MainContent_FormSections_btnEmailNotification')
        elif self.page != 'email': result.add(P + 'StepNavigationTemplateContainerID_btnNext')
        return result

    def find_elements(self, by, key):
        if by == By.CSS_SELECTOR and 'month' in key:
            return [Element(self, P + 'txtMonths')] if self.page == 'demolition_weeks' else []
        if by == By.XPATH:
            match = re.fullmatch(r"//label\[@for='([^']+)'\]", key)
            key = match.group(1) if match else ''
        return [Element(self, key)] if key in self.visible() else []

    def find_element(self, by, key):
        found = self.find_elements(by, key)
        if not found: raise NoSuchElementException(f'{key} is not on {self.page}')
        return found[0]

    def execute_script(self, script, *_args): return 'complete' if 'document.readyState' in script else None

    def advance(self):
        self.next_clicks += 1
        order = list(self.pages)
        if self.page == 'owner': self.page = 'owner_details' if P + 'rbApplicantOwnerNo' in self.checked else 'construction'
        elif self.page == 'construction': self.page = 'construction_use' if P + 'rbIncludeConstructionYes' in self.checked else 'existing'
        elif self.page == 'existing': self.page = 'existing_use' if P + 'rbWorkExistingBuildingYes' in self.checked else 'proposed'
        elif self.page == 'conversion': self.page = 'conversion_descriptions' if P + 'rbConversionRegsYes' in self.checked else 'proposed'
        elif self.page == 'demolition': self.page = 'demolition_weeks' if P + 'rbDemolitionOfBuildingYes' in self.checked else 'life'
        elif self.page == 'listed': self.page = 'listing_category' if P + 'rbListedBuildingYes' in self.checked else 'historical'
        elif self.page == 'construction_cert': self.page = 'construction_cert_details' if P + 'rbCertificateAccompanyYes' in self.checked else 'new_build'
        elif self.page == 'stas': self.page = 'stas_reference' if P + 'rbSTASYes' in self.checked else 'inspection'
        elif self.page == 'fire': self.page = 'fire_name' if P + 'rbUnderFireRescueNo' in self.checked else 'listed'
        elif self.page == 'new_build': self.page = 'higher' if P + 'rbNewBuildingConstructionYes' in self.checked else 'stas'
        elif self.page == 'higher': self.page = 'multiple' if P + 'rbHigherLevelsSustainabiityYes' in self.checked else 'stas'
        elif self.page == 'domestic': self.page = 'domestic_matrix' if P + 'rbDomesticUseYes' in self.checked else 'non_domestic'
        elif self.page == 'non_domestic': self.page = 'non_domestic_matrix' if P + 'rbNonDomesticUseYes' in self.checked else 'stas'
        else: self.page = order[order.index(self.page) + 1]
        self.path.append(self.page)


class BothUsesFirstPortal(Portal):
    def advance(self):
        if self.page in ('domestic', 'non_domestic', 'domestic_matrix'):
            self.next_clicks += 1
            if self.page == 'domestic': self.page = 'non_domestic'
            elif self.page == 'non_domestic':
                self.page = 'domestic_matrix' if P + 'rbDomesticUseYes' in self.checked else 'non_domestic_matrix' if P + 'rbNonDomesticUseYes' in self.checked else 'stas'
            else: self.page = 'non_domestic_matrix' if P + 'rbNonDomesticUseYes' in self.checked else 'stas'
            self.path.append(self.page)
        else: super().advance()


class MainDetailsFinished(Exception): pass


def prepare_workflow(monkeypatch):
    for name in ('clear_checkpoint', 'record_checkpoint', 'login_to_ebuilding', 'create_proposal_and_resume', 'fill_agent_details', 'fill_applicant_details'):
        monkeypatch.setattr(warrant, name, lambda *_a, **_kw: None)
    monkeypatch.setattr(warrant.os.path, 'isdir', lambda _p: True)
    monkeypatch.setattr(warrant.os.path, 'exists', lambda _p: True)
    monkeypatch.setattr(warrant, 'load_supporting_docs_upload_list', lambda *_a, **_kw: ([], 'location.pdf', 'C:/test', {}))
    monkeypatch.setattr(warrant, 'get_paper_size_from_pdf', lambda _p: 'A4')


@pytest.mark.parametrize('existing', ['Yes', 'No'])
def test_actual_main_waits_for_each_next_screen_and_skips_absent_conversion(monkeypatch, existing):
    prepare_workflow(monkeypatch)
    inputs = runtime(job_for()).mutable_inputs()
    inputs['Declaration Authorised'] = 'Yes'
    inputs.update({'Includes Existing Building Work': existing, 'Approved Certifier Design': 'No',
                   'Proposed Work Types': ['Construct', 'Provide Services']})
    driver = Portal()
    driver.checked.add(P + 'W4')  # A resumed draft must not retain an obsolete selection.
    def progress(stage, status, _message):
        if stage == 'documents' and status == 'running': raise MainDetailsFinished()
    with pytest.raises(MainDetailsFinished):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={}, progress=progress)
    assert ('conversion' in driver.path) == (existing == 'Yes')
    assert driver.checked.intersection({P + f'W{i}' for i in range(1, 5)}) == {P + 'W1', P + 'W3'}
    assert driver.values[P + 'txtProposedUse'] == inputs['Description of Work']
    assert driver.values[P + 'txtEstimatedValue'] == str(inputs['Estimated Work Value'])
    assert driver.page == 'email'


def test_multiple_work_selection_is_verified_and_idempotent():
    driver = Portal()
    driver.page = 'proposed'
    inputs = {'Description of Work': 'Convert and extend', 'Proposed Work Types': ['Construct', 'Convert', 'Demolish']}
    main_details.fill_description_and_proposed_work(driver, inputs)
    clicks = list(driver.checkbox_clicks)
    main_details.fill_description_and_proposed_work(driver, inputs)
    assert driver.checkbox_clicks == clicks
    assert driver.checked == {P + 'W1', P + 'W2', P + 'W4'}


def test_uncertain_next_is_not_clicked_again():
    driver = Portal()
    with pytest.raises(RuntimeError, match='Next was not repeated'):
        navigation.click_next(driver, timeout=0, expected_ids=P + 'W1', screen_name='proposed work')
    assert driver.next_clicks == 1


@pytest.mark.parametrize('field', ['Conversion Regulations', 'Includes Demolition', 'STAS'])
def test_missing_follow_up_stops_before_portal_login(monkeypatch, field):
    job = runtime(job_for())
    inputs = job.mutable_inputs()
    inputs['Declaration Authorised'] = 'Yes'
    inputs[field] = 'Yes'
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError):
        warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


@pytest.mark.parametrize('value', [None, '', 0, -1, 'NaN', 'Infinity'])
def test_missing_or_invalid_value_is_rejected_without_a_default(monkeypatch, value):
    inputs = runtime(job_for()).mutable_inputs()
    inputs['Declaration Authorised'] = 'Yes'
    inputs['Estimated Work Value'] = value
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    with pytest.raises(ValueError, match='estimated value'):
        warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})


def test_owner_choice_and_fixed_work_started_are_applied_by_actual_adapter():
    job = job_for()
    job['dataSnapshot']['buildingWarrant']['unusualAnswers']['applicantIsOwner'] = False
    assert runtime(job).user_inputs['Applicant Is Owner'] == 'No'
    assert runtime(job).user_inputs['Work Started'] == 'No'
    job['dataSnapshot']['buildingWarrant']['unusualAnswers']['workStartedBeforeApplication'] = True
    with pytest.raises(Exception, match='recalculate its fee'):
        runtime(job)


def run_through_main(monkeypatch, job, extra=None, driver=None):
    prepare_workflow(monkeypatch)
    inputs = runtime(job).mutable_inputs()
    inputs['Approved Certifier Design'] = 'No'
    inputs['Declaration Authorised'] = 'Yes'
    if extra: inputs.update(extra)
    driver = driver or Portal()
    driver.values[P + 'txtNumBuildings'] = '99'
    def progress(stage, status, _message):
        if stage == 'documents' and status == 'running': raise MainDetailsFinished()
    with pytest.raises(MainDetailsFinished):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={}, progress=progress)
    return driver


@pytest.mark.parametrize('fire', [False, True])
def test_fire_no_requires_name_screen_and_yes_skips_it(monkeypatch, fire):
    job = job_for()
    job['dataSnapshot']['buildingWarrant']['unusualAnswers']['fireAndRescueServiceEnforcingAuthority'] = fire
    job['dataSnapshot']['buildingWarrant']['fireAuthorityName'] = 'Authority per app'
    driver = run_through_main(monkeypatch, job)
    assert ('fire_name' in driver.path) == (not fire)
    assert driver.values.get(P + 'txtFireAuthority') == (None if fire else 'Authority per app')


@pytest.mark.parametrize('answer', [False, True])
def test_captured_text_follow_ups_reach_the_correct_next_questions(monkeypatch, answer):
    job = job_for()
    record = job['dataSnapshot']['buildingWarrant']
    for key in ('otherHistoricalImportance', 'dangerousBuildingNotice', 'scottishMinistersRelaxationDirection'):
        record['unusualAnswers'][key] = answer
    record.update(historicalBuildingDetails='Historical association', dangerousBuildingReferences='DBN-123; DBN-456',
                  relaxationReference='RD-123', relaxationDate='2026-11-01')
    driver = run_through_main(monkeypatch, job)
    for key, text in {'txtHistoricalBuildingDetails': 'Historical association', 'txtDangerousBuildingRefNum': 'DBN-123; DBN-456', 'RelaxationDirections_txtReferenceNumber': 'RD-123'}.items():
        assert driver.values.get(P + key) == (text if answer else None)
    assert driver.values.get('txtRelaxDirDate') == ('01/11/2026' if answer else None)


@pytest.mark.parametrize(('domestic', 'non_domestic'), [(True, False), (False, True), (True, True)])
@pytest.mark.parametrize('multiple', [False, True])
@pytest.mark.parametrize('portal_type', [Portal, BothUsesFirstPortal])
def test_actual_new_build_flow_uses_captured_domestic_and_non_domestic_ids(monkeypatch, domestic, non_domestic, multiple, portal_type):
    job = job_for(('new_build',))
    job['dataSnapshot']['buildingWarrant']['sustainability'] = {
        'higherLevels': True, 'multipleBuildings': multiple, 'buildingCount': 3,
        'domesticUse': domestic, 'nonDomesticUse': non_domestic,
        'domesticLevels': ['platinum'] + ['silver', 'gold', 'silver', 'gold', 'silver', 'gold', 'silver'],
        'nonDomesticLevels': ['bronze_active'] + ['gold'] * 7,
    }
    driver = run_through_main(monkeypatch, job, driver=portal_type())
    assert driver.path.count('domestic_matrix') == int(domestic)
    assert driver.path.count('non_domestic_matrix') == int(non_domestic)
    assert ('domestic_matrix' in driver.path) == domestic
    assert ('non_domestic_matrix' in driver.path) == non_domestic
    assert driver.values[P + 'txtNumBuildings'] == ('3' if multiple else '')
    if domestic:
        assert P + 'SustainabilityDomesticLevels_dgDomesticSustainability_platinumActiveCheckBox_0' in driver.checked
        for row, token in enumerate(['silver', 'gold', 'silver', 'gold', 'silver', 'gold', 'silver'], 1):
            assert P + f'SustainabilityDomesticLevels_dgDomesticSustainability_{token if token == "silver" else "goldActive"}CheckBox_{row}' in driver.checked
    if non_domestic:
        assert P + 'SustainabilityNonDomesticLevels_dgNonDomesticSustainability_bronzeActiveCheckBox_0' in driver.checked
        for row in range(1, 8): assert P + f'SustainabilityNonDomesticLevels_dgNonDomesticSustainability_goldActiveCheckBox_{row}' in driver.checked
    assert driver.page == 'email'


def test_new_build_lower_sustainability_skips_all_higher_level_screens(monkeypatch):
    job = job_for(('new_build',))
    job['dataSnapshot']['buildingWarrant']['sustainability'] = {'higherLevels': False}
    driver = run_through_main(monkeypatch, job)
    assert 'higher' in driver.path
    assert not set(['multiple', 'domestic', 'domestic_matrix', 'non_domestic', 'non_domestic_matrix']).intersection(driver.path)


@pytest.mark.parametrize(('answer', 'field', 'text'), [
    ('Fire Rescue Enforcing Authority', 'Fire Authority Name', ''),
    ('Fire Rescue Enforcing Authority', 'Fire Authority Name', 'x' * 21),
    ('Other Historical Importance', 'Historical Building Details', ''),
    ('Other Historical Importance', 'Historical Building Details', 'x' * 751),
    ('Dangerous Building Notice', 'Dangerous Building References', ''),
    ('Dangerous Building Notice', 'Dangerous Building References', 'x' * 751),
    ('Relaxation Direction', 'Relaxation Reference', ''),
    ('Relaxation Direction', 'Relaxation Date', '2026-02-30'),
])
def test_missing_or_invalid_follow_ups_stop_before_login(monkeypatch, answer, field, text):
    inputs = runtime(job_for()).mutable_inputs()
    inputs['Declaration Authorised'] = 'Yes'
    inputs.update({'Fire Authority Name': 'Valid authority', 'Relaxation Reference': 'RD-1', 'Relaxation Date': '2026-11-01'})
    inputs[answer] = 'No' if answer == 'Fire Rescue Enforcing Authority' else 'Yes'
    inputs[field] = text
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError): warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


@pytest.mark.parametrize('source', ['CLIENT', 'MANUAL'])
def test_owner_no_fills_all_captured_owner_fields_and_continues(monkeypatch, source):
    from automation.building_warrant.owner import FIELDS
    job = job_for()
    record = job['dataSnapshot']['buildingWarrant']
    record['unusualAnswers']['applicantIsOwner'] = False
    details = {'title': 'Ms', 'firstName': 'Property', 'lastName': 'Owner', 'telephone': '01410000000',
               'email': 'owner@example.test', 'buildingNumber': '12', 'addressLine1': 'Owner Street',
               'townCity': 'Glasgow', 'country': 'United Kingdom', 'postcode': 'G1 1AA', 'source': source}
    record['owner'] = details
    record['ownerIsClient'] = source == 'CLIENT'
    titles = []
    monkeypatch.setattr(owner, 'select_applicant_title', lambda driver, element_id, title, *_a, **_kw: titles.append((element_id, title)))
    driver = run_through_main(monkeypatch, job)
    assert 'owner_details' in driver.path
    assert titles == [(P + 'OwnerDetails_ddlOwnerTitle', 'Ms')]
    for key, (suffix, _limit) in FIELDS.items():
        assert driver.values.get(P + 'OwnerDetails_' + suffix, '') == details.get(key, '')
    assert driver.page == 'email'


def test_owner_no_with_incomplete_client_copy_stops_before_login(monkeypatch):
    inputs = runtime(job_for()).mutable_inputs()
    inputs['Declaration Authorised'] = 'Yes'
    inputs.update({'Applicant Is Owner': 'No', 'Owner Details': {'title': 'Ms', 'firstName': 'Missing contact'}})
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError, match="property owner's"):
        warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


class AfterNextFollowUps(Portal):
    pages = {**Portal.pages, 'historical_details': ['txtHistoricalBuildingDetails'],
             'relaxation_details': ['RelaxationDirections_txtReferenceNumber'], 'dangerous_details': ['txtDangerousBuildingRefNum']}

    def visible(self):
        result = super().visible()
        if self.page == 'historical': result.discard(P + 'txtHistoricalBuildingDetails')
        if self.page == 'relaxation': result.difference_update({P + 'RelaxationDirections_txtReferenceNumber', 'txtRelaxDirDate'})
        if self.page == 'notices': result.discard(P + 'txtDangerousBuildingRefNum')
        if self.page == 'relaxation_details': result.add('txtRelaxDirDate')
        return result

    def advance(self):
        routes = {'historical': 'historical_details', 'historical_details': 'relaxation',
                  'relaxation': 'relaxation_details', 'relaxation_details': 'notices',
                  'notices': 'dangerous_details', 'dangerous_details': 'value'}
        if self.page in routes:
            self.next_clicks += 1
            self.page = routes[self.page]
            self.path.append(self.page)
        else: super().advance()


def test_actual_main_handles_omitted_next_before_follow_up_details(monkeypatch):
    job = job_for()
    record = job['dataSnapshot']['buildingWarrant']
    for key in ('otherHistoricalImportance', 'dangerousBuildingNotice', 'scottishMinistersRelaxationDirection'):
        record['unusualAnswers'][key] = True
    record.update(historicalBuildingDetails='History', dangerousBuildingReferences='DB-1', relaxationReference='RD-1', relaxationDate='2026-11-01')
    driver = run_through_main(monkeypatch, job, driver=AfterNextFollowUps())
    assert {'historical_details', 'relaxation_details', 'dangerous_details'}.issubset(driver.path)
    assert driver.values['txtRelaxDirDate'] == '01/11/2026'
    assert driver.page == 'email'


@pytest.mark.parametrize(('work_types', 'extra', 'expected_page', 'expected_field', 'expected_value'), [
    (('conversion_change_of_use',), {'Conversion Descriptions': ['C1', 'C3', 'C10']}, 'conversion_descriptions', 'C1', None),
    (('demolition',), {'Demolition Weeks': 12}, 'demolition_weeks', 'txtWeeks', '12'),
    (('domestic_alteration_extension',), {'Listed Or Conservation Area': 'Yes', 'Listing Category': 'Category B'}, 'listing_category', 'txtListedBuildingCategory', 'Category B'),
    (('domestic_alteration_extension',), {'STAS': 'Yes', 'STAS Reference': 'STAS-123'}, 'stas_reference', 'txtSTAS', 'STAS-123'),
    (('domestic_alteration_extension',), {'Approved Certifier Construction': 'Yes', 'Construction Certificate': {
        'schemeType': '2', 'certifierName': 'Electrical Certifier', 'registrationNumber': 'EC-1',
        'approvedBody': 'Approved Body', 'approvedBodyRegistrationNumber': 'AB-1', 'workTypeDetails': 'New electrical installation'}},
        'construction_cert_details', 'CertificatesInformation_ddlSchemeType', '2'),
])
def test_captured_remaining_yes_branches_run_to_final_main_details(monkeypatch, work_types, extra, expected_page, expected_field, expected_value):
    driver = Portal()
    driver.checked.add(P + 'C2')
    driver.values[P + 'txtMonths'] = '8'
    driver = run_through_main(monkeypatch, job_for(work_types), extra=extra, driver=driver)
    assert expected_page in driver.path
    if expected_value is not None: assert driver.values[P + expected_field] == expected_value
    if expected_page == 'conversion_descriptions':
        assert driver.checked.intersection({P + f'C{i}' for i in range(1, 11)}) == {P + key for key in extra['Conversion Descriptions']}
    if expected_page == 'demolition_weeks': assert driver.values[P + 'txtMonths'] == ''
    if expected_page == 'construction_cert_details': assert driver.values[P + 'CertificatesInformation_txtWorkTypeDetails'] == extra['Construction Certificate']['workTypeDetails']
    assert driver.page == 'email'


@pytest.mark.parametrize(('field', 'value', 'extra'), [
    ('Conversion Descriptions', [], {'Conversion Regulations': 'Yes'}),
    ('Conversion Descriptions', ['C11'], {'Conversion Regulations': 'Yes'}),
    ('Demolition Weeks', 0, {'Includes Demolition': 'Yes'}),
    ('Demolition Weeks', 100, {'Includes Demolition': 'Yes'}),
    ('Demolition Weeks', 1.5, {'Includes Demolition': 'Yes'}),
    ('Listing Category', 'x' * 751, {'Listed Or Conservation Area': 'Yes'}),
    ('STAS Reference', 'x' * 21, {'STAS': 'Yes'}),
    ('Construction Certificate', {'schemeType': '3'}, {'Approved Certifier Construction': 'Yes'}),
])
def test_incomplete_captured_follow_ups_are_rejected_before_login(monkeypatch, field, value, extra):
    inputs = runtime(job_for()).mutable_inputs()
    inputs.update({'Declaration Authorised': 'Yes', **extra, field: value})
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError): warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


def test_no_declaration_permission_never_opens_the_portal(monkeypatch):
    inputs = runtime(job_for()).mutable_inputs()
    inputs['Declaration Authorised'] = 'No'
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError, match='authorise the portal declaration'):
        warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


class AddedRelaxationRow:
    def __init__(self, entry): self.text = entry['reference'] + ' ' + entry['date']
    def is_displayed(self): return True


class AddRelaxationButton:
    def __init__(self, driver): self.driver = driver
    def click(self):
        key = P + 'RelaxationDirections_txtReferenceNumber'
        self.driver.relaxation_rows.append({'reference': self.driver.values[key], 'date': self.driver.values['txtRelaxDirDate']})
        self.driver.values[key] = self.driver.values['txtRelaxDirDate'] = ''


class MultipleRelaxationsPortal(Portal):
    def __init__(self):
        super().__init__()
        self.relaxation_rows = []
        self.ambiguous_add = False
    def execute_script(self, script, *_args):
        if 'ARCHPRO_RELAXATION_ADD' in script:
            return [AddRelaxationButton(self)] * (2 if self.ambiguous_add else 1)
        return super().execute_script(script, *_args)
    def find_elements(self, by, key):
        if by == By.CSS_SELECTOR and key == 'tr,li,[role="row"]':
            return [AddedRelaxationRow(entry) for entry in self.relaxation_rows]
        return super().find_elements(by, key)


def test_multiple_relaxation_directions_are_added_and_confirmed_before_next(monkeypatch):
    driver = MultipleRelaxationsPortal()
    run_through_main(monkeypatch, job_for(), extra={'Relaxation Direction': 'Yes', 'Relaxation Directions': [
        {'reference': 'RD-1', 'date': '2026-11-01'}, {'reference': 'RD-2', 'date': '2024-02-29'},
    ]}, driver=driver)
    assert driver.relaxation_rows == [{'reference': 'RD-1', 'date': '01/11/2026'}, {'reference': 'RD-2', 'date': '29/02/2024'}]
    assert driver.page == 'email'


def test_multiple_relaxations_never_click_an_ambiguous_add_control(monkeypatch):
    prepare_workflow(monkeypatch)
    inputs = runtime(job_for()).mutable_inputs()
    inputs.update({'Declaration Authorised': 'Yes', 'Relaxation Direction': 'Yes', 'Approved Certifier Design': 'No', 'Relaxation Directions': [
        {'reference': 'RD-1', 'date': '2026-11-01'}, {'reference': 'RD-2', 'date': '2026-11-02'},
    ]})
    driver = MultipleRelaxationsPortal()
    driver.ambiguous_add = True
    with pytest.raises(RuntimeError, match='unambiguous Add direction'):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={})
    assert driver.relaxation_rows == []


@pytest.mark.parametrize('directions', [[{'reference': '', 'date': '2026-11-01'}], [{'reference': 'RD-1', 'date': '2026-02-30'}], [{'reference': 'RD-1', 'date': '2026-11-01'}] * 21])
def test_bad_relaxation_list_stops_before_login(monkeypatch, directions):
    inputs = runtime(job_for()).mutable_inputs()
    inputs.update({'Declaration Authorised': 'Yes', 'Relaxation Direction': 'Yes', 'Relaxation Directions': directions})
    calls = []
    monkeypatch.setattr(warrant, 'clear_checkpoint', lambda: None)
    monkeypatch.setattr(warrant, 'login_to_ebuilding', lambda *_a: calls.append('login'))
    with pytest.raises(ValueError): warrant.main(user_inputs=inputs, password='test-only', driver=Portal(), document_mapping={})
    assert calls == []


class DeferredNextPortal(Portal):
    def __init__(self):
        super().__init__()
        self.pending_next = 0
    def advance(self): self.pending_next = 3
    def find_elements(self, by, key):
        if self.pending_next:
            self.pending_next -= 1
            if not self.pending_next: super().advance()
        return super().find_elements(by, key)


def test_sustainability_waits_past_the_old_controls_during_postback(monkeypatch):
    job = job_for(('new_build',))
    job['dataSnapshot']['buildingWarrant']['sustainability'] = {
        'higherLevels': True, 'multipleBuildings': False,
        'domesticUse': True, 'nonDomesticUse': True,
        'domesticLevels': ['silver'] * 8, 'nonDomesticLevels': ['gold'] * 8,
    }
    driver = run_through_main(monkeypatch, job, driver=DeferredNextPortal())
    assert driver.path.count('domestic_matrix') == 1
    assert driver.path.count('non_domestic_matrix') == 1
    assert driver.page == 'email'


@pytest.mark.parametrize('skip_required', [False, True])
def test_sustainability_does_not_skip_or_accept_an_unrequested_matrix(monkeypatch, skip_required):
    class UnexpectedPortal(BothUsesFirstPortal):
        def advance(self):
            if (skip_required and self.page == 'non_domestic') or (not skip_required and self.page == 'domestic'):
                self.next_clicks += 1
                self.page = 'stas' if skip_required else 'non_domestic_matrix'
                self.path.append(self.page)
            else: super().advance()
    job = job_for(('new_build',))
    job['dataSnapshot']['buildingWarrant']['sustainability'] = {'higherLevels': True, 'multipleBuildings': False,
        'domesticUse': True, 'nonDomesticUse': False, 'domesticLevels': ['silver'] * 8}
    inputs = runtime(job).mutable_inputs()
    inputs.update({'Approved Certifier Design': 'No', 'Declaration Authorised': 'Yes'})
    prepare_workflow(monkeypatch)
    driver = UnexpectedPortal()
    with pytest.raises(RuntimeError, match='skipped a required sustainability' if skip_required else 'unexpected non-domestic sustainability'):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping={})
    assert 'email' not in driver.path

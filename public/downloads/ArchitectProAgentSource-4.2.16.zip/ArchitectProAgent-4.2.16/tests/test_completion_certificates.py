import pytest

from automation.building_warrant.certificates import CertificateValidationError
from automation.completion_certificate.certificates import (
    CONSTRUCTION,
    DESIGN,
    RegisterStateError,
    fill_register,
    pager,
    validate_entries,
)
from automation.completion_certificate.fields import PREFIX

from completion_fakes import FakeDriver, FakeRegister


def entry(number="CC-100", part1="SEL1", spec=CONSTRUCTION, **change):
    value = {
        "certificateNumber": number,
        "certifierRegistration": {"part1": part1, "part2": spec.certifier_part2, "number": "12345"},
        "certifierSignatureDate": "2026-03-05",
        "approvedBodyRegistration": {"part1": part1, "part2": spec.approved_body_part2, "number": "678"},
        "approvedBodySignatureDate": "2026-10-02",
        "documentId": None,
    }
    value.update(change)
    return value


def register(spec=CONSTRUCTION, **options):
    driver = FakeDriver()
    fake = FakeRegister(driver, spec.prefix, spec.scheme, spec.part1, spec.certifier_part2, spec.approved_body_part2, **options)
    return driver, fake


def saved(number="CC-100", a_number="12345"):
    return {"scheme": "Construction", "number": number, "a1": "SEL1", "a2": "C", "a_number": a_number, "a_date": "05/03/2026",
            "b1": "SEL1", "b2": "CB", "b_number": "678", "b_date": "02/10/2026"}


def test_register_specs_match_the_portal():
    assert CONSTRUCTION.prefix == PREFIX + "CertificatesRegister_"
    assert DESIGN.prefix == PREFIX + "CertificatesRegister1_"
    assert (CONSTRUCTION.scheme, CONSTRUCTION.part1, CONSTRUCTION.certifier_part2, CONSTRUCTION.approved_body_part2) == (
        "Construction", ("NIC1", "SEL1", "SNP1"), "C", "CB")
    assert (DESIGN.scheme, DESIGN.part1, DESIGN.certifier_part2, DESIGN.approved_body_part2) == (
        "Design", ("BRE1", "BRE2", "RIA1", "RIA2", "SER1"), "D", "DB")


def test_single_entry_fills_the_blank_first_entry():
    driver, fake = register()
    fill_register(driver, [entry()], CONSTRUCTION)
    assert pager(driver, CONSTRUCTION) == (1, 1)
    assert fake.entries == [saved()]
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 0
    assert fake.validated == [1]


def test_dates_typed_as_portal_dates():
    driver, fake = register()
    fill_register(driver, [entry()], CONSTRUCTION)
    assert fake.entries[0]["a_date"] == "05/03/2026"
    assert fake.entries[0]["b_date"] == "02/10/2026"


def test_three_entries_add_twice():
    driver, fake = register()
    fill_register(driver, [entry("CC-1"), entry("CC-2", "NIC1"), entry("CC-3", "SNP1")], CONSTRUCTION)
    assert pager(driver, CONSTRUCTION) == (3, 3)
    assert [item["number"] for item in fake.entries] == ["CC-1", "CC-2", "CC-3"]
    assert [item["a1"] for item in fake.entries] == ["SEL1", "NIC1", "SNP1"]
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 2
    assert fake.validated == [1, 2, 3]


def test_design_register_uses_design_codes():
    driver, fake = register(DESIGN)
    fill_register(driver, [entry("FQ-200", "SER1", DESIGN)], DESIGN)
    assert (fake.entries[0]["scheme"], fake.entries[0]["a2"], fake.entries[0]["b2"]) == ("Design", "D", "DB")


def test_saved_entries_corrected_in_place():
    driver, fake = register(saved=[saved("CC-1", a_number="00000"), saved("CC-2")])
    fake.current = 1
    fake.load()                                  # the earlier run left the pager on entry 2
    fill_register(driver, [entry("CC-1"), entry("CC-2")], CONSTRUCTION)
    assert fake.entries[0]["a_number"] == "12345"
    assert len(fake.entries) == 2
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 0
    typed = [item[1] for item in driver.typed()]
    assert typed == [CONSTRUCTION.prefix + "txtCertifierRegNo"], "only the changed field is retyped"
    assert fake.validated == [1, 2]


def test_saved_entries_then_one_more():
    driver, fake = register(saved=[saved("CC-1")])
    fill_register(driver, [entry("CC-1"), entry("CC-2")], CONSTRUCTION)
    assert [item["number"] for item in fake.entries] == ["CC-1", "CC-2"]
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 1


def test_extra_saved_entries_stop():
    driver, fake = register(saved=[saved("CC-1"), saved("CC-2"), saved("CC-3")])
    with pytest.raises(RegisterStateError, match="3 .*2"):
        fill_register(driver, [entry("CC-1"), entry("CC-2")], CONSTRUCTION)
    assert driver.clicks(CONSTRUCTION.prefix + "btnRemoveCertificate") == 0
    assert driver.typed() == []
    assert RegisterStateError.confirmation_required is True


def test_missing_option_lists_what_the_portal_offers():
    driver, fake = register()
    fake.part1 = ["NIC1", "SNP1"]                 # the portal no longer offers SEL1
    with pytest.raises(RuntimeError) as error:
        fill_register(driver, [entry()], CONSTRUCTION, timeout=0.5)
    assert "SEL1" in str(error.value) and "NIC1" in str(error.value) and "SNP1" in str(error.value)
    assert fake.validated == []


def test_validation_rejection_names_the_entry():
    driver, fake = register(invalid_entries={2})
    with pytest.raises(CertificateValidationError) as error:
        fill_register(driver, [entry("CC-1"), entry("CC-2")], CONSTRUCTION)
    assert "certificate of construction 2" in str(error.value).lower()
    assert "invalid" in str(error.value).lower()
    assert fake.validated == [1, 2]
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 1


def test_validation_timeout_is_not_repeated():
    driver, fake = register(validation="none")
    with pytest.raises(RuntimeError, match="Validation Check was not repeated"):
        fill_register(driver, [entry()], CONSTRUCTION, timeout=0.5)
    assert driver.clicks(CONSTRUCTION.prefix + "btnValidate") == 1


def test_add_not_confirmed_is_not_repeated():
    driver, fake = register(add_works=False)
    with pytest.raises(RuntimeError, match="Add was not repeated"):
        fill_register(driver, [entry("CC-1"), entry("CC-2")], CONSTRUCTION, timeout=0.5)
    assert driver.clicks(CONSTRUCTION.prefix + "btnAddCertificate") == 1
    assert len(fake.entries) == 1


@pytest.mark.parametrize("bad", [
    [],
    [entry(part1="SER1")],                                       # a design code in the construction register
    [entry(certificateNumber="")],
    [entry(certifierSignatureDate="05/03/2026")],
    [entry(approvedBodySignatureDate=None)],
    [entry(certifierRegistration={"part1": "SEL1", "part2": "D", "number": "1"})],
    [entry(approvedBodyRegistration={"part1": "SEL1", "part2": "CB", "number": ""})],
    [entry()] * 21,
])
def test_validate_entries_rejects_before_any_portal_action(bad):
    driver, fake = register()
    with pytest.raises(ValueError):
        fill_register(driver, bad, CONSTRUCTION)
    assert driver.log == []


def test_validate_entries_names_the_entry_number():
    with pytest.raises(ValueError, match="certificate of construction 2"):
        validate_entries([entry(), entry(certificateNumber=" ")], CONSTRUCTION)
    validate_entries([entry()], CONSTRUCTION)

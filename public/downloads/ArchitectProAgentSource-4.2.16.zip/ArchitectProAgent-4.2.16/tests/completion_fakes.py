"""A small in-memory page model for completion-certificate tests.

It behaves like the parts of Selenium the workflow uses, including ASP.NET
postbacks: after a postback every element handle obtained earlier is stale,
exactly as on the real portal, so code that fails to look a control up again
fails here too. Nothing in this module opens a browser.
"""

from __future__ import annotations

import re

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException
from selenium.webdriver.common.by import By


class Field:
    """State of one control. Handles returned to the code under test wrap this."""

    def __init__(self, element_id, kind="text", value="", text="", options=(), visible=True,
                 group=None, on_click=None, on_change=None, target=None, enabled=True):
        self.element_id = element_id
        self.kind = kind            # text | textarea | radio | label | button | select | option | message | link
        self.value = value
        self.text = text
        self.options = list(options)
        self.visible = visible
        self.group = group
        self.on_click = on_click
        self.on_change = on_change
        self.target = target        # label -> radio id
        self.enabled = enabled
        self.selected = False


class Handle:
    def __init__(self, driver, field, option=None):
        self._driver = driver
        self._field = field
        self._option = option
        self._generation = driver.generation
        self.id = f"{field.element_id}:{option}:{self._generation}"

    def _live(self):
        if self._generation != self._driver.generation:
            raise StaleElementReferenceException("stale element reference: a postback replaced this control")
        return self._field

    @property
    def tag_name(self):
        if self._option is not None:
            return "option"
        return {"text": "input", "radio": "input", "button": "input", "textarea": "textarea",
                "select": "select", "label": "label", "message": "span", "link": "a"}[self._field.kind]

    @property
    def text(self):
        field = self._live()
        if self._option is not None:
            return self._option
        return field.text or (field.value if field.kind in ("button", "link") else "")

    def is_displayed(self):
        field = self._live()
        return field.visible and self._driver.is_visible(field.element_id)

    def is_enabled(self):
        return self._live().enabled

    def is_selected(self):
        field = self._live()
        if self._option is not None:
            return field.value == self._option
        return field.selected

    def get_attribute(self, name):
        field = self._live()
        if name == "value":
            return self._option if self._option is not None else field.value
        if name == "id":
            return field.element_id
        if name == "for":
            return field.target
        if name == "type":
            return {"radio": "radio", "button": "submit", "text": "text"}.get(field.kind)
        return None

    def get_dom_attribute(self, name):
        return None if name == "multiple" else self.get_attribute(name)

    def clear(self):
        field = self._live()
        self._driver.log.append(("clear", field.element_id))
        field.value = ""

    def send_keys(self, text):
        field = self._live()
        self._driver.log.append(("type", field.element_id, text))
        field.value += text

    def click(self):
        field = self._live()
        if not self.is_displayed():
            raise AssertionError(f"clicked a hidden control: {field.element_id}")
        if self._option is not None:
            self._driver.log.append(("select", field.element_id, self._option))
            field.value = self._option
            if field.on_change:
                field.on_change(self._driver)
            return
        self._driver.log.append(("click", field.element_id))
        if field.kind == "label" and field.target:
            self._driver.select_radio(field.target)
        elif field.kind == "radio":
            self._driver.select_radio(field.element_id)
        if field.on_click:
            field.on_click(self._driver)

    def find_elements(self, by, value):
        field = self._live()
        if field.kind != "select":
            return []
        if by == By.TAG_NAME and value == "option":
            return [Handle(self._driver, field, option) for option in field.options]
        match = re.search(r"normalize-space\(\.\) = \"(.*)\"\]$", value) if by == By.XPATH else None
        if match:
            return [Handle(self._driver, field, option) for option in field.options if option == match.group(1)]
        return []


class FakeDriver:
    """Looks controls up by id, by label ``for=``, and by the few selectors the workflow uses."""

    def __init__(self):
        self.fields = {}
        self.generation = 0
        self.log = []
        self.current_url = "https://www.ebuildingstandards.scot/eBuildingStandardsClient/"
        self.visible_ids = None     # None = every field; otherwise the ids on the current screen
        self.scripts = {}           # marker text in a script -> callable returning its result

    # ---- page model -----------------------------------------------------
    def add(self, element_id, **kwargs):
        self.fields[element_id] = Field(element_id, **kwargs)
        return self.fields[element_id]

    def add_radio(self, element_id, group, selected=False, on_click=None):
        radio = self.add(element_id, kind="radio", group=group, on_click=on_click)
        radio.selected = selected
        self.add(f"label:{element_id}", kind="label", target=element_id, text=element_id)
        return radio

    def postback(self):
        self.generation += 1

    def is_visible(self, element_id):
        if self.visible_ids is None or self.fields[element_id].kind == "message":
            return True   # a validation result panel belongs to whichever screen produced it
        target = self.fields[element_id].target if element_id.startswith("label:") else element_id
        return target in self.visible_ids

    def select_radio(self, element_id):
        radio = self.fields[element_id]
        for other in self.fields.values():
            if other.kind == "radio" and other.group == radio.group:
                other.selected = False
        radio.selected = True
        if radio.on_click:
            radio.on_click(self)

    def value(self, element_id):
        return self.fields[element_id].value

    def selected(self, element_id):
        return self.fields[element_id].selected

    def clicks(self, element_id):
        return sum(1 for entry in self.log if entry[:2] in (("click", element_id), ("click", f"label:{element_id}")))

    def typed(self):
        return [entry for entry in self.log if entry[0] == "type"]

    # ---- Selenium surface ----------------------------------------------
    def find_elements(self, by, value):
        if by == By.ID:
            return [Handle(self, self.fields[value])] if value in self.fields else []
        if by == By.XPATH:
            label = re.fullmatch(r"//label\[@for='([^']+)'\]", value)
            if label:
                key = f"label:{label.group(1)}"
                return [Handle(self, self.fields[key])] if key in self.fields else []
            if "validation check" in value:
                return [Handle(self, field) for field in self.fields.values()
                        if field.kind == "button" and field.value == "Validation Check" and self.is_visible(field.element_id)]
            return []
        if by == By.CSS_SELECTOR and "valid" in value:
            return [Handle(self, field) for field in self.fields.values() if field.kind == "message" and field.visible]
        if by == By.TAG_NAME and value == "body":
            return [Handle(self, Field("body", kind="message", text=""))]
        return []

    def find_element(self, by, value):
        found = self.find_elements(by, value)
        if not found:
            raise NoSuchElementException(f"{by}={value}")
        return found[0]

    def execute_script(self, script, *args):
        if "document.readyState" in script:
            return "complete"
        for marker, handler in self.scripts.items():
            if marker in script:
                return handler(*args)
        return None


BLANK_ENTRY = {
    "scheme": "Please select Scheme Type...", "number": "", "a1": "...", "a2": "...", "a_number": "", "a_date": "",
    "b1": "...", "b2": "...", "b_number": "", "b_date": "",
}


class FakeRegister:
    """One certificate register (construction or Form Q) with pager, postbacks and validation.

    ``validation`` is "valid", "invalid" or "none" (the portal never answers).
    ``saved`` pre-populates entries, as a rerun over an earlier draft would find them.
    """

    def __init__(self, driver, prefix, scheme, part1, certifier_part2, body_part2, *, saved=None,
                 validation="valid", add_works=True, invalid_entries=()):
        self.driver = driver
        self.prefix = prefix
        self.scheme = scheme
        self.part1 = list(part1)
        self.certifier_part2 = certifier_part2
        self.body_part2 = body_part2
        self.validation = validation
        self.add_works = add_works
        self.invalid_entries = set(invalid_entries)
        self.entries = [dict(BLANK_ENTRY, **entry) for entry in (saved or [])] or [dict(BLANK_ENTRY)]
        self.current = 0
        self.validated = []
        p = prefix
        self.ids = {
            "scheme": p + "ddlSchemeType", "number": p + "txtCertificateNumber",
            "a1": p + "ddlCertifierRegNo1", "a2": p + "ddlCertifierRegNo2", "a_number": p + "txtCertifierRegNo",
            "a_date": "txtCertifierSignatureDate",
            "b1": p + "ddlApprovedBodyRegNo1", "b2": p + "ddlApprovedBodyRegNo2", "b_number": p + "txtApprovedBodyRegNo",
            "b_date": "txtApprovedBodySignatureDate",
        }
        driver.add(self.ids["scheme"], kind="select", on_change=self._changed)
        driver.add(self.ids["a1"], kind="select", on_change=self._changed)
        driver.add(self.ids["a2"], kind="select")
        driver.add(self.ids["b1"], kind="select")
        driver.add(self.ids["b2"], kind="select")
        for key in ("number", "a_number", "a_date", "b_number", "b_date"):
            driver.add(self.ids[key])
        driver.add(p + "btnAddCertificate", kind="button", value="Add", on_click=lambda _d: self._add())
        driver.add(p + "btnNextCertificate", kind="button", value=">", on_click=lambda _d: self._move(self.current + 1))
        driver.add(p + "btnPreviousCertificate", kind="button", value="<", on_click=lambda _d: self._move(self.current - 1))
        driver.add(p + "btnFirstCertificate", kind="button", value="<<", on_click=lambda _d: self._move(0))
        driver.add(p + "btnLastCertificate", kind="button", value=">>", on_click=lambda _d: self._move(len(self.entries) - 1))
        driver.add(p + "btnRemoveCertificate", kind="button", value="Remove")
        driver.add(p + "btnValidate", kind="button", value="Validation Check", on_click=lambda _d: self._validate())
        driver.scripts["ARCHPRO_REGISTER_PAGER"] = self._pager
        self.load()

    def element_ids(self):
        p = self.prefix
        return set(self.ids.values()) | {p + name for name in (
            "btnAddCertificate", "btnNextCertificate", "btnPreviousCertificate", "btnFirstCertificate",
            "btnLastCertificate", "btnRemoveCertificate", "btnValidate")}

    def _pager(self, add_button_id):
        return f"Please provide details. {self.current + 1}/{len(self.entries)}" if add_button_id.startswith(self.prefix) else ""

    def _options(self):
        entry = self.entries[self.current]
        chosen = entry["scheme"] == self.scheme
        self.driver.fields[self.ids["scheme"]].options = ["Please select Scheme Type...", self.scheme]
        self.driver.fields[self.ids["a1"]].options = ["..."] + (self.part1 if chosen else [])
        self.driver.fields[self.ids["b1"]].options = ["..."] + (self.part1 if chosen else [])
        self.driver.fields[self.ids["a2"]].options = ["..."] + ([self.certifier_part2] if entry["a1"] != "..." else [])
        self.driver.fields[self.ids["b2"]].options = ["..."] + ([self.body_part2] if chosen else [])

    def load(self):
        """Show the current entry in the page's fields (call when this register's screen opens)."""
        self.driver.scripts["ARCHPRO_REGISTER_PAGER"] = self._pager
        for key, element_id in self.ids.items():
            self.driver.fields[element_id].value = self.entries[self.current][key]
        self._options()
        for field in list(self.driver.fields.values()):
            if field.kind == "message":
                del self.driver.fields[field.element_id]

    def store(self):
        for key, element_id in self.ids.items():
            self.entries[self.current][key] = self.driver.fields[element_id].value

    def _changed(self, driver):
        self.store()
        entry = self.entries[self.current]
        if entry["scheme"] != self.scheme:
            entry.update(a1="...", a2="...", b1="...", b2="...")
        if entry["a1"] == "...":
            entry["a2"] = "..."
        driver.postback()
        self.load()

    def _move(self, index):
        self.store()
        self.current = max(0, min(len(self.entries) - 1, index))
        self.driver.postback()
        self.load()

    def _add(self):
        self.store()
        if self.add_works:
            self.entries.append(dict(BLANK_ENTRY))
            self.current = len(self.entries) - 1
        self.driver.postback()
        self.load()

    def _validate(self):
        self.store()
        self.validated.append(self.current + 1)
        if self.validation == "none":
            return
        self.driver.postback()
        self.load()
        bad = self.validation == "invalid" or (self.current + 1) in self.invalid_entries
        self.driver.add(
            "validation-result", kind="message",
            text="The certifier registration number is invalid." if bad else "Validation successful.",
        )

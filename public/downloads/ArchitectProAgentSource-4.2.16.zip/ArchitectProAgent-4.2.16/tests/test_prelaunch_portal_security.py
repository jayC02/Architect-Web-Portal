import io
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import Mock

import pytest

from gui.services import agent_update, callback_outbox, portal_handoff


@pytest.mark.parametrize('url', [
    'https://untrusted.test', 'https://www.architectpro.co.uk.evil.test',
    'https://www.architectpro.co.uk:444', 'http://www.architectpro.co.uk',
    'https://user@www.architectpro.co.uk', 'https://www.architectpro.co.uk/path',
    'https://www.architectpro.co.uk?portal=evil', 'https://www.architectpro.co.uk/#fragment',
])
def test_launch_origin_must_be_explicitly_approved(url):
    code = 'aph_' + 'a' * 43
    from urllib.parse import quote
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.parse_automation_launch(f'architectpro://automation/job_123456?code={code}&portal={quote(url, safe="")}')


def test_local_development_origins_are_never_accepted_by_installed_build(monkeypatch):
    monkeypatch.setattr(portal_handoff.sys, 'frozen', False, raising=False)
    assert portal_handoff._normalise_portal_url('http://127.0.0.1:4321') == 'http://127.0.0.1:4321'
    monkeypatch.setattr(portal_handoff.sys, 'frozen', True)
    with pytest.raises(portal_handoff.PortalHandoffError): portal_handoff._normalise_portal_url('http://127.0.0.1:4321')


def test_handoff_saves_job_access_without_repointing_agent(monkeypatch):
    response = io.BytesIO(json.dumps({'accessToken': 'apd_' + 'a' * 40}).encode())
    monkeypatch.setattr(portal_handoff, '_open_portal_url', lambda *_a, **_kw: response)
    save_origin, save_token = Mock(), Mock()
    monkeypatch.setattr(portal_handoff, 'save_portal_url', save_origin)
    monkeypatch.setattr(portal_handoff, 'save_job_access_token', save_token)
    client = portal_handoff.PortalClient.from_handoff('https://www.architectpro.co.uk', 'job_123456', 'aph_' + 'a' * 43)
    save_origin.assert_not_called()
    save_token.assert_called_once_with('job_123456', 'apd_' + 'a' * 40)
    assert client.portal_url == 'https://www.architectpro.co.uk'


@pytest.mark.parametrize('path', ['https://untrusted.test/file', '//untrusted.test/file', '/\\untrusted.test/file', '\n//untrusted.test/file', 'file.pdf'])
def test_document_urls_cannot_send_bearer_token_elsewhere(monkeypatch, tmp_path, path):
    monkeypatch.setattr(portal_handoff.storage_paths, 'app_data_dir', lambda: str(tmp_path))
    client = portal_handoff.PortalClient('https://www.architectpro.co.uk', 'test-only')
    request = Mock()
    monkeypatch.setattr(client, '_request', request)
    downloaded, failures = client.download_documents({'id': 'job_123456', 'documents': [{'id': 'document', 'downloadUrl': path, 'originalFilename': 'test.pdf'}]})
    assert downloaded == [] and len(failures) == 1
    request.assert_not_called()


def test_authorised_requests_refuse_cross_origin_redirect_before_following(monkeypatch):
    monkeypatch.setattr(portal_handoff.sys, 'frozen', False, raising=False)
    requests = []
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            requests.append((self.path, self.headers.get('Authorization')))
            self.send_response(302)
            self.send_header('Location', 'https://untrusted.invalid/capture-token')
            self.end_headers()
        def log_message(self, *_args): pass
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        client = portal_handoff.PortalClient(f'http://127.0.0.1:{server.server_port}', 'test-only-token')
        with pytest.raises(portal_handoff.PortalHandoffError, match='redirect'):
            client._request('/redirect', binary=True)
        assert requests == [('/redirect', 'Bearer test-only-token')]
    finally:
        server.shutdown(); server.server_close(); thread.join(2)


def test_update_cannot_trust_an_arbitrary_saved_origin():
    with pytest.raises(portal_handoff.PortalHandoffError): agent_update.validate_release('https://untrusted.test', {})


def test_update_installation_requires_explicit_confirmation(monkeypatch):
    launch = Mock()
    monkeypatch.setattr(agent_update.subprocess, 'Popen', launch)
    with pytest.raises(portal_handoff.PortalHandoffError, match='Confirm'):
        agent_update.launch_installer('C:/verified/setup.exe')
    launch.assert_not_called()


@pytest.mark.parametrize('status', ['COMPLETED', 'FAILED_RETRYABLE', 'FAILED_FINAL', 'CANCELLED'])
def test_every_final_acknowledgement_clears_job_token(monkeypatch, tmp_path, status):
    monkeypatch.setattr(callback_outbox.storage_paths, 'app_data_dir', lambda: str(tmp_path))
    clear = Mock()
    monkeypatch.setattr(portal_handoff, 'clear_job_access_token', clear)
    event = callback_outbox.build_event(job_id='job_123456', status=status, event_type='result')
    client = Mock()
    client.send_callback.return_value = {'ok': True, 'status': status}
    assert callback_outbox.deliver_event(event, client=client)
    clear.assert_called_once_with('job_123456')


def test_declining_downloaded_update_does_not_launch_installer(monkeypatch):
    from tests.test_agent_gui import make_window
    from gui import agent_app
    window = make_window()
    launch, quit_agent, failed = Mock(), Mock(), Mock()
    monkeypatch.setattr(agent_app.QMessageBox, 'question', lambda *_a, **_kw: agent_app.QMessageBox.StandardButton.No)
    monkeypatch.setattr(agent_app.agent_update, 'launch_installer', launch)
    monkeypatch.setattr(window, 'quit_agent', quit_agent)
    monkeypatch.setattr(window, 'on_update_failed', failed)
    try:
        window.on_update_downloaded('C:/verified/setup.exe')
        launch.assert_not_called(); quit_agent.assert_not_called()
        failed.assert_called_once()
    finally: window.close()

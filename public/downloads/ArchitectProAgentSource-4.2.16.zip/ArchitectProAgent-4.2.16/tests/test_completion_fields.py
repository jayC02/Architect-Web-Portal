import pytest

from automation.building_warrant.agent import fill_agent_details
from automation.building_warrant.applicant import fill_applicant_details
from automation.completion_certificate import fields, navigation
from automation.completion_certificate.fields import PREFIX, choose, choose_yes_no, portal_date, set_text

from completion_fakes import FakeDriver

NEXT = PREFIX + "StepNavigationTemplateContainerID_btnNext"


def test_prefix_is_the_completion_wizard():
    assert PREFIX == "MainContent_CompletionCertificateAppWizard_"


def test_portal_date():
    assert portal_date("2026-03-05") == "05/03/2026"
    assert portal_date("2026-12-31") == "31/12/2026"


@pytest.mark.parametrize("bad", ["05/03/2026", "2026-13-01", "2026-02-30", "", None, "2026-3-5"])
def test_portal_date_rejects_anything_else(bad):
    with pytest.raises(ValueError):
        portal_date(bad)


def test_set_text_skips_matching_value():
    driver = FakeDriver()
    driver.add("field", value="26/01234/WARR")
    assert set_text(driver, "field", "26/01234/WARR") is False
    assert driver.typed() == []


def test_set_text_replaces_different_value():
    driver = FakeDriver()
    driver.add("field", value="old")
    assert set_text(driver, "field", "26/01234/WARR") is True
    assert driver.value("field") == "26/01234/WARR"


def test_set_text_keeps_line_breaks():
    driver = FakeDriver()
    driver.add("notes", kind="textarea")
    set_text(driver, "notes", "01/06/2026\n09/07/2026")
    assert driver.value("notes") == "01/06/2026\n09/07/2026"


def test_set_text_treats_browser_line_endings_as_equal():
    driver = FakeDriver()
    driver.add("notes", kind="textarea", value="01/06/2026\r\n09/07/2026")
    assert set_text(driver, "notes", "01/06/2026\n09/07/2026") is False


def test_set_text_can_clear_a_saved_value():
    driver = FakeDriver()
    driver.add("field", value="stale")
    assert set_text(driver, "field", "") is True
    assert driver.value("field") == ""


def test_choose_selects_radio_by_its_label():
    driver = FakeDriver()
    driver.add_radio("rbYes", "g")
    driver.add_radio("rbNo", "g", selected=True)
    assert choose(driver, "rbYes") is True
    assert driver.selected("rbYes") and not driver.selected("rbNo")
    assert ("click", "label:rbYes") in driver.log


def test_choose_skips_selected_radio():
    driver = FakeDriver()
    driver.add_radio("rbYes", "g", selected=True)
    assert choose(driver, "rbYes") is False
    assert driver.clicks("rbYes") == 0


def test_choose_survives_a_postback_on_click():
    driver = FakeDriver()
    driver.add_radio("rbYes", "g", on_click=lambda current: current.postback())
    assert choose(driver, "rbYes") is True
    assert driver.selected("rbYes")


def test_choose_yes_no():
    driver = FakeDriver()
    driver.add_radio("rbYes", "g")
    driver.add_radio("rbNo", "g")
    choose_yes_no(driver, False, "rbYes", "rbNo")
    assert driver.selected("rbNo")
    choose_yes_no(driver, True, "rbYes", "rbNo")
    assert driver.selected("rbYes")
    with pytest.raises(ValueError):
        choose_yes_no(driver, None, "rbYes", "rbNo")


def _two_screens(inline=False):
    driver = FakeDriver()
    driver.add("first")
    driver.add("second")
    driver.visible_ids = {"first", NEXT} | ({"second"} if inline else set())
    driver.add(NEXT, kind="button", value="Next",
               on_click=lambda current: (current.postback(), setattr(current, "visible_ids", {"second", NEXT})))
    return driver


def test_click_next_waits_for_the_destination():
    driver = _two_screens()
    assert navigation.click_next(driver, expected_ids="second", screen_name="second") == "second"
    assert driver.clicks(NEXT) == 1


def test_click_next_does_not_repeat():
    driver = FakeDriver()
    driver.add("first")
    driver.add("second")
    driver.visible_ids = {"first", NEXT}
    driver.add(NEXT, kind="button", value="Next")     # the portal never moves on
    with pytest.raises(RuntimeError, match="Next was not repeated"):
        navigation.click_next(driver, expected_ids="second", screen_name="second", timeout=0.5)
    assert driver.clicks(NEXT) == 1


def test_ensure_step_inline_needs_no_next():
    driver = _two_screens(inline=True)
    assert navigation.ensure_step(driver, "second", screen_name="second", inline_timeout=0.3) == "second"
    assert driver.clicks(NEXT) == 0


def test_ensure_step_clicks_next_once_when_not_inline():
    driver = _two_screens()
    assert navigation.ensure_step(driver, "second", screen_name="second", inline_timeout=0.3) == "second"
    assert driver.clicks(NEXT) == 1


def _party_driver(prefix):
    driver = FakeDriver()
    for suffix in ("AgentDetails_txtAgentFirstName", "AgentDetails_txtAgentSurname", "AgentDetails_txtAgentTelNo",
                   "AgentDetails_txtAgentEmailAddress", "AgentDetails_txtAgentBuildingNo", "AgentDetails_txtAgentAddress1",
                   "AgentDetails_txtAgentTown", "AgentDetails_txtAgentCountry", "AgentDetails_txtAgentPostcode"):
        driver.add(prefix + suffix)
    driver.add(prefix + "StepNavigationTemplateContainerID_btnClearPage", kind="button", value="Clear Page")
    driver.add_radio(prefix + "AgentDetails_rblIndividualOrOrganisation_0", "relevant")
    return driver


AGENT_INPUTS = {
    "Agent First Name": "Alex", "Agent Last Name": "Agent", "Agent Telephone Number": "07000000001",
    "Agent Email Address": "agent@example.com", "Agent Building Number": "1", "Agent Address 1": "Practice Street",
    "Agent Town/City": "Glasgow", "Agent Country": "United Kingdom", "Agent Postcode": "G1 1AA",
}


def test_agent_details_use_the_completion_prefix():
    driver = _party_driver(PREFIX)
    fill_agent_details(driver, AGENT_INPUTS, prefix=PREFIX)
    assert driver.value(PREFIX + "AgentDetails_txtAgentFirstName") == "Alex"
    assert driver.value(PREFIX + "AgentDetails_txtAgentPostcode") == "G1 1AA"
    assert driver.selected(PREFIX + "AgentDetails_rblIndividualOrOrganisation_0")
    assert all(entry[1].replace("label:", "").startswith(PREFIX) for entry in driver.log)


def test_agent_details_default_prefix_unchanged():
    warrant_prefix = "MainContent_BuildingWarrantAppWizard_"
    driver = _party_driver(warrant_prefix)
    fill_agent_details(driver, AGENT_INPUTS)
    assert driver.value(warrant_prefix + "AgentDetails_txtAgentSurname") == "Agent"


def test_applicant_details_accept_a_prefix():
    import inspect

    assert inspect.signature(fill_applicant_details).parameters["prefix"].default == "MainContent_BuildingWarrantAppWizard_"
    assert inspect.signature(fill_agent_details).parameters["prefix"].default == "MainContent_BuildingWarrantAppWizard_"


def test_fields_module_does_not_hardcode_another_wizard():
    import pathlib

    for module in (fields, navigation):
        assert "BuildingWarrantAppWizard" not in pathlib.Path(module.__file__).read_text(encoding="utf-8")


def test_a_radio_hidden_behind_its_label_still_marks_the_screen():
    """Styled portal radios can hide the input and draw the circle on the label."""
    driver = FakeDriver()
    driver.add_radio("rbNo", "g")
    driver.fields["rbNo"].visible = False
    assert navigation.wait_for_step(driver, "rbNo", screen_name="notices", timeout=0.5) == "rbNo"


def test_a_hidden_radio_with_no_visible_label_is_not_a_screen():
    driver = FakeDriver()
    driver.add_radio("rbNo", "g")
    driver.fields["rbNo"].visible = False
    driver.fields["label:rbNo"].visible = False
    with pytest.raises(RuntimeError):
        navigation.wait_for_step(driver, "rbNo", screen_name="notices", timeout=0.3)

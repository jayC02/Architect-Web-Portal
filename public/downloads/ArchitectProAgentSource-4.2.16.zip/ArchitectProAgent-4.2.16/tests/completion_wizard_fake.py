"""A model of the Completion Certificate Main Details wizard for tests.

Screens, their controls and the Yes/No branches follow the architect's portal
mapping. ``inline`` decides whether a follow-up (warrant details, relaxation
fields, continuing-requirements text) appears on the same screen after Yes or
on its own screen after Next: the mapping does not say, so both are tested.
"""

from __future__ import annotations

from automation.completion_certificate.certificates import CONSTRUCTION, DESIGN
from automation.completion_certificate.fields import PREFIX as P
from automation.completion_certificate.navigation import NEXT_BUTTON_ID, SUPPORTING_DOCUMENTATION_BUTTON_ID

from completion_fakes import FakeDriver, FakeRegister

WARRANT_DETAILS = [P + "BuildingWarrantDetails_txtBuildingWarrantRefNumber", "txtBuildingWarrantDate",
                   P + "BuildingWarrantDetails_txtAmendmentDates"]
RELAXATION_FIELDS = [P + "RelaxationDirections_txtReferenceNumber", "txtRelaxDirDate"]
CONTINUING_TEXT = [P + "txtContinuingRequirements"]
NOTICES = [P + "txtBuildingRegComplianceNotice", P + "txtBuildingWarrantEnforcementNotice", P + "txtDefectiveBuildingsNotice"]

RADIO_GROUPS = {
    "obtain": ("rbObtainBWYes", "rbObtainBWNo"),
    "dangerous": ("rbDangerousBuildingYes", "rbDangerousBuildingNo"),
    "role": ("ApplicantOrAgent_rbAgent", "ApplicantOrAgent_rbApplicant"),
    "account": ("ApplicantOrAgent_rbAccountYes", "ApplicantOrAgent_rbAccountNo"),
    "owner": ("rbApplicantOwnerYes", "rbApplicantOwnerNo"),
    "address": ("rbDifferentAddressYes", "rbDifferentAddressNo"),
    "cover": ("rbSumissionCoverYes", "rbSumissionCoverNo"),
    "relaxation": ("rbRelaxationDirectionYes", "rbRelaxationDirectionNo"),
    "construction": ("CertificatesRegisterQuestion_rbCertificatesAccompanyYes", "CertificatesRegisterQuestion_rbCertificatesAccompanyNo"),
    "design": ("rbDesignCertificatesAccompanyYes", "rbDesignCertificatesAccompanyNo"),
    "form_q": ("rbNoticeOfDesignDetailsYes", "rbNoticeOfDesignDetailsNo"),
    "epc": ("rbEnergyPerformanceYes", "rbEnergyPerformanceNo"),
    "sustainability": ("rbSustainabilityYes", "rbSustainabilityNo"),
    "fire": ("rbFireSafetyYes", "rbFireSafetyNo"),
    "continuing": ("rbContinuingRequirementsYes", "rbContinuingRequirementsNo"),
}
SCREEN_GROUPS = {
    "completion_warrant": ["obtain"], "notices": ["dangerous"], "applicant_or_agent": ["role", "account"],
    "ownership": ["owner", "address"], "extent_relaxation": ["cover", "relaxation"],
    "construction_question": ["construction"], "design_question": ["design"], "form_q_question": ["form_q"],
    "epc": ["epc"], "sustainability": ["sustainability"], "fire_safety": ["fire"], "continuing": ["continuing"],
}
SCREEN_FIELDS = {
    "completion_warrant": ["txtDateWorkCompleted"], "notices": NOTICES,
    "agent": [P + "AgentDetails_txtAgentFirstName"], "relevant_person": [P + "ApplicantDetails_txtApplicantFirstName"],
    "warrant_details": WARRANT_DETAILS, "relaxation_fields": RELAXATION_FIELDS, "continuing_text": CONTINUING_TEXT,
}
# follow-up fields, the screen they belong to, and the Yes radio that reveals them
FOLLOW_UPS = {
    "warrant_details": ("completion_warrant", "rbObtainBWYes"),
    "relaxation_fields": ("extent_relaxation", "rbRelaxationDirectionYes"),
    "continuing_text": ("continuing", "rbContinuingRequirementsYes"),
}


class FakeWizard:
    def __init__(self, *, inline=True, completes=True, saved=None, construction_saved=None, form_q_saved=None):
        self.driver = FakeDriver()
        self.inline = inline
        self.completes = completes
        self.screen = "intro"
        self.screens_visited = ["intro"]
        driver = self.driver
        for group, ids in RADIO_GROUPS.items():
            for suffix in ids:
                driver.add_radio(P + suffix, group, on_click=lambda _d: self._show())
        for ids in SCREEN_FIELDS.values():
            for element_id in ids:
                driver.add(element_id, kind="textarea" if element_id.endswith(("txtAmendmentDates", "txtContinuingRequirements")) else "text")
        driver.add(NEXT_BUTTON_ID, kind="button", value="Next", on_click=lambda _d: self._next())
        driver.add(SUPPORTING_DOCUMENTATION_BUTTON_ID, kind="button", value="Supporting Documentation")
        self.construction = FakeRegister(driver, CONSTRUCTION.prefix, CONSTRUCTION.scheme, CONSTRUCTION.part1,
                                         CONSTRUCTION.certifier_part2, CONSTRUCTION.approved_body_part2, saved=construction_saved)
        self.form_q = FakeRegister(driver, DESIGN.prefix, DESIGN.scheme, DESIGN.part1,
                                   DESIGN.certifier_part2, DESIGN.approved_body_part2, saved=form_q_saved)
        for element_id, value in (saved or {}).items():
            field = driver.fields[element_id]
            if field.kind == "radio":
                driver.select_radio(element_id)
            else:
                field.value = value
        driver.log.clear()
        self._show()

    # ---- helpers for assertions ----------------------------------------
    def value(self, suffix):
        return self.driver.value(suffix if suffix in self.driver.fields else P + suffix)

    def selected(self, suffix):
        return self.driver.selected(P + suffix)

    def next_clicks(self):
        return self.driver.clicks(NEXT_BUTTON_ID)

    def radio_clicks(self):
        return [entry for entry in self.driver.log if entry[0] == "click" and entry[1].startswith("label:")]

    # ---- behaviour ------------------------------------------------------
    def _yes(self, suffix):
        return self.driver.fields[P + suffix].selected

    def _show(self):
        if self.screen == "form_summary":
            self.driver.visible_ids = {SUPPORTING_DOCUMENTATION_BUTTON_ID} if self.completes else set()
            return
        visible = {NEXT_BUTTON_ID}
        for group in SCREEN_GROUPS.get(self.screen, []):
            visible |= {P + suffix for suffix in RADIO_GROUPS[group]}
        visible |= set(SCREEN_FIELDS.get(self.screen, []))
        if self.inline:
            for follow_up, (screen, yes_radio) in FOLLOW_UPS.items():
                if screen == self.screen and self._yes(yes_radio):
                    visible |= set(SCREEN_FIELDS[follow_up])
        if self.screen == "construction_register":
            visible |= self.construction.element_ids()
        if self.screen == "form_q_register":
            visible |= self.form_q.element_ids()
        self.driver.visible_ids = visible

    def _after(self):
        follow_up = lambda name: (not self.inline) and self._yes(FOLLOW_UPS[name][1])  # noqa: E731
        return {
            "intro": lambda: "completion_warrant",
            "completion_warrant": lambda: "warrant_details" if follow_up("warrant_details") else "notices",
            "warrant_details": lambda: "notices",
            "notices": lambda: "applicant_or_agent",
            "applicant_or_agent": lambda: "agent",
            "agent": lambda: "relevant_person",
            "relevant_person": lambda: "ownership",
            "ownership": lambda: "extent_relaxation",
            "extent_relaxation": lambda: "relaxation_fields" if follow_up("relaxation_fields") else "construction_question",
            "relaxation_fields": lambda: "construction_question",
            "construction_question": lambda: "construction_register" if self._yes(RADIO_GROUPS["construction"][0]) else "design_question",
            "construction_register": lambda: "design_question",
            "design_question": lambda: "form_q_question" if self._yes(RADIO_GROUPS["design"][0]) else "epc",
            "form_q_question": lambda: "form_q_register" if self._yes(RADIO_GROUPS["form_q"][0]) else "epc",
            "form_q_register": lambda: "epc",
            "epc": lambda: "sustainability",
            "sustainability": lambda: "fire_safety",
            "fire_safety": lambda: "continuing",
            "continuing": lambda: "continuing_text" if follow_up("continuing_text") else "final",
            "continuing_text": lambda: "final",
            "final": lambda: "form_summary",
        }[self.screen]()

    def _next(self):
        if self.screen == "construction_register":
            self.construction.store()
        if self.screen == "form_q_register":
            self.form_q.store()
        self.screen = self._after()
        self.screens_visited.append(self.screen)
        self.driver.postback()
        if self.screen == "construction_register":
            self.construction.load()
        if self.screen == "form_q_register":
            self.form_q.load()
        self._show()

import json
from pathlib import Path
import uuid

import pytest

from automation.common.proposal_creation import (
    BUILDING_WARRANT, HOUSEHOLDER, ProposalCreationError, ProposalNameInUse,
    ProposalStateStore, build_context, fresh_draft_proposal_name,
)
from tests.test_proposal_creation import FakePortal, MemoryStore, inputs, run
from gui.services.portal_handoff import portal_job_to_values


@pytest.mark.parametrize('kind', [HOUSEHOLDER, BUILDING_WARRANT])
def test_same_address_resets_create_distinct_drafts_without_reusing_legacy_names(kind):
    names = []
    for _ in range(2):
        portal = FakePortal(kind)
        key = str(uuid.uuid4())
        values = inputs(kind, **{'Portal Draft Key': key})
        run(portal, values=values)
        name = next(event[1] for event in portal.events if isinstance(event, tuple) and event[0] == 'proposal-details')
        assert uuid.UUID(key).hex in name
        assert portal.events.count('create-proposal') == 1
        assert not any(isinstance(event, tuple) and event[0] == 'open-existing' for event in portal.events)
        names.append(name)
    assert names[0] != names[1]


def test_reset_collision_only_recovers_its_own_exact_name():
    key = str(uuid.uuid4())

    class ExistingReset(FakePortal):
        def enter_proposal_details(self, name, description):
            super().enter_proposal_details(name, description)
            raise ProposalNameInUse('Proposal details', 'reserved')

    portal = ExistingReset(HOUSEHOLDER, recovered_reference='123456789')
    run(portal, values=inputs(HOUSEHOLDER, **{'Portal Draft Key': key}))
    lookup = next(event[1] for event in portal.events if isinstance(event, tuple) and event[0] == 'find-matching-draft')
    assert lookup.endswith(uuid.UUID(key).hex)
    assert 'create-proposal' not in portal.events
    assert ('open-existing', '123456789') in portal.events

    portal = ExistingReset(HOUSEHOLDER)
    with pytest.raises(ProposalCreationError, match='exact draft name is reserved'):
        run(portal, values=inputs(HOUSEHOLDER, **{'Portal Draft Key': key}))
    assert portal.events.count('open-new') == 1
    assert 'create-proposal' not in portal.events


def test_reset_identity_survives_portal_name_limit_and_never_shortens_the_address_context():
    key = str(uuid.uuid4())
    address = '12 Long Street, ' + 'A very long town name ' * 10
    name = fresh_draft_proposal_name(address, key, 80)
    assert len(name) <= 80
    assert name.endswith(uuid.UUID(key).hex)
    with pytest.raises(ProposalCreationError, match='cannot retain'):
        fresh_draft_proposal_name(address, key, 20)


def test_invalid_reset_key_stops_before_opening_the_portal():
    portal = FakePortal(HOUSEHOLDER)
    with pytest.raises(ProposalCreationError, match='valid fresh-draft identity'):
        run(portal, values=inputs(HOUSEHOLDER, **{'Portal Draft Key': 'wrong'}))
    assert portal.events == []


def test_saved_identity_from_another_reset_is_not_resumed(tmp_path):
    store = ProposalStateStore(str(tmp_path / 'state.json'))
    first = build_context(inputs(HOUSEHOLDER, **{'Portal Draft Key': str(uuid.uuid4())}))
    store.save(first, '123', 'first reset')
    second = build_context(inputs(HOUSEHOLDER, **{'Portal Draft Key': str(uuid.uuid4())}))
    assert store.get(second) is None
    assert store.get(first)['proposalReference'] == '123'


def test_trusted_web_reset_identity_reaches_the_automation_context():
    snapshot = json.loads((Path(__file__).parent / 'fixtures/automation-job-v2-building-warrant.json').read_text())
    key = str(uuid.uuid4())
    snapshot['metadata']['portalDraftKey'] = key
    job = {'id': snapshot['metadata']['jobId'], 'projectId': snapshot['metadata']['projectId'], 'type': 'BUILDING_WARRANT', 'dataSnapshot': snapshot}
    values = portal_job_to_values(job)
    assert values['Portal Draft Key'] == key
    assert build_context(values).draft_key == key

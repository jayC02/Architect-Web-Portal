"""Exercise the actual warrant workflow with job-local files and no legacy settings."""
from types import SimpleNamespace
from pathlib import Path

import pytest

from automation.building_warrant import run as warrant
from automation.common import documents
from automation.building_warrant.fee import CALCULATED_FEE_MINOR_UNITS_KEY


class PortalElement:
    def __init__(self, driver):
        self.driver = driver

    def click(self):
        pass

    def clear(self):
        pass

    def send_keys(self, value):
        if str(value).endswith('.pdf'):
            self.driver.uploads.append(str(value))

    def is_displayed(self):
        return True

    def is_enabled(self):
        return True

    def is_selected(self):
        return False


class PortalDriver:
    def __init__(self):
        self.uploads = []

    def find_element(self, *_args):
        return PortalElement(self)

    def execute_script(self, script, *_args):
        return 'complete' if 'document.readyState' in script else True


class ImmediateWait:
    def __init__(self, driver, *_args, **_kwargs):
        self.driver = driver

    def until(self, _condition):
        return PortalElement(self.driver)


@pytest.fixture
def workflow(monkeypatch, tmp_path):
    driver = PortalDriver()
    for name in (
        'clear_checkpoint', 'record_checkpoint', 'login_to_ebuilding',
        'create_proposal_and_resume', 'click_next', 'fill_agent_details',
        'fill_applicant_details', 'type_into',
        'fill_description_and_proposed_work', 'ensure_follow_up', 'fill_owner_details', 'complete_sustainability',
        'dismiss_gdpr_modal_if_present', 'wait_dom_ready', 'js_click_by_id',
        'click_when_clickable', 'complete_declaration', 'enter_calculated_fee',
        'select_by_text', 'wait_for_supporting_doc_upload_result',
    ):
        monkeypatch.setattr(warrant, name, lambda *_args, **_kwargs: None)
    monkeypatch.setattr(warrant, 'click_yes_no_answer', lambda _driver, values, key, *_a, **kw: warrant.yes_no_answer(values, key, kw.get('default', 'No')))
    monkeypatch.setattr(warrant, 'WebDriverWait', ImmediateWait)
    monkeypatch.setattr(warrant, 'Select', lambda _element: SimpleNamespace(select_by_visible_text=lambda _value: None))
    monkeypatch.setattr(warrant, 'get_paper_size_from_pdf', lambda _path: 'A4')
    monkeypatch.setattr(warrant, 'get_document_type_from_pdf', lambda _path: 'Drawing')
    monkeypatch.setattr(warrant, 'open_fee_and_handoff', lambda *_args, **_kwargs: 'prepared')
    for name in ('location.pdf', 'proposed.pdf'):
        (tmp_path / name).write_bytes(b'%PDF-1.4\n%%EOF')
    mapping = {
        'pdf_folder_path': str(tmp_path),
        'buckets': {'location_plan': ['location.pdf'], 'proposed': ['proposed.pdf']},
        'bucket_labels': {'proposed': 'Proposed plans'},
    }
    inputs = {'Email': 'agent@example.test', 'PDF Folder Path': str(tmp_path),
              'Description of Work': 'Extend dwelling', 'Estimated Work Value': '35000',
              'Declaration Authorised': 'Yes', CALCULATED_FEE_MINOR_UNITS_KEY: 76000}
    return driver, inputs, mapping


@pytest.mark.parametrize('legacy_file', ['missing', 'different_job', 'other_project_exists'])
def test_portal_job_never_reloads_a_global_document_list(monkeypatch, tmp_path, workflow, legacy_file):
    driver, inputs, mapping = workflow
    legacy_reads = []
    if legacy_file == 'other_project_exists':
        (tmp_path / 'another-project.pdf').write_bytes(b'%PDF-1.4\n%%EOF')

    def legacy_json(*_args, **_kwargs):
        legacy_reads.append(True)
        if legacy_file == 'missing':
            raise RuntimeError('Required JSON file is missing: supporting_docs.json')
        return {**mapping, 'buckets': {'proposed': ['another-project.pdf']}}

    monkeypatch.setattr(documents.storage_paths, 'migrate_json_if_missing', lambda *_args, **_kwargs: None)
    monkeypatch.setattr(documents, 'load_required_json', legacy_json)
    assert warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping=mapping) == 'prepared'
    assert legacy_reads == []
    assert driver.uploads == [str(tmp_path / 'proposed.pdf'), str(tmp_path / 'location.pdf')]


def test_document_failure_names_the_step_without_exposing_the_raw_error(monkeypatch, workflow):
    from automation.common.uploads import DocumentPreparationError
    from selenium.common.exceptions import TimeoutException
    driver, inputs, mapping = workflow
    failure = TimeoutException('private browser diagnostics')

    def fail_confirmation(*_args, **_kwargs):
        raise failure

    monkeypatch.setattr(warrant, 'wait_for_supporting_doc_upload_result', fail_confirmation)
    with pytest.raises(DocumentPreparationError) as raised:
        warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping=mapping)
    assert raised.value.operation == 'Waiting for supporting document upload confirmation'
    assert raised.value.__cause__ is failure
    assert 'private browser diagnostics' not in str(raised.value)
    assert 'existing eBuilding Standards draft' in str(raised.value)


def test_document_phase_still_honours_cancellation(monkeypatch, workflow):
    from automation.runner import AutomationCancelled, CancellationToken
    driver, inputs, mapping = workflow
    token = CancellationToken()

    def progress(stage, status, _message):
        if stage == 'documents' and status == 'running':
            token.cancel()

    with pytest.raises(AutomationCancelled):
        warrant.main(user_inputs=inputs, password='test-only', driver=driver,
                     document_mapping=mapping, progress=progress, cancellation_token=token)


def test_location_plan_only_does_not_claim_or_open_an_empty_supporting_upload(monkeypatch, workflow):
    driver, inputs, mapping = workflow
    mapping['buckets']['proposed'] = []
    choices = []
    monkeypatch.setattr(warrant, 'click_yes_no_answer', lambda _driver, values, key, *_a, **kw: choices.append((key, warrant.yes_no_answer(values, key, kw.get('default', 'No')))) or choices[-1][1])
    assert warrant.main(user_inputs=inputs, password='test-only', driver=driver, document_mapping=mapping) == 'prepared'
    assert ('SupportingDocs', 'No') in choices
    assert ('Supporting Documents', 'No') in choices
    assert driver.uploads == [str(Path(mapping['pdf_folder_path']) / 'location.pdf')]

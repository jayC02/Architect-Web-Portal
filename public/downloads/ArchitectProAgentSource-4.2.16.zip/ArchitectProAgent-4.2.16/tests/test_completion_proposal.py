import json

import pytest

from automation.common.proposal_creation import (
    BUILDING_WARRANT,
    ProposalCreationUncertain,
    ProposalStateStore,
    SavedProposalNotFoundError,
    proposal_name_matches_address,
    submitted_forms_include,
)
from automation.completion_certificate.proposal import (
    COMPLETION_FORM,
    CompletionFormError,
    ProposalSelectionRequired,
    open_completion_form,
    open_source_proposal,
    site_matches,
)

SITE = "112 Ralston Avenue, Glasgow, G52 3NB"
SUMMARY = """Proposal Summary
Delete Proposal | New Proposal
Summary
Need Help
112 RALSTON AVENUE, GLASGOW, G52 3NB
Resi
Edit Proposal Details
Status: Active
Primary Contact: Jayveer Chall
Date Started: 07/10/2026
Proposal Reference 500816704
Draft Forms
To complete the proposal click on the form.
Application for Building Warrant
Completion Certificate
Add Additional Forms
Submitted Forms
Submitted forms are automatically removed from the site 90 days after the submission date.
Name Submission Date
No Submitted Forms
Site Location
112 RALSTON AVENUE, GLASGOW, G52 3NB
Change Address
Hints and Tips
How do I submit revised drawings?
"""
INPUTS = {"Project ID": "project", "Site Address": SITE, "Site Postcode": "G52 3NB"}


class FakeStore:
    def __init__(self, saved=None):
        self.saved = saved
        self.remembered = []

    def find_for_project(self, project_reference, application_type, site_address):
        assert (project_reference, application_type, site_address) == ("project", BUILDING_WARRANT, SITE)
        return self.saved

    def remember_for_project(self, *args):
        self.remembered.append(args)


class FakePortal:
    def __init__(self, *, listed=(), existing=("500816704",), summary=SUMMARY, drafts=1, submitted=False,
                 add_creates=True, add_error=None):
        self.listed = list(listed)              # (reference, name) pairs returned by a name search
        self.existing = set(existing)
        self.summary = summary
        self.drafts = drafts
        self.submitted = submitted
        self.add_creates = add_creates
        self.add_error = add_error
        self.calls = []
        self.on_summary = False

    def open_existing_proposal(self, reference, name=""):
        self.calls.append(("open", reference, name))
        if reference not in self.existing:
            raise SavedProposalNotFoundError("Resume", "absent")
        self.on_summary = True

    def proposals_named(self, site_address):
        self.calls.append(("named", site_address))
        return list(self.listed)

    def show_proposal_list(self):
        self.calls.append(("list",))

    def wait_for_summary(self, timeout=None):
        self.calls.append(("wait_summary",))
        if not self.on_summary:
            raise AssertionError("waited for a summary that nothing opened")

    def summary_text(self):
        return self.summary

    def draft_form_count(self, text):
        assert text == COMPLETION_FORM
        return self.drafts

    def submitted_forms_include(self, text):
        return self.submitted

    def add_standard_form(self, text):
        self.calls.append(("add", text))
        if self.add_error:
            raise self.add_error
        if self.add_creates:
            self.drafts += 1

    def wait_for_draft_form(self, text, timeout=None):
        self.calls.append(("wait_form", text))
        return self.drafts

    def open_draft_form(self, text):
        self.calls.append(("open_form", text))

    def count(self, name):
        return sum(1 for call in self.calls if call[0] == name)


def user_opens(portal):
    def wait_for_user(_reason):
        portal.calls.append(("user",))
        portal.on_summary = True
    return wait_for_user


# ---- finding the proposal ---------------------------------------------------

def test_saved_identity_opens_by_reference():
    portal = FakePortal()
    store = FakeStore({"proposalReference": "500816704", "proposalName": "112 RALSTON AVENUE, GLASGOW, G52 3NB"})
    assert open_source_proposal(portal, INPUTS, state_store=store) == "500816704"
    assert portal.calls[0] == ("open", "500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")
    assert portal.count("named") == 0


def test_saved_reference_missing_falls_back_to_name_match():
    portal = FakePortal(listed=[("500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")])
    store = FakeStore({"proposalReference": "400000001", "proposalName": "old"})
    assert open_source_proposal(portal, INPUTS, state_store=store) == "500816704"
    assert [call[0] for call in portal.calls[:3]] == ["open", "named", "open"]


def test_unique_name_match_is_remembered():
    portal = FakePortal(listed=[("500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")])
    store = FakeStore()
    assert open_source_proposal(portal, INPUTS, state_store=store) == "500816704"
    assert store.remembered == [("project", BUILDING_WARRANT, SITE, "500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")]


def test_ambiguous_list_asks_the_user():
    portal = FakePortal(listed=[("500816704", "a"), ("500816999", "b")])
    assert open_source_proposal(portal, INPUTS, state_store=FakeStore(), wait_for_user=user_opens(portal)) == "500816704"
    assert portal.count("user") == 1
    assert portal.count("open") == 0, "the Agent opens nothing itself when the match is ambiguous"
    assert portal.calls.index(("list",)) < portal.calls.index(("user",))


def test_no_match_asks_the_user():
    portal = FakePortal(listed=[])
    open_source_proposal(portal, INPUTS, state_store=FakeStore(), wait_for_user=user_opens(portal))
    assert portal.count("user") == 1


def test_no_match_without_a_user_stops():
    portal = FakePortal(listed=[])
    with pytest.raises(ProposalSelectionRequired):
        open_source_proposal(portal, INPUTS, state_store=FakeStore())
    assert portal.count("open") == 0


def test_address_formats_match():
    assert site_matches("112 Ralston Avenue, Glasgow G52 3NB", "G52 3NB", SUMMARY)
    assert site_matches("112 Ralston Ave., Glasgow", "g523nb", SUMMARY)
    assert site_matches(SITE, "G52 3NB", SUMMARY.upper())


def test_address_mismatches_are_detected():
    assert not site_matches("12 Ralston Avenue, Glasgow, G52 3NB", "G52 3NB", SUMMARY), "12 is not 112"
    assert not site_matches("112 Ralston Avenue, Glasgow, G52 3NA", "G52 3NA", SUMMARY)
    assert not site_matches("9 Other Road, Glasgow, G52 3NB", "G52 3NB", SUMMARY)
    assert not site_matches("", "", SUMMARY)


def test_address_mismatch_stops_and_names_both():
    portal = FakePortal()
    store = FakeStore({"proposalReference": "500816704", "proposalName": ""})
    inputs = {**INPUTS, "Site Address": "9 Other Road, Glasgow, G1 1AA", "Site Postcode": "G1 1AA"}
    store.find_for_project = lambda *_args: store.saved
    with pytest.raises(CompletionFormError) as error:
        open_source_proposal(portal, inputs, state_store=store)
    assert "112 RALSTON AVENUE" in str(error.value) and "9 Other Road" in str(error.value)
    assert error.value.confirmation_required is True


def test_proposal_name_matching():
    assert proposal_name_matches_address("112 RALSTON AVENUE, GLASGOW, G52 3NB", SITE)
    assert proposal_name_matches_address("112 RALSTON AVENUE, GLASGOW, G52 3NB - R0123456789abcdef0123456789abcdef", SITE)
    assert not proposal_name_matches_address("114 RALSTON AVENUE, GLASGOW, G52 3NB", SITE)
    assert not proposal_name_matches_address("", SITE)


# ---- opening the form -------------------------------------------------------

def test_form_reused():
    portal = FakePortal(drafts=1)
    assert open_completion_form(portal) == "reused"
    assert portal.count("add") == 0 and portal.count("open_form") == 1


def test_form_created():
    portal = FakePortal(drafts=0)
    assert open_completion_form(portal) == "created"
    assert portal.calls == [("add", COMPLETION_FORM), ("wait_form", COMPLETION_FORM), ("open_form", COMPLETION_FORM)]


def test_duplicate_forms_stop():
    portal = FakePortal(drafts=2)
    with pytest.raises(CompletionFormError, match="2 Completion Certificate forms"):
        open_completion_form(portal)
    assert portal.count("open_form") == 0 and portal.count("add") == 0


def test_already_submitted_stops():
    portal = FakePortal(drafts=0, submitted=True)
    with pytest.raises(CompletionFormError, match="already been submitted"):
        open_completion_form(portal)
    assert portal.count("add") == 0


def test_uncertain_add_is_not_repeated():
    portal = FakePortal(drafts=0, add_creates=False)
    with pytest.raises(ProposalCreationUncertain):
        open_completion_form(portal)
    assert portal.count("add") == 1 and portal.count("open_form") == 0


def test_add_failure_is_not_repeated():
    portal = FakePortal(drafts=0, add_error=ProposalCreationUncertain("Add form", "The portal did not return."))
    with pytest.raises(ProposalCreationUncertain):
        open_completion_form(portal)
    assert portal.count("add") == 1


def test_submitted_forms_parsing():
    assert not submitted_forms_include(SUMMARY, "Completion Certificate"), "a draft form is not a submitted one"
    submitted = SUMMARY.replace("No Submitted Forms", "Completion Certificate 01/11/2026")
    assert submitted_forms_include(submitted, "Completion Certificate")
    assert not submitted_forms_include(submitted, "Application for Building Warrant")
    assert not submitted_forms_include("", "Completion Certificate")


# ---- saved identity ---------------------------------------------------------

def test_find_for_project_returns_newest(tmp_path):
    path = tmp_path / "proposal_state.json"
    entry = lambda reference, updated, **change: {  # noqa: E731
        "proposalReference": reference, "proposalName": "name", "applicationType": BUILDING_WARRANT,
        "siteAddress": SITE, "projectReference": "project", "updatedAt": updated, "draftKey": "", **change,
    }
    path.write_text(json.dumps({"jobs": {
        "job-old": entry("400000001", 10),
        "job-new": entry("500816704", 20),
        "job-other-project": entry("600000001", 30, projectReference="another"),
        "job-planning": entry("700000001", 40, applicationType="Householder Application (Planning)"),
        "job-other-site": entry("800000001", 50, siteAddress="9 Other Road, Glasgow, G1 1AA"),
    }}), encoding="utf-8")
    store = ProposalStateStore(str(path))
    assert store.find_for_project("project", BUILDING_WARRANT, "112 RALSTON AVENUE, GLASGOW, G52 3NB")["proposalReference"] == "500816704"
    assert store.find_for_project("missing", BUILDING_WARRANT, SITE) is None
    assert store.find_for_project("", BUILDING_WARRANT, SITE) is None


def test_remember_for_project_round_trips_and_keeps_other_entries(tmp_path):
    path = tmp_path / "proposal_state.json"
    path.write_text(json.dumps({"jobs": {"job-1": {"proposalReference": "1", "applicationType": BUILDING_WARRANT,
                                                  "siteAddress": "x", "projectReference": "p", "updatedAt": 1}}}), encoding="utf-8")
    store = ProposalStateStore(str(path))
    store.remember_for_project("project", BUILDING_WARRANT, SITE, "500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")
    assert store.find_for_project("project", BUILDING_WARRANT, SITE)["proposalReference"] == "500816704"
    assert "job-1" in json.loads(path.read_text(encoding="utf-8"))["jobs"]

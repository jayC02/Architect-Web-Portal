"""Review commands must be visible before login, not only at final handoff."""
import os
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from automation.common import driver as browser_driver
from automation.common.browser_mode import BrowserMode
from gui.agent_app import ExistingApplicationThread


@pytest.mark.parametrize("application_type", ["HOUSEHOLDER_PLANNING", "PLANNING_APPLICATION", "BUILDING_WARRANT"])
@pytest.mark.parametrize("navigation_fails", [False, True])
def test_review_is_visible_throughout_navigation_and_handed_off_only_on_success(monkeypatch, application_type, navigation_fails):
    events, modes, chrome_options, opened, failed = [], [], [], [], []
    window = SimpleNamespace(visible=False, focused=False)

    class Driver:
        session_id = "visible-review-session"

        def set_page_load_timeout(self, _timeout):
            pass

        def maximize_window(self):
            events.append("maximized")

        def get(self, url):
            assert window.visible and window.focused, "Portal navigation must already be visible."
            events.append(url)

        def quit(self):
            events.append("closed")

    class OwnedWindow:
        def __init__(self, current_driver):
            assert current_driver is driver

        def hide(self):
            window.visible = False
            events.append("hidden")

        def reveal_and_focus(self):
            window.visible = window.focused = True
            events.append("foreground")

    driver = Driver()

    def create_driver(options):
        chrome_options.append(options)
        events.append("started")
        return driver

    def managed_browser(mode):
        modes.append(mode)
        return browser_driver.ManagedChrome(mode, window_factory=OwnedWindow)

    def navigate(current_driver, workflow, inputs, *, password):
        assert current_driver is driver and workflow == application_type
        assert inputs["Automation Job ID"] == "review-job"
        assert password == "test-only-password"
        current_driver.get("https://portal.example.test/login")
        if navigation_fails:
            raise RuntimeError("Saved application unavailable")
        current_driver.get("https://portal.example.test/saved-application")

    monkeypatch.setattr(browser_driver, "create_chrome_driver", create_driver)
    monkeypatch.setattr(browser_driver, "_HANDED_OFF_BROWSERS", {})
    monkeypatch.setattr(browser_driver, "_HANDED_OFF_BROWSERS_BY_JOB", {})
    monkeypatch.setattr("gui.agent_app.create_managed_chrome", managed_browser)
    monkeypatch.setattr("gui.agent_app.open_existing_application", navigate)
    thread = ExistingApplicationThread("review-job", application_type, {"Automation Job ID": "review-job"}, "test-only-password")
    thread.opened.connect(opened.append)
    thread.failed.connect(failed.append)
    thread.run()

    assert modes == [BrowserMode.VISIBLE]
    assert not any(argument.startswith("--headless") for argument in chrome_options[0].arguments)
    assert "--start-minimized" not in chrome_options[0].arguments
    assert events[:3] == ["started", "maximized", "foreground"]
    assert "hidden" not in events
    assert thread.password == ""
    if navigation_fails:
        assert failed == ["Saved application unavailable"] and opened == []
        assert events[-1] == "closed"
        assert "review-job" not in browser_driver._HANDED_OFF_BROWSERS_BY_JOB
    else:
        assert failed == [] and opened == [driver.session_id]
        assert events[-1] == "foreground"
        assert "closed" not in events
        assert browser_driver._HANDED_OFF_BROWSERS_BY_JOB["review-job"].driver is driver

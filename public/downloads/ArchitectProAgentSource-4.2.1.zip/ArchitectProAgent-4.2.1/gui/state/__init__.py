"""Small state models for the desktop GUI."""

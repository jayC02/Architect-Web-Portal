from dataclasses import dataclass, field
from typing import Any


@dataclass
class AppState:
    application_type: str
    script_dir: str
    selected_pdf_folder: str = ""
    selected_pdf_paths: list[str] = field(default_factory=list)
    mapping_saved_once: bool = False
    portal_email: str = ""
    portal_password_available: bool = False
    portal_job_id: str = ""
    portal_job_title: str = ""
    portal_job_status: str = ""
    portal_job_state: Any = None

    def set_pdf_selection(self, folder: str, paths: list[str]):
        self.selected_pdf_folder = folder or ""
        self.selected_pdf_paths = list(paths or [])

    def set_mapping_saved(self, saved: bool):
        self.mapping_saved_once = bool(saved)

    def set_login_state(self, email: str, password_available: bool):
        self.portal_email = (email or "").strip()
        self.portal_password_available = bool(password_available)

    def set_portal_job(self, job_id: str, title: str, status: str):
        self.portal_job_id = str(job_id or "")
        self.portal_job_title = str(title or "")
        self.portal_job_status = str(status or "")

    def set_portal_job_state(self, state):
        self.portal_job_state = state

import html
import json
import os
import sys
import webbrowser
from datetime import datetime, timezone

import Building_Warrant
import Householder
from automation.common.runtime import AUTOMATION_CHECKPOINT_FILE, clear_checkpoint
from PySide6.QtCore import QEvent, QSize, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QKeyEvent, QKeySequence
from PySide6.QtWidgets import QApplication, QFileDialog, QLabel, QCheckBox, QComboBox, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPushButton, QTabWidget, QHBoxLayout, QFrame, QVBoxLayout, QWidget, QDialog, QDialogButtonBox, QFormLayout
from PySide6.QtGui import QShortcut

from .application_selector import ApplicationSelectorDialog
from .components import repolish, style_dropdown, validate_field
from .controllers import login_preset_controller, preflight_controller
from .pages import (
    agent_details_page,
    ai_intake_page,
    application_questions_page,
    applicant_details_page,
    certificates_page,
    data_entry_page,
    organise_pdfs_page,
    start_page,
    welcome_page,
)
from .services import ai_intake, callback_outbox, pdf_mapping, portal_answers, portal_handoff, presets, storage_paths
from .services.pdf_mapping import CONFIDENCE_ROLE, FILENAME_ROLE
from .sidebar import Sidebar
from .state.app_state import AppState
from .startup_splash import close_startup_splash, show_window_after_splash
from .stepper import Stepper
from .theme import APP_QSS


if getattr(sys, "frozen", False):
    SCRIPT_DIR = os.path.dirname(sys.executable)
else:
    SCRIPT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def automation_entrypoint_for_application_type(application_type):
    if application_type == portal_answers.HOUSEHOLDER_TYPE:
        return Householder.main, "Householder.main()"
    if application_type == portal_answers.BUILDING_WARRANT_TYPE:
        return Building_Warrant.main, "Building_Warrant.main()"
    raise RuntimeError("The application type is missing or unsupported; automation was not started.")


class AutomationThread(QThread):
    update_log = Signal(str)
    run_completed = Signal(bool)

    def __init__(self, application_type, runtime_password=""):
        super().__init__()
        self.application_type = application_type
        self.runtime_password = runtime_password

    def run(self):
        success = False
        password_env_key = "BUILDING_PORTAL_RUNTIME_PASSWORD"
        previous_password = os.environ.get(password_env_key)
        try:
            self.update_log.emit("Automation thread started.")
            json_path = storage_paths.runtime_path("user_inputs.json", SCRIPT_DIR)
            if not os.path.exists(json_path):
                self.update_log.emit(f"Missing user_inputs.json at: {json_path}")
                return
            if self.runtime_password:
                os.environ[password_env_key] = self.runtime_password
            entrypoint, entrypoint_name = automation_entrypoint_for_application_type(self.application_type)
            self.update_log.emit(f"Launching {entrypoint_name}...")
            entrypoint()
            self.update_log.emit("Automation finished.")
            success = True
        except Exception:
            import traceback

            self.update_log.emit("CRASH:\n" + traceback.format_exc())
        finally:
            self.runtime_password = ""
            if previous_password is None:
                os.environ.pop(password_env_key, None)
            else:
                os.environ[password_env_key] = previous_password
            self.run_completed.emit(success)


class AiIntakeThread(QThread):
    completed = Signal(object)
    failed = Signal(str)

    def __init__(self, application_type, notes, pdf_paths, existing_values):
        super().__init__()
        self.application_type = application_type
        self.notes = notes
        self.pdf_paths = list(pdf_paths or [])
        self.existing_values = dict(existing_values or {})

    def run(self):
        try:
            result = ai_intake.extract_application_details(
                SCRIPT_DIR,
                self.application_type,
                self.notes,
                self.pdf_paths,
                self.existing_values,
            )
            self.completed.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class BuildingWarrantApp(QWidget):
    BUILDING_WARRANT_STEPS = [
        "Welcome",
        "Application Questions",
        "Organise PDFs",
        "Data Entry",
        "Agent Details",
        "Applicant Details",
        "Certificates",
        "Start Automation",
    ]
    HOUSEHOLDER_STEPS = [
        "Welcome",
        "Application Questions",
        "Organise PDFs",
        "Data Entry",
        "Agent Details",
        "Applicant Details",
        "Start Automation",
    ]

    def __init__(self, application_type=None, portal_job=None, portal_client=None, downloaded_documents=None, download_failures=None, defer_portal_load=True):
        super().__init__()
        self.script_dir = SCRIPT_DIR
        self.application_type = application_type or portal_answers.BUILDING_WARRANT_TYPE
        self.state = AppState(application_type=self.application_type, script_dir=self.script_dir)
        self.portal_job = portal_job
        self.portal_client = portal_client
        self.downloaded_documents = list(downloaded_documents or [])
        self.download_failures = list(download_failures or [])
        self.portal_import_blocking_issues = []
        self.proposal_context = {}
        self._last_reported_checkpoint = ""
        self.WORKFLOW_STEPS = self.HOUSEHOLDER_STEPS if self.is_householder_application() else self.BUILDING_WARRANT_STEPS
        self.setWindowTitle(f"NinetyOneArchitects - {self.application_type}")
        self.setGeometry(120, 80, 1440, 900)
        self.setMinimumSize(1120, 720)
        self.setStyleSheet(APP_QSS)

        self.bucket_defs = [
            ("location_plan", "Location Plan", True, 1),
            ("proposed", "Proposed Plans", False, None),
            ("existing", "Existing Plans", False, None),
            ("elevations", "Elevations", False, None),
            ("sections", "Sections", False, None),
            ("details", "Details", False, None),
            ("calcs", "Calculations", False, None),
            ("specs", "Specification / Reports", False, None),
            ("photos", "Photos", False, None),
            ("other", "Other", False, None),
        ]

        self.pdf_folder_path = ""
        self.selected_pdf_paths = []
        self.completed_steps = set()
        self.previous_tab_index = 0
        self._ignore_tab_change = False
        self.mapping_saved_once = False
        self.state.set_mapping_saved(False)
        self._last_saved_mapping_snapshot = None
        self._start_tab_intro_shown = False
        self._last_tab_clicked_index = None
        self.cert_fields = []
        self.cert_line_edits = {}
        self.cert_dropdowns = {}
        self.application_questions_tab_index = self.step_index("Application Questions")
        self.organise_tab_index = self.step_index("Organise PDFs")
        self.start_tab_index = self.step_index("Start Automation")

        self._build_shell()
        self._build_pages()
        self._load_all_presets()
        self._setup_shortcuts()
        self._setup_pause_timer()
        self.update_navigation_state(0)
        self.apply_application_type()
        self.refresh_preflight_checklist()
        if self.portal_job and defer_portal_load:
            QTimer.singleShot(0, self.load_from_portal_job)

    def _build_shell(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        self.sidebar = Sidebar(self.WORKFLOW_STEPS, self.navigate_to_step)
        root.addWidget(self.sidebar)

        main = QFrame()
        main.setObjectName("MainShell")
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(28, 22, 28, 22)
        main_layout.setSpacing(16)
        self.stepper = Stepper(self.WORKFLOW_STEPS)
        main_layout.addWidget(self.stepper)
        self.tabs = QTabWidget()
        self.tabs.tabBar().hide()
        self.tabs.currentChanged.connect(self.on_tab_changed)
        main_layout.addWidget(self.tabs, 1)
        root.addWidget(main, 1)

    def _build_pages(self):
        builder_map = {
            "Welcome": welcome_page.build,
            "Application Questions": application_questions_page.build,
            "Organise PDFs": organise_pdfs_page.build,
            "Data Entry": data_entry_page.build,
            "Agent Details": agent_details_page.build,
            "Applicant Details": applicant_details_page.build,
            "Certificates": certificates_page.build,
            "Start Automation": start_page.build,
        }
        for label in self.WORKFLOW_STEPS:
            builder = builder_map[label]
            self.tabs.addTab(builder(self), label)

    def _load_all_presets(self):
        self.load_login_preset_list()
        self.load_agent_preset_list()
        self.load_preset_list()
        if hasattr(self, "cert_preset_combo"):
            self.load_cert_preset_list()

    def is_householder_application(self):
        return self.application_type == portal_answers.HOUSEHOLDER_TYPE

    def step_index(self, label):
        return self.WORKFLOW_STEPS.index(label)

    def _setup_shortcuts(self):
        for key, bucket in [
            ("L", "location_plan"),
            ("P", "proposed"),
            ("E", "existing"),
            ("V", "elevations"),
            ("S", "sections"),
            ("D", "details"),
            ("C", "calcs"),
            ("R", "specs"),
            ("O", "other"),
        ]:
            shortcut = QShortcut(QKeySequence(key), self)
            shortcut.activated.connect(lambda b=bucket: self.move_selected_to_bucket(b))

    def _setup_pause_timer(self):
        self.pause_watch_timer = QTimer(self)
        self.pause_watch_timer.setInterval(1000)
        self.pause_watch_timer.timeout.connect(self.check_for_pause_notification)
        self.pause_watch_timer.start()

    def keyPressEvent(self, event: QKeyEvent):
        if event.key() in [Qt.Key_Enter, Qt.Key_Return] and self.tabs.currentIndex() == 0:
            self.navigate_to_step(1)
            return
        super().keyPressEvent(event)

    def navigate_to_step(self, index):
        self._last_tab_clicked_index = index
        self.tabs.setCurrentIndex(index)

    def back(self):
        self.navigate_to_step(max(0, self.tabs.currentIndex() - 1))

    def update_navigation_state(self, index=None):
        index = self.tabs.currentIndex() if index is None else index
        self.sidebar.update_state(index, self.completed_steps)
        self.stepper.update_state(index, self.completed_steps)

    def on_tab_changed(self, index):
        if self._ignore_tab_change:
            self.update_navigation_state(index)
            return
        if self.previous_tab_index == self.organise_tab_index and index > self.organise_tab_index and not self.is_mapping_currently_saved():
            self.start_save_mapping_highlight()
            QMessageBox.warning(self, "Save mapping required", "Please click 'Save Mapping' before moving to the next page.")
            self._ignore_tab_change = True
            self.tabs.setCurrentIndex(self.organise_tab_index)
            self._ignore_tab_change = False
            self.update_navigation_state(self.organise_tab_index)
            return
        if self.previous_tab_index != index:
            self.completed_steps.add(self.previous_tab_index)
        self.previous_tab_index = index
        if index == self.start_tab_index:
            self.refresh_preflight_checklist()
        self.update_navigation_state(index)

    def setup_dnd_list(self, list_widget: QListWidget):
        list_widget.installEventFilter(self)
        list_widget.model().rowsInserted.connect(lambda *args: self.update_bucket_counts())
        list_widget.model().rowsRemoved.connect(lambda *args: self.update_bucket_counts())
        list_widget.itemDoubleClicked.connect(lambda item, widget=list_widget: self.open_pdf_preview(widget, item))

    def open_pdf_preview(self, list_widget, item):
        filename = self.item_filename(item)
        path = os.path.join(self.pdf_folder_path, filename) if self.pdf_folder_path else ""
        if not path or not os.path.exists(path):
            QMessageBox.warning(self, "PDF not found", f"Could not find this PDF:\n{filename}")
            return
        try:
            os.startfile(path)
        except Exception:
            webbrowser.open(path)

    def eventFilter(self, obj, event):
        if isinstance(obj, QListWidget) and event.type() == QEvent.Drop:
            self.mark_mapping_dirty()
            self.refresh_pdf_lists()
        return super().eventFilter(obj, event)

    def select_pdf_folder(self):
        self.select_pdf_files()

    def select_pdf_files(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select PDFs for this application", "", "PDF files (*.pdf)")
        if not files:
            return
        if not self.set_selected_pdf_paths(files):
            return
        self.clear_pdf_mapping_lists_for_new_selection()
        self.load_inbox_from_folder()
        self.splash_folder_path_label.setText(self.pdf_folder_path)
        self.splash_folder_badge.setText("PDFs selected")
        self.splash_folder_badge.setObjectName("SuccessBadge")
        repolish(self.splash_folder_badge)

    def clear_pdf_mapping_lists_for_new_selection(self):
        if hasattr(self, "inbox_list"):
            self.inbox_list.clear()
        for widget in getattr(self, "bucket_lists", {}).values():
            widget.clear()
        self.mapping_saved_once = False
        self._last_saved_mapping_snapshot = None
        if hasattr(self, "mapping_reminder"):
            self.stop_save_mapping_highlight()

    def set_selected_pdf_paths(self, paths):
        pdf_paths = [path for path in paths if str(path).lower().endswith(".pdf")]
        if not pdf_paths:
            QMessageBox.warning(self, "No PDFs selected", "Select at least one PDF file.")
            return False
        folders = {os.path.abspath(os.path.dirname(path)) for path in pdf_paths}
        if len(folders) != 1:
            QMessageBox.warning(self, "PDFs must be in one folder", "For this version, select PDFs from the same folder so the portal upload mapping stays reliable.")
            return False
        self.pdf_folder_path = next(iter(folders))
        seen = set()
        self.selected_pdf_paths = []
        for path in pdf_paths:
            absolute = os.path.abspath(path)
            if absolute not in seen:
                seen.add(absolute)
                self.selected_pdf_paths.append(absolute)
        self.state.set_pdf_selection(self.pdf_folder_path, self.selected_pdf_paths)
        return True

    def load_inbox_from_folder(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.load_inbox_from_folder()
        self.inbox_list.clear()
        if not self.pdf_folder_path or not os.path.isdir(self.pdf_folder_path):
            self.organise_status.setText("Select a valid folder first.")
            self.organise_status.setObjectName("WarningBadge")
            repolish(self.organise_status)
            return
        if self.selected_pdf_paths:
            filenames = [os.path.basename(path) for path in self.selected_pdf_paths]
        else:
            filenames = sorted(filename for filename in os.listdir(self.pdf_folder_path) if filename.lower().endswith(".pdf"))
        for filename in filenames:
            organise_pdfs_page.add_pdf_item(self.inbox_list, filename)
        self.organise_status.setText(f"Inbox loaded: {self.inbox_list.count()} selected PDF(s).")
        self.organise_status.setObjectName("InfoBadge")
        repolish(self.organise_status)
        self.mark_mapping_dirty()
        self.update_bucket_counts()

    def filter_inbox(self, text):
        needle = text.lower().strip()
        for row in range(self.inbox_list.count()):
            item = self.inbox_list.item(row)
            item.setHidden(bool(needle and needle not in item.text().lower()))

    def move_selected_to_bucket(self, bucket_key):
        selected = self.inbox_list.selectedItems()
        if not selected or bucket_key not in self.bucket_lists:
            return
        for item in selected:
            self.inbox_list.takeItem(self.inbox_list.row(item))
            self.add_file_item_to_bucket(bucket_key, item)
        self.mark_mapping_dirty()
        self.refresh_pdf_lists()

    def clear_sorting(self):
        for key in self.bucket_lists:
            widget = self.bucket_lists[key]
            items = [self.item_filename(widget.item(i)) for i in range(widget.count())]
            widget.clear()
            for text in items:
                item = QListWidgetItem(text)
                item.setData(FILENAME_ROLE, text)
                self.inbox_list.addItem(item)
        self.organise_status.setText("Sorting cleared. Everything is back in Inbox.")
        self.organise_status.setObjectName("WarningBadge")
        repolish(self.organise_status)
        self.mark_mapping_dirty()
        self.refresh_pdf_lists()

    def autosort_pdfs(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.autosort_pdfs()
        result = pdf_mapping.autosort_pdfs(self.pdf_folder_path, self.inbox_list, self.bucket_lists, self.log)
        self.refresh_pdf_lists()
        if result["warnings"]:
            self.organise_log_box.setVisible(True)
            self.organise_log_toggle.setText("Hide")
        self.organise_status.setText(f"Auto-sort done. {result['sorted']} sorted, {result['review']} for review.")
        self.organise_status.setObjectName("WarningBadge" if result["review"] else "SuccessBadge")
        repolish(self.organise_status)
        self.mark_mapping_dirty()
        return result

    def item_filename(self, item):
        return item.data(FILENAME_ROLE) or item.text()

    def add_file_item_to_bucket(self, bucket_key, item, confidence=None):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.add_file_item_to_bucket(bucket_key, item, confidence)
        filename = self.item_filename(item)
        item.setData(FILENAME_ROLE, filename)
        if confidence:
            item.setData(CONFIDENCE_ROLE, confidence)
        item.setText(filename)
        item.setSizeHint(QSize(0, 30))
        self.bucket_lists[bucket_key].addItem(item)

    def refresh_pdf_lists(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.refresh_pdf_lists()
        self.refresh_inbox_rows()
        self.refresh_bucket_rows()
        self.update_bucket_counts()

    def refresh_inbox_rows(self):
        for row in range(self.inbox_list.count()):
            item = self.inbox_list.item(row)
            filename = self.item_filename(item)
            self.inbox_list.removeItemWidget(item)
            item.setData(FILENAME_ROLE, filename)
            item.setData(CONFIDENCE_ROLE, None)
            item.setText(filename)
            item.setSizeHint(QSize())

    def refresh_bucket_rows(self):
        for widget in self.bucket_lists.values():
            for row in range(widget.count()):
                item = widget.item(row)
                filename = self.item_filename(item)
                confidence = item.data(CONFIDENCE_ROLE)
                widget.removeItemWidget(item)
                item.setData(FILENAME_ROLE, filename)
                item.setText(filename)
                item.setToolTip(f"{filename} | Auto-sort confidence: {confidence}" if confidence else filename)
                item.setSizeHint(QSize(0, 30))

    def save_pdf_mapping(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.save_pdf_mapping()
        out_path = pdf_mapping.save_mapping(self, SCRIPT_DIR, self.pdf_folder_path, self.bucket_defs, self.bucket_lists)
        if not out_path:
            return
        self.organise_status.setText(f"Saved mapping: {out_path}")
        self.organise_status.setObjectName("SuccessBadge")
        repolish(self.organise_status)
        self.log("Saved supporting_docs.json (organised PDF mapping).")
        self.mapping_saved_once = True
        self.state.set_mapping_saved(True)
        self.completed_steps.add(self.organise_tab_index)
        self._last_saved_mapping_snapshot = self.build_mapping_snapshot()
        self.stop_save_mapping_highlight()
        self.update_navigation_state()

    def build_mapping_snapshot(self):
        return pdf_mapping.build_snapshot(self.pdf_folder_path, self.bucket_lists)

    def is_mapping_currently_saved(self):
        return self.mapping_saved_once and self._last_saved_mapping_snapshot == self.build_mapping_snapshot()

    def mark_mapping_dirty(self):
        self.update_bucket_counts()

    def start_save_mapping_highlight(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.start_save_mapping_highlight()
        self.mapping_reminder.setVisible(True)
        self.btn_save_mapping.setStyleSheet("QPushButton { background: #F59E0B; color: #111827; border-color: #FCD34D; }")

    def stop_save_mapping_highlight(self):
        self.mapping_reminder.setVisible(False)
        self.btn_save_mapping.setStyleSheet("")

    def update_bucket_counts(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.update_bucket_counts()
        if hasattr(self, "inbox_count"):
            self.inbox_count.setText(str(self.inbox_list.count()))
        if not hasattr(self, "bucket_count_labels"):
            return
        for key, label in self.bucket_count_labels.items():
            count = self.bucket_lists[key].count()
            label.setText(str(count))
            if key in self.bucket_empty_labels and self.bucket_empty_labels[key] is not None:
                self.bucket_empty_labels[key].setVisible(count == 0)

    def toggle_organise_log(self):
        if hasattr(self, "pdf_mapping_controller"):
            return self.pdf_mapping_controller.toggle_organise_log()
        visible = not self.organise_log_box.isVisible()
        self.organise_log_box.setVisible(visible)
        self.organise_log_toggle.setText("Hide" if visible else "Show")

    def load_json(self, filename):
        return presets.load_json(SCRIPT_DIR, filename, self.log)

    def save_json(self, filename, data):
        presets.save_json(SCRIPT_DIR, filename, data)

    def configure_ai_settings(self):
        settings = ai_intake.load_settings(SCRIPT_DIR)
        dialog = QDialog(self)
        dialog.setObjectName("ApplicationSelectorDialog")
        dialog.setWindowTitle("AI Intake settings")
        dialog.setModal(True)
        dialog.setMinimumWidth(560)
        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(14)

        title = QLabel("AI Intake settings")
        title.setObjectName("ApplicationSelectorTitle")
        subtitle = QLabel("Choose an AI provider and enter the architect/company API key for this computer. Keys are stored in Windows Credential Manager and are not bundled into test builds.")
        subtitle.setObjectName("ApplicationSelectorSubtitle")
        subtitle.setWordWrap(True)
        provider = QComboBox()
        provider.addItems([ai_intake.PROVIDER_GEMINI, ai_intake.PROVIDER_OPENAI])
        style_dropdown(provider)
        provider.setCurrentText(settings.get("provider") or ai_intake.DEFAULT_PROVIDER)
        api_key = QLineEdit()
        api_key.setEchoMode(QLineEdit.Password)
        api_key.setPlaceholderText("API key")
        model = QLineEdit()

        def sync_provider_fields():
            selected = provider.currentText()
            if selected == ai_intake.PROVIDER_OPENAI:
                api_key.setPlaceholderText("sk-...")
                api_key.setText(settings.get("openai_api_key", ""))
                model.setPlaceholderText(ai_intake.DEFAULT_MODEL)
                model.setText(settings.get("openai_model") or ai_intake.DEFAULT_MODEL)
            else:
                api_key.setPlaceholderText("Gemini API key")
                api_key.setText(settings.get("gemini_api_key", ""))
                model.setPlaceholderText(ai_intake.DEFAULT_GEMINI_MODEL)
                model.setText(settings.get("gemini_model") or ai_intake.DEFAULT_GEMINI_MODEL)

        provider.currentIndexChanged.connect(sync_provider_fields)
        sync_provider_fields()
        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addWidget(QLabel("Provider"))
        layout.addWidget(provider)
        layout.addWidget(QLabel("API key"))
        layout.addWidget(api_key)
        layout.addWidget(QLabel("Model"))
        layout.addWidget(model)

        row = QHBoxLayout()
        row.addStretch(1)
        clear = QPushButton("Clear key")
        cancel = QPushButton("Cancel")
        save = QPushButton("Save")
        save.setObjectName("PrimaryButton")
        clear.clicked.connect(lambda: (api_key.clear(), ai_intake.clear_settings(SCRIPT_DIR), self.log("AI API key cleared.")))
        cancel.clicked.connect(dialog.reject)
        save.clicked.connect(dialog.accept)
        row.addWidget(clear)
        row.addWidget(cancel)
        row.addWidget(save)
        layout.addLayout(row)

        if dialog.exec() == QDialog.Accepted:
            try:
                ai_intake.save_settings(SCRIPT_DIR, provider.currentText(), api_key.text(), model.text())
            except RuntimeError as exc:
                QMessageBox.warning(self, "AI settings not saved", str(exc))
                return
            self.log("AI Intake settings saved.")
            self.refresh_ai_key_status()
            QMessageBox.information(self, "AI settings saved", "AI Intake settings have been saved on this computer.")

    def refresh_ai_key_status(self):
        if not hasattr(self, "ai_key_status_label"):
            return
        settings = ai_intake.load_settings(SCRIPT_DIR)
        has_key = bool(settings.get("api_key"))
        self.ai_key_status_label.setText("AI ready" if has_key else "Setup needed")
        unavailable = settings.get("secure_storage_error")
        self.ai_key_status_detail.setText(
            f"{settings.get('provider', 'Gemini')} key secured on this device"
            if has_key
            else (unavailable or "Add a Gemini or OpenAI key")
        )
        self.ai_key_status_label.setObjectName("AiStatusTitle" if has_key else "WarningBadge")
        repolish(self.ai_key_status_label)
        if hasattr(self, "ai_provider_label"):
            self.ai_provider_label.setText(f"Provider: {settings.get('provider') or ai_intake.DEFAULT_PROVIDER}")

    def update_ai_intake_estimate(self):
        if not hasattr(self, "ai_intake_estimate_label"):
            return
        notes = self.ai_intake_notes.toPlainText() if hasattr(self, "ai_intake_notes") else ""
        pdf_paths = getattr(self, "ai_intake_pdf_paths", [])
        estimate = ai_intake.estimate_payload(notes, pdf_paths)
        self.ai_intake_estimate_label.setText(f"{estimate['size']} intake | {estimate['pdf_count']} PDF(s)")
        self.ai_intake_estimate_label.setObjectName("InfoBadge" if estimate["size"] != "Large" else "WarningBadge")
        repolish(self.ai_intake_estimate_label)
        if hasattr(self, "ai_summary_pdf_count"):
            self.ai_summary_pdf_count.setText(f"{estimate['pdf_count']} file{'s' if estimate['pdf_count'] != 1 else ''}")
        if hasattr(self, "ai_summary_notes"):
            self.ai_summary_notes.setText("Yes" if notes.strip() else "No")

    def select_ai_intake_pdfs(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Attach PDFs for AI Intake", "", "PDF files (*.pdf)")
        if not files:
            return
        existing = set(getattr(self, "ai_intake_pdf_paths", []))
        for path in files:
            if path not in existing:
                self.ai_intake_pdf_paths.append(path)
                existing.add(path)
        self.refresh_ai_intake_pdf_list()
        if self.set_selected_pdf_paths(self.ai_intake_pdf_paths) and hasattr(self, "inbox_list"):
            self.clear_pdf_mapping_lists_for_new_selection()
            self.load_inbox_from_folder()
            self.log(f"Loaded {len(self.selected_pdf_paths)} AI Intake PDF(s) into Organise PDFs.")

    def clear_ai_intake_pdfs(self):
        self.ai_intake_pdf_paths = []
        self.refresh_ai_intake_pdf_list()
        self.selected_pdf_paths = []
        if hasattr(self, "inbox_list"):
            self._clear_organise_state()

    def refresh_ai_intake_pdf_list(self):
        if not hasattr(self, "ai_intake_pdf_list"):
            return
        self.ai_intake_pdf_list.clear()
        for path in getattr(self, "ai_intake_pdf_paths", []):
            item = QListWidgetItem(os.path.basename(path))
            item.setToolTip(path)
            item.setSizeHint(QSize(0, 42))
            self.ai_intake_pdf_list.addItem(item)
            self.ai_intake_pdf_list.setItemWidget(item, ai_intake_page.file_source_row(os.path.basename(path)))
        if hasattr(self, "ai_pdf_sources_title"):
            count = len(getattr(self, "ai_intake_pdf_paths", []))
            self.ai_pdf_sources_title.setText(f"Files added ({count})")
        self.update_ai_intake_estimate()

    def start_ai_intake_extraction(self):
        if getattr(self, "ai_intake_thread", None) and self.ai_intake_thread.isRunning():
            return
        notes = self.ai_intake_notes.toPlainText() if hasattr(self, "ai_intake_notes") else ""
        pdf_paths = getattr(self, "ai_intake_pdf_paths", [])
        if not notes.strip() and not pdf_paths:
            QMessageBox.warning(self, "Nothing to extract", "Paste notes or attach PDFs before running AI Intake.")
            return
        self.run_ai_intake_pdf_sort()
        settings = ai_intake.load_settings(SCRIPT_DIR)
        if not settings.get("api_key"):
            QMessageBox.warning(self, "AI API key missing", "Add your Gemini or OpenAI API key before using AI Intake.")
            self.configure_ai_settings()
            if not ai_intake.load_settings(SCRIPT_DIR).get("api_key"):
                return
        self.apply_presets_mentioned_in_notes(notes)
        self.ai_intake_extract_button.setEnabled(False)
        ai_intake_page.set_status(self.ai_intake_status_label, "Extracting...", "info")
        self.log("AI Intake extraction started.")
        self.ai_intake_thread = AiIntakeThread(self.application_type, notes, pdf_paths, self.collect_user_inputs())
        self.ai_intake_thread.completed.connect(self.on_ai_intake_completed)
        self.ai_intake_thread.failed.connect(self.on_ai_intake_failed)
        self.ai_intake_thread.start()

    def run_ai_intake_pdf_sort(self):
        pdf_paths = getattr(self, "ai_intake_pdf_paths", [])
        if not pdf_paths or not hasattr(self, "inbox_list") or not hasattr(self, "bucket_lists"):
            return
        if not self.pdf_folder_path:
            if not self.set_selected_pdf_paths(pdf_paths):
                return
            self.load_inbox_from_folder()
        self.ensure_ai_pdfs_loaded_for_sorting()
        if self.inbox_list.count() == 0:
            self.log("AI Intake PDF sort skipped: all attached PDFs are already assigned to buckets.")
            return
        result = self.autosort_pdfs()
        sorted_count = result.get("sorted", 0) if isinstance(result, dict) else 0
        review_count = result.get("review", 0) if isinstance(result, dict) else 0
        if hasattr(self, "ai_summary_pdf_sort"):
            self.ai_summary_pdf_sort.setText(f"{sorted_count} sorted, {review_count} review")
        if hasattr(self, "ai_intake_status_label"):
            ai_intake_page.set_status(self.ai_intake_status_label, f"PDFs sorted: {sorted_count}", "success" if sorted_count else "warning")
        self.log(f"AI Intake sorted attached PDFs: {sorted_count} sorted, {review_count} need review.")

    def ensure_ai_pdfs_loaded_for_sorting(self):
        attached_names = [os.path.basename(path) for path in getattr(self, "ai_intake_pdf_paths", [])]
        loaded = set()
        for widget in [getattr(self, "inbox_list", None), *getattr(self, "bucket_lists", {}).values()]:
            if widget is None:
                continue
            for row in range(widget.count()):
                item = widget.item(row)
                loaded.add(item.data(FILENAME_ROLE) or item.text())
        for filename in attached_names:
            if filename not in loaded:
                organise_pdfs_page.add_pdf_item(self.inbox_list, filename)
        if attached_names:
            self.mark_mapping_dirty()
            self.refresh_pdf_lists()

    def apply_presets_mentioned_in_notes(self, notes):
        text = self.normalise_ai_preset_text(notes)
        applied = []
        self.ai_preset_applied_fields = set()
        self.ai_preset_applied_count = 0
        agent_match = self.find_mentioned_preset("agent_presets.json", text, self.agent_preset_match_names)
        if agent_match:
            name, data = agent_match
            for field in getattr(self, "agent_fields", []):
                if field in data and field in self.agent_line_edits:
                    self.agent_line_edits[field].setText(str(data[field]))
                    self.ai_preset_applied_fields.add(field)
            applied.append(f"Agent preset: {name}")
        if not self.is_householder_application():
            cert_match = self.find_mentioned_preset("cert_presets.json", text, self.cert_preset_match_names)
            if cert_match:
                name, data = cert_match
                widgets = {**getattr(self, "cert_line_edits", {}), **getattr(self, "cert_dropdowns", {})}
                for field in getattr(self, "cert_fields", []):
                    if field in data and field in widgets:
                        self.set_widget_value(widgets[field], str(data[field]))
                        self.ai_preset_applied_fields.add(field)
                self.update_portal_answer_summary()
                applied.append(f"Certificate preset: {name}")
        if hasattr(self, "ai_summary_presets"):
            self.ai_summary_presets.setText(str(len(applied)))
        self.ai_preset_applied_count = len(applied)
        if applied:
            self.log("AI Intake loaded mentioned preset(s): " + "; ".join(applied))

    def find_mentioned_preset(self, filename, normalised_notes, candidate_builder):
        presets_data = self.load_json(filename)
        best = None
        for name, data in presets_data.items():
            candidates = candidate_builder(name, data)
            for candidate in candidates:
                normalised = self.normalise_ai_preset_text(candidate)
                score = self.score_preset_candidate(normalised, normalised_notes)
                if score and (best is None or score > best[0]):
                    best = (score, name, data)
        if best:
            return best[1], best[2]
        return None

    def score_preset_candidate(self, candidate, normalised_notes):
        import difflib

        if len(candidate) < 3:
            return 0
        if candidate in normalised_notes:
            return 1000 + len(candidate)
        candidate_tokens = candidate.split()
        note_tokens = normalised_notes.split()
        if not candidate_tokens or not note_tokens:
            return 0
        for size in {len(candidate_tokens), len(candidate_tokens) + 1, max(1, len(candidate_tokens) - 1)}:
            for index in range(0, max(0, len(note_tokens) - size + 1)):
                window_tokens = note_tokens[index:index + size]
                window = " ".join(window_tokens)
                ratio = difflib.SequenceMatcher(None, candidate, window).ratio()
                if ratio >= 0.84:
                    return int(800 * ratio) + len(candidate)
        if len(candidate_tokens) >= 2:
            first = candidate_tokens[0]
            last = candidate_tokens[-1]
            for index, token in enumerate(note_tokens):
                if token != first:
                    continue
                nearby = note_tokens[index + 1:index + 4]
                if any(difflib.SequenceMatcher(None, last, option).ratio() >= 0.82 for option in nearby):
                    return 700 + len(candidate)
        return 0

    def agent_preset_match_names(self, name, data):
        first = str(data.get("Agent First Name", "")).strip()
        last = str(data.get("Agent Last Name", "")).strip()
        full = f"{first} {last}".strip()
        return [name, name.replace("_", " "), full]

    def cert_preset_match_names(self, name, data):
        certifier = str(data.get("Name of Certifier", "")).strip()
        certifier_without_title = self.strip_person_title(certifier)
        return [
            name,
            name.replace("_", " "),
            certifier,
            certifier_without_title,
            str(data.get("Name of Approved Body", "")).strip(),
        ]

    def strip_person_title(self, value):
        import re

        return re.sub(r"^(mr|mrs|miss|ms|dr|prof|sir|madam)\s+", "", str(value or "").strip(), flags=re.IGNORECASE)

    def normalise_ai_preset_text(self, value):
        import re

        return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()

    def on_ai_intake_completed(self, result):
        self.ai_intake_extract_button.setEnabled(True)
        self.ai_intake_result = result
        values = result.get("values", [])
        self.apply_automatic_ai_values(values)
        ai_intake_page.fill_review_table(self, result)
        visible_suggestions = self.ai_intake_table.rowCount() if hasattr(self, "ai_intake_table") else len(values)
        summary_parts = []
        if result.get("summary"):
            summary_parts.append(result["summary"])
        preset_count = max(0, int(getattr(self, "ai_preset_applied_count", 0)))
        if preset_count:
            summary_parts.append("Saved preset details were applied automatically and hidden from the review table.")
        summary_parts.append(f"{visible_suggestions} value(s) need review.")
        if result.get("missing_required_fields"):
            summary_parts.append("Missing or uncertain required fields: " + ", ".join(result["missing_required_fields"]))
        self.ai_intake_summary_label.setText("\n".join(summary_parts))
        missing_count = len(result.get("missing_required_fields") or [])
        confidence = self.ai_overall_confidence(values, missing_count)
        if hasattr(self, "ai_summary_suggestions"):
            self.ai_summary_suggestions.setText(str(visible_suggestions))
        if hasattr(self, "ai_summary_missing"):
            self.ai_summary_missing.setText(str(missing_count))
        if hasattr(self, "ai_summary_confidence"):
            self.ai_summary_confidence.setText(confidence)
        if hasattr(self, "ai_stat_suggestions"):
            self.ai_stat_suggestions.value_label.setText(str(visible_suggestions))
            self.ai_stat_presets.value_label.setText(str(preset_count))
            self.ai_stat_missing.value_label.setText(str(missing_count))
            self.ai_stat_confidence.value_label.setText(confidence)
        warnings = result.get("warnings") or []
        self.ai_intake_warnings_label.setVisible(bool(warnings))
        self.ai_intake_warnings_label.setText("\n".join(warnings[:8]))
        self.ai_intake_review_card.setVisible(True)
        ai_intake_page.set_status(self.ai_intake_status_label, "Review suggestions", "success")
        if hasattr(self, "ai_intake_scroll_area"):
            QTimer.singleShot(80, lambda: self.ai_intake_scroll_area.ensureWidgetVisible(self.ai_intake_review_card, 0, 12))
        self.log(f"AI Intake returned {len(values)} suggestion(s).")

    def apply_automatic_ai_values(self, values):
        auto_fields = set(getattr(self, "ai_preset_applied_fields", set()))
        applied = 0
        for item in values:
            key = item.get("key", "")
            value = item.get("value", "")
            if not key.startswith("Applicant ") or not value:
                continue
            if self.apply_ai_value(key, value):
                auto_fields.add(key)
                applied += 1
        self.ai_preset_applied_fields = auto_fields
        if applied:
            self.log(f"AI Intake automatically applied {applied} applicant detail value(s).")

    def ai_overall_confidence(self, values, missing_count):
        if not values:
            return "Not found"
        low = sum(1 for item in values if item.get("confidence") == "low")
        medium = sum(1 for item in values if item.get("confidence") == "medium")
        if missing_count or low:
            return "Needs review"
        if medium:
            return "Medium"
        return "High"

    def on_ai_intake_failed(self, message):
        self.ai_intake_extract_button.setEnabled(True)
        ai_intake_page.set_status(self.ai_intake_status_label, "Error", "error")
        self.log(f"AI Intake failed: {message}")
        QMessageBox.critical(self, "AI Intake failed", message)

    def set_all_ai_intake_rows(self, checked):
        if not hasattr(self, "ai_intake_table"):
            return
        for row in range(self.ai_intake_table.rowCount()):
            box = self.ai_intake_table.cellWidget(row, 0)
            checkbox = box.findChild(QCheckBox) if box else None
            if checkbox:
                checkbox.setChecked(checked)

    def select_safe_ai_intake_rows(self):
        if not hasattr(self, "ai_intake_table"):
            return
        for row in range(self.ai_intake_table.rowCount()):
            confidence = self.ai_intake_table.item(row, 3).text().strip().lower() if self.ai_intake_table.item(row, 3) else "low"
            checked = confidence in {"high", "medium"}
            box = self.ai_intake_table.cellWidget(row, 0)
            checkbox = box.findChild(QCheckBox) if box else None
            if checkbox:
                checkbox.setChecked(checked)

    def apply_ai_intake_results(self):
        rows = ai_intake_page.selected_rows_payload(self)
        if not rows:
            QMessageBox.warning(self, "No AI values selected", "Tick at least one suggested value before applying to the form.")
            return
        applied = 0
        labels = []
        for item in rows:
            if self.apply_ai_value(item["key"], item["value"]):
                applied += 1
                labels.append(item.get("label") or item["key"])
        self.completed_steps.add(self.step_index("AI Intake"))
        self.update_navigation_state()
        if hasattr(self, "ai_apply_summary_label"):
            shown = ", ".join(labels[:8])
            extra = f" and {len(labels) - 8} more" if len(labels) > 8 else ""
            self.ai_apply_summary_label.setText(f"Updated {applied} field(s): {shown}{extra}")
            self.ai_apply_summary_label.setVisible(True)
        self.log(f"Applied {applied} AI Intake value(s) to the form.")
        QMessageBox.information(self, "AI values applied", f"Applied {applied} value(s) to the form. Review the pages before starting automation.")

    def apply_ai_value(self, key, value):
        if key in {portal_answers.PROFILE_KEY, portal_answers.TYPE_OF_WORKS_KEY} and hasattr(self, "set_portal_profiles"):
            return self.set_portal_profiles(value)
        if key in getattr(self, "portal_exception_widgets", {}):
            self.portal_exception_widgets[key].setChecked(portal_answers.yes_no(value, "No") == "Yes")
            self.update_portal_answer_summary()
            return True
        if key in getattr(self, "householder_question_widgets", {}):
            self.householder_question_widgets[key].setChecked(portal_answers.yes_no(value, "No") == "Yes")
            self.update_portal_answer_summary()
            return True
        if key in getattr(self, "householder_parking_widgets", {}):
            self.householder_parking_widgets[key].setText(value)
            self.update_portal_answer_summary()
            return True
        if key in getattr(self, "householder_text_widgets", {}):
            self.householder_text_widgets[key].setText(value)
            self.update_portal_answer_summary()
            return True
        for widgets in [
            getattr(self, "input_fields", {}),
            getattr(self, "agent_line_edits", {}),
            getattr(self, "applicant_line_edits", {}),
            getattr(self, "cert_line_edits", {}),
            getattr(self, "cert_dropdowns", {}),
        ]:
            if key in widgets:
                changed = self.set_widget_value(widgets[key], value)
                if hasattr(self, "update_portal_answer_summary"):
                    self.update_portal_answer_summary()
                return changed
        return False

    def load_from_portal_job(self):
        job = self.portal_job or {}
        portal_state = portal_handoff.normalise_portal_job(
            job,
            self.downloaded_documents,
            self.download_failures,
        )
        self.state.set_portal_job_state(portal_state)
        values = portal_state.form_values
        self.clear_portal_import_state()
        proposal_keys = {
            "Site Address",
            "Site Postcode",
            "Automation Job ID",
            "Project ID",
            "Application Record ID",
            portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY,
        }
        self.proposal_context = {
            key: (
                values.get(key)
                if key == portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY
                else str(values.get(key) or "")
            )
            for key in proposal_keys
            if str(values.get(key) or "").strip()
        }
        applied = []
        unapplied = []
        for key, value in values.items():
            if key in proposal_keys:
                continue
            if key in {"Email", "Password"} and not str(value or "").strip():
                continue
            if self.apply_ai_value(key, str(value)):
                applied.append(key)
            elif key != portal_answers.APPLICATION_TYPE_KEY:
                unapplied.append(key)

        pdf_documents = [
            item for item in portal_state.documents
            if str(item.get("localPath", "")).lower().endswith(".pdf")
        ]
        buckets = portal_state.document_buckets
        paths = [item["localPath"] for item in pdf_documents]
        if paths and self.set_selected_pdf_paths(paths):
            self.load_inbox_from_folder()
            for bucket_key, filenames in buckets.items():
                for filename in filenames:
                    for row in range(self.inbox_list.count()):
                        item = self.inbox_list.item(row)
                        if self.item_filename(item) == filename:
                            self.inbox_list.takeItem(row)
                            self.pdf_mapping_controller.add_file_item_to_bucket(bucket_key, item, "Portal")
                            break
            self.pdf_mapping_controller.refresh_pdf_lists()
            if self.bucket_lists["location_plan"].count() == 1:
                out_path = pdf_mapping.save_mapping(self, self.script_dir, self.pdf_folder_path, self.bucket_defs, self.bucket_lists)
                if out_path:
                    self.mapping_saved_once = True
                    self.state.set_mapping_saved(True)
                    self._last_saved_mapping_snapshot = self.build_mapping_snapshot()

        summary, missing = portal_handoff.build_review_summary(job, values, buckets, self.download_failures)
        if unapplied:
            missing.extend(f"Desktop field mapping missing: {key}" for key in unapplied)
        missing.extend(portal_state.blocking_issues)
        if portal_state.review_issues:
            summary += "\n\nDocument mapping review:\n" + "\n".join(
                f"  {issue}" for issue in portal_state.review_issues
            )
        if unapplied:
            summary += "\n\nDesktop mapping errors:\n" + "\n".join(
                f"  {key}" for key in unapplied
            )
        self.portal_import_blocking_issues = list(dict.fromkeys(
            portal_state.blocking_issues
            + [f"Desktop field mapping missing: {key}" for key in unapplied]
        ))
        self.state.set_portal_job(job.get("id", ""), job.get("title", ""), job.get("status", ""))
        self.portal_review_summary.setPlainText(summary)
        self.portal_import_panel.setVisible(True)
        self.completed_steps.update(index for index in range(self.start_tab_index))
        self.navigate_to_step(self.start_tab_index)
        self.refresh_preflight_checklist()
        self.update_navigation_state()
        self.log(f"Loaded portal job with {len(applied)} form value(s) and {len(pdf_documents)} PDF(s).")
        if missing:
            self.set_automation_state("Needs review", f"Review {len(missing)} incomplete item(s) before starting.", "WarningBadge")

    def clear_portal_import_state(self):
        # Snapshot V2 is authoritative. Retain only the login credentials
        # needed on this device and clear every project-specific value.
        credentials = {}
        for key in ("Email", "Password"):
            widget = getattr(self, "input_fields", {}).get(key)
            if widget is not None:
                if hasattr(widget, "toPlainText"):
                    credentials[key] = widget.toPlainText()
                elif hasattr(widget, "currentText"):
                    credentials[key] = widget.currentText()
                else:
                    credentials[key] = widget.text()

        for field, widget in getattr(self, "input_fields", {}).items():
            if field in credentials:
                continue
            self.clear_portal_widget(widget)
        for group in (
            getattr(self, "agent_line_edits", {}),
            getattr(self, "applicant_line_edits", {}),
            getattr(self, "cert_line_edits", {}),
            getattr(self, "cert_dropdowns", {}),
        ):
            for widget in group.values():
                self.clear_portal_widget(widget)

        for widget in getattr(self, "portal_exception_widgets", {}).values():
            widget.setChecked(False)
        for widget in getattr(self, "portal_profile_widgets", {}).values():
            widget.blockSignals(True)
            widget.setChecked(False)
            widget.blockSignals(False)
        for widget in getattr(self, "householder_question_widgets", {}).values():
            widget.setChecked(False)
        for widget in getattr(self, "householder_parking_widgets", {}).values():
            widget.clear()
        for widget in getattr(self, "householder_text_widgets", {}).values():
            widget.clear()

        for combo_name in (
            "agent_preset_combo",
            "preset_combo",
            "cert_preset_combo",
        ):
            combo = getattr(self, combo_name, None)
            if combo is not None:
                presets.reset_preset_selection(combo)

        self.clear_pdf_mapping_lists_for_new_selection()
        self.pdf_folder_path = ""
        self.selected_pdf_paths = []
        self.state.set_pdf_selection("", [])
        self.portal_import_blocking_issues = []
        self.proposal_context = {}
        self.update_portal_answer_summary()

    def clear_portal_widget(self, widget):
        if hasattr(widget, "setCurrentIndex"):
            widget.blockSignals(True)
            widget.setCurrentIndex(-1)
            widget.blockSignals(False)
        elif hasattr(widget, "clear"):
            widget.clear()
        else:
            widget.setText("")
        widget.setProperty("touched", False)
        widget.setProperty("invalid", "false")
        repolish(widget)

    def clear_portal_import_identity_sections(self):
        # Backwards-compatible wrapper for older callers.
        self.clear_portal_import_state()

    def update_portal_job_status(
        self,
        status,
        result_summary="",
        error="",
        event_type="checkpoint",
        last_checkpoint="",
        result=None,
    ):
        if not self.portal_client or not self.state.portal_job_id:
            return
        delivered = callback_outbox.queue_and_deliver(
            self.portal_client,
            job_id=self.state.portal_job_id,
            status=status,
            event_type=event_type,
            result_summary=result_summary,
            error=error,
            last_checkpoint=last_checkpoint,
            result=result,
        )
        if delivered:
            self.state.portal_job_status = status
            callback_outbox.retry_pending(log=self.log)
        else:
            self.log("Portal result is waiting to sync and will retry automatically.")

    def set_widget_value(self, widget, value):
        if hasattr(widget, "setPlainText"):
            widget.setPlainText(value)
            return True
        if hasattr(widget, "findText"):
            return self.set_combo_value(widget, value)
        if hasattr(widget, "setText"):
            widget.setText(value)
            return True
        return False

    def set_combo_value(self, combo, value):
        index = combo.findText(value, Qt.MatchFixedString)
        if index < 0:
            return False
        combo.setCurrentIndex(index)
        return True

    def load_combo_presets(self, filename, combo):
        presets.populate_combo(SCRIPT_DIR, filename, combo, self.log)
        self.restore_last_used_preset(filename, combo)

    def load_preset_data(self, filename, combo, fields, widgets):
        self.remember_last_used_preset(filename, combo.currentText().strip())
        presets.apply_preset(SCRIPT_DIR, filename, combo, fields, widgets, self.log)

    def restore_last_used_preset(self, filename, combo):
        data = presets.load_json(SCRIPT_DIR, "last_used_presets.json")
        selected = str(data.get(filename) or "").strip() if isinstance(data, dict) else ""
        if not selected:
            return
        index = combo.findText(selected, Qt.MatchFixedString)
        if index >= 0:
            combo.setCurrentIndex(index)

    def remember_last_used_preset(self, filename, selected):
        selected = str(selected or "").strip()
        placeholder = ""
        combo = None
        for candidate in [
            getattr(self, "login_preset_combo", None),
            getattr(self, "agent_preset_combo", None),
            getattr(self, "preset_combo", None),
            getattr(self, "cert_preset_combo", None),
        ]:
            if candidate is not None and candidate.currentText().strip() == selected:
                combo = candidate
                break
        if combo is not None:
            placeholder = str(combo.property("placeholder_text") or "").strip()
        if not selected or selected == placeholder:
            return
        data = presets.load_json(SCRIPT_DIR, "last_used_presets.json")
        if not isinstance(data, dict):
            data = {}
        if selected == presets.CLEAR_PRESET_LABEL:
            data.pop(filename, None)
        else:
            data[filename] = selected
        presets.save_json(SCRIPT_DIR, "last_used_presets.json", data)

    def show_preset_saved(self, preset_type, name):
        QMessageBox.information(self, "Preset saved", f"{preset_type} preset saved: {name}")

    def save_login_preset(self):
        login_preset_controller.save_login_preset(self)

    def load_login_preset(self):
        login_preset_controller.load_login_preset(self)

    def load_login_preset_list(self):
        login_preset_controller.load_login_preset_list(self)

    def save_agent_preset(self):
        name = f"{self.agent_line_edits['Agent First Name'].text()}_{self.agent_line_edits['Agent Last Name'].text()}".strip("_") or "Unnamed_Preset"
        data = self.load_json("agent_presets.json")
        data[name] = {field: self.agent_line_edits[field].text() for field in self.agent_fields}
        self.save_json("agent_presets.json", data)
        self.remember_last_used_preset("agent_presets.json", name)
        self.load_agent_preset_list()
        self.log(f"Agent preset saved: {name}")
        self.show_preset_saved("Agent", name)

    def load_agent_preset_list(self):
        self.load_combo_presets("agent_presets.json", self.agent_preset_combo)

    def load_agent_preset(self):
        self.load_preset_data("agent_presets.json", self.agent_preset_combo, self.agent_fields, self.agent_line_edits)

    def save_applicant_preset(self):
        name = f"{self.applicant_line_edits['Applicant First Name'].text()}_{self.applicant_line_edits['Applicant Last Name'].text()}".strip("_") or "Unnamed_Preset"
        data = {}
        for field, widget in self.applicant_line_edits.items():
            data[field] = widget.currentText() if hasattr(widget, "currentText") else widget.text()
        presets_data = self.load_json("applicant_presets.json")
        presets_data[name] = data
        self.save_json("applicant_presets.json", presets_data)
        self.remember_last_used_preset("applicant_presets.json", name)
        self.load_preset_list()
        self.log(f"Applicant preset saved: {name}")
        self.show_preset_saved("Applicant", name)

    def load_preset_list(self):
        self.load_combo_presets("applicant_presets.json", self.preset_combo)

    def load_preset_applicant(self):
        self.load_preset_data("applicant_presets.json", self.preset_combo, self.applicant_fields, self.applicant_line_edits)

    def clear_applicant_form(self):
        for widget in self.applicant_line_edits.values():
            if hasattr(widget, "setCurrentIndex"):
                widget.setCurrentIndex(0)
            else:
                widget.clear()
            widget.setProperty("touched", False)
            widget.setProperty("invalid", "false")
            repolish(widget)
        self.log("Applicant form cleared.")

    def save_cert_preset(self):
        name = self.cert_line_edits["Name of Certifier"].text().strip().replace(" ", "_") or "Unnamed_Preset"
        data = {}
        for field in self.cert_fields:
            if field in self.cert_line_edits:
                data[field] = self.cert_line_edits[field].text()
            else:
                data[field] = self.cert_dropdowns[field].currentText()
        presets_data = self.load_json("cert_presets.json")
        presets_data[name] = data
        self.save_json("cert_presets.json", presets_data)
        self.remember_last_used_preset("cert_presets.json", name)
        self.load_cert_preset_list()
        self.log(f"Certificate preset saved: {name}")
        self.show_preset_saved("Certificate", name)

    def load_cert_preset_list(self):
        self.load_combo_presets("cert_presets.json", self.cert_preset_combo)

    def load_cert_preset(self):
        selected = self.cert_preset_combo.currentText().strip()
        if not selected:
            return
        self.remember_last_used_preset("cert_presets.json", selected)
        widgets = {**self.cert_line_edits, **self.cert_dropdowns}
        if selected == presets.CLEAR_PRESET_LABEL:
            presets.clear_preset_fields(self.cert_preset_combo, self.cert_fields, widgets)
            self.log("Certificate preset selection cleared.")
            self.update_portal_answer_summary()
            return
        data = self.load_json("cert_presets.json").get(selected)
        if not data:
            return
        for field in self.cert_fields:
            if field not in data:
                continue
            widget = widgets[field]
            if hasattr(widget, "findText"):
                index = widget.findText(data[field], Qt.MatchFixedString)
                if index >= 0:
                    widget.setCurrentIndex(index)
            else:
                widget.setText(data[field])
        self.update_portal_answer_summary()

    def collect_user_inputs(self):
        values = {}
        for group in [self.input_fields, self.applicant_line_edits, self.agent_line_edits]:
            for field, widget in group.items():
                if hasattr(widget, "toPlainText"):
                    values[field] = widget.toPlainText()
                elif hasattr(widget, "currentText"):
                    values[field] = widget.currentText()
                else:
                    values[field] = widget.text()
        for field in self.cert_fields:
            if field in self.cert_line_edits:
                values[field] = self.cert_line_edits[field].text()
            else:
                values[field] = self.cert_dropdowns[field].currentText()
        values["Registration Number (A)"] = f"{values.get('Registration Number (A) Part 1', '')}D{values.get('Registration Number (A) Part 2', '')}"
        values["Registration Number (B)"] = f"{values.get('Registration Number (B) Part 1', '')}DB{values.get('Registration Number (B) Part 2', '')}"
        exception_values = {
            key: ("Yes" if widget.isChecked() else "No")
            for key, widget in getattr(self, "portal_exception_widgets", {}).items()
        }
        profiles = [
            name for name, widget in getattr(self, "portal_profile_widgets", {}).items()
            if widget.isChecked()
        ]
        values[portal_answers.APPLICATION_TYPE_KEY] = self.application_type
        values.update(getattr(self, "proposal_context", {}))
        values.update(portal_answers.collect_answers(profiles, exception_values, values))
        householder_question_values = {
            key: ("Yes" if widget.isChecked() else "No")
            for key, widget in getattr(self, "householder_question_widgets", {}).items()
        }
        householder_parking_values = {
            key: widget.text()
            for key, widget in getattr(self, "householder_parking_widgets", {}).items()
        }
        householder_text_values = {
            key: widget.text()
            for key, widget in getattr(self, "householder_text_widgets", {}).items()
        }
        values.update(portal_answers.collect_householder_answers(
            householder_question_values,
            householder_parking_values,
            householder_text_values,
        ))
        values["PDF Folder Path"] = self.pdf_folder_path
        return values

    def apply_application_type(self):
        is_householder = self.application_type == portal_answers.HOUSEHOLDER_TYPE
        if hasattr(self, "welcome_title"):
            self.welcome_title.setText(self.application_type)
        if hasattr(self, "welcome_description"):
            if is_householder:
                self.welcome_description.setText("Organise PDFs, complete planning application details and automate Householder submissions through a single streamlined workflow.")
            else:
                self.welcome_description.setText("Organise PDFs, complete application details and automate Building Warrant submissions through a single streamlined workflow.")
        if hasattr(self, "building_warrant_questions_card"):
            self.building_warrant_questions_card.setVisible(not is_householder)
        if hasattr(self, "building_warrant_details_card"):
            self.building_warrant_details_card.setVisible(not is_householder)
        if hasattr(self, "householder_questions_card"):
            self.householder_questions_card.setVisible(is_householder)
        if hasattr(self, "portal_answers_summary"):
            self.update_portal_answer_summary()

    def validate_required_fields(self):
        valid = True
        missing = []
        groups = [
            ("Data Entry", self.input_fields),
            ("Agent Details", self.agent_line_edits),
            ("Applicant Details", self.applicant_line_edits),
        ]
        for step, group in groups:
            for field, widget in group.items():
                field_valid = validate_field(widget, force=True)
                if not field_valid:
                    missing.append((step, field, widget))
                valid = field_valid and valid
        cert_values = {field: widget.text() for field, widget in self.cert_line_edits.items()}
        if cert_values and portal_answers.has_partial_certificate_details(cert_values):
            self.log("Certificate details are partially filled. Complete all certificate details or clear them to skip certificate automation.")
            for field, widget in self.cert_line_edits.items():
                field_valid = validate_field(widget, force=True)
                if not field_valid:
                    missing.append(("Certificates", field, widget))
                valid = field_valid and valid
            for field, widget in self.cert_dropdowns.items():
                field_valid = validate_field(widget, force=True)
                if not field_valid:
                    missing.append(("Certificates", field, widget))
                valid = field_valid and valid
        self._last_missing_required_fields = missing
        return valid

    def missing_required_field_names(self):
        return preflight_controller.missing_required_field_names(self)

    def refresh_preflight_checklist(self):
        preflight_controller.refresh_preflight_checklist(self)

    def focus_first_missing_field(self):
        missing = getattr(self, "_last_missing_required_fields", [])
        if not missing:
            return
        step, field, widget = missing[0]
        self.navigate_to_step(self.step_index(step))
        QTimer.singleShot(150, widget.setFocus)
        QMessageBox.warning(
            self,
            "Missing required fields",
            "Please complete the highlighted required field before starting automation:\n\n"
            f"{step} - {field}",
        )

    def start_automation(self):
        self.refresh_preflight_checklist()
        if self.portal_import_blocking_issues:
            self.set_automation_state(
                "Needs review",
                "The portal job was only partially imported.",
                "ErrorBadge",
            )
            QMessageBox.critical(
                self,
                "Portal job import incomplete",
                "Automation cannot start because the portal job was only partially imported:\n\n"
                + "\n".join(f"- {issue}" for issue in self.portal_import_blocking_issues),
            )
            return
        if not self.pdf_folder_path:
            self.log("No PDFs selected.")
            self.set_automation_state("Ready", "Select PDFs before starting automation.", "WarningBadge")
            self.navigate_to_step(self.organise_tab_index)
            QMessageBox.warning(self, "PDFs missing", "Select the PDFs for this application and save the PDF mapping before starting automation.")
            return
        if not self.is_mapping_currently_saved():
            self.log("PDF mapping has not been saved.")
            self.set_automation_state("Ready", "Save the PDF mapping before starting automation.", "WarningBadge")
            self.navigate_to_step(self.organise_tab_index)
            self.start_save_mapping_highlight()
            QMessageBox.warning(self, "PDF mapping not saved", "Please save the PDF mapping before starting automation.")
            return
        if not self.validate_required_fields():
            self.log("Required fields are missing. Please review highlighted fields.")
            self.set_automation_state("Ready", "Some required fields need attention.", "WarningBadge")
            self.focus_first_missing_field()
            return
        self.hide_completion_panel()
        clear_checkpoint()
        self._last_reported_checkpoint = ""
        self.update_portal_job_status(
            "IN_PROGRESS",
            "Desktop automation started.",
            event_type="started",
            last_checkpoint="automation_started",
        )
        user_inputs = self.collect_user_inputs()
        runtime_password = str(user_inputs.pop("Password", "") or "")
        # Password is passed to the automation thread through process memory only;
        # it is deliberately not persisted to user_inputs.json.
        json_path = storage_paths.runtime_path("user_inputs.json", SCRIPT_DIR)
        with open(json_path, "w", encoding="utf-8") as handle:
            json.dump(user_inputs, handle, indent=4)
        self.log(f"Saved user_inputs.json to {json_path}")
        self.set_automation_state("Running", "Automation is active. Watch the browser and activity log.", "InfoBadge")
        self.start_button.setEnabled(False)
        self.automation_thread = AutomationThread(self.application_type, runtime_password)
        self.automation_thread.update_log.connect(self.log)
        self.automation_thread.run_completed.connect(self.on_automation_completed)
        self.automation_thread.start()

    def set_automation_state(self, state, detail, badge_name):
        self.automation_state_label.setText(state)
        state_name = {
            "SuccessBadge": "ready",
            "ErrorBadge": "error",
            "WarningBadge": "warning",
            "InfoBadge": "running",
        }.get(badge_name, "ready")
        self.automation_state_label.setObjectName("AutomationStatusText")
        self.automation_state_label.setProperty("state", state_name)
        repolish(self.automation_state_label)
        self.automation_state_detail.setText(detail)

    def on_automation_completed(self, success):
        self.start_button.setEnabled(True)
        if success:
            self.completed_steps.add(self.start_tab_index)
            self.set_automation_state("Complete", "Automation finished successfully.", "SuccessBadge")
            self.show_completion_panel()
            QMessageBox.information(self, "Application Automation Complete", "The automation has finished successfully.")
            self.update_portal_job_status(
                "AWAITING_PORTAL_REVIEW",
                "Portal form is ready for final user review.",
                event_type="result",
                last_checkpoint="final_review_reached",
                result={
                    "outcome": "completed_to_final_review",
                    "lastCompletedStep": "final_review_reached",
                    "currentSection": "final_review",
                    "documentsUploaded": len(self.downloaded_documents),
                    "warnings": [],
                    "userActionRequired": "Review the government portal form before submitting.",
                    "safeRetryPoint": None,
                    "errorCode": None,
                    "errorSummary": None,
                    "occurredAt": datetime.now(timezone.utc).isoformat(),
                },
            )
        else:
            self.set_automation_state("Error", "Automation stopped before completion. Check the activity log.", "ErrorBadge")
            self.hide_completion_panel()
            self.update_portal_job_status(
                "FAILED_RETRYABLE",
                "Desktop automation stopped before completion.",
                error="Desktop automation stopped before completion. Review the desktop activity log.",
                event_type="result",
                last_checkpoint="automation_started",
                result={
                    "outcome": "failed_retryable",
                    "lastCompletedStep": "automation_started",
                    "currentSection": None,
                    "documentsUploaded": 0,
                    "warnings": [],
                    "userActionRequired": "Review the desktop activity log, then prepare a retry.",
                    "safeRetryPoint": "start",
                    "errorCode": "DESKTOP_AUTOMATION_STOPPED",
                    "errorSummary": "Desktop automation stopped before reaching final review.",
                    "occurredAt": datetime.now(timezone.utc).isoformat(),
                },
            )
        self.update_navigation_state()

    def check_for_pause_notification(self):
        self.report_automation_checkpoint()
        automation_running = (
            hasattr(self, "automation_thread")
            and self.automation_thread.isRunning()
        )
        waiting = (
            automation_running
            and os.path.exists(storage_paths.runtime_path("continue_flag.txt", SCRIPT_DIR))
        )
        if waiting:
            self.highlight_continue_button()
            self.set_automation_state("Waiting for Form Summary", "Automation is waiting for the portal page or manual fallback.", "WarningBadge")
        else:
            self.clear_continue_highlight()

    def report_automation_checkpoint(self):
        if not self.portal_client or not os.path.exists(AUTOMATION_CHECKPOINT_FILE):
            return
        try:
            with open(AUTOMATION_CHECKPOINT_FILE, "r", encoding="utf-8") as handle:
                checkpoint = json.load(handle)
        except (OSError, json.JSONDecodeError):
            return
        checkpoint_name = str(checkpoint.get("checkpoint", "") or "")
        if not checkpoint_name or checkpoint_name == self._last_reported_checkpoint:
            return
        self._last_reported_checkpoint = checkpoint_name
        section = str(checkpoint.get("section", "") or "")
        detail = str(checkpoint.get("detail", "") or "")
        self.update_portal_job_status(
            "IN_PROGRESS",
            detail or f"Completed {section.replace('_', ' ')}.",
            event_type="checkpoint",
            last_checkpoint=checkpoint_name,
        )

    def highlight_continue_button(self):
        if hasattr(self, "continue_button"):
            self.continue_button.setStyleSheet("QPushButton { background: #20231F; color: white; border-color: #20231F; }")

    def clear_continue_highlight(self):
        if hasattr(self, "continue_button"):
            self.continue_button.setStyleSheet("")

    def remove_flag_file(self):
        flag_path = storage_paths.runtime_path("continue_flag.txt", SCRIPT_DIR)
        if os.path.exists(flag_path):
            os.remove(flag_path)
            self.log("Manual fallback used. Script should resume shortly if it is waiting.")
            self.set_automation_state("Running", "Manual fallback used; waiting for automation to resume.", "InfoBadge")
        else:
            self.log("No continue_flag.txt found. Automatic detection may not be waiting.")

    def show_completion_panel(self):
        self.completion_panel.setVisible(True)

    def hide_completion_panel(self):
        self.completion_panel.setVisible(False)

    def _set_combo_to_first(self, combo):
        if combo.count() > 0:
            combo.setCurrentIndex(0)

    def _clear_organise_state(self):
        self.inbox_list.clear()
        for widget in self.bucket_lists.values():
            widget.clear()
        self.pdf_folder_path = ""
        self.selected_pdf_paths = []
        if hasattr(self, "ai_intake_pdf_paths"):
            self.ai_intake_pdf_paths = []
            self.refresh_ai_intake_pdf_list()
        self.mapping_saved_once = False
        self._last_saved_mapping_snapshot = None
        self.stop_save_mapping_highlight()
        self.organise_status.setText("No PDFs loaded yet.")
        self.organise_status.setObjectName("InfoBadge")
        repolish(self.organise_status)
        self.splash_folder_path_label.setText("No PDFs selected")
        self.splash_folder_badge.setText("No PDFs selected")
        self.splash_folder_badge.setObjectName("WarningBadge")
        repolish(self.splash_folder_badge)
        self.update_bucket_counts()

    def reset_for_new_application_keep_presets(self, log_message=True):
        self._clear_organise_state()
        for field in ["Proposed Use", "Current Use", "Estimated Work Value"]:
            if field in self.input_fields:
                self.input_fields[field].clear()
        if "Description of Work" in self.input_fields:
            self.input_fields["Description of Work"].clear()
        if "Proposed Work" in self.input_fields:
            index = self.input_fields["Proposed Work"].findText("Construct", Qt.MatchFixedString)
            self.input_fields["Proposed Work"].setCurrentIndex(index if index >= 0 else 0)
        if hasattr(self, "set_portal_profiles"):
            self.set_portal_profiles([portal_answers.DOMESTIC_PROFILE])
            for key, widget in getattr(self, "portal_exception_widgets", {}).items():
                widget.setChecked(portal_answers.EXCEPTION_DEFAULTS.get(key, "No") == "Yes")
            self.update_portal_answer_summary()
        self.hide_completion_panel()
        self.navigate_to_step(self.application_questions_tab_index)
        if log_message:
            self.log("Ready for a new application. Presets kept, project-specific fields cleared.")

    def full_reset_application(self):
        self.reset_for_new_application_keep_presets(log_message=False)
        for field in ("Email", "Password"):
            self.input_fields[field].clear()
        for widget_map in [self.agent_line_edits, self.applicant_line_edits, self.cert_line_edits]:
            for widget in widget_map.values():
                widget.clear()
        for combo_map in [self.cert_dropdowns]:
            for combo in combo_map.values():
                self._set_combo_to_first(combo)
        for combo in [getattr(self, "login_preset_combo", None), getattr(self, "agent_preset_combo", None), getattr(self, "preset_combo", None), getattr(self, "cert_preset_combo", None)]:
            if combo is not None:
                self._set_combo_to_first(combo)
        self.log("Application fully reset. All fields cleared.")

    def format_log_message(self, message):
        text = str(message)
        lower = text.lower()
        escaped = html.escape(text).replace("\n", "<br>")
        if any(token in lower for token in ["crash", "error", "failed", "could not", "missing", "exception"]):
            style = "color:#991B1B; background-color:#FEF2F2; border-left:3px solid #B91C1C; padding:4px 7px; margin:2px 0;"
        elif any(token in lower for token in ["warning", "required", "skipped", "review", "manual"]):
            style = "color:#7C4A03; background-color:#FEF7E0; border-left:3px solid #D97706; padding:4px 7px; margin:2px 0;"
        else:
            style = "color:#5F5A52; padding:2px 7px; margin:1px 0;"
        return f'<div style="{style}">{escaped}</div>'

    def log(self, message):
        try:
            print(message)
        except Exception:
            pass
        formatted = self.format_log_message(message)
        if hasattr(self, "log_box"):
            self.log_box.append(formatted)
        if hasattr(self, "organise_log_box"):
            self.organise_log_box.append(formatted)


def select_application_type():
    selector = ApplicationSelectorDialog()
    selector.setStyleSheet(APP_QSS)
    if selector.exec() != QDialog.Accepted or not selector.selected_application_type:
        return None
    return selector.selected_application_type


def main(app=None, splash=None):
    from gui.startup_splash import update_startup_splash

    app = app or QApplication(sys.argv)
    app.setStyleSheet(APP_QSS)
    app.processEvents()
    portal_handoff.cleanup_old_job_caches(log=print)
    callback_outbox.retry_pending(log=print)
    portal_handoff.register_protocol_handler()
    launch_url = portal_handoff.automation_url_from_args()
    window = None

    if launch_url:
        try:
            update_startup_splash(splash, "loading_application", app)
            launch = portal_handoff.parse_automation_launch(launch_url)
            client = portal_handoff.PortalClient.from_handoff(
                launch["portal_url"], launch["job_id"], launch["code"]
            )
            job = client.get_job(launch["job_id"])
            if not job:
                raise portal_handoff.PortalHandoffError("The automation job could not be loaded.")
            update_startup_splash(splash, "preparing_project_data", app)
            identity = portal_handoff.application_identity_from_job(job)
            documents, failures = client.download_documents(job)
            application_type = portal_handoff.application_type_from_job(job)
            print(
                "Portal desktop job loaded:",
                {
                    "jobId": identity["job_id"],
                    "projectId": identity["project_id"],
                    "applicationType": identity["application_type"],
                    "applicationId": identity["application_id"],
                    "snapshotVersion": identity["snapshot_version"],
                    "selectedAutomation": identity["selected_automation"],
                },
            )
            update_startup_splash(splash, "opening_workspace", app)
            window = BuildingWarrantApp(
                application_type,
                job,
                client,
                documents,
                failures,
                defer_portal_load=False,
            )
            window.load_from_portal_job()
        except portal_handoff.PortalHandoffError as exc:
            close_startup_splash(splash, app)
            splash = None
            QMessageBox.warning(None, "Automation job could not be opened", f"{exc}\n\nArchitectPro will open normally so you can continue manually.")

    if window is None:
        update_startup_splash(splash, "opening_workspace", app)
        if splash is not None:
            splash.record_startup_complete()
        close_startup_splash(splash, app)
        splash = None
        application_type = select_application_type()
        if not application_type:
            return 0
        window = BuildingWarrantApp(application_type)
    show_window_after_splash(window, splash, app)
    return app.exec()


import os
from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QIcon, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout, QWidget

try:
    import qtawesome as qta
except Exception:
    qta = None


class BlueprintHeroCard(QFrame):
    def __init__(self, image_path, parent=None):
        super().__init__(parent)
        self.pixmap = QPixmap(image_path)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        rect = self.rect()
        radius = 20
        path = QPainterPath()
        path.addRoundedRect(QRectF(rect.adjusted(1, 1, -1, -1)), radius, radius)
        painter.setClipPath(path)
        painter.fillRect(rect, QColor("#4F4A43"))

        if not self.pixmap.isNull():
            scaled = self.pixmap.scaled(rect.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            x = rect.right() - scaled.width()
            y = rect.top() + (rect.height() - scaled.height()) / 2
            painter.drawPixmap(int(x), int(y), scaled)

        glow = QRadialGradient(rect.center().x() + rect.width() * 0.12, rect.center().y(), rect.width() * 0.72)
        glow.setColorAt(0.0, QColor(238, 243, 234, 68))
        glow.setColorAt(0.52, QColor(238, 243, 234, 28))
        glow.setColorAt(1.0, QColor(79, 74, 67, 0))
        painter.fillRect(rect, glow)

        fade = QLinearGradient(rect.left(), 0, rect.right(), 0)
        fade.setColorAt(0.0, QColor(31, 33, 29, 210))
        fade.setColorAt(0.46, QColor(31, 33, 29, 128))
        fade.setColorAt(1.0, QColor(31, 33, 29, 36))
        painter.fillRect(rect, fade)

        vignette = QLinearGradient(0, rect.bottom(), 0, rect.top())
        vignette.setColorAt(0.0, QColor(31, 33, 29, 120))
        vignette.setColorAt(0.55, QColor(31, 33, 29, 0))
        vignette.setColorAt(1.0, QColor(31, 33, 29, 0))
        painter.fillRect(rect, vignette)
        painter.setClipping(False)
        painter.setPen(QPen(QColor(221, 214, 202, 72), 1))
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(rect.adjusted(0, 0, -1, -1), radius, radius)


def build(app):
    page = QWidget()
    page.setObjectName("WelcomePage")
    layout = QVBoxLayout(page)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(16)

    app.splash_folder_badge = QLabel()
    app.splash_folder_badge.setVisible(False)
    app.splash_folder_path_label = QLabel()
    app.splash_folder_path_label.setVisible(False)

    layout.addWidget(_build_hero(app), 1)
    layout.addWidget(_build_workflow_strip(), 0)
    return page


def _build_hero(app):
    hero = BlueprintHeroCard(os.path.join(_project_root(), "assets", "blueprint.jpg"))
    hero.setObjectName("WelcomeHero")
    hero.setMinimumHeight(560)
    hero.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
    layout = QVBoxLayout(hero)
    layout.setContentsMargins(56, 96, 56, 56)
    layout.setSpacing(0)

    content = QWidget()
    content.setObjectName("WelcomeHeroContent")
    content.setMaximumWidth(760)
    copy = QVBoxLayout(content)
    copy.setSpacing(16)
    copy.setContentsMargins(0, 0, 0, 0)

    brand = QLabel("NinetyOneArchitects")
    brand.setObjectName("WelcomeEyebrow")
    title = QLabel(getattr(app, "application_type", "Building Warrant"))
    title.setObjectName("WelcomeHeroTitle")
    title.setWordWrap(False)
    app.welcome_title = title
    description = QLabel(
        "Organise PDFs, complete application details and automate Building Warrant submissions through a single streamlined workflow."
    )
    description.setObjectName("WelcomeHeroSubtitle")
    description.setMaximumWidth(680)
    description.setWordWrap(True)
    app.welcome_description = description

    actions = QHBoxLayout()
    actions.setSpacing(14)
    start = QPushButton("Start Workflow")
    start.setObjectName("WelcomePrimaryButton")
    start_icon = _awesome_icon("fa5s.rocket", "#FFFFFF")
    if not start_icon.isNull():
        start.setIcon(start_icon)
        start.setText("  Start Workflow")
    start.setIconSize(QSize(18, 18))
    start.setFixedSize(220, 56)
    start.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
    start.setCursor(Qt.PointingHandCursor)
    start.clicked.connect(lambda: app.navigate_to_step(1))
    actions.addWidget(start)
    actions.addStretch(1)

    copy.addWidget(brand)
    copy.addWidget(title)
    copy.addWidget(description)
    copy.addSpacing(10)
    copy.addLayout(actions)
    copy.addStretch(1)
    layout.addWidget(content, 0, Qt.AlignLeft | Qt.AlignTop)
    return hero


def _build_workflow_strip():
    strip = QFrame()
    strip.setObjectName("WelcomeWorkflowStrip")
    strip.setFixedHeight(154)
    layout = QVBoxLayout(strip)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(12)

    title = QLabel("Simple Workflow")
    title.setObjectName("WelcomeStripTitle")
    layout.addWidget(title)

    cards = QHBoxLayout()
    cards.setSpacing(14)
    for index, (icon, heading, body) in enumerate([
        ("fa5s.folder-open", "Organise PDFs", "Sort drawings and supporting documents"),
        ("fa5s.clipboard-list", "Complete Details", "Review Agent, Applicant and application information"),
        ("fa5s.rocket", "Run Automation", "Submit directly into eDevelopment portal"),
    ], start=1):
        cards.addWidget(_workflow_card(index, icon, heading, body), 1)
    layout.addLayout(cards, 1)
    return strip


def _workflow_card(index, icon_name, heading, body):
    card = QFrame()
    card.setObjectName("WelcomeWorkflowCard")
    layout = QHBoxLayout(card)
    layout.setContentsMargins(16, 14, 16, 14)
    layout.setSpacing(13)

    icon = QLabel()
    icon.setObjectName("WelcomeWorkflowIcon")
    card_icon = _awesome_icon(icon_name, "#4F6748")
    if card_icon.isNull():
        icon.setText(str(index))
    else:
        icon.setPixmap(card_icon.pixmap(22, 22))
    icon.setFixedSize(42, 42)
    icon.setAlignment(Qt.AlignCenter)

    copy = QVBoxLayout()
    copy.setSpacing(4)
    title = QLabel(heading)
    title.setObjectName("WelcomeWorkflowTitle")
    text = QLabel(body)
    text.setObjectName("WelcomeWorkflowText")
    text.setWordWrap(True)
    copy.addWidget(title)
    copy.addWidget(text)

    layout.addWidget(icon)
    layout.addLayout(copy, 1)
    return card


def _project_root():
    return os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _awesome_icon(name, color):
    if qta is None:
        return QIcon()
    try:
        return qta.icon(name, color=color)
    except Exception:
        return QIcon()

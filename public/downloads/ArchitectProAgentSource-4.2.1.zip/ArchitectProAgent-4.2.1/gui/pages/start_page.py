from PySide6.QtGui import QFont
from PySide6.QtWidgets import QHBoxLayout, QLabel, QTextEdit, QVBoxLayout

from ..components import action_bar, button, card, scroll_page


def _page_header():
    frame, layout = card("HeaderCard")
    title = QLabel("Run Automation")
    title.setObjectName("PageTitle")
    description = QLabel(
        "Review anything that needs attention, then start the controlled browser automation."
    )
    description.setObjectName("Muted")
    description.setWordWrap(True)
    layout.addWidget(title)
    layout.addWidget(description)
    return frame


def build(app):
    page, layout = scroll_page()
    layout.addWidget(_page_header())

    app.portal_import_panel, portal_layout = card("FormCard")
    portal_title = QLabel("Portal application ready to review")
    portal_title.setObjectName("CardTitle")
    portal_hint = QLabel(
        "Project information and documents have been loaded. Review anything marked as incomplete before starting."
    )
    portal_hint.setObjectName("Muted")
    portal_hint.setWordWrap(True)
    app.portal_review_summary = QTextEdit()
    app.portal_review_summary.setReadOnly(True)
    app.portal_review_summary.setMinimumHeight(220)
    app.portal_review_summary.setObjectName("ActivityLog")
    portal_actions = QHBoxLayout()
    app.portal_edit_button = button("Edit Information", "secondary")
    app.portal_edit_button.clicked.connect(
        lambda: app.navigate_to_step(app.step_index("Data Entry"))
    )
    portal_actions.addWidget(app.portal_edit_button)
    portal_actions.addStretch(1)
    portal_layout.addWidget(portal_title)
    portal_layout.addWidget(portal_hint)
    portal_layout.addWidget(app.portal_review_summary)
    portal_layout.addLayout(portal_actions)
    app.portal_import_panel.setVisible(False)
    layout.addWidget(app.portal_import_panel)

    controls, controls_layout = card("FormCard")
    controls_header = QHBoxLayout()
    controls_copy = QVBoxLayout()
    controls_copy.setSpacing(4)
    title = QLabel("Start automation")
    title.setObjectName("CardTitle")
    app.automation_state_detail = QLabel(
        "Ready to start when every required section is complete."
    )
    app.automation_state_detail.setObjectName("Muted")
    app.automation_state_detail.setWordWrap(True)
    controls_copy.addWidget(title)
    controls_copy.addWidget(app.automation_state_detail)
    controls_header.addLayout(controls_copy, 1)
    app.automation_state_label = QLabel("Ready")
    app.automation_state_label.setObjectName("AutomationStatusText")
    app.automation_state_label.setProperty("state", "ready")
    controls_header.addWidget(app.automation_state_label)
    controls_layout.addLayout(controls_header)
    app.start_button = button("Start Automation", "primary")
    app.start_button.setMinimumHeight(54)
    app.start_button.clicked.connect(app.start_automation)
    controls_layout.addWidget(app.start_button)
    layout.addWidget(controls)

    checklist, checklist_layout = card("FormCard")
    checklist_header = QHBoxLayout()
    checklist_copy = QVBoxLayout()
    checklist_copy.setSpacing(4)
    checklist_title = QLabel("Pre-flight checklist")
    checklist_title.setObjectName("CardTitle")
    app.preflight_hint_label = QLabel("")
    app.preflight_hint_label.setObjectName("Muted")
    app.preflight_hint_label.setWordWrap(True)
    checklist_copy.addWidget(checklist_title)
    checklist_copy.addWidget(app.preflight_hint_label)
    checklist_header.addLayout(checklist_copy, 1)
    app.preflight_summary_label = QLabel("Checking application...")
    app.preflight_summary_label.setObjectName("PreflightSummary")
    checklist_header.addWidget(app.preflight_summary_label)
    checklist_layout.addLayout(checklist_header)
    app.preflight_rows_layout = QVBoxLayout()
    app.preflight_rows_layout.setSpacing(0)
    checklist_layout.addLayout(app.preflight_rows_layout)
    app.preflight_rows = {}
    layout.addWidget(checklist)

    app.completion_panel, completion_layout = card("StatusCard")
    complete_title = QLabel("Application Complete")
    complete_title.setObjectName("CardTitle")
    complete_text = QLabel(
        "Automation has finished. Continue reviewing the browser session, or reset this app for another application."
    )
    complete_text.setObjectName("Muted")
    complete_text.setWordWrap(True)
    completion_layout.addWidget(complete_title)
    completion_layout.addWidget(complete_text)
    buttons = QHBoxLayout()
    app.prepare_new_app_btn = button("Prepare New Application", "secondary")
    app.prepare_new_app_btn.clicked.connect(app.reset_for_new_application_keep_presets)
    app.full_reset_btn = button("Full Reset", "ghost")
    app.full_reset_btn.clicked.connect(app.full_reset_application)
    app.hide_completion_btn = button("Hide", "ghost")
    app.hide_completion_btn.clicked.connect(app.hide_completion_panel)
    buttons.addWidget(app.prepare_new_app_btn)
    buttons.addWidget(app.full_reset_btn)
    buttons.addWidget(app.hide_completion_btn)
    buttons.addStretch(1)
    completion_layout.addLayout(buttons)
    app.completion_panel.setVisible(False)
    layout.addWidget(app.completion_panel)

    log_card, log_layout = card("Terminal")
    log_title = QLabel("Activity Log")
    log_title.setObjectName("CardTitle")
    app.log_box = QTextEdit()
    app.log_box.setObjectName("ActivityLog")
    app.log_box.setReadOnly(True)
    app.log_box.setFont(QFont("Consolas", 10))
    app.log_box.setMinimumHeight(220)
    log_layout.addWidget(log_title)
    log_layout.addWidget(app.log_box)
    layout.addWidget(log_card, 1)
    layout.addWidget(action_bar(app.back))
    return page

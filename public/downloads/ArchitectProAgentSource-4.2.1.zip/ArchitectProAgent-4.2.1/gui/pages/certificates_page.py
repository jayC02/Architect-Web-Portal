from PySide6.QtWidgets import QComboBox, QLabel, QLineEdit

from ..components import action_bar, card, configure_field, form_grid, form_section_header, preset_header_card, scroll_page


def _preset_combo(app):
    app.cert_preset_combo = QComboBox()
    app.cert_preset_combo.currentIndexChanged.connect(app.load_cert_preset)
    return app.cert_preset_combo


def build(app):
    page, layout = scroll_page()
    layout.addWidget(preset_header_card(
        "Certificates",
        "Add certificate scheme, certifier, and approved body information.",
        "fa5s.certificate",
        _preset_combo(app),
        "Load Certificate Preset",
        app.save_cert_preset,
    ))
    app.cert_fields = [
        "Scheme Type",
        "Registration Number (A) Part 1",
        "Registration Number (A) Part 2",
        "Name of Certifier",
        "Registration Number (B) Part 1",
        "Registration Number (B) Part 2",
        "Name of Approved Body",
    ]
    app.cert_line_edits = {}
    app.cert_dropdowns = {}
    items = []
    for field in app.cert_fields:
        if field in {"Registration Number (A) Part 1", "Registration Number (B) Part 1"}:
            widget = QComboBox()
            widget.addItems(["BRE1", "BRE2", "RIA1", "RIA2", "SER1"])
            app.cert_dropdowns[field] = configure_field(widget, required=True)
        else:
            widget = configure_field(QLineEdit(), f"Enter {field.lower()}", required=field != "Scheme Type")
            widget.textChanged.connect(app.update_portal_answer_summary)
            app.cert_line_edits[field] = widget
        items.append((field, widget, bool(widget.property("required"))))
    form, form_layout = card("FormCard")
    form_layout.addLayout(form_section_header("Certificate Information", "fa5s.certificate"))
    hint = QLabel("Use the saved certifier preset where possible. Dropdowns and text fields share the same layout so the certificate references are easy to check.")
    hint.setObjectName("Muted")
    hint.setWordWrap(True)
    form_layout.addWidget(hint)
    form_layout.addLayout(form_grid(items, columns=2))
    layout.addWidget(form)
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.step_index("Start Automation")), app.save_cert_preset))
    return page

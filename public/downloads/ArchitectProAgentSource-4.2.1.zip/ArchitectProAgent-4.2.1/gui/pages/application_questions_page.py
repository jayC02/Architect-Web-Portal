from types import MethodType

from PySide6.QtWidgets import QCheckBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QSizePolicy, QVBoxLayout

from ..components import action_bar, badge, card, configure_field, field_block, form_section_header, header_card, repolish, scroll_page, vector_icon_label
from ..services import portal_answers


def build(app):
    _install_application_question_hooks(app)

    page, layout = scroll_page()
    if not app.is_householder_application():
        layout.addWidget(header_card(
            "Application Questions",
            "Choose the type of work and set any unusual details before the automation answers the portal questions.",
            "Q",
        ))

    form, form_layout = card("FormCard")
    app.building_warrant_questions_card = form
    form_layout.addLayout(form_section_header("Type of Work", "fa5s.tasks"))

    hint = QLabel("Choose the main type of application work first, then review only the unusual details below.")
    hint.setObjectName("Muted")
    hint.setWordWrap(True)
    form_layout.addWidget(hint)

    selector = QFrame()
    selector.setObjectName("PrimaryDropdownPanel")
    selector_layout = QVBoxLayout(selector)
    selector_layout.setContentsMargins(18, 16, 18, 18)
    selector_layout.setSpacing(12)

    selector_header = QHBoxLayout()
    selector_header.setSpacing(12)
    selector_header.addWidget(vector_icon_label("fa5s.tasks", "#4F6748", 36, 15, "DropdownPromptIcon"))
    selector_copy = QVBoxLayout()
    selector_copy.setSpacing(2)
    selector_title = QLabel("Select every type of work that applies")
    selector_title.setObjectName("PrimaryFieldLabel")
    selector_hint = QLabel("More than one option can be selected.")
    selector_hint.setObjectName("DropdownHelp")
    selector_hint.setWordWrap(True)
    selector_copy.addWidget(selector_title)
    selector_copy.addWidget(selector_hint)
    selector_header.addLayout(selector_copy, 1)
    selector_header.addWidget(badge("Multiple choice", "info"))
    selector_layout.addLayout(selector_header)

    profile_grid = QGridLayout()
    profile_grid.setHorizontalSpacing(22)
    profile_grid.setVerticalSpacing(8)
    app.portal_profile_widgets = {}
    for index, name in enumerate(portal_answers.profile_names()):
        checkbox = QCheckBox(name)
        checkbox.setObjectName("PortalAnswerCheck")
        checkbox.setChecked(name == portal_answers.DOMESTIC_PROFILE)
        checkbox.toggled.connect(app.on_portal_profile_changed)
        app.portal_profile_widgets[name] = checkbox
        profile_grid.addWidget(checkbox, index // 2, index % 2)
    selector_layout.addLayout(profile_grid)
    form_layout.addWidget(selector)
    layout.addWidget(form)

    details, details_layout = card("FormCard")
    app.building_warrant_details_card = details
    details_layout.addLayout(form_section_header("Additional Unusual Application Details", "fa5s.sliders-h"))
    details_hint = QLabel("Leave these as they are for a normal domestic alteration or extension. Switch only the details that genuinely apply.")
    details_hint.setObjectName("Muted")
    details_hint.setWordWrap(True)
    details_layout.addWidget(details_hint)

    app.portal_exception_widgets = {}
    for key, default in portal_answers.EXCEPTION_DEFAULTS.items():
        checkbox = QCheckBox(portal_answers.FIELD_LABELS.get(key, key))
        checkbox.setObjectName("PortalAnswerCheck")
        checkbox.setChecked(default == "Yes")
        checkbox.toggled.connect(app.update_portal_answer_summary)
        app.portal_exception_widgets[key] = checkbox

    _add_question_group(
        details_layout,
        "Ownership",
        "Applicant and ownership assumptions for the application.",
        ["Applicant Is Owner"],
        app.portal_exception_widgets,
        columns=1,
    )
    _add_question_group(
        details_layout,
        "Application route",
        "Only change these when the warrant follows a less common route.",
        ["Application Staged", "Limited Life Building"],
        app.portal_exception_widgets,
    )
    _add_question_group(
        details_layout,
        "Site and authority constraints",
        "Checks that can trigger extra portal pages or supporting detail.",
        [
            "Fire Rescue Enforcing Authority",
            "Listed Or Conservation Area",
            "Other Historical Importance",
            "Relaxation Direction",
            "Dangerous Building Notice",
        ],
        app.portal_exception_widgets,
    )
    _add_question_group(
        details_layout,
        "Certification",
        "Construction certification and approval scheme details.",
        ["Approved Certifier Construction", "STAS"],
        app.portal_exception_widgets,
    )
    _add_question_group(
        details_layout,
        "Public register",
        "Restrict public inspection only where the proposal genuinely requires it.",
        ["Public Inspection Restricted"],
        app.portal_exception_widgets,
        columns=1,
    )

    layout.addWidget(details)
    layout.addWidget(_build_householder_questions_card(app))
    if app.is_householder_application():
        layout.addStretch(1)
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.organise_tab_index)))

    app.update_portal_answer_summary()
    app.apply_application_type()
    return page


def _build_householder_questions_card(app):
    frame, layout = card("FormCard")
    frame.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
    app.householder_questions_card = frame
    layout.addLayout(form_section_header("Householder Application Questions", "fa5s.home"))

    hint = QLabel("These answer the first Householder planning application pages. Leave the defaults unless this proposal is unusual.")
    hint.setObjectName("Muted")
    hint.setWordWrap(True)
    layout.addWidget(hint)

    app.householder_question_widgets = {}
    for key, default in portal_answers.HOUSEHOLDER_DEFAULTS.items():
        checkbox = QCheckBox(portal_answers.HOUSEHOLDER_FIELD_LABELS.get(key, key))
        checkbox.setObjectName("PortalAnswerCheck")
        checkbox.setChecked(default == "Yes")
        checkbox.toggled.connect(app.update_portal_answer_summary)
        if key == "Householder New Or Altered Vehicle Access":
            checkbox.toggled.connect(app.update_householder_parking_visibility)
        app.householder_question_widgets[key] = checkbox

    _add_question_group(
        layout,
        "Planning and site details",
        "Questions that affect the Main Details section.",
        [
            "Householder Discussed With Planning Authority",
            "Householder Trees On Site",
            "Householder New Or Altered Vehicle Access",
        ],
        app.householder_question_widgets,
    )
    _add_question_group(
        layout,
        "Ownership certificate",
        "Answers used by the Certificate of Ownership section.",
        [
            "Householder Sole Owner",
            "Householder Agricultural Holding",
            "Householder Identify All Other Owners",
            "Householder Notice To One Owner",
        ],
        app.householder_question_widgets,
    )

    app.householder_text_widgets = {}
    reasonable_steps = configure_field(
        QLineEdit(),
        "Describe the reasonable steps taken when other owners cannot be identified or notified",
        False,
    )
    app.householder_text_widgets["Householder Ownership Reasonable Steps"] = reasonable_steps
    reasonable_steps.textChanged.connect(app.update_portal_answer_summary)
    layout.addLayout(field_block(
        "Reasonable steps taken to identify or notify other owners",
        reasonable_steps,
        False,
    ))

    _add_question_group(
        layout,
        "Location plan",
        "Confirm this only after checking the submitted PDF.",
        ["Householder Location Plan Printed And Verified"],
        app.householder_question_widgets,
        columns=1,
    )

    parking_grid = QGridLayout()
    parking_grid.setHorizontalSpacing(24)
    parking_grid.setVerticalSpacing(12)
    app.householder_parking_widgets = {}
    current = configure_field(QLineEdit(), "0", False)
    proposed = configure_field(QLineEdit(), "0", False)
    app.householder_parking_widgets["Householder Current Parking Spaces"] = current
    app.householder_parking_widgets["Householder Proposed Parking Spaces"] = proposed
    current.textChanged.connect(app.update_portal_answer_summary)
    proposed.textChanged.connect(app.update_portal_answer_summary)
    current_block = field_block("Current vehicle parking spaces", current, False)
    proposed_block = field_block("Proposed total vehicle parking spaces", proposed, False)
    app.householder_parking_blocks = [current_block, proposed_block]
    parking_grid.addLayout(current_block, 0, 0)
    parking_grid.addLayout(proposed_block, 0, 1)
    layout.addLayout(parking_grid)

    app.update_householder_parking_visibility()
    frame.setVisible(False)
    return frame


def _add_question_group(parent_layout, title, hint, keys, widgets, columns=2):
    group = QFrame()
    group.setObjectName("QuestionGroup")
    group_layout = QVBoxLayout(group)
    group_layout.setContentsMargins(16, 12, 16, 14)
    group_layout.setSpacing(8)

    title_label = QLabel(title)
    title_label.setObjectName("QuestionGroupTitle")
    group_layout.addWidget(title_label)
    if hint:
        hint_label = QLabel(hint)
        hint_label.setObjectName("QuestionGroupHint")
        hint_label.setWordWrap(True)
        group_layout.addWidget(hint_label)

    grid = QGridLayout()
    grid.setHorizontalSpacing(22)
    grid.setVerticalSpacing(8)
    visible_index = 0
    for key in keys:
        widget = widgets.get(key)
        if widget is None:
            continue
        grid.addWidget(widget, visible_index // columns, visible_index % columns)
        visible_index += 1
    group_layout.addLayout(grid)
    parent_layout.addWidget(group)
    return group


def _install_application_question_hooks(app):
    if getattr(app, "_portal_answer_hooks_installed", False):
        return
    app._portal_answer_hooks_installed = True
    app.update_portal_answer_summary = MethodType(_update_portal_answer_summary, app)
    app.on_portal_profile_changed = MethodType(_on_portal_profile_changed, app)
    app.set_portal_profiles = MethodType(_set_portal_profiles, app)
    app.update_householder_parking_visibility = MethodType(_update_householder_parking_visibility, app)


def _current_portal_answers(app):
    profiles = _selected_profiles(app)
    exceptions = {
        key: ("Yes" if widget.isChecked() else "No")
        for key, widget in getattr(app, "portal_exception_widgets", {}).items()
    }
    certificate_values = {}
    for field, widget in getattr(app, "cert_line_edits", {}).items():
        certificate_values[field] = widget.text()
    return portal_answers.collect_answers(profiles, exceptions, certificate_values)


def _update_portal_answer_summary(app):
    if hasattr(app, "portal_answers_summary"):
        answers = _current_portal_answers(app)
        app.portal_answers_summary.setText("\n".join(portal_answers.summary_lines(answers)))
        repolish(app.portal_answers_summary)
    if hasattr(app, "householder_summary"):
        question_values = {
            key: ("Yes" if widget.isChecked() else "No")
            for key, widget in getattr(app, "householder_question_widgets", {}).items()
        }
        parking_values = {
            key: widget.text()
            for key, widget in getattr(app, "householder_parking_widgets", {}).items()
        }
        text_values = {
            key: widget.text()
            for key, widget in getattr(app, "householder_text_widgets", {}).items()
        }
        householder_answers = portal_answers.collect_householder_answers(
            question_values,
            parking_values,
            text_values,
        )
        app.householder_summary.setText("\n".join(portal_answers.householder_summary_lines(householder_answers)))
        repolish(app.householder_summary)


def _selected_profiles(app):
    return [
        name for name, widget in getattr(app, "portal_profile_widgets", {}).items()
        if widget.isChecked()
    ]


def _set_portal_profiles(app, value):
    profiles = portal_answers.normalise_profiles(value)
    for name, widget in getattr(app, "portal_profile_widgets", {}).items():
        widget.blockSignals(True)
        widget.setChecked(name in profiles)
        widget.blockSignals(False)
    app.on_portal_profile_changed()
    return True


def _on_portal_profile_changed(app, *_):
    profiles = _selected_profiles(app)
    if not profiles:
        domestic = getattr(app, "portal_profile_widgets", {}).get(portal_answers.DOMESTIC_PROFILE)
        if domestic is not None:
            domestic.blockSignals(True)
            domestic.setChecked(True)
            domestic.blockSignals(False)
        profiles = [portal_answers.DOMESTIC_PROFILE]
    proposed_work = portal_answers.proposed_work_for_profiles(profiles)
    proposed_work_combo = getattr(app, "input_fields", {}).get("Proposed Work")
    if proposed_work_combo is not None and hasattr(proposed_work_combo, "findText"):
        index = proposed_work_combo.findText(proposed_work)
        if index >= 0:
            proposed_work_combo.setCurrentIndex(index)
    app.update_portal_answer_summary()


def _update_householder_parking_visibility(app):
    access_widget = getattr(app, "householder_question_widgets", {}).get("Householder New Or Altered Vehicle Access")
    visible = bool(access_widget and access_widget.isChecked())
    for block in getattr(app, "householder_parking_blocks", []):
        for index in range(block.count()):
            item = block.itemAt(index)
            if item and item.widget():
                item.widget().setVisible(visible)
    app.update_portal_answer_summary()

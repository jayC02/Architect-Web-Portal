import os

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QScrollArea,
    QSizePolicy,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from ..components import CompactListWidget, PdfFileDelegate, badge, button, configure_field, repolish, themed_icon
from ..controllers.pdf_mapping_controller import PdfMappingController
from ..services.pdf_mapping import CONFIDENCE_ROLE, FILENAME_ROLE

SIZE_ROLE = Qt.UserRole + 3


class MappingRing(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.assigned = 0
        self.total = 0
        self.setFixedSize(124, 124)

    def set_value(self, assigned, total):
        self.assigned = max(0, int(assigned or 0))
        self.total = max(0, int(total or 0))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(12, 12, 100, 100)
        pen = QPen(QColor("#E9E2D8"), 10)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        painter.drawArc(rect, 0, 360 * 16)
        if self.total:
            progress = max(0.0, min(1.0, self.assigned / self.total))
            pen.setColor(QColor("#166534"))
            painter.setPen(pen)
            painter.drawArc(rect, 90 * 16, int(-360 * progress * 16))

        painter.setPen(QColor("#1F211D"))
        painter.setFont(QFont("Segoe UI", 15, QFont.Bold))
        painter.drawText(self.rect().adjusted(0, 30, 0, -52), Qt.AlignCenter, f"{self.assigned} / {self.total}")
        painter.setPen(QColor("#6F6A62"))
        painter.setFont(QFont("Segoe UI", 9))
        painter.drawText(self.rect().adjusted(0, 60, 0, -28), Qt.AlignCenter, "Files assigned")


class BucketDropCard(QFrame):
    def __init__(self, app, bucket_key, parent=None):
        super().__init__(parent)
        self.app = app
        self.bucket_key = bucket_key
        self.setAcceptDrops(True)
        self.setProperty("dragActive", "false")

    def set_drag_active(self, active):
        value = "true" if active else "false"
        if self.property("dragActive") != value:
            self.setProperty("dragActive", value)
            repolish(self)

    def dragEnterEvent(self, event):
        accepted = _can_accept_bucket_drop(self.app, event.source(), self.bucket_key)
        self.set_drag_active(accepted)
        if accepted:
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        accepted = _can_accept_bucket_drop(self.app, event.source(), self.bucket_key)
        self.set_drag_active(accepted)
        if accepted:
            event.acceptProposedAction()
        else:
            event.ignore()

    def dragLeaveEvent(self, event):
        self.set_drag_active(False)
        event.accept()

    def dropEvent(self, event):
        self.set_drag_active(False)
        if _move_selected_items_to_bucket(self.app, event.source(), self.bucket_key):
            event.acceptProposedAction()
        else:
            event.ignore()

def build(app):
    _install_organise_hooks(app)

    page = QWidget()
    layout = QVBoxLayout(page)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(12)

    layout.addWidget(_build_header(app))

    workspace = QHBoxLayout()
    workspace.setSpacing(12)
    workspace.addWidget(_build_inbox_panel(app), 24)
    workspace.addWidget(_build_groups_panel(app), 54)
    workspace.addWidget(_build_summary_panel(app), 22)
    layout.addLayout(workspace, 1)

    app.mapping_reminder = QLabel("Save Mapping is required before you continue.")
    app.mapping_reminder.setObjectName("WarningBadge")
    app.mapping_reminder.setVisible(False)
    layout.addWidget(app.mapping_reminder, 0, Qt.AlignLeft)

    toast_row = QHBoxLayout()
    toast_row.setContentsMargins(0, 0, 0, 0)
    toast_row.addStretch(1)
    app.mapping_toast = _build_save_toast(app)
    toast_row.addWidget(app.mapping_toast)
    layout.addLayout(toast_row)

    layout.addWidget(_build_activity_log(app))
    app.update_bucket_counts()
    return page


def _build_header(app):
    frame = QFrame()
    frame.setObjectName("OrganiseHeader")
    frame.setFixedHeight(106)
    layout = QHBoxLayout(frame)
    layout.setContentsMargins(24, 18, 24, 18)
    layout.setSpacing(18)

    icon = QLabel("PDF")
    icon.setObjectName("IconTile")
    icon.setAlignment(Qt.AlignCenter)
    icon.setFixedSize(60, 60)
    icon.setFont(QFont("Segoe UI", 15, QFont.Bold))
    layout.addWidget(icon)

    copy = QVBoxLayout()
    copy.setSpacing(5)
    title = QLabel("Organise PDFs")
    title.setObjectName("PageTitle")
    description = QLabel("Sort supporting files into the correct upload groups before submission.")
    description.setObjectName("Muted")
    copy.addWidget(title)
    copy.addWidget(description)
    layout.addLayout(copy, 1)

    select = button("  Select PDFs", "secondary", awesome="fa5s.file-pdf", icon_color="#4F4A43", icon_size=16)
    select.setObjectName("PdfSelectFolderButton")
    select.clicked.connect(app.select_pdf_files)
    app.btn_autosort = button("  Auto-sort PDFs", "secondary", awesome="fa5s.magic", icon_color="#FFFFFF", icon_size=16)
    app.btn_autosort.setObjectName("PdfAiSortButton")
    app.btn_autosort.clicked.connect(app.autosort_pdfs)
    app.btn_save_mapping = button("  Save Mapping", "primary", awesome="fa5s.save", icon_color="#FFFFFF", icon_size=16)
    app.btn_save_mapping.setObjectName("PdfSaveMappingButton")
    app.btn_save_mapping.clicked.connect(app.save_pdf_mapping)
    actions = QHBoxLayout()
    actions.setSpacing(12)
    for action, size in (
        (select, QSize(170, 50)),
        (app.btn_autosort, QSize(165, 50)),
        (app.btn_save_mapping, QSize(155, 50)),
    ):
        action.setFixedSize(size)
        action.setIconSize(QSize(16, 16))
        action.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        actions.addWidget(action)
    layout.addLayout(actions)
    return frame


def _build_inbox_panel(app):
    panel = QFrame()
    panel.setObjectName("OrganisePanel")
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(16, 16, 16, 16)
    layout.setSpacing(10)

    header = QHBoxLayout()
    app.inbox_title = QLabel("Inbox (0)")
    app.inbox_title.setObjectName("CardTitle")
    app.inbox_count = badge("0", "info")
    header.addWidget(app.inbox_title)
    header.addStretch(1)
    header.addWidget(app.inbox_count)
    layout.addLayout(header)

    app.pdf_filter = configure_field(QLineEdit(), "Filter PDFs...", False)
    app.pdf_filter.setFixedHeight(34)
    app.pdf_filter.textChanged.connect(app.filter_inbox)
    layout.addWidget(app.pdf_filter)

    preview_hint = QLabel("Double-click a PDF to preview it.")
    preview_hint.setObjectName("Muted")
    layout.addWidget(preview_hint)

    app.inbox_list = CompactListWidget("No PDFs loaded")
    app.inbox_list.setObjectName("FileList")
    app.inbox_list.owner_app = app
    app.inbox_list.setItemDelegate(PdfFileDelegate(FILENAME_ROLE, SIZE_ROLE, CONFIDENCE_ROLE, row_height=32, parent=app.inbox_list))
    app.inbox_list.setMinimumHeight(260)
    app.setup_dnd_list(app.inbox_list)
    layout.addWidget(app.inbox_list, 1)

    drop = QFrame()
    drop.setObjectName("InboxDropZone")
    drop.setFixedHeight(90)
    drop_layout = QVBoxLayout(drop)
    drop_layout.setContentsMargins(10, 10, 10, 10)
    drop_layout.setSpacing(2)
    drop_icon = QLabel("PDF")
    drop_icon.setObjectName("PdfIcon")
    drop_icon.setAlignment(Qt.AlignCenter)
    drop_icon.setFixedSize(22, 22)
    drop_label = QLabel("Drop a PDF here")
    drop_label.setObjectName("FieldLabel")
    drop_hint = QLabel("or click to browse")
    drop_hint.setObjectName("Muted")
    drop_layout.addWidget(drop_icon, 0, Qt.AlignHCenter)
    drop_layout.addWidget(drop_label, 0, Qt.AlignHCenter)
    drop_layout.addWidget(drop_hint, 0, Qt.AlignHCenter)
    layout.addWidget(drop)
    return panel


def _build_groups_panel(app):
    panel = QFrame()
    panel.setObjectName("OrganisePanel")
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(16, 16, 16, 16)
    layout.setSpacing(10)
    title = QLabel("Upload Groups")
    title.setObjectName("CardTitle")
    layout.addWidget(title)
    hint = QLabel("Drag files between buckets to correct the mapping. Double-click any assigned PDF to preview it.")
    hint.setObjectName("Muted")
    layout.addWidget(hint)
    app.organise_status = QLabel("")
    app.organise_status.setObjectName("InfoBadge")
    app.organise_status.setVisible(False)

    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.NoFrame)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    scroll_body = QWidget()
    grid = QGridLayout(scroll_body)
    grid.setHorizontalSpacing(10)
    grid.setVerticalSpacing(10)
    grid.setContentsMargins(0, 0, 0, 0)
    app.bucket_lists = {}
    app.bucket_count_labels = {}
    app.bucket_empty_labels = {}
    for index, (key, label, required, max_files) in enumerate(app.bucket_defs):
        grid.addWidget(_bucket_card(app, key, label, required), index // 2, index % 2)
    scroll.setWidget(scroll_body)
    layout.addWidget(scroll, 1)
    return panel


def _bucket_card(app, key, title_text, required):
    frame = BucketDropCard(app, key)
    frame.setObjectName("BucketCard")
    frame.setMinimumHeight(94)
    frame.setToolTip("Drop PDFs anywhere in this bucket")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(10, 8, 10, 8)
    layout.setSpacing(6)

    header = QHBoxLayout()
    header.setSpacing(6)
    title = QLabel(title_text)
    title.setObjectName("FieldLabel")
    count = badge("0", "info")
    count.setFixedSize(24, 24)
    app.bucket_count_labels[key] = count
    header.addWidget(title, 1)
    if required:
        required_badge = badge("Required", "required")
        required_badge.setFixedHeight(24)
        header.addWidget(required_badge)
    header.addWidget(count)
    layout.addLayout(header)

    empty = QLabel("Drop PDFs anywhere in this bucket")
    empty.setObjectName("Muted")
    app.bucket_empty_labels[key] = empty
    layout.addWidget(empty)

    file_list = CompactListWidget("Drop files here")
    file_list.setObjectName("FileList")
    file_list.setProperty("bucketList", "true")
    repolish(file_list)
    file_list.owner_app = app
    file_list.setItemDelegate(PdfFileDelegate(FILENAME_ROLE, SIZE_ROLE, CONFIDENCE_ROLE, row_height=28, parent=file_list))
    file_list.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    file_list.setMinimumHeight(28)
    file_list.setMaximumHeight(128)
    app.setup_dnd_list(file_list)
    app.bucket_lists[key] = file_list
    layout.addWidget(file_list, 1)
    return frame


def _build_summary_panel(app):
    panel = QFrame()
    panel.setObjectName("OrganisePanel")
    layout = QVBoxLayout(panel)
    layout.setContentsMargins(16, 16, 16, 16)
    layout.setSpacing(12)

    title = QLabel("Mapping Summary")
    title.setObjectName("CardTitle")
    layout.addWidget(title)
    app.mapping_ring = MappingRing()
    layout.addWidget(app.mapping_ring, 0, Qt.AlignHCenter)

    app.summary_rows = {}
    for key, label in [
        ("required", "Required groups"),
        ("recommended", "Recommended"),
        ("optional", "Optional"),
        ("loaded", "Total files loaded"),
        ("assigned", "Files assigned"),
        ("unassigned", "Unassigned files"),
    ]:
        row, value = _summary_row(label)
        app.summary_rows[key] = value
        layout.addLayout(row)

    success = QFrame()
    success.setObjectName("SuccessSummary")
    app.required_success_card = success
    success_layout = QHBoxLayout(success)
    success_layout.setContentsMargins(14, 14, 14, 14)
    success_layout.setSpacing(10)
    success_icon = QLabel()
    success_icon.setPixmap(themed_icon("check", "#86EFAC").pixmap(18, 18))
    success_icon.setObjectName("SuccessSummaryIcon")
    success_icon.setFixedWidth(28)
    success_icon.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    app.required_success_text = QLabel("All required groups have at least one file.")
    app.required_success_text.setObjectName("SuccessSummaryText")
    app.required_success_text.setWordWrap(True)
    success_layout.addWidget(success_icon)
    success_layout.addWidget(app.required_success_text, 1)
    layout.addWidget(success)

    tip = QFrame()
    tip.setObjectName("TipCard")
    tip_layout = QVBoxLayout(tip)
    tip_layout.setContentsMargins(14, 14, 14, 14)
    tip_layout.setSpacing(5)
    tip_title = QLabel("Tip")
    tip_title.setObjectName("TipTitle")
    tip_body = QLabel("Auto-sort uses file names and PDF content to suggest the best upload group. Please review before saving.")
    tip_body.setObjectName("TipBody")
    tip_body.setWordWrap(True)
    tip_layout.addWidget(tip_title)
    tip_layout.addWidget(tip_body)
    layout.addWidget(tip)
    layout.addStretch(1)
    return panel


def _summary_row(label_text):
    row = QHBoxLayout()
    row.setSpacing(8)
    label = QLabel(label_text)
    label.setObjectName("Muted")
    value = QLabel("0")
    value.setObjectName("FieldLabel")
    value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    row.addWidget(label, 1)
    row.addWidget(value)
    return row, value


def _build_activity_log(app):
    frame = QFrame()
    frame.setObjectName("OrganisePanel")
    frame.setMinimumHeight(56)
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(16, 10, 16, 10)
    layout.setSpacing(8)
    header = QHBoxLayout()
    title = QLabel("Activity Log")
    title.setObjectName("FieldLabel")
    app.organise_log_toggle = button("Show", "ghost")
    app.organise_log_toggle.clicked.connect(app.toggle_organise_log)
    header.addWidget(title)
    header.addStretch(1)
    header.addWidget(app.organise_log_toggle)
    layout.addLayout(header)

    app.organise_log_box = QTextEdit()
    app.organise_log_box.setObjectName("OrganiseActivityLog")
    app.organise_log_box.setReadOnly(True)
    app.organise_log_box.setFont(QFont("Consolas", 9))
    app.organise_log_box.setMinimumHeight(96)
    app.organise_log_box.setMaximumHeight(120)
    app.organise_log_box.setVisible(False)
    layout.addWidget(app.organise_log_box)
    return frame


def _build_save_toast(app):
    toast = QFrame()
    toast.setObjectName("SaveToast")
    toast.setVisible(False)
    toast.setMaximumWidth(360)
    layout = QHBoxLayout(toast)
    layout.setContentsMargins(16, 12, 16, 12)
    layout.setSpacing(10)

    app.mapping_toast_icon = QLabel()
    app.mapping_toast_icon.setPixmap(themed_icon("check", "#86EFAC").pixmap(18, 18))
    app.mapping_toast_icon.setObjectName("ToastIcon")
    app.mapping_toast_icon.setFixedWidth(24)
    app.mapping_toast_icon.setAlignment(Qt.AlignLeft | Qt.AlignTop)
    layout.addWidget(app.mapping_toast_icon)

    copy = QVBoxLayout()
    copy.setSpacing(2)
    app.mapping_toast_title = QLabel("Mapping saved")
    app.mapping_toast_title.setObjectName("ToastTitle")
    app.mapping_toast_detail = QLabel("PDF mapping saved locally")
    app.mapping_toast_detail.setObjectName("ToastDetail")
    app.mapping_toast_detail.setWordWrap(True)
    copy.addWidget(app.mapping_toast_title)
    copy.addWidget(app.mapping_toast_detail)
    layout.addLayout(copy, 1)
    return toast


def add_pdf_item(list_widget, filename, confidence=None):
    item = QListWidgetItem(filename)
    item.setData(FILENAME_ROLE, filename)
    item.setData(SIZE_ROLE, _file_size_for_list(list_widget, filename))
    if confidence:
        item.setData(CONFIDENCE_ROLE, confidence)
    item.setSizeHint(QSize(0, 32))
    list_widget.addItem(item)


def _install_organise_hooks(app):
    if getattr(app, "_organise_reference_hooks_installed", False):
        return
    app._organise_reference_hooks_installed = True
    app.pdf_mapping_controller = PdfMappingController(app, SIZE_ROLE)


def _file_size_for_list(list_widget, filename):
    owner = getattr(list_widget, "owner_app", None)
    return _file_size_for_app(owner, filename) if owner is not None else ""


def _file_size_for_app(app, filename):
    if not app or not getattr(app, "pdf_folder_path", ""):
        return ""
    path = os.path.join(app.pdf_folder_path, filename)
    if not os.path.exists(path):
        return ""
    size = os.path.getsize(path)
    if size >= 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    return f"{max(1, round(size / 1024))} KB"


def _can_accept_bucket_drop(app, source, bucket_key):
    source = _drop_source_list(source)
    if not isinstance(source, QListWidget):
        return False
    if not hasattr(app, "bucket_lists") or bucket_key not in app.bucket_lists:
        return False
    return source is not app.bucket_lists[bucket_key] and bool(source.selectedItems())


def _move_selected_items_to_bucket(app, source, bucket_key):
    source = _drop_source_list(source)
    if not _can_accept_bucket_drop(app, source, bucket_key):
        return False
    selected = list(source.selectedItems())
    for item in selected:
        moved_item = source.takeItem(source.row(item))
        if moved_item is not None:
            app.add_file_item_to_bucket(bucket_key, moved_item)
    app.mark_mapping_dirty()
    app.refresh_pdf_lists()
    return bool(selected)


def _drop_source_list(source):
    if isinstance(source, QListWidget):
        return source
    parent = source.parent() if source is not None and hasattr(source, "parent") else None
    return parent if isinstance(parent, QListWidget) else source

from PySide6.QtWidgets import QComboBox, QLabel, QLineEdit

from ..components import action_bar, button, card, configure_field, field_block, form_grid, form_section_header, preset_header_card, scroll_page


def _preset_combo(app):
    app.preset_combo = QComboBox()
    app.preset_combo.currentIndexChanged.connect(app.load_preset_applicant)
    return app.preset_combo


def _widget(field, placeholder, required):
    if field == "Applicant Title":
        widget = QComboBox()
        widget.addItems(["Mr", "Mrs", "Miss", "Ms", "Other"])
        return configure_field(widget, required=required)
    return configure_field(QLineEdit(), placeholder, required)


def build(app):
    application_name = "householder planning application" if app.is_householder_application() else "building warrant application"
    page, layout = scroll_page()
    layout.addWidget(preset_header_card(
        "Applicant Details",
        f"Enter the applicant's details for the {application_name}.",
        "fa5s.user",
        _preset_combo(app),
        "Load Applicant Preset",
        app.save_applicant_preset,
    ))

    app.applicant_fields = [
        "Applicant Title", "Applicant First Name", "Applicant Last Name",
        "Applicant Mobile Number", "Applicant Email", "Applicant Building Number",
        "Applicant Address 1", "Applicant Town/City", "Applicant Country",
        "Applicant Postcode", "Applicant Company", "Applicant Building Name",
    ]
    app.applicant_line_edits = {}
    clear = button("  Clear Form", "ghost", awesome="fa5s.trash-alt", icon_color="#4F4A43", icon_size=15)
    clear.setObjectName("InlineUtilityButton")
    clear.setFixedHeight(38)
    clear.clicked.connect(app.clear_applicant_form)
    form, form_layout = card("FormCard")
    hint = QLabel("Required fields are marked with *. Validation appears after a field is edited or automation is started.")
    hint.setObjectName("Muted")
    form_layout.addLayout(form_section_header("Applicant Information", "fa5s.user", [clear]))
    form_layout.addWidget(hint)

    title_widget = _widget("Applicant Title", "", True)
    app.applicant_line_edits["Applicant Title"] = title_widget
    form_layout.addLayout(field_block("Applicant Title", title_widget, True))

    fields = [
        ("Applicant First Name", "Enter first name", True),
        ("Applicant Last Name", "Enter last name", True),
        ("Applicant Mobile Number", "Enter mobile number", False),
        ("Applicant Email", "Enter email address", True),
        ("Applicant Building Number", "Enter building number", True),
        ("Applicant Address 1", "Enter address line 1", True),
        ("Applicant Town/City", "Enter town or city", True),
        ("Applicant Country", "United Kingdom", True),
        ("Applicant Postcode", "Enter postcode", True),
        ("Applicant Company", "Enter company name (optional)", False),
        ("Applicant Building Name", "Enter building name (if applicable)", False),
    ]
    items = []
    for field, placeholder, required in fields:
        widget = _widget(field, placeholder, required)
        if field == "Applicant Country":
            widget.setText("United Kingdom")
        app.applicant_line_edits[field] = widget
        items.append((field, widget, required))
    form_layout.addLayout(form_grid(items))
    layout.addWidget(form)
    next_step = "Start Automation" if app.is_householder_application() else "Certificates"
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.step_index(next_step)), app.save_applicant_preset))
    return page

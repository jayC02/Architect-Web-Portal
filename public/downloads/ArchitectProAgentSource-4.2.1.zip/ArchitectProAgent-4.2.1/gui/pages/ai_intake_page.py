from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
)

from ..components import action_bar, button, card, form_section_header, repolish, scroll_page, vector_icon_label
from ..services import ai_intake


def build(app):
    page, layout = scroll_page()
    app.ai_intake_scroll_area = page
    layout.setSpacing(16)

    layout.addWidget(_build_ai_header(app))

    workspace = QHBoxLayout()
    workspace.setSpacing(16)
    workspace.addWidget(_build_source_card(app), 58)
    workspace.addWidget(_build_intake_summary_card(app), 42)
    layout.addLayout(workspace)

    layout.addWidget(_build_review_card(app))
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.application_questions_tab_index), primary_text="Next"))

    app.ai_intake_pdf_paths = []
    app.ai_intake_result = None
    app.update_ai_intake_estimate()
    return page


def _build_ai_header(app):
    frame, layout = card("AiHeroCard")
    layout.setContentsMargins(24, 22, 24, 22)
    row = QHBoxLayout()
    row.setSpacing(18)
    row.addWidget(vector_icon_label("fa5s.magic", "#166534", 58, 26, "AiHeroIcon"))

    copy = QVBoxLayout()
    copy.setSpacing(5)
    title = QLabel("Smart Application Intake")
    title.setObjectName("AiHeroTitle")
    subtitle = QLabel("Paste notes, upload PDFs, and let the assistant suggest application values before anything is applied.")
    subtitle.setObjectName("Muted")
    subtitle.setWordWrap(True)
    copy.addWidget(title)
    copy.addWidget(subtitle)
    row.addLayout(copy, 1)

    settings = ai_intake.load_settings(app.script_dir if hasattr(app, "script_dir") else _script_dir_from_app(app))
    app.ai_key_status_card = QFrame()
    app.ai_key_status_card.setObjectName("AiStatusCard")
    status_layout = QVBoxLayout(app.ai_key_status_card)
    status_layout.setContentsMargins(16, 10, 16, 10)
    status_layout.setSpacing(2)
    app.ai_key_status_label = QLabel("AI ready" if settings.get("api_key") else "Setup needed")
    app.ai_key_status_label.setObjectName("AiStatusTitle")
    app.ai_key_status_detail = QLabel(
        f"{settings.get('provider', 'Gemini')} key secured on this device"
        if settings.get("api_key")
        else (settings.get("secure_storage_error") or "Add a Gemini or OpenAI key")
    )
    app.ai_key_status_detail.setObjectName("TipBody")
    status_layout.addWidget(app.ai_key_status_label)
    status_layout.addWidget(app.ai_key_status_detail)
    row.addWidget(app.ai_key_status_card)

    settings_button = button("  AI settings", "secondary", awesome="fa5s.cog", icon_color="#4F4A43", icon_size=15)
    settings_button.setObjectName("AiSettingsButton")
    settings_button.setFixedSize(170, 58)
    settings_button.clicked.connect(app.configure_ai_settings)
    row.addWidget(settings_button)
    layout.addLayout(row)
    return frame


def _build_source_card(app):
    form, form_layout = card("FormCard")
    form_layout.addLayout(form_section_header("1. Add source information", "fa5s.file-alt"))
    hint = QLabel("Paste emails, client notes, project briefs, addresses, certificate details or any other source text. Do not paste portal passwords here.")
    hint.setObjectName("Muted")
    hint.setWordWrap(True)
    form_layout.addWidget(hint)

    app.ai_intake_notes = QTextEdit()
    app.ai_intake_notes.setObjectName("AiIntakeNotes")
    app.ai_intake_notes.setPlaceholderText("Example: client name, site address, proposed works, applicant details, planning notes, certificate information...")
    app.ai_intake_notes.setMinimumHeight(190)
    app.ai_intake_notes.textChanged.connect(app.update_ai_intake_estimate)
    form_layout.addWidget(app.ai_intake_notes)

    controls = QHBoxLayout()
    controls.setSpacing(12)
    attach = button("  Attach PDFs", "secondary", awesome="fa5s.paperclip", icon_color="#4F4A43", icon_size=15)
    attach.setObjectName("InlineUtilityButton")
    attach.setFixedSize(150, 42)
    attach.clicked.connect(app.select_ai_intake_pdfs)
    clear = button("  Clear PDFs", "ghost", awesome="fa5s.times", icon_color="#4F4A43", icon_size=14)
    clear.setObjectName("InlineUtilityButton")
    clear.setFixedSize(132, 42)
    clear.clicked.connect(app.clear_ai_intake_pdfs)
    app.ai_intake_estimate_label = QLabel("")
    app.ai_intake_estimate_label.setObjectName("InfoBadge")
    controls.addWidget(attach)
    controls.addWidget(clear)
    controls.addStretch(1)
    form_layout.addLayout(controls)

    app.ai_pdf_sources_title = QLabel("Files added (0)")
    app.ai_pdf_sources_title.setObjectName("FieldLabel")
    form_layout.addWidget(app.ai_pdf_sources_title)

    app.ai_intake_pdf_list = QListWidget()
    app.ai_intake_pdf_list.setObjectName("AiPdfList")
    app.ai_intake_pdf_list.setMinimumHeight(132)
    form_layout.addWidget(app.ai_intake_pdf_list)

    privacy = QLabel("This version can only read selectable PDF text. Scanned drawings or image-only PDFs may need manual review.")
    privacy.setObjectName("TipBody")
    privacy.setWordWrap(True)
    form_layout.addWidget(privacy)
    return form


def _build_intake_summary_card(app):
    frame, layout = card("FormCard")
    layout.addLayout(form_section_header("Intake summary", "fa5s.chart-bar"))
    app.ai_summary_pdf_count = _summary_value_row(layout, "PDFs attached", "0 files")
    app.ai_summary_notes = _summary_value_row(layout, "Notes included", "No")
    app.ai_summary_pdf_sort = _summary_value_row(layout, "PDF sorting", "Not run")
    app.ai_summary_presets = _summary_value_row(layout, "Presets loaded", "0")
    app.ai_summary_suggestions = _summary_value_row(layout, "Suggested values found", "0")
    app.ai_summary_missing = _summary_value_row(layout, "Missing / uncertain fields", "0")
    app.ai_summary_confidence = _summary_value_row(layout, "Overall confidence", "Not run")
    settings = ai_intake.load_settings(app.script_dir if hasattr(app, "script_dir") else _script_dir_from_app(app))
    app.ai_provider_label = QLabel(f"Provider: {settings.get('provider') or ai_intake.DEFAULT_PROVIDER}")
    app.ai_provider_label.setObjectName("InfoBadge")
    safety = QLabel("AI intake may send selected notes or extracted document text to the selected AI provider. Check you are allowed to process this information before continuing.")
    safety.setObjectName("WarningBadge")
    safety.setWordWrap(True)

    app.ai_intake_extract_button = button("  Run AI extraction", "primary", awesome="fa5s.wand-magic-sparkles", icon_color="#FFFFFF", icon_size=15)
    app.ai_intake_extract_button.setObjectName("ActionNextButton")
    app.ai_intake_extract_button.setMinimumHeight(54)
    app.ai_intake_extract_button.clicked.connect(app.start_ai_intake_extraction)

    review = button("  Review suggestions", "secondary", awesome="fa5s.eye", icon_color="#4F4A43", icon_size=15)
    review.setObjectName("ActionPresetButton")
    review.setMinimumHeight(50)
    review.clicked.connect(lambda: app.ai_intake_review_card.setVisible(True))

    skip = button("Skip AI intake", "secondary")
    skip.setObjectName("ActionPresetButton")
    skip.setMinimumHeight(48)
    skip.clicked.connect(lambda: app.navigate_to_step(app.application_questions_tab_index))

    app.ai_intake_status_label = QLabel("Ready")
    app.ai_intake_status_label.setObjectName("InfoBadge")
    layout.addWidget(app.ai_provider_label, 0, Qt.AlignLeft)
    layout.addWidget(safety)
    layout.addWidget(app.ai_intake_extract_button)
    layout.addWidget(review)
    layout.addWidget(skip)
    layout.addWidget(app.ai_intake_status_label, 0, Qt.AlignLeft)
    layout.addStretch(1)
    return frame


def _summary_value_row(layout, label_text, value_text):
    row = QHBoxLayout()
    row.setSpacing(12)
    label = QLabel(label_text)
    label.setObjectName("Muted")
    value = QLabel(value_text)
    value.setObjectName("FieldLabel")
    value.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    row.addWidget(label, 1)
    row.addWidget(value)
    layout.addLayout(row)
    return value


def _build_review_card(app):
    frame, layout = card("FormCard")
    app.ai_intake_review_card = frame
    frame.setVisible(False)
    layout.addLayout(form_section_header("Application summary", "fa5s.home"))

    app.ai_intake_summary_label = QLabel("")
    app.ai_intake_summary_label.setObjectName("TipBody")
    app.ai_intake_summary_label.setWordWrap(True)
    layout.addWidget(app.ai_intake_summary_label)

    stats = QGridLayout()
    stats.setHorizontalSpacing(14)
    stats.setVerticalSpacing(10)
    app.ai_stat_suggestions = _stat_card("0", "Suggested values")
    app.ai_stat_presets = _stat_card("0", "Presets applied")
    app.ai_stat_missing = _stat_card("0", "Needs review")
    app.ai_stat_confidence = _stat_card("Not run", "Confidence")
    for index, widget in enumerate([app.ai_stat_suggestions, app.ai_stat_presets, app.ai_stat_missing, app.ai_stat_confidence]):
        stats.addWidget(widget, 0, index)
    layout.addLayout(stats)

    app.ai_review_hint = QLabel("Applicant, Agent and Certificate details are applied automatically and hidden here. Review them on their own pages before starting automation.")
    app.ai_review_hint.setObjectName("TipBody")
    app.ai_review_hint.setWordWrap(True)
    layout.addWidget(app.ai_review_hint)

    app.ai_intake_table = QTableWidget(0, 5)
    app.ai_intake_table.setObjectName("AiReviewTable")
    app.ai_intake_table.setHorizontalHeaderLabels(["Apply", "Field", "Suggested value", "Confidence", "Source"])
    app.ai_intake_table.verticalHeader().setVisible(False)
    app.ai_intake_table.setAlternatingRowColors(True)
    app.ai_intake_table.setSelectionBehavior(QAbstractItemView.SelectRows)
    app.ai_intake_table.setSelectionMode(QAbstractItemView.SingleSelection)
    app.ai_intake_table.setMinimumHeight(190)
    app.ai_intake_table.setMaximumHeight(260)
    app.ai_intake_table.setColumnWidth(0, 58)
    app.ai_intake_table.setColumnWidth(1, 235)
    app.ai_intake_table.setColumnWidth(2, 360)
    app.ai_intake_table.setColumnWidth(3, 105)
    app.ai_intake_table.setColumnWidth(4, 150)
    layout.addWidget(app.ai_intake_table)

    app.ai_intake_warnings_label = QLabel("")
    app.ai_intake_warnings_label.setObjectName("WarningBadge")
    app.ai_intake_warnings_label.setWordWrap(True)
    app.ai_intake_warnings_label.setVisible(False)
    layout.addWidget(app.ai_intake_warnings_label)

    app.ai_apply_summary_label = QLabel("")
    app.ai_apply_summary_label.setObjectName("SuccessBadge")
    app.ai_apply_summary_label.setWordWrap(True)
    app.ai_apply_summary_label.setVisible(False)
    layout.addWidget(app.ai_apply_summary_label)

    row = QHBoxLayout()
    row.setSpacing(12)
    select_safe = button("Select safe values", "secondary")
    select_safe.setObjectName("InlineUtilityButton")
    select_safe.setFixedSize(150, 40)
    select_safe.clicked.connect(app.select_safe_ai_intake_rows)
    select_all = button("Select all", "secondary")
    select_all.setObjectName("InlineUtilityButton")
    select_all.setFixedSize(105, 40)
    select_all.clicked.connect(lambda: app.set_all_ai_intake_rows(True))
    clear_all = button("Deselect all", "ghost")
    clear_all.setObjectName("InlineUtilityButton")
    clear_all.setFixedSize(120, 40)
    clear_all.clicked.connect(lambda: app.set_all_ai_intake_rows(False))
    apply = button("  Apply to form", "primary", awesome="fa5s.check", icon_color="#FFFFFF", icon_size=15)
    apply.setObjectName("ActionNextButton")
    apply.setFixedSize(170, 44)
    apply.clicked.connect(app.apply_ai_intake_results)
    row.addWidget(select_safe)
    row.addWidget(select_all)
    row.addWidget(clear_all)
    row.addStretch(1)
    row.addWidget(apply)
    layout.addLayout(row)
    return frame


def _stat_card(value, label):
    frame = QFrame()
    frame.setObjectName("AiStatCard")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(16, 12, 16, 12)
    layout.setSpacing(3)
    value_label = QLabel(value)
    value_label.setObjectName("AiStatValue")
    label_widget = QLabel(label)
    label_widget.setObjectName("TipBody")
    label_widget.setWordWrap(True)
    layout.addWidget(value_label)
    layout.addWidget(label_widget)
    frame.value_label = value_label
    return frame


def file_source_row(filename):
    ext = filename.rsplit(".", 1)[-1].upper() if "." in filename else "FILE"
    icon_text = "PDF" if ext == "PDF" else ext[:4]
    row = QFrame()
    row.setObjectName("AiFileSourceRow")
    layout = QHBoxLayout(row)
    layout.setContentsMargins(10, 4, 10, 4)
    layout.setSpacing(10)

    icon = QLabel(icon_text)
    icon.setObjectName("AiPdfSourceIcon" if ext == "PDF" else "AiGenericSourceIcon")
    icon.setAlignment(Qt.AlignCenter)
    icon.setFixedSize(30, 30)
    layout.addWidget(icon)

    name = QLabel(filename)
    name.setObjectName("AiFileSourceName")
    name.setWordWrap(False)
    layout.addWidget(name, 1)

    status = QLabel("Ready")
    status.setObjectName("InfoBadge")
    status.setAlignment(Qt.AlignCenter)
    layout.addWidget(status)
    return row


def set_status(label, text, kind="info"):
    label.setText(text)
    label.setObjectName({"info": "InfoBadge", "success": "SuccessBadge", "warning": "WarningBadge", "error": "ErrorBadge"}.get(kind, "InfoBadge"))
    repolish(label)


def fill_review_table(app, result):
    table = app.ai_intake_table
    table.setRowCount(0)
    current_values = app.collect_user_inputs()
    for item in result.get("values", []):
        key = item["key"]
        value = item["value"]
        if _should_hide_ai_row(app, key, value, current_values):
            continue
        row = table.rowCount()
        table.insertRow(row)
        existing = str(current_values.get(key, "") or "").strip()
        confidence = item.get("confidence", "low")
        conflict = bool(existing and existing != value)
        checked = confidence in {"high", "medium"} and not conflict

        check = QCheckBox()
        check.setObjectName("AiReviewCheck")
        check.setChecked(checked)
        _sync_check_text(check)
        check.toggled.connect(lambda _=False, widget=check: _sync_check_text(widget))
        box = QFrame()
        box_layout = QHBoxLayout(box)
        box_layout.setContentsMargins(18, 0, 0, 0)
        box_layout.addWidget(check)
        box_layout.addStretch(1)
        table.setCellWidget(row, 0, box)

        values = [
            _display_field_name(key),
            value,
            confidence.title(),
            _source_label(item),
        ]
        for column, cell_value in enumerate(values, start=1):
            cell = QTableWidgetItem(str(cell_value))
            if column != 2:
                cell.setFlags(cell.flags() & ~Qt.ItemIsEditable)
            tooltip = item.get("reason", "")
            if existing:
                tooltip = (tooltip + "\n" if tooltip else "") + f"Current form value: {existing}"
            if conflict:
                tooltip = (tooltip + "\n" if tooltip else "") + "Existing value differs from AI suggestion. Tick Apply if you want to replace it."
            if tooltip:
                cell.setToolTip(tooltip)
            if column == 1:
                cell.setData(Qt.UserRole, key)
            table.setItem(row, column, cell)
    table.resizeRowsToContents()


def selected_rows_payload(app):
    table = app.ai_intake_table
    rows = []
    for row in range(table.rowCount()):
        box = table.cellWidget(row, 0)
        checkbox = box.findChild(QCheckBox) if box else None
        if not checkbox or not checkbox.isChecked():
            continue
        key_item = table.item(row, 1)
        key = key_item.data(Qt.UserRole) if key_item else ""
        value_item = table.item(row, 2)
        value = value_item.text().strip() if value_item else ""
        if value:
            label = key_item.text().strip() if key_item else key
            rows.append({"key": key, "value": value, "label": label})
    return rows


def _should_hide_ai_row(app, key, value, current_values):
    preset_fields = getattr(app, "ai_preset_applied_fields", set())
    if key in preset_fields:
        return True
    existing = str(current_values.get(key, "") or "").strip()
    if existing and existing == str(value or "").strip() and (key.startswith("Applicant ") or key.startswith("Agent ") or key in _certificate_keys()):
        return True
    return False


def _display_field_name(key):
    names = {
        "Description of Work": "Work description",
        "Application Profile": "Type of work",
        "Householder Discussed With Planning Authority": "Discussed with planning authority",
        "Householder Trees On Site": "Trees on or near site",
        "Householder New Or Altered Vehicle Access": "New or altered vehicle access",
        "Householder Current Parking Spaces": "Current parking spaces",
        "Householder Proposed Parking Spaces": "Proposed parking spaces",
        "Householder Sole Owner": "Sole owner",
        "Householder Agricultural Holding": "Agricultural holding",
    }
    return names.get(key, key.replace("Householder ", ""))


def _source_label(item):
    source = str(item.get("source") or "").replace("_", " ").title()
    return source or "AI"


def _certificate_keys():
    return {
        "Scheme Type",
        "Registration Number (A) Part 1",
        "Registration Number (A) Part 2",
        "Registration Number (B) Part 1",
        "Registration Number (B) Part 2",
        "Name of Certifier",
        "Name of Approved Body",
    }


def _section_for_key(key):
    if key.startswith("Agent "):
        return "Agent"
    if key.startswith("Applicant "):
        return "Applicant"
    if key.startswith("Householder "):
        return "Householder"
    if key in {
        "Registration Number (A) Part 1",
        "Registration Number (A) Part 2",
        "Registration Number (B) Part 1",
        "Registration Number (B) Part 2",
        "Name of Certifier",
        "Name of Approved Body",
    }:
        return "Certificates"
    if key in {
        "Includes Existing Building Work",
        "Includes New Building Or Extension",
        "New Building Construction",
        "Conversion Regulations",
        "Includes Demolition",
        "Applicant Is Owner",
        "Application Staged",
        "Limited Life Building",
        "Fire Rescue Enforcing Authority",
        "Listed Or Conservation Area",
        "Other Historical Importance",
        "Relaxation Direction",
        "Dangerous Building Notice",
        "Approved Certifier Construction",
        "STAS",
        "Public Inspection Restricted",
        "Application Profile",
    }:
        return "Questions"
    return "Data Entry"


def _sync_check_text(checkbox):
    checkbox.setText("")


def _script_dir_from_app(app):
    return getattr(app, "SCRIPT_DIR", "")

from PySide6.QtGui import QAction
from PySide6.QtWidgets import QComboBox, QGridLayout, QLineEdit, QTextEdit

from ..components import action_bar, awesome_icon, card, configure_field, field_block, form_section_header, preset_header_card, scroll_page


def _preset_combo(app):
    app.login_preset_combo = QComboBox()
    app.login_preset_combo.currentIndexChanged.connect(app.load_login_preset)
    return app.login_preset_combo


def _password_field():
    field = QLineEdit()
    field.setEchoMode(QLineEdit.Password)
    show_action = QAction(awesome_icon("fa5s.eye", "#4F4A43"), "Show password", field)
    show_action.setToolTip("Show password")

    def toggle_password():
        visible = field.echoMode() == QLineEdit.Password
        field.setEchoMode(QLineEdit.Normal if visible else QLineEdit.Password)
        show_action.setText("Hide password" if visible else "Show password")
        show_action.setToolTip("Hide password" if visible else "Show password")
        show_action.setIcon(awesome_icon("fa5s.eye-slash" if visible else "fa5s.eye", "#4F4A43"))

    show_action.triggered.connect(toggle_password)
    field.addAction(show_action, QLineEdit.TrailingPosition)
    return field


def build(app):
    is_householder = app.is_householder_application()
    page, layout = scroll_page()
    layout.addWidget(preset_header_card(
        "Data Entry",
        "Enter portal login and the application description." if is_householder else "Enter portal login and core application information.",
        "fa5s.clipboard-list",
        _preset_combo(app),
        "Load Login Preset",
        app.save_login_preset,
    ))
    form, form_layout = card("FormCard")
    form_layout.addLayout(form_section_header("Application Information", "fa5s.file-alt"))

    app.input_fields = {}
    grid = QGridLayout()
    grid.setHorizontalSpacing(24)
    grid.setVerticalSpacing(16)
    specs = [
        ("Email", QLineEdit(), "Enter portal email", True),
        ("Password", _password_field(), "Enter portal password", True),
    ]
    if not is_householder:
        specs.extend([
            ("Proposed Use", QLineEdit(), "Residential Dwelling", False),
            ("Current Use", QLineEdit(), "Residential Dwelling", False),
            ("Estimated Work Value", QLineEdit(), "10000", False),
        ])
        proposed_work = QComboBox()
        proposed_work.addItems(["Construct", "Convert", "Provide Services", "Demolish"])
        specs.append(("Proposed Work", proposed_work, "", False))
    for index, (field, widget, placeholder, required) in enumerate(specs):
        app.input_fields[field] = configure_field(widget, placeholder, required)
        grid.addLayout(field_block(field, widget, required), index // 2, index % 2)
    desc = configure_field(
        QTextEdit(),
        "Describe the proposed householder works" if is_householder else "Describe the proposed building warrant works",
        True,
    )
    app.input_fields["Description of Work"] = desc
    desc_row = (len(specs) + 1) // 2
    grid.addLayout(field_block("Description of Work", desc, True), desc_row, 0, 1, 2)
    form_layout.addLayout(grid)
    layout.addWidget(form)
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.step_index("Agent Details")), app.save_login_preset))
    return page

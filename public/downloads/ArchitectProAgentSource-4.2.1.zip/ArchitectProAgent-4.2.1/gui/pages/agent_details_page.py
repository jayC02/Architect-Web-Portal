from PySide6.QtWidgets import QComboBox, QLineEdit

from ..components import action_bar, card, configure_field, form_grid, form_section_header, preset_header_card, scroll_page


def _preset_combo(app):
    app.agent_preset_combo = QComboBox()
    app.agent_preset_combo.currentIndexChanged.connect(app.load_agent_preset)
    return app.agent_preset_combo


def build(app):
    application_name = "householder planning application" if app.is_householder_application() else "building warrant application"
    page, layout = scroll_page()
    layout.addWidget(preset_header_card(
        "Agent Details",
        f"Enter the agent details used for the {application_name}.",
        "fa5s.user-tie",
        _preset_combo(app),
        "Load Agent Preset",
        app.save_agent_preset,
    ))
    app.agent_fields = [
        "Agent First Name", "Agent Last Name", "Agent Telephone Number",
        "Agent Email Address", "Agent Building Number", "Agent Address 1",
        "Agent Town/City", "Agent Country", "Agent Postcode",
    ]
    required = {
        "Agent First Name", "Agent Last Name", "Agent Email Address",
        "Agent Building Number", "Agent Address 1", "Agent Town/City",
        "Agent Postcode",
    }
    app.agent_line_edits = {}
    items = []
    for field in app.agent_fields:
        widget = configure_field(QLineEdit(), f"Enter {field.lower()}", field in required)
        app.agent_line_edits[field] = widget
        items.append((field, widget, field in required))
    form, form_layout = card("FormCard")
    form_layout.addLayout(form_section_header("Agent Information", "fa5s.user-tie"))
    form_layout.addLayout(form_grid(items))
    layout.addWidget(form)
    layout.addWidget(action_bar(app.back, lambda: app.navigate_to_step(app.step_index("Applicant Details")), app.save_agent_preset))
    return page

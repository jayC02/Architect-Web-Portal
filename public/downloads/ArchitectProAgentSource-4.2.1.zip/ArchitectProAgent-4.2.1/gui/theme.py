THEME = {
    "app_bg": "#F7F4ED",
    "sidebar_bg": "#FBFAF6",
    "main_panel": "#F7F4ED",
    "card": "#FFFFFF",
    "card_subtle": "#FBFAF6",
    "input": "#FFFFFF",
    "border": "#DDD6CA",
    "border_subtle": "#E9E2D8",
    "primary": "#20231F",
    "primary_hover": "#34362F",
    "success": "#166534",
    "warning": "#A16207",
    "error": "#B91C1C",
    "text": "#1F211D",
    "secondary": "#6F6A62",
    "muted": "#8A8176",
}

SPACING = {
    "xs": 8,
    "sm": 12,
    "md": 16,
    "lg": 24,
    "xl": 32,
}

RADIUS = {
    "sm": 8,
    "md": 10,
    "lg": 14,
}

APP_QSS = f"""
QWidget {{
    background: transparent;
    color: {THEME["text"]};
    font-family: "Segoe UI", Arial, sans-serif;
    font-size: 14px;
}}
QLabel {{
    background: transparent;
}}
QFrame#Sidebar {{
    background: {THEME["sidebar_bg"]};
    border-right: 1px solid {THEME["border_subtle"]};
}}
QFrame#MainShell {{
    background: {THEME["main_panel"]};
}}
QTabWidget,
QTabWidget::pane,
QTabWidget > QWidget,
QWidget#PageCanvas,
QWidget#PageScrollViewport {{
    background: transparent;
    border: 0;
}}
QScrollArea#PageScroll {{
    background: transparent;
    border: 0;
}}
QScrollArea#PageScroll > QWidget {{
    background: transparent;
    border: 0;
}}
QFrame#HeaderCard, QFrame#Card, QFrame#FormCard, QFrame#ActionBar, QFrame#BucketCard,
QFrame#StatusCard, QFrame#HelpCard, QFrame#OrganiseHeader,
QFrame#OrganisePanel, QFrame#SummaryCard, QFrame#TipCard, QFrame#SuccessSummary,
QFrame#AiHeroCard, QFrame#AiStatusCard, QFrame#AiStatCard {{
    background: {THEME["card"]};
    border: 1px solid {THEME["border_subtle"]};
    border-radius: {RADIUS["lg"]}px;
}}
QFrame#PrimaryDropdownPanel {{
    background: #FBFAF6;
    border: 1px solid #D6CEC2;
    border-radius: 14px;
}}
QFrame#PrimaryDropdownPanel:hover {{
    background: #FFFFFF;
    border-color: #BFB5A8;
}}
QFrame#AiHeroCard {{
    background: #FFFFFF;
    border-color: #E4DDD2;
    border-radius: 16px;
}}
QLabel#AiHeroIcon {{
    background: #ECFDF3;
    border: 1px solid #BBF7D0;
    border-radius: 12px;
}}
QLabel#AiHeroTitle {{
    color: #1F211D;
    font-size: 26px;
    font-weight: 850;
}}
QFrame#AiStatusCard {{
    background: #F7FFF8;
    border-color: #D4F4D7;
    border-radius: 10px;
    min-width: 170px;
}}
QLabel#AiStatusTitle {{
    color: #166534;
    font-size: 13px;
    font-weight: 850;
}}
QFrame#AiStatCard {{
    background: #FBFAF6;
    border-color: #E4DDD2;
    border-radius: 12px;
}}
QLabel#AiStatValue {{
    color: #1F211D;
    font-size: 19px;
    font-weight: 850;
}}
QFrame#OrganiseHeader {{
    border-radius: 14px;
}}
QFrame#HeaderCard {{
    border-radius: 16px;
}}
QFrame#FormCard {{
    background: #FFFFFF;
    border-color: #E4DDD2;
    border-radius: 16px;
}}
QFrame#OrganisePanel {{
    background: #FFFFFF;
    border-color: #E4DDD2;
    border-radius: 12px;
}}
QFrame#BucketCard {{
    background: #FBFAF6;
    border-color: #E4DDD2;
    border-radius: 10px;
}}
QFrame#BucketCard:hover {{
    background: #FFFFFF;
    border-color: #BFB5A8;
}}
QFrame#BucketCard[dragActive="true"] {{
    background: #F7FFF8;
    border: 1px dashed #166534;
}}
QFrame#TipCard {{
    background: #FBFAF6;
    border-color: #E4DDD2;
    border-radius: 8px;
}}
QFrame#SuccessSummary {{
    background: #ECFDF3;
    border-color: #BBF7D0;
    border-radius: 10px;
}}
QFrame#SaveToast {{
    background: #ECFDF3;
    border: 1px solid #BBF7D0;
    border-radius: 10px;
}}
QFrame#ErrorToast {{
    background: #FEF2F2;
    border: 1px solid #FECACA;
    border-radius: 10px;
}}
QFrame#CardSubtle, QFrame#Terminal {{
    background: {THEME["card_subtle"]};
    border: 1px solid {THEME["border_subtle"]};
    border-radius: {RADIUS["lg"]}px;
}}
QFrame#QuestionGroup {{
    background: #FBFAF6;
    border: 1px solid #E9E2D8;
    border-radius: 12px;
}}
QLabel#QuestionGroupTitle {{
    color: #1F211D;
    font-size: 13px;
    font-weight: 800;
}}
QLabel#QuestionGroupHint {{
    color: #6F6A62;
    font-size: 12px;
    font-weight: 500;
}}
QLabel#BrandTitle {{
    font-size: 17px;
    font-weight: 700;
}}
QLabel#BrandSubtitle, QLabel#Muted, QLabel#HelpText, QLabel#FormHint {{
    color: {THEME["secondary"]};
}}
QLabel#SectionTitle {{
    color: {THEME["muted"]};
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0px;
}}
QLabel#PageTitle {{
    font-size: 26px;
    font-weight: 750;
}}
QLabel#CardTitle {{
    font-size: 17px;
    font-weight: 700;
}}
QLabel#FieldLabel {{
    color: #4F4A43;
    font-size: 13px;
    font-weight: 600;
}}
QLabel#TipTitle {{
    color: #1F211D;
    font-size: 14px;
    font-weight: 700;
}}
QLabel#TipBody {{
    color: #6F6A62;
    font-size: 13px;
}}
QLabel#SuccessSummaryIcon {{
    color: #166534;
    font-size: 18px;
    font-weight: 900;
    background: transparent;
    border: 0;
}}
QLabel#SuccessSummaryText {{
    color: #166534;
    font-size: 13px;
    font-weight: 600;
    background: transparent;
    border: 0;
}}
QLabel#ToastIcon {{
    color: #166534;
    font-size: 16px;
    font-weight: 900;
    background: transparent;
}}
QLabel#ToastTitle {{
    color: #166534;
    font-size: 13px;
    font-weight: 700;
    background: transparent;
}}
QLabel#ToastDetail {{
    color: #15803D;
    font-size: 12px;
    background: transparent;
}}
QFrame#ErrorToast QLabel#ToastIcon,
QFrame#ErrorToast QLabel#ToastTitle {{
    color: #B91C1C;
}}
QFrame#ErrorToast QLabel#ToastDetail {{
    color: #991B1B;
}}
QLabel#FileName {{
    color: #1F211D;
    font-size: 12px;
    font-weight: 500;
    background: transparent;
}}
QLabel#IconTile {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 8px;
    color: #4F6748;
}}
QLabel#PageIconTile {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 10px;
}}
QLabel#FormSectionIcon {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 8px;
}}
QLabel#FormSectionTitle {{
    color: #1F211D;
    font-size: 18px;
    font-weight: 800;
}}
QLabel#PrimaryFieldLabel {{
    color: #1F211D;
    font-size: 17px;
    font-weight: 850;
}}
QLabel#DropdownHelp {{
    color: #6F6A62;
    font-size: 13px;
    font-weight: 600;
}}
QLabel#DropdownPromptIcon {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 10px;
}}
QLabel#PresetLabel {{
    color: #1F211D;
    font-size: 14px;
    font-weight: 700;
}}
QFrame#PresetSelector {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    border-radius: 10px;
}}
QFrame#PresetSelector:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QLabel#PresetSelectorIcon {{
    background: transparent;
    border: 0;
}}
QComboBox#PresetCombo {{
    background: transparent;
    border: 0;
    color: #1F211D;
    font-size: 13px;
    font-weight: 600;
    padding-left: 0px;
    padding-right: 22px;
    min-height: 48px;
}}
QComboBox#PresetCombo::drop-down {{
    border: 0;
    width: 0px;
}}
QComboBox#PresetCombo QAbstractItemView {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    border-radius: 8px;
    color: #1F211D;
    selection-background-color: #EEF3EA;
    selection-color: #1F211D;
    padding: 6px;
    outline: 0;
}}
QComboBox#PresetCombo QAbstractItemView::item {{
    min-height: 30px;
    padding: 6px 10px;
    color: #1F211D;
}}
QComboBox#PresetCombo QAbstractItemView::item:hover,
QComboBox#PresetCombo QAbstractItemView::item:selected {{
    background: #EEF3EA;
    color: #1F211D;
}}
QLabel#PdfIcon {{
    background: #EF4444;
    border: 1px solid #FCA5A5;
    border-radius: 4px;
    color: white;
    font-size: 7px;
    font-weight: 900;
}}
QLabel#FileSize {{
    color: #8A8176;
    font-size: 12px;
    background: transparent;
}}
QLabel#Badge, QLabel#InfoBadge, QLabel#SuccessBadge, QLabel#WarningBadge,
QLabel#RequiredBadge, QLabel#ErrorBadge {{
    background: transparent;
    border: 0;
    border-radius: 0;
    padding: 0 2px;
    font-size: 12px;
    font-weight: 650;
}}
QLabel#InfoBadge {{
    color: #4F6748;
}}
QLabel#SuccessBadge {{
    color: #166534;
}}
QLabel#WarningBadge, QLabel#RequiredBadge {{
    color: #8A5A00;
}}
QLabel#ErrorBadge {{
    color: #B91C1C;
}}
QLabel#AutomationStatusText {{
    background: transparent;
    border: 0;
    color: #5F5A52;
    font-size: 13px;
    font-weight: 650;
    padding: 0;
}}
QLabel#AutomationStatusText[state="ready"] {{
    color: #4F6748;
}}
QLabel#AutomationStatusText[state="warning"] {{
    color: #8A5A00;
}}
QLabel#AutomationStatusText[state="error"] {{
    color: #991B1B;
}}
QLabel#AutomationStatusText[state="running"] {{
    color: #334155;
}}
QLabel#PreflightSummary {{
    background: transparent;
    border: 0;
    color: #5F5A52;
    font-size: 13px;
    font-weight: 650;
    padding: 0;
}}
QLabel#PreflightSummary[state="ready"] {{
    color: #4F6748;
}}
QLabel#PreflightSummary[state="missing"] {{
    color: #991B1B;
}}
QFrame#PreflightRow {{
    background: transparent;
    border: 0;
    border-bottom: 1px solid #ECE7DE;
    border-radius: 0;
}}
QLabel#PreflightMarker {{
    background: #FFFFFF;
    border: 1px solid #D6CEC2;
    border-radius: 12px;
    color: #5F5A52;
    font-size: 12px;
    font-weight: 800;
}}
QLabel#PreflightMarker[state="ready"] {{
    border-color: #A9B9A2;
    color: #4F6748;
}}
QLabel#PreflightMarker[state="missing"] {{
    border-color: #C9A7A7;
    color: #991B1B;
}}
QLabel#PreflightItemTitle {{
    color: #1F211D;
    font-size: 14px;
    font-weight: 650;
}}
QLabel#PreflightItemDetail {{
    color: #6F6A62;
    font-size: 12px;
    font-weight: 400;
}}
QLabel#PreflightReadyText {{
    background: transparent;
    border: 0;
    color: #4F6748;
    font-size: 13px;
    font-weight: 650;
    padding: 0;
}}
QPushButton#PreflightActionButton {{
    min-height: 34px;
    max-height: 34px;
    padding: 0 14px;
    background: #FFFFFF;
    border: 1px solid #D6CEC2;
    border-radius: 6px;
    color: #1F211D;
    font-size: 13px;
    font-weight: 600;
}}
QPushButton#PreflightActionButton:hover {{
    background: #F7F4EE;
    border-color: #AFA69A;
}}
QPushButton {{
    background: {THEME["input"]};
    color: {THEME["text"]};
    border: 1px solid {THEME["border"]};
    border-radius: {RADIUS["md"]}px;
    padding: 7px 12px;
    min-height: 18px;
    font-weight: 600;
    outline: 0;
}}
QPushButton:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QPushButton#PrimaryButton {{
    background: {THEME["primary"]};
    border-color: {THEME["primary"]};
    color: white;
}}
QPushButton#PrimaryButton:hover {{
    background: {THEME["primary_hover"]};
    border-color: {THEME["primary_hover"]};
}}
QPushButton#HeaderSavePresetButton {{
    background: #20231F;
    border: 1px solid #20231F;
    border-radius: 10px;
    color: #FFFFFF;
    font-size: 14px;
    font-weight: 700;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 18px;
    padding-right: 18px;
}}
QPushButton#HeaderSavePresetButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QPushButton#ActionBackButton,
QPushButton#ActionPresetButton,
QPushButton#ActionNextButton,
QPushButton#InlineUtilityButton,
QPushButton#AiSettingsButton {{
    border-radius: 10px;
    font-size: 14px;
    font-weight: 700;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 18px;
    padding-right: 18px;
}}
QPushButton#ActionBackButton,
QPushButton#ActionPresetButton,
QPushButton#InlineUtilityButton,
QPushButton#AiSettingsButton {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    color: #1F211D;
}}
QPushButton#ActionBackButton:hover,
QPushButton#ActionPresetButton:hover,
QPushButton#InlineUtilityButton:hover,
QPushButton#AiSettingsButton:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QPushButton#ActionNextButton {{
    background: #20231F;
    border: 1px solid #20231F;
    color: #FFFFFF;
}}
QPushButton#ActionNextButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QFrame#SaveStatus {{
    background: #ECFDF3;
    border: 1px solid #BBF7D0;
    border-radius: 10px;
}}
QLabel#SaveStatusIcon {{
    background: #DCFCE7;
    border: 1px solid #BBF7D0;
    border-radius: 11px;
}}
QLabel#SaveStatusText {{
    color: #166534;
    font-size: 14px;
    font-weight: 800;
    background: transparent;
}}
QPushButton#PdfSelectFolderButton,
QPushButton#PdfAiSortButton,
QPushButton#PdfSaveMappingButton {{
    min-height: 50px;
    max-height: 50px;
    height: 50px;
    border-radius: 10px;
    margin: 0px;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 16px;
    padding-right: 16px;
    font-size: 14px;
    font-weight: 700;
    text-align: center;
}}
QPushButton#PdfSelectFolderButton {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    color: #1F211D;
}}
QPushButton#PdfSelectFolderButton:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QPushButton#PdfAiSortButton {{
    background: #20231F;
    border: 1px solid #20231F;
    color: #FFFFFF;
}}
QPushButton#PdfAiSortButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QPushButton#PdfSaveMappingButton {{
    background: #20231F;
    border: 1px solid #20231F;
    color: #FFFFFF;
}}
QPushButton#PdfSaveMappingButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QPushButton#GhostButton {{
    background: transparent;
    color: #4F4A43;
    border-color: {THEME["border_subtle"]};
}}
QPushButton#SidebarItem {{
    background: transparent;
    border: 1px solid transparent;
    border-left: 3px solid transparent;
    border-radius: 9px;
    color: #4F4A43;
    padding: 9px 10px;
    text-align: left;
    font-weight: 500;
}}
QPushButton#SidebarItem:hover {{
    background: #F2EEE7;
}}
QPushButton#SidebarItem[active="true"] {{
    background: #20231F;
    border: 1px solid #20231F;
    border-left: 3px solid {THEME["primary"]};
    color: #FFFFFF;
}}
QLabel#StatusDot {{
    min-width: 16px;
    min-height: 16px;
    max-width: 16px;
    max-height: 16px;
    border-radius: 8px;
    border: 1px solid {THEME["border"]};
    color: {THEME["success"]};
    font-size: 11px;
    font-weight: 900;
}}
QWidget#StepCircle {{
    background: transparent;
    border: 0;
}}
QLabel#StepLabel {{
    color: {THEME["muted"]};
    font-size: 12px;
    font-weight: 600;
}}
QLabel#StepLabel[state="active"] {{
    color: {THEME["text"]};
}}
QLineEdit, QTextEdit, QComboBox, QListWidget {{
    background: {THEME["input"]};
    border: 1px solid {THEME["border"]};
    border-radius: {RADIUS["md"]}px;
    color: {THEME["text"]};
    selection-background-color: {THEME["primary"]};
}}
QLineEdit, QComboBox {{
    min-height: 42px;
    padding: 0 12px;
    font-size: 14px;
}}
QComboBox {{
    padding-right: 34px;
    selection-background-color: #EEF3EA;
    selection-color: #1F211D;
}}
QComboBox:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QComboBox:focus {{
    border-color: #4F6748;
}}
QComboBox:disabled {{
    background: #F2EEE7;
    border-color: #E4DDD2;
    color: #8A8176;
}}
QComboBox#DropdownCombo {{
    min-height: 42px;
    border-radius: {RADIUS["md"]}px;
    padding-left: 12px;
    padding-right: 34px;
    font-size: 14px;
    font-weight: 500;
}}
QComboBox#PrimaryDropdownCombo {{
    min-height: 50px;
    border: 1px solid #BFB5A8;
    border-radius: 12px;
    padding-left: 14px;
    padding-right: 38px;
    font-size: 14px;
    font-weight: 650;
}}
QComboBox::drop-down,
QComboBox#DropdownCombo::drop-down,
QComboBox#PrimaryDropdownCombo::drop-down {{
    subcontrol-origin: padding;
    subcontrol-position: top right;
    background: #F2EEE7;
    border-left: 1px solid #DDD6CA;
    border-top-right-radius: {RADIUS["md"]}px;
    border-bottom-right-radius: {RADIUS["md"]}px;
    width: 30px;
}}
QComboBox#PrimaryDropdownCombo::drop-down {{
    width: 34px;
}}
QComboBox::down-arrow,
QComboBox#DropdownCombo::down-arrow,
QComboBox#PrimaryDropdownCombo::down-arrow {{
    width: 10px;
    height: 10px;
}}
QComboBox QAbstractItemView,
QComboBox#DropdownCombo QAbstractItemView,
QComboBox#PrimaryDropdownCombo QAbstractItemView {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    border-radius: 10px;
    color: #1F211D;
    selection-background-color: #EEF3EA;
    selection-color: #1F211D;
    padding: 6px;
    outline: 0;
}}
QComboBox QAbstractItemView::item,
QComboBox#DropdownCombo QAbstractItemView::item,
QComboBox#PrimaryDropdownCombo QAbstractItemView::item {{
    min-height: 30px;
    padding: 6px 10px;
    color: #1F211D;
}}
QComboBox QAbstractItemView::item:hover,
QComboBox QAbstractItemView::item:selected,
QComboBox#DropdownCombo QAbstractItemView::item:hover,
QComboBox#DropdownCombo QAbstractItemView::item:selected,
QComboBox#PrimaryDropdownCombo QAbstractItemView::item:hover,
QComboBox#PrimaryDropdownCombo QAbstractItemView::item:selected {{
    background: #EEF3EA;
    color: #1F211D;
}}
QLineEdit[invalid="true"], QComboBox[invalid="true"], QTextEdit[invalid="true"] {{
    border-color: {THEME["error"]};
}}
QTextEdit {{
    padding: 10px;
}}
QTextEdit#ActivityLog,
QTextEdit#OrganiseActivityLog {{
    background: #FBFAF6;
    border: 1px solid #E4DDD2;
    border-radius: 10px;
    color: #4F4A43;
    padding: 10px;
}}
QLineEdit::placeholder, QTextEdit::placeholder {{
    color: {THEME["muted"]};
}}
QCheckBox#PortalAnswerCheck {{
    color: #1F211D;
    spacing: 10px;
    font-size: 13px;
    font-weight: 600;
}}
QCheckBox#PortalAnswerCheck::indicator {{
    width: 18px;
    height: 18px;
    border-radius: 5px;
    border: 1px solid #DDD6CA;
    background: #FFFFFF;
}}
QCheckBox#PortalAnswerCheck::indicator:hover {{
    border-color: #BFB5A8;
    background: #FBFAF6;
}}
QCheckBox#PortalAnswerCheck::indicator:checked {{
    background: #20231F;
    border-color: #20231F;
}}
QCheckBox#AiReviewCheck {{
    color: #166534;
    font-size: 13px;
    font-weight: 900;
    spacing: 0px;
}}
QCheckBox#AiReviewCheck::indicator {{
    width: 20px;
    height: 20px;
    border-radius: 6px;
    border: 1px solid #BFB5A8;
    background: #FFFFFF;
}}
QCheckBox#AiReviewCheck::indicator:checked {{
    background: #166534;
    border-color: #166534;
}}
QListWidget {{
    padding: 3px;
    outline: 0;
}}
QListWidget#FileList {{
    background: #FFFFFF;
    border-color: #DDD6CA;
    border-radius: 8px;
}}
QListWidget#AiPdfList {{
    background: #FFFFFF;
    border-color: #E4DDD2;
    border-radius: 10px;
    padding: 8px 10px;
}}
QListWidget#AiPdfList::item {{
    background: transparent;
    border: 0;
    padding: 0;
    margin: 4px 0;
    color: transparent;
}}
QListWidget#AiPdfList::item:selected {{
    background: transparent;
    border: 0;
    color: transparent;
}}
QFrame#AiFileSourceRow {{
    background: #FBFAF6;
    border: 1px solid #E4DDD2;
    border-radius: 8px;
    min-height: 44px;
}}
QLabel#AiPdfSourceIcon {{
    background: #FEF2F2;
    border: 1px solid #FECACA;
    border-radius: 8px;
    color: #DC2626;
    font-size: 10px;
    font-weight: 900;
}}
QLabel#AiGenericSourceIcon {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 8px;
    color: #4F6748;
    font-size: 10px;
    font-weight: 900;
}}
QLabel#AiFileSourceName {{
    color: #1F211D;
    font-size: 13px;
    font-weight: 700;
}}
QTableWidget#AiReviewTable {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    border-radius: 10px;
    gridline-color: #E9E2D8;
    selection-background-color: #EEF3EA;
    selection-color: #1F211D;
}}
QTableWidget#AiReviewTable::item {{
    padding: 8px;
}}
QHeaderView::section {{
    background: #FBFAF6;
    border: 0;
    border-bottom: 1px solid #E4DDD2;
    color: #6F6A62;
    font-size: 12px;
    font-weight: 800;
    padding: 9px 8px;
}}
QListWidget#FileList[bucketList="true"] {{
    background: transparent;
    border: 0;
    border-radius: 0;
    padding: 0;
}}
QListWidget::item {{
    background: #FFFFFF;
    border: 1px solid {THEME["border_subtle"]};
    border-radius: 7px;
    color: transparent;
    padding: 0;
    margin: 1px 0;
}}
QListWidget::item:hover {{
    border-color: #BFB5A8;
}}
QListWidget::item:selected {{
    background: #EEF3EA;
    border-color: #B7C9AF;
}}
QListWidget#FileList[bucketList="true"]::item {{
    background: transparent;
    border: 0;
    margin: 0;
}}
QScrollArea {{
    border: 0;
    background: transparent;
}}
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
}}
QScrollBar::handle:vertical {{
    background: #D6CEC2;
    border-radius: 5px;
    min-height: 38px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}
QFrame#InboxDropZone {{
    background: #FBFAF6;
    border: 1px dashed #BFB5A8;
    border-radius: 8px;
}}
QWidget#WelcomePage {{
    background: #F7F4ED;
}}
QFrame#WelcomeHero {{
    background: transparent;
    border: 0;
    border-radius: 20px;
}}
QLabel#WelcomeLogo {{
    background: transparent;
}}
QLabel#WelcomeBrand {{
    color: #4F4A43;
    font-size: 15px;
    font-weight: 700;
}}
QLabel#WelcomeEyebrow {{
    color: #EEF3EA;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0px;
}}
QLabel#WelcomeHeroTitle {{
    color: #FFFFFF;
    font-size: 40px;
    font-weight: 800;
}}
QLabel#WelcomeHeroSubtitle {{
    color: #F7F4ED;
    font-size: 17px;
    line-height: 145%;
}}
QPushButton#WelcomePrimaryButton,
QPushButton#WelcomeSecondaryButton {{
    min-height: 56px;
    max-height: 56px;
    height: 56px;
    border-radius: 10px;
    margin: 0px;
    color: #FFFFFF;
    font-size: 15px;
    font-weight: 700;
    padding-top: 0px;
    padding-bottom: 0px;
    padding-left: 24px;
    padding-right: 24px;
}}
QPushButton#WelcomePrimaryButton {{
    background: #20231F;
    border: 1px solid #20231F;
}}
QPushButton#WelcomePrimaryButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QPushButton#WelcomeSecondaryButton {{
    background: #FFFFFF;
    border: 1px solid #DDD6CA;
    color: #1F211D;
}}
QPushButton#WelcomeSecondaryButton:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
    color: #1F211D;
}}
QFrame#WelcomeWorkflowStrip {{
    background: #FFFFFF;
    border: 1px solid #E4DDD2;
    border-radius: 16px;
}}
QLabel#WelcomeStripTitle {{
    color: #1F211D;
    font-size: 16px;
    font-weight: 800;
}}
QFrame#WelcomeWorkflowCard {{
    background: #FBFAF6;
    border: 1px solid #E9E2D8;
    border-radius: 12px;
}}
QFrame#WelcomeWorkflowCard:hover {{
    background: #F2EEE7;
    border-color: #D6CEC2;
}}
QLabel#WelcomeWorkflowIcon {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 21px;
    color: #4F6748;
    font-size: 14px;
    font-weight: 800;
}}
QLabel#WelcomeWorkflowTitle {{
    color: #1F211D;
    font-size: 12px;
    font-weight: 800;
}}
QLabel#WelcomeWorkflowText {{
    color: #6F6A62;
    font-size: 11px;
    font-weight: 600;
}}
QMessageBox {{
    background: #FFFFFF;
    color: #1F211D;
}}
QMessageBox QLabel {{
    color: #1F211D;
    background: transparent;
    font-size: 14px;
}}
QMessageBox QPushButton {{
    background: #20231F;
    border: 1px solid #20231F;
    border-radius: 10px;
    color: #FFFFFF;
    min-width: 92px;
    min-height: 34px;
    padding: 0 14px;
    font-weight: 700;
}}
QMessageBox QPushButton:hover {{
    background: #34362F;
    border-color: #34362F;
}}
QDialog#ApplicationSelectorDialog {{
    background: #F7F4ED;
}}
QLabel#ApplicationSelectorTitle {{
    color: #1F211D;
    font-size: 30px;
    font-weight: 800;
}}
QLabel#ApplicationSelectorSubtitle {{
    color: #6F6A62;
    font-size: 15px;
    font-weight: 600;
}}
QFrame#ApplicationChoiceCard {{
    background: #FFFFFF;
    border: 1px solid #E4DDD2;
    border-radius: 16px;
}}
QFrame#ApplicationChoiceCard:hover {{
    background: #FBFAF6;
    border-color: #BFB5A8;
}}
QLabel#ApplicationChoiceEyebrow {{
    background: #EEF3EA;
    border: 1px solid #D6E2D0;
    border-radius: 10px;
    color: #4F6748;
    font-size: 12px;
    font-weight: 800;
    padding: 6px 10px;
}}
QLabel#ApplicationChoiceTitle {{
    background: transparent;
    color: #1F211D;
    font-size: 24px;
    font-weight: 800;
}}
QLabel#ApplicationChoiceBody {{
    background: transparent;
    color: #6F6A62;
    font-size: 14px;
    font-weight: 600;
    line-height: 145%;
}}
QLabel#ApplicationChoiceAction {{
    background: #20231F;
    border-radius: 10px;
    color: #FFFFFF;
    font-size: 13px;
    font-weight: 800;
    min-height: 38px;
    min-width: 140px;
    padding: 0 14px;
}}
"""

from PySide6.QtWidgets import QMessageBox

from ..services import presets, secure_credentials


def save_login_preset(app):
    email = app.input_fields["Email"].text().strip()
    if not email:
        app.log("Please enter an Email before saving preset.")
        return
    data = app.load_json("login_presets.json")
    presets.scrub_legacy_passwords(data)
    # Login presets deliberately exclude passwords. Remembered passwords are
    # stored in Windows Credential Manager only, and never in JSON files.
    data[email] = {"Email": email}
    app.save_json("login_presets.json", data)
    app.remember_last_used_preset("login_presets.json", email)
    password = app.input_fields["Password"].text()
    if password:
        ok, message = secure_credentials.save_login_password(email, password)
        if not ok:
            QMessageBox.warning(app, "Password not saved", message)
    else:
        secure_credentials.delete_login_password(email)
    app.load_login_preset_list()
    app.log(f"Login preset saved for: {email}")
    app.show_preset_saved("Login", email)


def load_login_preset(app):
    selected = app.login_preset_combo.currentText().strip()
    if not selected:
        return
    if selected == presets.CLEAR_PRESET_LABEL:
        app.input_fields["Email"].clear()
        app.input_fields["Password"].clear()
        app.remember_last_used_preset("login_presets.json", selected)
        presets.reset_preset_selection(app.login_preset_combo)
        app.log("Login preset selection cleared.")
        return
    data = app.load_json("login_presets.json").get(selected)
    if data:
        app.remember_last_used_preset("login_presets.json", selected)
        email = str(data.get("Email") or selected).strip()
        if email:
            app.input_fields["Email"].setText(email)
        password, _, _ = secure_credentials.get_login_password(email)
        if password:
            app.input_fields["Password"].setText(password)
        else:
            app.input_fields["Password"].clear()
        app.log(f"Loaded login preset for: {selected}")


def load_login_preset_list(app):
    app.load_combo_presets("login_presets.json", app.login_preset_combo)

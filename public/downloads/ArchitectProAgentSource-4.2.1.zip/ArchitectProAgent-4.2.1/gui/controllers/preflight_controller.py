import os

from PySide6.QtCore import QTimer, Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QVBoxLayout, QWidget

from ..components import button, repolish
from ..services import portal_answers


def _widget_text(widget):
    if hasattr(widget, "toPlainText"):
        return widget.toPlainText()
    if hasattr(widget, "currentText"):
        return widget.currentText()
    return widget.text()


def missing_required_fields(app):
    missing = []
    for step, group in [
        ("Data Entry", getattr(app, "input_fields", {})),
        ("Agent Details", getattr(app, "agent_line_edits", {})),
        ("Applicant Details", getattr(app, "applicant_line_edits", {})),
    ]:
        for field, widget in group.items():
            if not bool(widget.property("required")):
                continue
            if not str(_widget_text(widget) or "").strip():
                missing.append({
                    "title": field,
                    "detail": f"Required in {step}.",
                    "step": step,
                    "widget": widget,
                })

    cert_values = {
        field: widget.text()
        for field, widget in getattr(app, "cert_line_edits", {}).items()
    }
    if cert_values and portal_answers.has_partial_certificate_details(cert_values):
        for field, widget in getattr(app, "cert_line_edits", {}).items():
            if bool(widget.property("required")) and not widget.text().strip():
                missing.append({
                    "title": field,
                    "detail": "Required because certificate details have been started.",
                    "step": "Certificates",
                    "widget": widget,
                })
        for field, widget in getattr(app, "cert_dropdowns", {}).items():
            value = widget.currentText() if hasattr(widget, "currentText") else ""
            if bool(widget.property("required")) and not str(value or "").strip():
                missing.append({
                    "title": field,
                    "detail": "Required because certificate details have been started.",
                    "step": "Certificates",
                    "widget": widget,
                })
    return missing


def missing_required_field_names(app):
    return [
        f"{item['step']}: {item['title']}"
        for item in missing_required_fields(app)
    ]


def _pdf_state(app):
    pdfs_selected = bool(
        app.pdf_folder_path
        and (app.selected_pdf_paths or os.path.isdir(app.pdf_folder_path))
    )
    location_plan_ready = bool(
        getattr(app, "bucket_lists", {}).get("location_plan")
        and app.bucket_lists["location_plan"].count() == 1
    )
    mapping_saved = app.is_mapping_currently_saved()
    return pdfs_selected, mapping_saved, location_plan_ready


def build_preflight_checks(app):
    """Retain the compact machine-readable checks used by existing tests."""
    missing_required = missing_required_field_names(app)
    password_widget = getattr(app, "input_fields", {}).get("Password")
    email_widget = getattr(app, "input_fields", {}).get("Email")
    password_available = bool(password_widget and password_widget.text().strip())
    email_entered = bool(email_widget and email_widget.text().strip())
    pdfs_selected, mapping_saved, location_plan_ready = _pdf_state(app)

    if hasattr(app, "state"):
        app.state.set_login_state(
            email_widget.text() if email_widget else "",
            password_available,
        )
        app.state.set_pdf_selection(app.pdf_folder_path, app.selected_pdf_paths)
        app.state.set_mapping_saved(mapping_saved)

    return {
        "application_type": ("Ready", app.application_type, "SuccessBadge"),
        "required_fields": (
            "Ready" if not missing_required else "Missing",
            "All required fields complete"
            if not missing_required
            else f"{len(missing_required)} required field(s) missing",
            "SuccessBadge" if not missing_required else "ErrorBadge",
        ),
        "email": (
            "Ready" if email_entered else "Missing",
            "Portal email entered"
            if email_entered
            else "Enter portal email on Data Entry",
            "SuccessBadge" if email_entered else "ErrorBadge",
        ),
        "password": (
            "Ready" if password_available else "Missing",
            "Password available for this run"
            if password_available
            else "Enter portal password on Data Entry",
            "SuccessBadge" if password_available else "ErrorBadge",
        ),
        "pdfs": (
            "Ready" if pdfs_selected else "Missing",
            "PDFs selected" if pdfs_selected else "Select PDFs on Organise PDFs",
            "SuccessBadge" if pdfs_selected else "ErrorBadge",
        ),
        "mapping": (
            "Ready" if mapping_saved else "Missing",
            "PDF mapping saved" if mapping_saved else "Save the PDF mapping",
            "SuccessBadge" if mapping_saved else "ErrorBadge",
        ),
        "location_plan": (
            "Ready" if location_plan_ready else "Missing",
            "Location Plan mapped"
            if location_plan_ready
            else "Exactly one Location Plan is required",
            "SuccessBadge" if location_plan_ready else "ErrorBadge",
        ),
    }


def build_preflight_report(app):
    issues = []
    for message in getattr(app, "portal_import_blocking_issues", []):
        lower = str(message).lower()
        step = "Organise PDFs" if any(
            token in lower for token in ("document", "pdf", "download", "category")
        ) else "Data Entry"
        issues.append({
            "title": str(message),
            "detail": "The portal job cannot start until this is corrected.",
            "step": step,
            "widget": None,
        })

    issues.extend(missing_required_fields(app))
    pdfs_selected, mapping_saved, location_plan_ready = _pdf_state(app)
    if not pdfs_selected:
        issues.append({
            "title": "No PDF files selected",
            "detail": "Choose the documents for this application.",
            "step": "Organise PDFs",
            "widget": None,
        })
    elif not mapping_saved:
        issues.append({
            "title": "Document sorting has not been saved",
            "detail": "Review the PDF buckets and save the mapping.",
            "step": "Organise PDFs",
            "widget": None,
        })
    elif not location_plan_ready:
        issues.append({
            "title": "Exactly one Location Plan is required",
            "detail": "Move the correct drawing into the Location Plan bucket.",
            "step": "Organise PDFs",
            "widget": None,
        })

    if issues:
        return {"ready": False, "items": issues}

    section_details = {
        "Application Questions": "Application answers are prepared.",
        "Organise PDFs": "Documents are selected and the mapping is saved.",
        "Data Entry": "All required application details are complete.",
        "Agent Details": "Agent details are complete.",
        "Applicant Details": "Applicant details are complete.",
        "Certificates": "Certificate information is complete or not required.",
    }
    items = []
    for step in getattr(app, "WORKFLOW_STEPS", []):
        if step in {"Welcome", "Start Automation"}:
            continue
        items.append({
            "title": step,
            "detail": section_details.get(step, "Section complete."),
            "step": step,
            "widget": None,
        })
    return {"ready": True, "items": items}


def _clear_layout(layout):
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget()
        child_layout = item.layout()
        if widget is not None:
            widget.hide()
            widget.setParent(None)
            widget.deleteLater()
        elif child_layout is not None:
            _clear_layout(child_layout)


def _open_issue(app, item):
    step = item["step"]
    if step in getattr(app, "WORKFLOW_STEPS", []):
        app.navigate_to_step(app.step_index(step))
    widget = item.get("widget")
    if widget is not None:
        QTimer.singleShot(120, widget.setFocus)


def _build_report_row(app, item, ready):
    row = QFrame()
    row.setObjectName("PreflightRow")
    row.setProperty("state", "ready" if ready else "missing")
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 13, 0, 13)
    layout.setSpacing(14)

    marker = QLabel("\u2713" if ready else "!")
    marker.setObjectName("PreflightMarker")
    marker.setProperty("state", "ready" if ready else "missing")
    marker.setAlignment(Qt.AlignCenter)
    marker.setFixedSize(24, 24)
    layout.addWidget(marker)

    copy = QVBoxLayout()
    copy.setSpacing(2)
    title = QLabel(item["title"])
    title.setObjectName("PreflightItemTitle")
    title.setWordWrap(True)
    detail = QLabel(item["detail"])
    detail.setObjectName("PreflightItemDetail")
    detail.setWordWrap(True)
    copy.addWidget(title)
    copy.addWidget(detail)
    layout.addLayout(copy, 1)

    if ready:
        status = QLabel("Ready")
        status.setObjectName("PreflightReadyText")
        layout.addWidget(status, 0, Qt.AlignRight | Qt.AlignVCenter)
    else:
        action = button(f"Open {item['step']}", "secondary")
        action.setObjectName("PreflightActionButton")
        action.clicked.connect(lambda checked=False, current=item: _open_issue(app, current))
        layout.addWidget(action, 0, Qt.AlignRight | Qt.AlignVCenter)
    return row


def refresh_preflight_checklist(app):
    if not hasattr(app, "preflight_rows_layout"):
        return

    report = build_preflight_report(app)
    _clear_layout(app.preflight_rows_layout)
    app.preflight_summary_label.setText(
        "Ready to run"
        if report["ready"]
        else f"{len(report['items'])} item(s) need attention"
    )
    app.preflight_hint_label.setText(
        "Every workflow section is complete."
        if report["ready"]
        else "Only missing information is shown. Open a section to correct it."
    )
    app.preflight_summary_label.setProperty(
        "state",
        "ready" if report["ready"] else "missing",
    )
    repolish(app.preflight_summary_label)
    if report["ready"]:
        app.set_automation_state(
            "Ready",
            "Every required section is complete.",
            "SuccessBadge",
        )
    else:
        app.set_automation_state(
            "Needs attention",
            f"{len(report['items'])} item(s) must be completed before automation can start.",
            "WarningBadge",
        )
    automation_running = (
        hasattr(app, "automation_thread")
        and app.automation_thread.isRunning()
    )
    if not automation_running:
        app.start_button.setEnabled(report["ready"])

    app.preflight_rows = {}
    for index, item in enumerate(report["items"]):
        row = _build_report_row(app, item, report["ready"])
        app.preflight_rows_layout.addWidget(row)
        app.preflight_rows[index] = row
    app.preflight_rows_layout.addStretch(1)

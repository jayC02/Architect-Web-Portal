import os

from PySide6.QtCore import QSize, QTimer, Qt
from PySide6.QtWidgets import QListWidgetItem

from ..components import awesome_icon, repolish, themed_icon
from ..services import pdf_mapping
from ..services.pdf_mapping import CONFIDENCE_ROLE, FILENAME_ROLE


class PdfMappingController:
    def __init__(self, app, size_role):
        self.app = app
        self.size_role = size_role
        self.app._organise_loaded_pdf_names = []

    def update_bucket_counts(self):
        app = self.app
        if getattr(app, "_organise_rendering", False):
            return
        self.render_all_lists()
        inbox_count = app.inbox_list.count() if hasattr(app, "inbox_list") else 0
        if hasattr(app, "inbox_count"):
            app.inbox_count.setText(str(inbox_count))
            app.inbox_title.setText(f"Inbox ({inbox_count})")
        assigned_files = set()
        recommended_used = 0
        for key, label in getattr(app, "bucket_count_labels", {}).items():
            count = app.bucket_lists[key].count()
            self.resize_bucket_list(app.bucket_lists[key], count)
            for row in range(count):
                filename = app.bucket_lists[key].item(row).data(FILENAME_ROLE) or app.bucket_lists[key].item(row).text()
                if filename:
                    assigned_files.add(filename)
            if key not in {"location_plan", "other"} and count > 0:
                recommended_used += 1
            label.setText(str(count))
            if key in app.bucket_empty_labels and app.bucket_empty_labels[key] is not None:
                app.bucket_empty_labels[key].setVisible(count == 0)
        if hasattr(app, "mapping_ring"):
            required_ok = app.bucket_lists["location_plan"].count() > 0
            optional_used = 1 if app.bucket_lists["other"].count() > 0 else 0
            total_loaded = self.total_files_loaded()
            total_assigned = len(assigned_files)
            unassigned = max(total_loaded - total_assigned, 0)
            app.mapping_ring.set_value(total_assigned, total_loaded)
            app.summary_rows["required"].setText("1 / 1 ready" if required_ok else "0 / 1")
            app.summary_rows["recommended"].setText(f"{recommended_used} / 8" + (" ready" if recommended_used == 8 else ""))
            app.summary_rows["optional"].setText(f"{optional_used} / 1" + (" ready" if optional_used else ""))
            app.summary_rows["loaded"].setText(str(total_loaded))
            app.summary_rows["assigned"].setText(str(total_assigned))
            app.summary_rows["unassigned"].setText(str(unassigned))
            app.required_success_text.setText(
                "All required groups have at least one file."
                if required_ok else
                "Location Plan is required before saving the mapping."
            )

    def refresh_pdf_lists(self):
        self.render_all_lists()
        self.update_bucket_counts()

    def render_all_lists(self):
        app = self.app
        if not hasattr(app, "inbox_list"):
            return
        app._organise_rendering = True
        try:
            self.render_file_list(app.inbox_list, row_height=32)
            for widget in getattr(app, "bucket_lists", {}).values():
                self.render_file_list(widget, row_height=28)
        finally:
            app._organise_rendering = False

    def render_file_list(self, list_widget, row_height):
        for row in range(list_widget.count()):
            item = list_widget.item(row)
            filename = item.data(FILENAME_ROLE) or item.text()
            if not filename:
                continue
            item.setData(FILENAME_ROLE, filename)
            size_text = item.data(self.size_role) or self.file_size(filename)
            item.setData(self.size_role, size_text)
            confidence = item.data(CONFIDENCE_ROLE)
            item.setText(filename)
            item.setToolTip(f"{filename} | Auto-sort confidence: {confidence}" if confidence else filename)
            item.setSizeHint(QSize(0, row_height))
        if list_widget.property("bucketList") == "true":
            self.resize_bucket_list(list_widget, list_widget.count())

    def add_file_item_to_bucket(self, bucket_key, item, confidence=None):
        app = self.app
        filename = item.data(FILENAME_ROLE) or item.text()
        item.setData(FILENAME_ROLE, filename)
        item.setData(self.size_role, item.data(self.size_role) or self.file_size(filename))
        if confidence:
            item.setData(CONFIDENCE_ROLE, confidence)
        item.setText(filename)
        item.setSizeHint(QSize(0, 28))
        app.bucket_lists[bucket_key].addItem(item)

    def toggle_organise_log(self):
        app = self.app
        visible = not app.organise_log_box.isVisible()
        app.organise_log_box.setVisible(visible)
        app.organise_log_toggle.setText("Hide" if visible else "Show")

    def load_inbox_from_folder(self):
        app = self.app
        app.inbox_list.clear()
        if not app.pdf_folder_path or not os.path.isdir(app.pdf_folder_path):
            app.organise_status.setText("Select a valid folder first.")
            app.organise_status.setObjectName("WarningBadge")
            repolish(app.organise_status)
            return
        if app.selected_pdf_paths:
            filenames = [os.path.basename(path) for path in app.selected_pdf_paths]
        else:
            filenames = self.list_folder_pdfs(app.pdf_folder_path)
        app._organise_loaded_pdf_names = filenames
        for filename in filenames:
            self.add_pdf_item(app.inbox_list, filename)
        app.organise_status.setText(f"Inbox loaded: {app.inbox_list.count()} selected PDF(s).")
        app.organise_status.setObjectName("InfoBadge")
        repolish(app.organise_status)
        app.mark_mapping_dirty()
        self.update_bucket_counts()

    def autosort_pdfs(self):
        app = self.app
        result = pdf_mapping.autosort_pdfs(app.pdf_folder_path, app.inbox_list, app.bucket_lists, app.log)
        self.refresh_pdf_lists()
        if result["warnings"]:
            app.organise_log_box.setVisible(True)
            app.organise_log_toggle.setText("Hide")
        app.organise_status.setText(f"Auto-sort done. {result['sorted']} sorted, {result['review']} for review.")
        app.organise_status.setObjectName("WarningBadge" if result["review"] else "SuccessBadge")
        repolish(app.organise_status)
        app.mark_mapping_dirty()
        return result

    def save_pdf_mapping(self):
        app = self.app
        try:
            out_path = pdf_mapping.save_mapping(app, app.script_dir, app.pdf_folder_path, app.bucket_defs, app.bucket_lists)
        except Exception as exc:
            app.log(f"Mapping save failed: {exc}")
            self.show_mapping_toast(False, "Mapping could not be saved", str(exc))
            return
        if not out_path:
            self.show_mapping_toast(False, "Mapping could not be saved", "Check required files and try again.")
            return
        app.organise_status.setText(f"Saved mapping: {out_path}")
        app.organise_status.setObjectName("SuccessBadge")
        repolish(app.organise_status)
        app.log("Saved supporting_docs.json (organised PDF mapping).")
        app.mapping_saved_once = True
        app.completed_steps.add(app.organise_tab_index)
        app._last_saved_mapping_snapshot = app.build_mapping_snapshot()
        app.stop_save_mapping_highlight()
        app.update_navigation_state()
        app.log("Mapping saved")
        self.show_mapping_toast(True, "Mapping saved", "PDF mapping saved locally")
        self.show_saved_button_state()
        self.update_bucket_counts()

    def start_save_mapping_highlight(self):
        app = self.app
        if hasattr(app, "mapping_reminder"):
            app.mapping_reminder.setVisible(True)
        if hasattr(app, "btn_save_mapping"):
            app.btn_save_mapping.setStyleSheet("")

    def add_pdf_item(self, list_widget, filename, confidence=None):
        item = QListWidgetItem(filename)
        item.setData(FILENAME_ROLE, filename)
        item.setData(self.size_role, self.file_size(filename))
        if confidence:
            item.setData(CONFIDENCE_ROLE, confidence)
        item.setSizeHint(QSize(0, 32))
        list_widget.addItem(item)

    def file_size(self, filename):
        app = self.app
        if not app or not getattr(app, "pdf_folder_path", ""):
            return ""
        path = os.path.join(app.pdf_folder_path, filename)
        if not os.path.exists(path):
            return ""
        size = os.path.getsize(path)
        if size >= 1024 * 1024:
            return f"{size / (1024 * 1024):.1f} MB"
        return f"{max(1, round(size / 1024))} KB"

    def total_files_loaded(self):
        app = self.app
        folder = getattr(app, "pdf_folder_path", "")
        if not folder or not os.path.isdir(folder):
            return 0
        if getattr(app, "selected_pdf_paths", []):
            return len(set(os.path.basename(path) for path in app.selected_pdf_paths))
        loaded = getattr(app, "_organise_loaded_pdf_names", None)
        if loaded is not None:
            return len(set(loaded))
        return len(self.list_folder_pdfs(folder))

    def list_folder_pdfs(self, folder):
        if not folder or not os.path.isdir(folder):
            return []
        return sorted(name for name in os.listdir(folder) if name.lower().endswith(".pdf"))

    def resize_bucket_list(self, list_widget, count):
        rows = max(1, min(int(count or 0), 4))
        height = rows * 30
        list_widget.setMinimumHeight(height)
        list_widget.setMaximumHeight(128 if int(count or 0) > 4 else height)
        list_widget.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)

    def show_saved_button_state(self):
        app = self.app
        if not hasattr(app, "btn_save_mapping"):
            return
        app.btn_save_mapping.setText("Saved")
        saved_icon = awesome_icon("fa5s.check", "#FFFFFF")
        app.btn_save_mapping.setIcon(saved_icon if not saved_icon.isNull() else themed_icon("check", "#FFFFFF"))
        app.btn_save_mapping.setIconSize(QSize(16, 16))

        def restore_button():
            if hasattr(app, "btn_save_mapping"):
                app.btn_save_mapping.setText("  Save Mapping")
                save_icon = awesome_icon("fa5s.save", "#FFFFFF")
                app.btn_save_mapping.setIcon(save_icon if not save_icon.isNull() else themed_icon("save", "#FFFFFF"))
                app.btn_save_mapping.setIconSize(QSize(16, 16))

        QTimer.singleShot(3000, restore_button)

    def show_mapping_toast(self, success, title, detail):
        app = self.app
        if not hasattr(app, "mapping_toast"):
            return
        app.mapping_toast.setObjectName("SaveToast" if success else "ErrorToast")
        if hasattr(app, "mapping_toast_icon"):
            app.mapping_toast_icon.setPixmap(themed_icon("check", "#166534" if success else "#B91C1C").pixmap(18, 18))
        app.mapping_toast_title.setText(title)
        app.mapping_toast_detail.setText(detail)
        app.mapping_toast.setVisible(True)
        repolish(app.mapping_toast)
        QTimer.singleShot(3000, lambda: hasattr(app, "mapping_toast") and app.mapping_toast.setVisible(False))

from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QWidget

from .components import repolish
from .theme import THEME


class StepCircle(QWidget):
    def __init__(self, number, parent=None):
        super().__init__(parent)
        self.number = number
        self.state = "future"
        self.setObjectName("StepCircle")
        self.setFixedSize(36, 36)

    def sizeHint(self):
        return QSize(36, 36)

    def set_state(self, state):
        if self.state != state:
            self.state = state
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(2, 2, 32, 32)

        if self.state == "complete":
            painter.setBrush(QColor("#ECFDF3"))
            painter.setPen(QPen(QColor("#166534"), 1.4))
            painter.drawEllipse(rect)

            check = QPainterPath()
            check.moveTo(10.5, 18.2)
            check.lineTo(15.0, 22.4)
            check.lineTo(25.4, 12.8)
            pen = QPen(QColor("#166534"), 2.6)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawPath(check)
            return

        if self.state == "active":
            painter.setBrush(QColor(THEME["primary"]))
            painter.setPen(QPen(QColor(THEME["primary"]), 1.4))
            text_color = QColor("#FFFFFF")
        else:
            painter.setBrush(QColor("#FFFFFF"))
            painter.setPen(QPen(QColor("#DDD6CA"), 1.2))
            text_color = QColor(THEME["secondary"])

        painter.drawEllipse(rect)
        painter.setPen(text_color)
        painter.setFont(QFont("Segoe UI", 12, QFont.Bold))
        painter.drawText(self.rect(), Qt.AlignCenter, str(self.number))


class Stepper(QFrame):
    def __init__(self, steps, parent=None):
        super().__init__(parent)
        self.steps = steps
        self.circles = []
        self.labels = []
        self.lines = []
        self.setObjectName("MainShell")
        self._build()

    def _build(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(4, 0, 4, 0)
        layout.setSpacing(8)
        for index, step in enumerate(self.steps):
            circle = StepCircle(index + 1)
            short_label = {
                "Application Questions": "Questions",
                "Organise PDFs": "PDFs",
                "Agent Details": "Agent",
                "Applicant Details": "Applicant",
                "Start Automation": "Start",
            }.get(step, step)
            label = QLabel(short_label)
            label.setToolTip(step)
            label.setObjectName("StepLabel")
            layout.addWidget(circle)
            layout.addWidget(label)
            self.circles.append(circle)
            self.labels.append(label)
            if index < len(self.steps) - 1:
                line = QFrame()
                line.setFrameShape(QFrame.HLine)
                line.setStyleSheet(f"background: {THEME['border_subtle']}; max-height: 1px;")
                layout.addWidget(line, 1)
                self.lines.append(line)

    def update_state(self, active_index, completed):
        for index, circle in enumerate(self.circles):
            if index == active_index:
                state = "active"
            elif index in completed or index < active_index:
                state = "complete"
            else:
                state = "future"
            circle.set_state(state)
            self.labels[index].setProperty("state", "active" if index == active_index else "future")
            repolish(self.labels[index])

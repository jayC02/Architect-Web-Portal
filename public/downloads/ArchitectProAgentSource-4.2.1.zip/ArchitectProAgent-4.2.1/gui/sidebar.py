from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

from .components import repolish
from .theme import SPACING


class Sidebar(QFrame):
    def __init__(self, steps, navigate_callback, parent=None):
        super().__init__(parent)
        self.steps = steps
        self.navigate_callback = navigate_callback
        self.buttons = {}
        self.status_dots = {}
        self.setObjectName("Sidebar")
        self.setFixedWidth(264)
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 22, 20, 18)
        layout.setSpacing(SPACING["sm"])

        brand = QVBoxLayout()
        title = QLabel("NinetyOneArchitects")
        title.setObjectName("BrandTitle")
        subtitle = QLabel("Building Warrant Tool")
        subtitle.setObjectName("BrandSubtitle")
        brand.addWidget(title)
        brand.addWidget(subtitle)
        layout.addLayout(brand)
        layout.addSpacing(SPACING["lg"])

        workflow = QLabel("Workflow")
        workflow.setObjectName("SectionTitle")
        layout.addWidget(workflow)

        for index, step in enumerate(self.steps):
            row = QHBoxLayout()
            row.setSpacing(8)
            item_text = {
                "Application Questions": "Questions",
                "Organise PDFs": "PDFs",
                "Agent Details": "Agent",
                "Applicant Details": "Applicant",
                "Start Automation": "Start Automation",
            }.get(step, step)
            item = QPushButton(item_text)
            item.setToolTip(step)
            item.setObjectName("SidebarItem")
            item.setCursor(Qt.PointingHandCursor)
            item.clicked.connect(
                lambda checked=False, i=index: self.navigate_callback(i)
            )
            dot = QLabel("")
            dot.setObjectName("StatusDot")
            dot.setAlignment(Qt.AlignCenter)
            row.addWidget(item, 1)
            row.addWidget(dot)
            layout.addLayout(row)
            self.buttons[index] = item
            self.status_dots[index] = dot

        layout.addStretch(1)
        help_card = QFrame()
        help_card.setObjectName("HelpCard")
        help_layout = QVBoxLayout(help_card)
        help_layout.setContentsMargins(14, 14, 14, 14)
        help_layout.setSpacing(8)
        help_title = QLabel("Need help?")
        help_title.setObjectName("CardTitle")
        help_text = QLabel(
            "Work down the workflow, save the PDF mapping, then run automation."
        )
        help_text.setObjectName("HelpText")
        help_text.setWordWrap(True)
        help_layout.addWidget(help_title)
        help_layout.addWidget(help_text)
        layout.addWidget(help_card)

        version = QLabel("v1.3.0")
        version.setObjectName("Muted")
        layout.addWidget(version)

    def update_state(self, active_index, completed):
        for index, item in self.buttons.items():
            item.setProperty(
                "active",
                "true" if index == active_index else "false",
            )
            repolish(item)
            self.status_dots[index].setText(
                "\u2713" if index in completed or index < active_index else ""
            )

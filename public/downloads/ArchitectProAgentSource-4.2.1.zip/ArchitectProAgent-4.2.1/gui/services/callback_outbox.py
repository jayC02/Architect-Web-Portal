import json
import os
import uuid
from datetime import datetime, timedelta, timezone

from . import portal_handoff, storage_paths
from .desktop_callback_contract import build_callback_payload


BACKOFF_SECONDS = (5, 30, 120, 600, 1800, 3600)
TERMINAL_STATUSES = {"FAILED_FINAL", "CANCELLED"}


def _outbox_root():
    return os.path.join(storage_paths.app_data_dir(), "callback_outbox")


def _event_path(event_id):
    return os.path.join(_outbox_root(), f"{event_id}.json")


def _now():
    return datetime.now(timezone.utc)


def build_event(
    job_id,
    status,
    event_type,
    result_summary="",
    error="",
    last_checkpoint="",
    result=None,
    callback_id=None,
    occurred_at=None,
):
    event_id = str(callback_id or uuid.uuid4())
    result_payload = dict(result) if result else None
    nested_occurred_at = result_payload.pop("occurredAt", None) if result_payload else None
    payload = build_callback_payload(
        job_id=job_id,
        status=status,
        event_type=event_type,
        callback_id=event_id,
        occurred_at=occurred_at or nested_occurred_at,
        result_summary=result_summary,
        error=error,
        last_checkpoint=last_checkpoint,
        result=result_payload,
    )
    return build_outbox_event(payload)


def build_outbox_event(payload, address_correction_postcode=None):
    event_id = str(payload["callbackId"])
    return {
        "id": event_id,
        "jobId": str(payload["jobId"]),
        "portalUrl": portal_handoff.load_portal_url(),
        "payload": dict(payload),
        "attempts": 0,
        "nextAttemptAt": _now().isoformat(),
        "createdAt": _now().isoformat(),
        **({"addressCorrection": {"postcode": address_correction_postcode}} if address_correction_postcode else {}),
    }


def save_event(event):
    os.makedirs(_outbox_root(), exist_ok=True)
    path = _event_path(event["id"])
    temporary = f"{path}.tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(event, handle, indent=2)
    os.replace(temporary, path)
    return path


def pending_events():
    root = _outbox_root()
    if not os.path.isdir(root):
        return []
    events = []
    for name in sorted(os.listdir(root)):
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(root, name), "r", encoding="utf-8") as handle:
                event = json.load(handle)
            if isinstance(event, dict) and event.get("id") and event.get("jobId"):
                events.append(event)
        except (OSError, json.JSONDecodeError):
            continue
    return events


def _mark_failed(event, now):
    attempts = int(event.get("attempts") or 0) + 1
    event["attempts"] = attempts
    delay = BACKOFF_SECONDS[min(attempts - 1, len(BACKOFF_SECONDS) - 1)]
    event["nextAttemptAt"] = (now + timedelta(seconds=delay)).isoformat()
    save_event(event)


def deliver_event(event, client=None, now=None, allow_start=False):
    now = now or _now()
    save_event(event)
    if event.get("recoveryBlocked"):
        return False
    # Only the live worker may request start. Replaying this after restart could
    # acknowledge a run with no worker, or authorise stale local execution.
    if event["payload"].get("eventType") == "started" and not allow_start:
        return False
    try:
        if client is None:
            token = portal_handoff.get_job_access_token(event["jobId"])
            if not token:
                raise portal_handoff.PortalHandoffError(
                    "Secure access for this portal job is no longer available."
                )
            client = portal_handoff.PortalClient(event["portalUrl"], token)
        response = None
        if not event.get("callbackAcknowledged"):
            response = client.send_callback(event["jobId"], event["payload"])
            if not isinstance(response, dict) or response.get("ok") is not True:
                raise portal_handoff.PortalHandoffError("Architect Pro did not acknowledge this result.")
        if event["payload"].get("eventType") == "started":
            if not isinstance(response, dict) or response.get("ok") is not True or response.get("status") != "IN_PROGRESS":
                raise portal_handoff.PortalHandoffError("Architect Pro did not acknowledge this start.")
        correction = event.get("addressCorrection")
        if correction:
            # Persist dependency completion before attempting correction. The
            # original result ID and correction intent survive app/network loss.
            event["callbackAcknowledged"] = True
            save_event(event)
            restarted = client.correct_address_and_restart(event["jobId"], correction["postcode"])
            successor = (restarted.get("job") or {}).get("id")
            if not successor:
                raise portal_handoff.PortalHandoffError("The corrected attempt was not acknowledged.")
            correction["newJobId"] = str(successor)
        try:
            os.remove(_event_path(event["id"]))
        except FileNotFoundError:
            pass
        if event["payload"].get("status") in TERMINAL_STATUSES:
            portal_handoff.clear_job_access_token(event["jobId"])
        return True
    except (OSError, portal_handoff.PortalHandoffError) as exc:
        if event.get("addressCorrection") and getattr(exc, "status_code", None) in {400, 401, 403, 404, 409, 410, 422}:
            event["recoveryBlocked"] = True
        _mark_failed(event, now)
        return False


def queue_and_deliver(client, **event_kwargs):
    allow_start = event_kwargs.pop("allow_start", False)
    payload = event_kwargs.pop("payload", None)
    event = build_outbox_event(payload) if payload else build_event(**event_kwargs)
    return deliver_event(event, client=client, allow_start=allow_start)


def retry_pending(now=None, log=None):
    now = now or _now()
    delivered = 0
    retained = 0
    blocked = 0
    for event in pending_events():
        if event.get("recoveryBlocked"):
            blocked += 1
            retained += 1
            continue
        try:
            next_attempt = datetime.fromisoformat(
                str(event.get("nextAttemptAt") or "").replace("Z", "+00:00")
            )
            if next_attempt.tzinfo is None:
                next_attempt = next_attempt.replace(tzinfo=timezone.utc)
        except (TypeError, ValueError):
            next_attempt = now
        if next_attempt > now:
            retained += 1
            continue
        if deliver_event(event, now=now):
            delivered += 1
        else:
            retained += 1
    if log and (delivered or retained):
        log(f"Portal result sync: {delivered} delivered, {retained} waiting.")
    return {"delivered": delivered, "retained": retained, **({"blocked": blocked} if blocked else {})}

"""First-run Agent enrollment using browser authentication, PKCE and strict loopback."""

from __future__ import annotations

import base64
import hashlib
import http.server
import secrets
import threading
import time
import urllib.parse
import webbrowser

from . import portal_handoff


CALLBACK_HOST = "127.0.0.1"
CALLBACK_PATH = "/callback"
ENROLLMENT_TIMEOUT_SECONDS = 5 * 60


class AgentEnrollmentError(RuntimeError):
    pass


def generate_pkce():
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()
    ).decode("ascii").rstrip("=")
    return verifier, challenge


def generate_state():
    return secrets.token_urlsafe(32)


def validate_port(value):
    if isinstance(value, bool):
        raise AgentEnrollmentError("The local connection port is invalid.")
    try:
        port = int(value)
    except (TypeError, ValueError) as exc:
        raise AgentEnrollmentError("The local connection port is invalid.") from exc
    if port < 1 or port > 65535:
        raise AgentEnrollmentError("The local connection port is invalid.")
    return port


def loopback_callback_url(port):
    return f"http://{CALLBACK_HOST}:{validate_port(port)}{CALLBACK_PATH}"


class _CallbackState:
    def __init__(self, expected_state, portal_url):
        self.expected_state = expected_state
        self.portal_url = portal_url
        self.grant = None
        self.error = None
        self.received = threading.Event()


class _CallbackHandler(http.server.BaseHTTPRequestHandler):
    server_version = "ArchitectProLoopback"

    def log_message(self, _format, *_args):
        return

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path != CALLBACK_PATH:
            self.send_error(404)
            return
        state = self.server.callback_state
        values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        returned_state = (values.get("state") or [""])[0]
        grant = (values.get("grant") or [""])[0]
        if not secrets.compare_digest(returned_state, state.expected_state):
            state.error = "The secure browser response did not match this Agent. Try connecting again."
            self.send_response(400)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()
            self.wfile.write(b"Architect Pro could not verify this connection. Return to the Agent and try again.")
            state.received.set()
            return
        if not grant.startswith("ape_") or len(grant) > 120:
            state.error = "The portal did not return a valid connection grant. Try connecting again."
            self.send_error(400)
            state.received.set()
            return
        state.grant = grant
        self.send_response(302)
        self.send_header("Location", f"{state.portal_url}/settings/integrations?agent=connecting")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        state.received.set()


class _LoopbackServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, callback_state):
        super().__init__((CALLBACK_HOST, 0), _CallbackHandler)
        self.callback_state = callback_state
        self.timeout = 0.5


def build_connection_url(portal_url, installation_id, code_challenge, state, port):
    portal_url = portal_handoff._normalise_portal_url(portal_url)
    query = urllib.parse.urlencode({
        "installationId": installation_id,
        "codeChallenge": code_challenge,
        "state": state,
        "port": validate_port(port),
    })
    return f"{portal_url}/desktop-agent/connect?{query}"


def enroll_via_browser(portal_url=None, timeout_seconds=ENROLLMENT_TIMEOUT_SECONDS, browser_open=webbrowser.open):
    from . import background_agent

    portal_url = portal_handoff._normalise_portal_url(portal_url or portal_handoff.load_portal_url())
    verifier, challenge = generate_pkce()
    state = generate_state()
    installation_id = background_agent.installation_id()
    callback_state = _CallbackState(state, portal_url)
    server = _LoopbackServer(callback_state)
    port = validate_port(server.server_address[1])
    connection_url = build_connection_url(portal_url, installation_id, challenge, state, port)
    deadline = time.monotonic() + timeout_seconds
    try:
        if not browser_open(connection_url):
            raise AgentEnrollmentError("Architect Pro could not open your browser. Try again from Agent settings.")
        while not callback_state.received.is_set() and time.monotonic() < deadline:
            server.handle_request()
        if not callback_state.received.is_set():
            raise AgentEnrollmentError("The secure browser connection expired. Try again.")
        if callback_state.error:
            raise AgentEnrollmentError(callback_state.error)
        client = background_agent.AgentApi.enroll_pkce(
            portal_url,
            callback_state.grant,
            verifier,
            installation_id,
        )
        return client
    finally:
        server.server_close()
        verifier = ""
        state = ""
        callback_state.grant = None

import json
import os

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QComboBox

from . import storage_paths

CLEAR_PRESET_LABEL = "Clear preset"


def load_json(base_dir, filename, log=None):
    path, _ = storage_paths.migrate_json_if_missing(
        filename,
        base_dir,
        scrubber=storage_paths.scrub_sensitive_fields,
        log=log,
    )
    if not os.path.exists(path):
        if log:
            log(f"Preset/config file not found, using defaults: {path}")
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        if log:
            log(f"Could not load {path}. Error: {exc}")
        return {}
    return data if isinstance(data, dict) else {}


def save_json(base_dir, filename, data):
    path = storage_paths.runtime_path(filename, base_dir)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=4)


def scrub_legacy_passwords(data):
    changed = False
    if not isinstance(data, dict):
        return False
    for preset_data in data.values():
        if isinstance(preset_data, dict) and "Password" in preset_data:
            preset_data.pop("Password", None)
            changed = True
    return changed


def populate_combo(base_dir, filename, combo, log=None):
    placeholder = combo.property("placeholder_text") or "Select preset..."
    preset_names = list(load_json(base_dir, filename, log))
    combo.blockSignals(True)
    combo.clear()
    if hasattr(combo, "setPlaceholderText"):
        combo.setPlaceholderText(placeholder)
    combo.addItem(CLEAR_PRESET_LABEL)
    if preset_names:
        combo.insertSeparator(combo.count())
    for key in preset_names:
        combo.addItem(key)
    combo.setCurrentIndex(-1)
    combo.blockSignals(False)


def reset_preset_selection(combo):
    combo.blockSignals(True)
    combo.setCurrentIndex(-1)
    combo.blockSignals(False)


def clear_preset_fields(combo, fields, widgets):
    for field in fields:
        widget = widgets[field]
        if isinstance(widget, QComboBox):
            widget.setCurrentIndex(0 if widget.count() else -1)
        elif hasattr(widget, "clear"):
            widget.clear()
        else:
            widget.setText("")
        widget.setProperty("touched", False)
        widget.setProperty("invalid", "false")
    reset_preset_selection(combo)


def apply_preset(base_dir, filename, combo, fields, widgets, log=None):
    selected = combo.currentText().strip()
    placeholder = combo.property("placeholder_text") or "Select preset..."
    if not selected or selected in {"Select preset...", placeholder}:
        return
    if selected == CLEAR_PRESET_LABEL:
        clear_preset_fields(combo, fields, widgets)
        if log:
            log("Preset selection cleared.")
        return
    presets = load_json(base_dir, filename, log)
    data = presets.get(selected)
    if not isinstance(data, dict):
        return
    for field in fields:
        if field not in data:
            continue
        widget = widgets[field]
        value = data[field]
        if isinstance(widget, QComboBox):
            index = widget.findText(value, Qt.MatchFixedString)
            if index >= 0:
                widget.setCurrentIndex(index)
        else:
            widget.setText(value)

APPLICATION_TYPE_KEY = "Application Type"
BUILDING_WARRANT_TYPE = "Building Warrant"
HOUSEHOLDER_TYPE = "Householder Application (Planning)"

PROFILE_KEY = "Application Profile"
TYPE_OF_WORKS_KEY = "Application Profiles"

DOMESTIC_PROFILE = "Domestic alteration / extension"
NEW_BUILD_PROFILE = "New build"
CONVERSION_PROFILE = "Conversion / change of use"
DEMOLITION_PROFILE = "Demolition"

PROFILES = {
    DOMESTIC_PROFILE: {
        "Includes Existing Building Work": "Yes",
        "Includes New Building Or Extension": "Yes",
        "New Building Construction": "No",
        "Conversion Regulations": "No",
        "Includes Demolition": "No",
    },
    NEW_BUILD_PROFILE: {
        "Includes Existing Building Work": "No",
        "Includes New Building Or Extension": "Yes",
        "New Building Construction": "Yes",
        "Conversion Regulations": "No",
        "Includes Demolition": "No",
    },
    CONVERSION_PROFILE: {
        "Includes Existing Building Work": "Yes",
        "Includes New Building Or Extension": "No",
        "New Building Construction": "No",
        "Conversion Regulations": "Yes",
        "Includes Demolition": "No",
    },
    DEMOLITION_PROFILE: {
        "Includes Existing Building Work": "Yes",
        "Includes New Building Or Extension": "No",
        "New Building Construction": "No",
        "Conversion Regulations": "No",
        "Includes Demolition": "Yes",
    },
}

PROFILE_FIELDS = [
    "Includes Existing Building Work",
    "Includes New Building Or Extension",
    "New Building Construction",
    "Conversion Regulations",
    "Includes Demolition",
]

EXCEPTION_DEFAULTS = {
    "Applicant Is Owner": "Yes",
    "Application Staged": "No",
    "Limited Life Building": "No",
    "Fire Rescue Enforcing Authority": "Yes",
    "Listed Or Conservation Area": "No",
    "Other Historical Importance": "No",
    "Relaxation Direction": "No",
    "Dangerous Building Notice": "No",
    "Approved Certifier Construction": "No",
    "STAS": "No",
    "Public Inspection Restricted": "No",
}

HOUSEHOLDER_DEFAULTS = {
    "Householder Discussed With Planning Authority": "No",
    "Householder Trees On Site": "No",
    "Householder New Or Altered Vehicle Access": "No",
    "Householder Sole Owner": "Yes",
    "Householder Agricultural Holding": "No",
    "Householder Identify All Other Owners": "No",
    "Householder Notice To One Owner": "No",
    "Householder Location Plan Printed And Verified": "No",
}

HOUSEHOLDER_FIELD_LABELS = {
    "Householder Discussed With Planning Authority": "Discussed proposal with planning authority",
    "Householder Trees On Site": "Trees on or adjacent to the application site",
    "Householder New Or Altered Vehicle Access": "New or altered vehicle access",
    "Householder Current Parking Spaces": "Current vehicle parking spaces",
    "Householder Proposed Parking Spaces": "Proposed total vehicle parking spaces",
    "Householder Sole Owner": "Applicant is sole owner of all land",
    "Householder Agricultural Holding": "Any land is part of an agricultural holding",
    "Householder Identify All Other Owners": "Able to identify and notify every other owner",
    "Householder Notice To One Owner": "Able to give notice to at least one other owner",
    "Householder Location Plan Printed And Verified": "Location plan printed from the submitted PDF and verified",
    "Householder Ownership Reasonable Steps": "Reasonable steps taken to identify or notify other owners",
}

FIELD_LABELS = {
    "Includes Existing Building Work": "Work to an existing building",
    "Includes New Building Or Extension": "New building or extension work",
    "New Building Construction": "Application is for a new building",
    "Conversion Regulations": "Conversion in terms of regulations",
    "Includes Demolition": "Includes demolition",
    "Applicant Is Owner": "Applicant is owner",
    "Application Staged": "Application is staged",
    "Limited Life Building": "Intended life is five years or less",
    "Fire Rescue Enforcing Authority": "Fire and Rescue Service enforcing authority",
    "Listed Or Conservation Area": "Listed building or conservation area",
    "Other Historical Importance": "Other historical importance",
    "Relaxation Direction": "Scottish Ministers relaxation direction",
    "Dangerous Building Notice": "Dangerous building notice",
    "Approved Certifier Design": "Approved certifier of design",
    "Approved Certifier Construction": "Approved certifier of construction",
    "STAS": "Covered by STAS",
    "Public Inspection Restricted": "Restrict public inspection",
}

CERTIFICATE_DETAIL_FIELDS = [
    "Registration Number (A) Part 2",
    "Name of Certifier",
    "Registration Number (B) Part 2",
    "Name of Approved Body",
]

UNSUPPORTED_MANUAL_YES_FIELDS = {
    "Application Staged": "The portal may ask for stage details.",
    "Approved Certifier Construction": "The portal may ask for construction certificate details.",
    "New Building Construction": "The portal may ask for sustainability or new-building details.",
    "Limited Life Building": "The portal may ask for intended life details.",
    "Listed Or Conservation Area": "The portal may ask for listed/conservation details.",
    "Other Historical Importance": "The portal may ask for historical-importance details.",
    "Relaxation Direction": "The portal may ask for relaxation direction details.",
    "Dangerous Building Notice": "The portal may ask for notice details.",
    "STAS": "The portal may ask for STAS approval details.",
    "Public Inspection Restricted": "The portal may ask for register restriction details.",
}


def yes_no(value, default="No"):
    if isinstance(value, bool):
        return "Yes" if value else "No"
    text = str(value or "").strip().lower()
    if text in {"yes", "y", "true", "1", "on"}:
        return "Yes"
    if text in {"no", "n", "false", "0", "off"}:
        return "No"
    return default


def profile_names():
    return list(PROFILES.keys())


def normalise_profiles(value):
    values = value if isinstance(value, (list, tuple, set)) else str(value or "").split("|")
    profiles = []
    for entry in values:
        profile = str(entry or "").strip()
        if profile in PROFILES and profile not in profiles:
            profiles.append(profile)
    return profiles or [DOMESTIC_PROFILE]


def primary_profile(value):
    return normalise_profiles(value)[0]


def proposed_work_for_profiles(value):
    profiles = normalise_profiles(value)
    if any(profile in {DOMESTIC_PROFILE, NEW_BUILD_PROFILE} for profile in profiles):
        return "Construct"
    if CONVERSION_PROFILE in profiles:
        return "Convert"
    return "Demolish"


def defaults_for_profiles(value):
    profiles = normalise_profiles(value)
    answers = dict(EXCEPTION_DEFAULTS)
    answers.update({field: "No" for field in PROFILE_FIELDS})
    for profile in profiles:
        for field, answer in PROFILES[profile].items():
            if answer == "Yes":
                answers[field] = "Yes"
    return answers


def defaults_for_profile(profile):
    return defaults_for_profiles([profile])


def infer_design_certificate(values):
    return "Yes" if any(str(values.get(field, "")).strip() for field in CERTIFICATE_DETAIL_FIELDS) else "No"


def has_partial_certificate_details(values):
    filled = [field for field in CERTIFICATE_DETAIL_FIELDS if str(values.get(field, "")).strip()]
    return bool(filled) and len(filled) < len(CERTIFICATE_DETAIL_FIELDS)


def collect_answers(profile, exception_values, certificate_values):
    profiles = normalise_profiles(profile)
    answers = defaults_for_profiles(profiles)
    for key, value in exception_values.items():
        answers[key] = yes_no(value, answers.get(key, "No"))
    answers["Approved Certifier Design"] = infer_design_certificate(certificate_values)
    answers[PROFILE_KEY] = profiles[0]
    answers[TYPE_OF_WORKS_KEY] = " | ".join(profiles)
    return answers


def collect_householder_answers(question_values, parking_values=None, text_values=None):
    answers = dict(HOUSEHOLDER_DEFAULTS)
    for key, value in question_values.items():
        if key in HOUSEHOLDER_DEFAULTS:
            answers[key] = yes_no(value, answers[key])
    parking_values = parking_values or {}
    answers["Householder Current Parking Spaces"] = str(parking_values.get("Householder Current Parking Spaces", "")).strip()
    answers["Householder Proposed Parking Spaces"] = str(parking_values.get("Householder Proposed Parking Spaces", "")).strip()
    if answers.get("Householder New Or Altered Vehicle Access") == "Yes":
        answers["Householder Current Parking Spaces"] = answers["Householder Current Parking Spaces"] or "0"
        answers["Householder Proposed Parking Spaces"] = answers["Householder Proposed Parking Spaces"] or "0"
    text_values = text_values or {}
    answers["Householder Ownership Reasonable Steps"] = str(
        text_values.get("Householder Ownership Reasonable Steps", "")
    ).strip()
    return answers


def summary_lines(answers):
    profiles = answers.get(TYPE_OF_WORKS_KEY) or answers.get(PROFILE_KEY, DOMESTIC_PROFILE)
    lines = [f"Type of Work: {str(profiles).replace(' | ', ', ')}"]
    for key in PROFILE_FIELDS:
        lines.append(f"{FIELD_LABELS[key]}: {answers.get(key, 'No')}")
    lines.append(f"{FIELD_LABELS['Approved Certifier Design']}: {answers.get('Approved Certifier Design', 'No')}")
    return lines


def householder_summary_lines(answers):
    lines = ["Application: Householder Application (Planning)"]
    for key in HOUSEHOLDER_DEFAULTS:
        lines.append(f"{HOUSEHOLDER_FIELD_LABELS[key]}: {answers.get(key, HOUSEHOLDER_DEFAULTS[key])}")
    if yes_no(answers.get("Householder New Or Altered Vehicle Access"), "No") == "Yes":
        current = answers.get("Householder Current Parking Spaces") or "Not entered"
        proposed = answers.get("Householder Proposed Parking Spaces") or "Not entered"
        lines.append(f"{HOUSEHOLDER_FIELD_LABELS['Householder Current Parking Spaces']}: {current}")
        lines.append(f"{HOUSEHOLDER_FIELD_LABELS['Householder Proposed Parking Spaces']}: {proposed}")
    return lines


def unsupported_yes_answers(answers):
    return [
        (FIELD_LABELS.get(key, key), reason)
        for key, reason in UNSUPPORTED_MANUAL_YES_FIELDS.items()
        if yes_no(answers.get(key), "No") == "Yes"
    ]

import json
import os
import re
import urllib.error
import urllib.request

from . import portal_answers, secure_credentials, storage_paths


AI_SETTINGS_FILENAME = "ai_settings.json"
PROVIDER_OPENAI = "OpenAI"
PROVIDER_GEMINI = "Gemini"
DEFAULT_PROVIDER = PROVIDER_GEMINI
DEFAULT_MODEL = "gpt-5.4-mini"
FALLBACK_MODEL = "gpt-5.4-nano"
DEFAULT_GEMINI_MODEL = "gemini-3.1-flash-lite"
MAX_PDF_CHARS_PER_FILE = 8000
MAX_TOTAL_PDF_CHARS = 80000
MAX_NOTE_CHARS = 30000


COMMON_FIELD_KEYS = [
    "Email",
    "Description of Work",
    "Agent First Name",
    "Agent Last Name",
    "Agent Telephone Number",
    "Agent Email Address",
    "Agent Building Number",
    "Agent Address 1",
    "Agent Town/City",
    "Agent Country",
    "Agent Postcode",
    "Applicant Title",
    "Applicant First Name",
    "Applicant Last Name",
    "Applicant Mobile Number",
    "Applicant Email",
    "Applicant Building Number",
    "Applicant Address 1",
    "Applicant Town/City",
    "Applicant Country",
    "Applicant Postcode",
    "Applicant Company",
    "Applicant Building Name",
]

BUILDING_WARRANT_FIELD_KEYS = [
    "Proposed Use",
    "Current Use",
    "Estimated Work Value",
    "Proposed Work",
    portal_answers.PROFILE_KEY,
    "Includes Existing Building Work",
    "Includes New Building Or Extension",
    "New Building Construction",
    "Conversion Regulations",
    "Includes Demolition",
    "Applicant Is Owner",
    "Application Staged",
    "Limited Life Building",
    "Fire Rescue Enforcing Authority",
    "Listed Or Conservation Area",
    "Other Historical Importance",
    "Relaxation Direction",
    "Dangerous Building Notice",
    "Approved Certifier Construction",
    "STAS",
    "Public Inspection Restricted",
    "Scheme Type",
    "Registration Number (A) Part 1",
    "Registration Number (A) Part 2",
    "Registration Number (B) Part 1",
    "Registration Number (B) Part 2",
    "Name of Certifier",
    "Name of Approved Body",
]

HOUSEHOLDER_FIELD_KEYS = [
    "Householder Discussed With Planning Authority",
    "Householder Trees On Site",
    "Householder New Or Altered Vehicle Access",
    "Householder Current Parking Spaces",
    "Householder Proposed Parking Spaces",
    "Householder Sole Owner",
    "Householder Agricultural Holding",
]

YES_NO_FIELD_KEYS = {
    "Includes Existing Building Work",
    "Includes New Building Or Extension",
    "New Building Construction",
    "Conversion Regulations",
    "Includes Demolition",
    "Applicant Is Owner",
    "Application Staged",
    "Limited Life Building",
    "Fire Rescue Enforcing Authority",
    "Listed Or Conservation Area",
    "Other Historical Importance",
    "Relaxation Direction",
    "Dangerous Building Notice",
    "Approved Certifier Construction",
    "STAS",
    "Public Inspection Restricted",
    "Householder Discussed With Planning Authority",
    "Householder Trees On Site",
    "Householder New Or Altered Vehicle Access",
    "Householder Sole Owner",
    "Householder Agricultural Holding",
}


def settings_path(base_dir):
    return storage_paths.runtime_path(AI_SETTINGS_FILENAME, base_dir)


def legacy_settings_path(base_dir):
    return os.path.join(base_dir, AI_SETTINGS_FILENAME)


def _plaintext_keys(data):
    return {
        PROVIDER_OPENAI: str(data.get("openai_api_key") or data.get("api_key") or "").strip(),
        PROVIDER_GEMINI: str(data.get("gemini_api_key") or "").strip(),
    }


def _migrate_plaintext_keys(data, source_path):
    keys = {provider: value for provider, value in _plaintext_keys(data).items() if value}
    if not keys:
        return True, ""
    for provider, value in keys.items():
        saved, message = secure_credentials.save_ai_api_key(provider, value)
        if not saved:
            return False, message or "Secure credential storage is unavailable."
    scrubbed = storage_paths.scrub_ai_settings_for_migration(data)
    try:
        with open(source_path, "w", encoding="utf-8") as handle:
            json.dump(scrubbed, handle, indent=4)
    except OSError:
        return False, "The API key was secured, but the legacy plaintext settings file could not be scrubbed."
    data.clear()
    data.update(scrubbed)
    return True, ""


def load_settings(base_dir):
    legacy = legacy_settings_path(base_dir)
    modern = settings_path(base_dir)
    migration_error = ""
    if not os.path.exists(modern) and os.path.exists(legacy):
        legacy_data, error = storage_paths.load_json_file(legacy)
        if isinstance(legacy_data, dict) and error is None:
            _, migration_error = _migrate_plaintext_keys(legacy_data, legacy)
    storage_paths.migrate_json_if_missing(
        AI_SETTINGS_FILENAME,
        base_dir,
        scrubber=storage_paths.scrub_ai_settings_for_migration,
    )
    path = modern
    if not os.path.exists(path):
        data = {}
    else:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, json.JSONDecodeError):
            data = {}
    if isinstance(data, dict):
        _, current_migration_error = _migrate_plaintext_keys(data, path) if os.path.exists(path) else (True, "")
        migration_error = migration_error or current_migration_error
    else:
        data = {}
    provider = str(data.get("provider") or "").strip()
    if provider not in {PROVIDER_OPENAI, PROVIDER_GEMINI}:
        provider = DEFAULT_PROVIDER
    openai_key, openai_available, openai_error = secure_credentials.get_ai_api_key(PROVIDER_OPENAI)
    gemini_key, gemini_available, gemini_error = secure_credentials.get_ai_api_key(PROVIDER_GEMINI)
    openai_model = str(data.get("openai_model") or (data.get("model") if provider == PROVIDER_OPENAI else "") or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    gemini_model = str(data.get("gemini_model") or (data.get("model") if provider == PROVIDER_GEMINI else "") or DEFAULT_GEMINI_MODEL).strip() or DEFAULT_GEMINI_MODEL
    secure_available = openai_available and gemini_available
    secure_error = migration_error or ("" if secure_available else (openai_error or gemini_error or "Secure credential storage is unavailable."))
    return {
        "provider": provider,
        "api_key": (openai_key or "") if provider == PROVIDER_OPENAI else (gemini_key or ""),
        "model": openai_model if provider == PROVIDER_OPENAI else gemini_model,
        "openai_api_key": openai_key or "",
        "openai_model": openai_model,
        "gemini_api_key": gemini_key or "",
        "gemini_model": gemini_model,
        "secure_storage_available": secure_available,
        "secure_storage_error": secure_error,
    }


def save_settings(base_dir, provider, api_key, model=None):
    previous = load_settings(base_dir)
    provider = provider if provider in {PROVIDER_OPENAI, PROVIDER_GEMINI} else DEFAULT_PROVIDER
    saved, message = secure_credentials.save_ai_api_key(provider, api_key)
    if not saved:
        raise RuntimeError(message or "The API key could not be stored securely.")
    data = {
        "provider": provider,
        "openai_model": previous.get("openai_model", DEFAULT_MODEL) or DEFAULT_MODEL,
        "gemini_model": previous.get("gemini_model", DEFAULT_GEMINI_MODEL) or DEFAULT_GEMINI_MODEL,
    }
    if provider == PROVIDER_OPENAI:
        data["openai_model"] = str(model or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    else:
        data["gemini_model"] = str(model or DEFAULT_GEMINI_MODEL).strip() or DEFAULT_GEMINI_MODEL
    path = settings_path(base_dir)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=4)


def clear_settings(base_dir):
    for provider in (PROVIDER_OPENAI, PROVIDER_GEMINI):
        secure_credentials.delete_ai_api_key(provider)
    for path in {settings_path(base_dir), legacy_settings_path(base_dir)}:
        if os.path.exists(path):
            os.remove(path)


def allowed_field_keys(application_type):
    keys = list(COMMON_FIELD_KEYS)
    if application_type == portal_answers.HOUSEHOLDER_TYPE:
        keys.extend(HOUSEHOLDER_FIELD_KEYS)
    else:
        keys.extend(BUILDING_WARRANT_FIELD_KEYS)
    return keys


def estimate_payload(notes, pdf_paths):
    notes_chars = len(notes or "")
    pdf_count = len(pdf_paths or [])
    rough_chars = min(notes_chars, MAX_NOTE_CHARS) + min(pdf_count * MAX_PDF_CHARS_PER_FILE, MAX_TOTAL_PDF_CHARS)
    rough_tokens = max(1, rough_chars // 4)
    if rough_tokens < 6000:
        size = "Small"
    elif rough_tokens < 22000:
        size = "Medium"
    else:
        size = "Large"
    return {"size": size, "rough_tokens": rough_tokens, "pdf_count": pdf_count}


def extract_application_details(base_dir, application_type, notes, pdf_paths, existing_values=None, retry_with_fallback=True):
    settings = load_settings(base_dir)
    provider = settings.get("provider") or DEFAULT_PROVIDER
    api_key = settings.get("api_key")
    if not api_key:
        raise RuntimeError(f"{provider} API key is missing. Add your own API key before using AI Intake.")

    notes = (notes or "").strip()
    if not notes and not pdf_paths:
        raise RuntimeError("Paste notes or attach at least one PDF before running AI Intake.")

    pdf_extracts, pdf_warnings = extract_pdf_texts(pdf_paths or [])
    payload = build_payload(application_type, notes, pdf_extracts, existing_values or {})
    model = settings.get("model") or (DEFAULT_MODEL if provider == PROVIDER_OPENAI else DEFAULT_GEMINI_MODEL)
    try:
        if provider == PROVIDER_GEMINI:
            result = call_gemini(api_key, model, payload)
        else:
            result = call_openai(api_key, model, payload)
    except RuntimeError as exc:
        if provider != PROVIDER_OPENAI or not retry_with_fallback or model == FALLBACK_MODEL:
            raise
        result = call_openai(api_key, FALLBACK_MODEL, payload)
        result.setdefault("warnings", []).append(f"Primary model failed; retried with {FALLBACK_MODEL}. Original error: {exc}")
    result.setdefault("warnings", [])
    result["warnings"].extend(pdf_warnings)
    result["estimate"] = estimate_payload(notes, pdf_paths or [])
    return normalise_result(result, allowed_field_keys(application_type))


def extract_pdf_texts(pdf_paths):
    extracts = []
    warnings = []
    total_chars = 0
    for path in pdf_paths[:35]:
        filename = os.path.basename(path)
        if not os.path.exists(path):
            warnings.append(f"Skipped missing PDF: {filename}")
            continue
        if not path.lower().endswith(".pdf"):
            warnings.append(f"Skipped non-PDF attachment: {filename}")
            continue
        text = ""
        try:
            text = _read_pdf_text(path)
        except Exception as exc:
            warnings.append(f"Could not extract text from {filename}: {exc}")
        text = clean_text(text)
        if not text:
            warnings.append(f"No selectable text found in {filename}; scanned PDFs need manual entry in this version.")
            text = ""
        remaining = max(0, MAX_TOTAL_PDF_CHARS - total_chars)
        if remaining <= 0:
            warnings.append("PDF text limit reached; remaining PDFs were represented by filename only.")
            text = ""
        else:
            text = text[: min(MAX_PDF_CHARS_PER_FILE, remaining)]
            total_chars += len(text)
        extracts.append({"filename": filename, "text": text})
    return extracts, warnings


def _read_pdf_text(path):
    try:
        from PyPDF2 import PdfReader
    except Exception as exc:
        raise RuntimeError("PyPDF2 is not installed") from exc
    reader = PdfReader(path)
    pages = []
    for page in reader.pages[:8]:
        pages.append(page.extract_text() or "")
    return "\n".join(pages)


def clean_text(value):
    text = re.sub(r"\s+", " ", value or "").strip()
    return text


def build_payload(application_type, notes, pdf_extracts, existing_values):
    allowed_keys = allowed_field_keys(application_type)
    instructions = {
        "application_type": application_type,
        "allowed_field_keys": allowed_keys,
        "allowed_application_profiles": portal_answers.profile_names(),
        "allowed_proposed_work": ["Construct", "Convert", "Provide Services", "Demolish"],
        "yes_no_fields": sorted(key for key in YES_NO_FIELD_KEYS if key in allowed_keys),
        "existing_values": {key: str(existing_values.get(key, "")) for key in allowed_keys if str(existing_values.get(key, "")).strip()},
        "notes": notes[:MAX_NOTE_CHARS],
        "pdf_extracts": pdf_extracts,
    }
    return instructions


def response_schema(allowed_keys):
    return {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "values": {
                "type": "array",
                "items": {
                    "type": "object",
                    "additionalProperties": False,
                    "properties": {
                        "key": {"type": "string", "enum": allowed_keys},
                        "value": {"type": "string"},
                        "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
                        "source": {"type": "string", "enum": ["notes", "pdf_text", "inferred"]},
                        "reason": {"type": "string"},
                    },
                    "required": ["key", "value", "confidence", "source", "reason"],
                },
            },
            "missing_required_fields": {"type": "array", "items": {"type": "string"}},
            "warnings": {"type": "array", "items": {"type": "string"}},
            "summary": {"type": "string"},
        },
        "required": ["values", "missing_required_fields", "warnings", "summary"],
    }


def call_openai(api_key, model, payload):
    system_prompt = (
        "You extract application form details for a UK architecture practice. "
        "Return only values that are directly present or strongly supported. "
        "Do not guess names, emails, addresses, certificate details, costs, or yes/no answers. "
        "For yes/no fields, return exactly Yes or No. "
        "For uncertain values, use confidence low and explain why. "
        "If an existing value conflicts with source material, return the source value with a warning; the user will review it."
    )
    user_prompt = "Extract application details from this JSON payload:\n" + json.dumps(payload, ensure_ascii=False)
    body = {
        "model": model,
        "input": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "text": {
            "format": {
                "type": "json_schema",
                "name": "ai_intake_result",
                "strict": True,
                "schema": response_schema(payload["allowed_field_keys"]),
            }
        },
    }
    request = urllib.request.Request(
        "https://api.openai.com/v1/responses",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI request failed ({exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"OpenAI request failed: {exc}") from exc
    data = json.loads(raw)
    text = extract_response_text(data)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError("OpenAI returned invalid JSON for the intake result.") from exc


def call_gemini(api_key, model, payload):
    prompt = (
        "You extract application form details for a UK architecture practice.\n"
        "Return only values that are directly present or strongly supported.\n"
        "Do not guess names, emails, addresses, certificate details, costs, or yes/no answers.\n"
        "For yes/no fields, return exactly Yes or No.\n"
        "For uncertain values, use confidence low and explain why.\n"
        "If an existing value conflicts with source material, return the source value with a warning; the user will review it.\n\n"
        "Extract application details from this JSON payload:\n"
        + json.dumps(payload, ensure_ascii=False)
    )
    body = {
        "model": model,
        "input": prompt,
        "response_format": {
            "type": "text",
            "mime_type": "application/json",
            "schema": response_schema(payload["allowed_field_keys"]),
        },
    }
    request = urllib.request.Request(
        "https://generativelanguage.googleapis.com/v1beta/interactions",
        data=json.dumps(body).encode("utf-8"),
        headers={
            "x-goog-api-key": api_key,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Gemini request failed ({exc.code}): {detail}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Gemini request failed: {exc}") from exc
    data = json.loads(raw)
    text = extract_gemini_response_text(data)
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise RuntimeError("Gemini returned invalid JSON for the intake result.") from exc


def extract_response_text(response_data):
    if response_data.get("output_text"):
        return response_data["output_text"]
    chunks = []
    for item in response_data.get("output", []):
        for content in item.get("content", []):
            if "text" in content:
                chunks.append(content["text"])
    text = "".join(chunks).strip()
    if not text:
        raise RuntimeError("OpenAI returned an empty intake result.")
    return text


def extract_gemini_response_text(response_data):
    if response_data.get("output_text"):
        return response_data["output_text"].strip()
    if response_data.get("text"):
        return response_data["text"].strip()
    chunks = []
    for item in response_data.get("output", []):
        for content in item.get("content", []):
            if "text" in content:
                chunks.append(content["text"])
    for candidate in response_data.get("candidates", []):
        content = candidate.get("content", {})
        for part in content.get("parts", []):
            if "text" in part:
                chunks.append(part["text"])
    for output in response_data.get("outputs", []):
        if "text" in output:
            chunks.append(output["text"])
        for content in output.get("content", []):
            if isinstance(content, dict) and "text" in content:
                chunks.append(content["text"])
    for step in response_data.get("steps", []):
        for content in step.get("content", []):
            if isinstance(content, dict) and content.get("type") == "text":
                chunks.append(content.get("text", ""))
    text = "".join(chunks).strip()
    if not text:
        raise RuntimeError("Gemini returned an empty intake result.")
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?\s*", "", text)
        text = re.sub(r"\s*```$", "", text).strip()
    return text


def normalise_result(result, allowed_keys):
    allowed = set(allowed_keys)
    values = []
    warnings = list(result.get("warnings") or [])
    seen = set()
    for item in result.get("values") or []:
        key = str(item.get("key") or "").strip()
        value = str(item.get("value") or "").strip()
        if not key or key not in allowed or not value:
            continue
        if key in seen:
            continue
        seen.add(key)
        if key in YES_NO_FIELD_KEYS:
            value = portal_answers.yes_no(value, "")
            if value not in {"Yes", "No"}:
                warnings.append(f"Rejected invalid yes/no value for {key}.")
                continue
        confidence = str(item.get("confidence") or "low").lower()
        if confidence not in {"high", "medium", "low"}:
            confidence = "low"
        source = str(item.get("source") or "notes").lower()
        if source not in {"notes", "pdf_text", "inferred"}:
            source = "notes"
        values.append(
            {
                "key": key,
                "value": value,
                "confidence": confidence,
                "source": source,
                "reason": str(item.get("reason") or "").strip(),
            }
        )
    return {
        "values": values,
        "missing_required_fields": [str(item) for item in result.get("missing_required_fields") or []],
        "warnings": warnings,
        "summary": str(result.get("summary") or "").strip(),
        "estimate": result.get("estimate") or {},
    }

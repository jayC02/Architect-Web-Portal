import os
import json


APP_VENDOR = "NinetyOneArchitects"
APP_NAME = "Building Portal"
SENSITIVE_FIELD_NAMES = {"Password", "password"}
AI_SECRET_FIELD_NAMES = {"api_key", "openai_api_key", "gemini_api_key"}


def app_data_dir():
    root = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(root, APP_VENDOR, APP_NAME)
    os.makedirs(folder, exist_ok=True)
    return folder


def runtime_path(filename, base_dir=None):
    return os.path.join(app_data_dir(), filename)


def legacy_path(filename, base_dir):
    return os.path.join(base_dir, filename)


def read_path(filename, base_dir=None):
    modern = runtime_path(filename, base_dir)
    if os.path.exists(modern):
        return modern
    if base_dir:
        legacy = legacy_path(filename, base_dir)
        if os.path.exists(legacy):
            return legacy
    return modern


def load_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        return None, exc
    return data, None


def scrub_sensitive_fields(value):
    if isinstance(value, dict):
        return {
            key: scrub_sensitive_fields(child)
            for key, child in value.items()
            if key not in SENSITIVE_FIELD_NAMES
        }
    if isinstance(value, list):
        return [scrub_sensitive_fields(item) for item in value]
    return value


def scrub_ai_settings_for_migration(value):
    data = scrub_sensitive_fields(value)
    if not isinstance(data, dict):
        return data
    for key in AI_SECRET_FIELD_NAMES:
        if key in data:
            data[key] = ""
    return data


def migrate_json_if_missing(filename, base_dir=None, scrubber=None, log=None):
    modern = runtime_path(filename, base_dir)
    if os.path.exists(modern):
        return modern, False
    if not base_dir:
        return modern, False
    legacy = legacy_path(filename, base_dir)
    if not os.path.exists(legacy):
        return modern, False

    data, error = load_json_file(legacy)
    if error or data is None:
        if log:
            log(f"Skipped legacy migration for {filename}: invalid JSON at {legacy}.")
        return modern, False
    if not isinstance(data, dict):
        if log:
            log(f"Skipped legacy migration for {filename}: expected a JSON object at {legacy}.")
        return modern, False

    scrubbed = scrubber(data) if scrubber else scrub_sensitive_fields(data)
    os.makedirs(os.path.dirname(modern), exist_ok=True)
    try:
        with open(modern, "w", encoding="utf-8") as handle:
            json.dump(scrubbed, handle, indent=4)
    except OSError as exc:
        if log:
            log(f"Could not migrate {filename} to {modern}: {exc}")
        return modern, False

    if log:
        log(f"Migrated legacy {filename} to app data. Original file was left untouched.")
    return modern, True

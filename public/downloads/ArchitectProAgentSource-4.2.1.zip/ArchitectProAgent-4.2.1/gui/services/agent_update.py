"""Verified in-place updates; the connection and user settings are never reset."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import urllib.parse
import urllib.request
from . import background_agent, portal_handoff, storage_paths

MAX_INSTALLER_BYTES = 150 * 1024 * 1024

def version_tuple(value):
    if not re.fullmatch(r"\d+\.\d+\.\d+", str(value)):
        raise portal_handoff.PortalHandoffError("The portal returned an invalid Agent version.")
    return tuple(int(part) for part in value.split('.'))

def release_metadata(portal_url=None):
    base = portal_handoff._normalise_portal_url(portal_url or portal_handoff.load_portal_url())
    url = base + '/api/desktop/releases/latest'
    with urllib.request.urlopen(url, timeout=30, context=portal_handoff._https_context(url)) as response:
        if urllib.parse.urlparse(response.geturl()).netloc != urllib.parse.urlparse(base).netloc:
            raise portal_handoff.PortalHandoffError("The update address changed unexpectedly.")
        data = json.loads(response.read(32_768).decode('utf-8'))
    return base, data

def validate_release(base, data):
    if data.get('status') != 'AVAILABLE':
        raise portal_handoff.PortalHandoffError("The latest Agent update is not available yet. Try again later.")
    version = data.get('version')
    version_tuple(version)
    digest = str(data.get('sha256') or '')
    size = data.get('sizeBytes')
    if not re.fullmatch(r'[a-fA-F0-9]{64}', digest) or type(size) is not int or not 0 < size <= MAX_INSTALLER_BYTES:
        raise portal_handoff.PortalHandoffError("The portal returned invalid update verification details.")
    url = urllib.parse.urljoin(base + '/', str(data.get('downloadUrl') or ''))
    parsed = urllib.parse.urlparse(url)
    trusted = urllib.parse.urlparse(base)
    if (parsed.scheme != trusted.scheme or parsed.netloc != trusted.netloc
        or parsed.username or parsed.password or parsed.query or parsed.fragment
        or parsed.path != f'/downloads/ArchitectProAgentSetup-{version}.exe'):
        raise portal_handoff.PortalHandoffError("The Agent update must come from this Architect Pro portal.")
    return url, version, digest.lower(), size

def download_update(portal_url=None, progress=lambda _message: None):
    base, data = release_metadata(portal_url)
    url, version, expected_hash, expected_size = validate_release(base, data)
    if version_tuple(version) <= version_tuple(background_agent.AGENT_VERSION):
        return None
    folder = Path(storage_paths.runtime_path('updates'))
    folder.mkdir(parents=True, exist_ok=True)
    destination = folder / f'ArchitectProAgentSetup-{version}.exe'
    partial = destination.with_suffix('.download')
    digest = hashlib.sha256()
    received = 0
    try:
        with urllib.request.urlopen(url, timeout=45, context=portal_handoff._https_context(url)) as response, partial.open('wb') as output:
            if urllib.parse.urlparse(response.geturl()).netloc != urllib.parse.urlparse(base).netloc:
                raise portal_handoff.PortalHandoffError("The update download changed address unexpectedly.")
            while chunk := response.read(1024 * 1024):
                received += len(chunk)
                if received > expected_size:
                    raise portal_handoff.PortalHandoffError("The Agent download is larger than expected. Try again.")
                digest.update(chunk)
                output.write(chunk)
                progress(f'Downloading Agent {version}: {round(received * 100 / expected_size)}%')
        if received != expected_size or digest.hexdigest() != expected_hash:
            raise portal_handoff.PortalHandoffError("The Agent download could not be verified. No update was installed; try again.")
        os.replace(partial, destination)
        return str(destination)
    finally:
        partial.unlink(missing_ok=True)

def launch_installer(path):
    # No uninstall, shell command, credentials or arbitrary installer arguments.
    return subprocess.Popen([str(path), '/VERYSILENT', '/SUPPRESSMSGBOXES', '/NORESTART',
                             '/CLOSEAPPLICATIONS', '/RESTARTAGENT=1'], close_fds=True)

import base64
import json
import os
import re
import socket
import ssl
import sys
import shutil
import urllib.error
import urllib.parse
import urllib.request

import certifi
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone

from . import portal_answers, storage_paths


DEFAULT_PORTAL_URL = "https://architectpro.co.uk"
TOKEN_CREDENTIAL_NAME = "architectpro-desktop-access"
TOKEN_SERVICE_NAME = "NinetyOneArchitects ArchitectPro"
JOB_TOKEN_PREFIX = "architectpro-job-"
JOB_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{8,120}$")
HANDOFF_CODE_PATTERN = re.compile(r"^aph_[A-Za-z0-9_-]{40,80}$")
JOB_CACHE_RETENTION_DAYS = 14
TERMINAL_CACHE_STATUSES = {"COMPLETED", "FAILED", "FAILED_FINAL", "CANCELLED"}
PLANNING_JOB_TYPES = {"HOUSEHOLDER_PLANNING", "PLANNING_APPLICATION"}
BUILDING_WARRANT_JOB_TYPE = "BUILDING_WARRANT"
CALCULATED_FEE_MINOR_UNITS_KEY = "Calculated Fee Minor Units"
MISSING_BUILDING_WARRANT_FEE_MESSAGE = (
    "The application fee could not be calculated because required fee information is missing. "
    "Review the relevant fee inputs in Architect Pro and start a fresh retry."
)
SUPPORTED_JOB_TYPES = PLANNING_JOB_TYPES | {BUILDING_WARRANT_JOB_TYPE}


def _site_address_value(address):
    address = address or {}
    line1 = str(address.get("addressLine1") or "").strip()
    line2 = str(address.get("addressLine2") or "").strip()
    building_number = re.match(r"^(\d+[A-Z]?)\b", line1, re.I)
    if building_number and line2.upper() == building_number.group(1).upper():
        line2 = ""
    return ", ".join(filter(None, [line1, line2, address.get("townCity"), address.get("postcode")]))


class PortalHandoffError(RuntimeError):
    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


@dataclass
class PortalJobState:
    snapshot_version: int
    form_values: dict = field(default_factory=dict)
    documents: list = field(default_factory=list)
    document_buckets: dict = field(default_factory=dict)
    blocking_issues: list = field(default_factory=list)
    review_issues: list = field(default_factory=list)


def _job_cache_root():
    return os.path.join(storage_paths.app_data_dir(), "jobs")


def _job_cache_metadata_path(job_id):
    return os.path.join(_job_cache_root(), str(job_id), "cache.json")


def record_job_cache_status(job_id, status):
    if not JOB_ID_PATTERN.fullmatch(str(job_id or "")):
        return False
    path = _job_cache_metadata_path(job_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(
            {
                "jobId": str(job_id),
                "status": str(status or "").upper(),
                "updatedAt": datetime.now(timezone.utc).isoformat(),
            },
            handle,
            indent=2,
        )
    return True


def cleanup_old_job_caches(now=None, retention_days=JOB_CACHE_RETENTION_DAYS, log=None):
    root = _job_cache_root()
    if not os.path.isdir(root):
        return []
    cutoff = (now or datetime.now(timezone.utc)) - timedelta(days=retention_days)
    removed = []
    for name in os.listdir(root):
        folder = os.path.join(root, name)
        metadata_path = os.path.join(folder, "cache.json")
        if not os.path.isdir(folder) or not os.path.isfile(metadata_path):
            continue
        try:
            with open(metadata_path, "r", encoding="utf-8") as handle:
                metadata = json.load(handle)
            status = str(metadata.get("status") or "").upper()
            updated_at = datetime.fromisoformat(str(metadata.get("updatedAt") or "").replace("Z", "+00:00"))
            if updated_at.tzinfo is None:
                updated_at = updated_at.replace(tzinfo=timezone.utc)
            if status in TERMINAL_CACHE_STATUSES and updated_at < cutoff:
                shutil.rmtree(folder)
                removed.append(name)
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            if log:
                log(f"Could not inspect cached job {name}: {exc}")
    return removed


def parse_automation_url(value):
    return parse_automation_launch(value)["job_id"]


def parse_automation_launch(value):
    if not value:
        return None
    try:
        parsed = urllib.parse.urlparse(str(value).strip())
    except ValueError as exc:
        raise PortalHandoffError("The ArchitectPro link is not valid.") from exc
    if parsed.scheme.lower() != "architectpro" or parsed.netloc.lower() != "automation":
        raise PortalHandoffError("This is not a valid ArchitectPro automation link.")
    path_parts = [part for part in parsed.path.strip("/").split("/") if part]
    job_id = path_parts[0] if path_parts else ""
    if not JOB_ID_PATTERN.fullmatch(job_id):
        raise PortalHandoffError("The automation job identifier is missing or invalid.")
    query = urllib.parse.parse_qs(parsed.query, strict_parsing=False)
    code = path_parts[1].strip() if len(path_parts) >= 2 else (query.get("code") or [""])[0].strip()
    portal_url = (query.get("portal") or [""])[0].strip()
    if len(path_parts) >= 3:
        try:
            encoded = path_parts[2] + ("=" * (-len(path_parts[2]) % 4))
            portal_url = base64.urlsafe_b64decode(encoded.encode("ascii")).decode("utf-8")
        except (ValueError, UnicodeDecodeError) as exc:
            raise PortalHandoffError("This desktop link contains an invalid web portal address.") from exc
    if not HANDOFF_CODE_PATTERN.fullmatch(code):
        raise PortalHandoffError("This desktop link is incomplete. Return to the portal and select Open in desktop app again.")
    if not portal_url:
        raise PortalHandoffError("This desktop link does not include the web portal address.")
    return {"job_id": job_id, "code": code, "portal_url": _normalise_portal_url(portal_url)}


def automation_url_from_args(args=None):
    for value in list(args if args is not None else sys.argv[1:]):
        if str(value).lower().startswith("architectpro:"):
            return str(value)
    return None


def is_login_settings_launch(value):
    try:
        parsed = urllib.parse.urlparse(str(value or ""))
    except ValueError:
        return False
    return (
        parsed.scheme.lower() == "architectpro"
        and parsed.netloc.lower() == "settings"
        and parsed.path.strip("/").lower() == "login"
        and not parsed.query
        and not parsed.fragment
    )


def is_agent_open_launch(value):
    try:
        parsed = urllib.parse.urlparse(str(value or ""))
    except ValueError:
        return False
    return (
        parsed.scheme.lower() == "architectpro"
        and parsed.netloc.lower() == "agent"
        and not parsed.path.strip("/")
        and not parsed.query
        and not parsed.fragment
    )


def is_agent_reconnect_launch(value):
    try:
        parsed = urllib.parse.urlparse(str(value or ""))
    except ValueError:
        return False
    return (
        parsed.scheme.lower() == "architectpro"
        and parsed.netloc.lower() == "reconnect"
        and not parsed.path.strip("/")
        and not parsed.query
        and not parsed.fragment
    )


def is_agent_update_launch(value):
    try:
        parsed = urllib.parse.urlparse(str(value or ""))
    except ValueError:
        return False
    return (parsed.scheme.lower() == "architectpro"
            and parsed.netloc.lower() == "update"
            and not parsed.path.strip("/") and not parsed.query and not parsed.fragment)


def is_agent_reset_launch(value):
    try:
        parsed = urllib.parse.urlparse(str(value or ""))
    except ValueError:
        return False
    return (parsed.scheme.lower() == "architectpro"
            and parsed.netloc.lower() == "reset-connection"
            and not parsed.path.strip("/") and not parsed.query and not parsed.fragment)


def register_protocol_handler():
    if os.name != "nt" or not getattr(sys, "frozen", False):
        return False
    try:
        import winreg

        command = f'"{os.path.abspath(sys.executable)}" "%1"'
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\architectpro") as key:
            winreg.SetValueEx(key, "", 0, winreg.REG_SZ, "URL:ArchitectPro Desktop")
            winreg.SetValueEx(key, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\architectpro\DefaultIcon") as key:
            winreg.SetValueEx(key, "", 0, winreg.REG_SZ, f'"{os.path.abspath(sys.executable)}",0')
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\architectpro\shell\open\command") as key:
            winreg.SetValueEx(key, "", 0, winreg.REG_SZ, command)
        return True
    except OSError:
        return False


def unregister_protocol_handler():
    if os.name != "nt":
        return False
    import winreg
    success = True
    for path in (
        r"Software\Classes\architectpro\shell\open\command",
        r"Software\Classes\architectpro\shell\open",
        r"Software\Classes\architectpro\shell",
        r"Software\Classes\architectpro\DefaultIcon",
        r"Software\Classes\architectpro",
    ):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, path)
        except FileNotFoundError:
            continue
        except OSError:
            success = False
    return success


def _normalise_portal_url(value):
    text = str(value or DEFAULT_PORTAL_URL).strip().rstrip("/")
    parsed = urllib.parse.urlparse(text)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
        raise PortalHandoffError("Enter a valid ArchitectPro portal address.")
    if parsed.scheme != "https" and parsed.hostname not in {"localhost", "127.0.0.1"}:
        raise PortalHandoffError("Desktop connections require HTTPS outside local development.")
    if parsed.hostname and parsed.hostname.lower() == "architectpro.co.uk":
        parsed = parsed._replace(netloc="www.architectpro.co.uk")
        text = urllib.parse.urlunparse(parsed).rstrip("/")
    return text


def _https_context(url):
    if urllib.parse.urlparse(url).scheme.lower() != "https":
        return None
    return ssl.create_default_context(cafile=certifi.where())


def _connection_error_message(exc):
    reason = getattr(exc, "reason", exc)
    detail = str(reason or "").strip()
    if isinstance(reason, ssl.SSLError) or "certificate" in detail.lower() or "ssl" in detail.lower():
        return "ArchitectPro Desktop could not establish a secure connection to the web portal. Close the app, reopen the latest build and try again."
    if detail:
        return f"ArchitectPro Desktop could not reach the web portal. Check your connection and try again. ({detail[:180]})"
    return "ArchitectPro Desktop could not reach the web portal. Check your connection and try again."


def load_portal_url():
    data, _ = storage_paths.load_json_file(storage_paths.runtime_path("portal_settings.json"))
    if isinstance(data, dict):
        try:
            return _normalise_portal_url(data.get("portal_url"))
        except PortalHandoffError:
            pass
    return DEFAULT_PORTAL_URL


def save_portal_url(value):
    portal_url = _normalise_portal_url(value)
    with open(storage_paths.runtime_path("portal_settings.json"), "w", encoding="utf-8") as handle:
        json.dump({"portal_url": portal_url}, handle, indent=2)
    return portal_url


def _keyring():
    try:
        import keyring
    except Exception as exc:
        raise PortalHandoffError("Windows Credential Manager support is unavailable on this device.") from exc
    return keyring


def get_access_token():
    try:
        return _keyring().get_password(TOKEN_SERVICE_NAME, TOKEN_CREDENTIAL_NAME) or ""
    except Exception as exc:
        raise PortalHandoffError("The desktop connection token could not be read from Windows Credential Manager.") from exc


def save_access_token(token):
    token = str(token or "").strip()
    if not token.startswith("apd_") or len(token) < 30:
        raise PortalHandoffError("Paste the complete desktop connection token from ArchitectPro Settings.")
    try:
        _keyring().set_password(TOKEN_SERVICE_NAME, TOKEN_CREDENTIAL_NAME, token)
    except Exception as exc:
        raise PortalHandoffError("The desktop connection token could not be saved securely.") from exc


def clear_access_token():
    try:
        _keyring().delete_password(TOKEN_SERVICE_NAME, TOKEN_CREDENTIAL_NAME)
    except Exception:
        pass


def _job_token_name(job_id):
    if not JOB_ID_PATTERN.fullmatch(str(job_id or "")):
        raise PortalHandoffError("The automation job identifier is invalid.")
    return f"{JOB_TOKEN_PREFIX}{job_id}"


def get_job_access_token(job_id):
    try:
        return _keyring().get_password(TOKEN_SERVICE_NAME, _job_token_name(job_id)) or ""
    except Exception as exc:
        raise PortalHandoffError("The saved desktop job access could not be read securely.") from exc


def save_job_access_token(job_id, token):
    token = str(token or "").strip()
    if not token.startswith("apd_"):
        raise PortalHandoffError("The web portal did not provide valid desktop job access.")
    try:
        _keyring().set_password(TOKEN_SERVICE_NAME, _job_token_name(job_id), token)
    except Exception as exc:
        raise PortalHandoffError("Desktop job access could not be saved securely.") from exc


def clear_job_access_token(job_id):
    try:
        _keyring().delete_password(TOKEN_SERVICE_NAME, _job_token_name(job_id))
    except Exception:
        pass


class PortalClient:
    def __init__(self, portal_url, token):
        self.portal_url = _normalise_portal_url(portal_url)
        self._token = str(token or "").strip()
        if not self._token:
            raise PortalHandoffError("ArchitectPro Desktop is not connected to the web portal.")

    @classmethod
    def from_handoff(cls, portal_url, job_id, code):
        portal_url = _normalise_portal_url(portal_url)
        url = urllib.parse.urljoin(f"{portal_url}/", "/api/desktop/handoff/exchange".lstrip("/"))
        body = json.dumps({"jobId": job_id, "code": code, "deviceName": socket.gethostname()}).encode("utf-8")
        request = urllib.request.Request(
            url,
            data=body,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=45, context=_https_context(url)) as response:
                result = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            try:
                result = json.loads(exc.read().decode("utf-8"))
                message = result.get("error") or "The portal rejected the desktop request."
            except Exception:
                message = "The portal rejected the desktop request."
            if exc.code in {401, 404, 409, 410}:
                message = "This desktop link has expired or was already used. Return to the web portal and select Open in desktop app again."
            raise PortalHandoffError(message) from exc
        except (urllib.error.URLError, TimeoutError, socket.timeout) as exc:
            raise PortalHandoffError(_connection_error_message(exc)) from exc
        except (ValueError, TypeError) as exc:
            raise PortalHandoffError("The web portal returned an invalid desktop handoff response.") from exc

        token = str(result.get("accessToken") or "").strip()
        if not token.startswith("apd_"):
            raise PortalHandoffError("The web portal did not provide valid access to this automation job.")
        save_portal_url(portal_url)
        save_job_access_token(job_id, token)
        return cls(portal_url, token)

    def _request(self, path, method="GET", payload=None, binary=False, include_headers=False):
        url = urllib.parse.urljoin(f"{self.portal_url}/", path.lstrip("/"))
        headers = {"Authorization": f"Bearer {self._token}", "Accept": "application/octet-stream" if binary else "application/json"}
        body = None
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(url, data=body, headers=headers, method=method)
        try:
            with urllib.request.urlopen(request, timeout=45, context=_https_context(url)) as response:
                data = response.read()
                if binary:
                    return (data, dict(response.headers.items())) if include_headers else data
                return json.loads(data.decode("utf-8")) if data else {}
        except urllib.error.HTTPError as exc:
            try:
                data = json.loads(exc.read().decode("utf-8"))
                message = data.get("error") or "The portal rejected the desktop request."
            except Exception:
                message = "The portal rejected the desktop request."
            if exc.code == 401:
                raise PortalHandoffError("Desktop access has expired or been revoked. Reconnect this device in portal Settings.", exc.code) from exc
            raise PortalHandoffError(message, exc.code) from exc
        except (urllib.error.URLError, TimeoutError, socket.timeout) as exc:
            raise PortalHandoffError(_connection_error_message(exc)) from exc

    def claim_job(self, job_id):
        return self._request(f"/api/desktop/automation-jobs/{job_id}/claim", "POST", {"deviceName": socket.gethostname()})

    def get_job(self, job_id):
        return self._request(f"/api/desktop/automation-jobs/{job_id}").get("job")

    def update_status(self, job_id, status, result_summary="", error=""):
        payload = {"status": status}
        if result_summary:
            payload["resultSummary"] = str(result_summary)[:1000]
        if error:
            payload["error"] = str(error)[:500]
        result = self._request(f"/api/desktop/automation-jobs/{job_id}", "PATCH", payload)
        record_job_cache_status(job_id, status)
        return result

    def send_callback(self, job_id, payload):
        result = self._request(f"/api/desktop/automation-jobs/{job_id}", "PATCH", payload)
        record_job_cache_status(job_id, result.get("status"))
        return result

    def send_progress(self, job_id, payload):
        return self._request(
            f"/api/desktop/automation-jobs/{job_id}/progress",
            "POST",
            payload,
        )

    def correct_address_and_restart(self, job_id, postcode):
        return self._request(
            f"/api/desktop/automation-jobs/{job_id}/correct-address",
            "POST",
            {"postcode": str(postcode or "").strip()},
        )

    def download_documents(self, job):
        folder = os.path.join(storage_paths.app_data_dir(), "jobs", job["id"], "documents")
        os.makedirs(folder, exist_ok=True)
        downloaded = []
        failures = []
        used_names = set()
        for document in job.get("documents") or []:
            try:
                data, response_headers = self._request(
                    document["downloadUrl"],
                    binary=True,
                    include_headers=True,
                )
                original = safe_local_filename(
                    document.get("originalFilename")
                    or document.get("originalName")
                    or document.get("fileName")
                    or document.get("filename")
                    or filename_from_content_disposition(
                        response_headers.get("Content-Disposition")
                        or response_headers.get("content-disposition")
                    )
                    or "document.pdf"
                )
                if (
                    str(document.get("mimeType") or "").lower() == "application/pdf"
                    and not original.lower().endswith(".pdf")
                ):
                    original = f"{original}.pdf"
                filename = unique_filename(original, used_names)
                target = os.path.join(folder, filename)
                with open(target, "wb") as handle:
                    handle.write(data)
                downloaded.append({
                    **document,
                    "originalName": original,
                    "type": normalise_document_category(
                        document.get("categoryKey")
                        or document.get("type")
                        or document.get("categoryLabel")
                    ),
                    "status": document.get("status") or document.get("reviewState"),
                    "localPath": target,
                    "localName": filename,
                })
            except (OSError, PortalHandoffError, KeyError) as exc:
                name = (
                    document.get("originalFilename")
                    or document.get("originalName")
                    or document.get("fileName")
                    or document.get("filename")
                    or document.get("id")
                    or "Unknown document"
                )
                failures.append({"name": str(name), "error": str(exc)})
        record_job_cache_status(job["id"], job.get("status") or "CLAIMED")
        return downloaded, failures


def safe_local_filename(value):
    raw = str(value or "document.pdf").replace("\x00", "").replace("\\", "/")
    filename = os.path.basename(raw)
    filename = re.sub(r"[<>:\"/\\|?*\r\n]", "_", filename).strip(" .")
    return filename[:180] or "document.pdf"


def filename_from_content_disposition(value):
    value = str(value or "")
    encoded = re.search(r"filename\*=UTF-8''([^;]+)", value, flags=re.IGNORECASE)
    if encoded:
        return urllib.parse.unquote(encoded.group(1).strip())
    quoted = re.search(r'filename="([^"]+)"', value, flags=re.IGNORECASE)
    if quoted:
        return quoted.group(1).strip()
    plain = re.search(r"filename=([^;]+)", value, flags=re.IGNORECASE)
    return plain.group(1).strip() if plain else ""


def unique_filename(filename, used):
    stem, extension = os.path.splitext(filename)
    candidate = filename
    index = 2
    while candidate.lower() in used:
        candidate = f"{stem} ({index}){extension}"
        index += 1
    used.add(candidate.lower())
    return candidate


def split_name(full_name):
    parts = str(full_name or "").strip().split()
    return (parts[0], " ".join(parts[1:])) if parts else ("", "")


def infer_profile(project_type):
    value = re.sub(r"[_-]+", " ", str(project_type or "").strip().lower())
    if "demol" in value:
        return portal_answers.DEMOLITION_PROFILE
    if "convert" in value or "change of use" in value:
        return portal_answers.CONVERSION_PROFILE
    if "new build" in value:
        return portal_answers.NEW_BUILD_PROFILE
    return portal_answers.DOMESTIC_PROFILE


def _warrant_profiles(project, warrant):
    labels = warrant.get("typeOfWorkLabels")
    keys = warrant.get("typeOfWorkKeys")
    candidates = labels if isinstance(labels, list) and labels else keys
    if isinstance(candidates, list) and candidates:
        return portal_answers.normalise_profiles([infer_profile(value) for value in candidates])
    project_type = project.get("typeOfWorkKey") or project.get("typeOfWorkLabel")
    fallback = project_type or warrant.get("presetKey") or warrant.get("presetLabel")
    return [infer_profile(fallback)]


def _yes_no(value):
    return "Yes" if value is True else "No"


def _set_if_present(values, key, value):
    if value not in (None, ""):
        values[key] = value


def _calculated_building_warrant_fee_minor_units(snapshot):
    calculation = ((snapshot.get("buildingWarrant") or {}).get("feeCalculation") or {})
    value = calculation.get("totalFeeMinorUnits")
    if (
        calculation.get("calculationStatus") == "CALCULATED"
        and isinstance(calculation.get("scheduleVersion"), str)
        and calculation.get("scheduleVersion").strip()
        and isinstance(value, int)
        and not isinstance(value, bool)
        and value >= 0
    ):
        return value
    return None


def normalise_document_category(value):
    token = re.sub(r"[^A-Z0-9]+", "_", str(value or "").strip().upper()).strip("_")
    aliases = {
        "LOCATION": "LOCATION_PLAN",
        "LOCATION_PLANS": "LOCATION_PLAN",
        "SITE_PLANS": "SITE_PLAN",
        "BLOCK_PLANS": "BLOCK_PLAN",
        "PROPOSED": "PROPOSED_DRAWING",
        "PROPOSED_PLAN": "PROPOSED_DRAWING",
        "PROPOSED_PLANS": "PROPOSED_DRAWING",
        "PROPOSED_DRAWINGS": "PROPOSED_DRAWING",
        "EXISTING": "EXISTING_DRAWING",
        "EXISTING_PLAN": "EXISTING_DRAWING",
        "EXISTING_PLANS": "EXISTING_DRAWING",
        "EXISTING_DRAWINGS": "EXISTING_DRAWING",
        "ELEVATIONS": "ELEVATION",
        "SECTIONS": "SECTION",
        "DETAIL": "DETAILS",
        "CALCULATION": "CALCULATIONS",
        "SPECIFICATION": "SPECIFICATIONS",
        "PHOTOS": "PHOTO",
        "SUPPORTING": "SUPPORTING_DOCUMENT",
        "SUPPORTING_DOCUMENTS": "SUPPORTING_DOCUMENT",
    }
    return aliases.get(token, token or "OTHER")


def _validate_snapshot_v2(job, snapshot):
    if snapshot.get("contractVersion") != "architectpro.automation-job":
        raise PortalHandoffError("This automation job uses an unsupported portal contract.")
    if snapshot.get("snapshotVersion") != 2:
        raise PortalHandoffError(
            f"This version of ArchitectPro Desktop cannot open snapshot version "
            f"{snapshot.get('snapshotVersion')!r}. Install the latest desktop app."
        )
    metadata = snapshot.get("metadata")
    if not isinstance(metadata, dict) or metadata.get("jobId") != job.get("id"):
        raise PortalHandoffError("This automation job failed its identity check.")
    job_type = str(job.get("type") or "").strip()
    snapshot_type = str(metadata.get("applicationType") or "").strip()
    if job_type not in SUPPORTED_JOB_TYPES or snapshot_type not in SUPPORTED_JOB_TYPES:
        raise PortalHandoffError(
            "This desktop job is missing its application type and cannot be opened safely."
        )
    if snapshot_type != job_type:
        raise PortalHandoffError(
            "The portal job and application type do not match. Return to Architect Pro and prepare the job again."
        )
    project_id = str(job.get("projectId") or "").strip()
    snapshot_project_id = str(metadata.get("projectId") or "").strip()
    if not project_id or snapshot_project_id != project_id:
        raise PortalHandoffError("This automation job failed its Project identity check.")
    planning_id = str((snapshot.get("planning") or {}).get("recordId") or "").strip()
    warrant_id = str((snapshot.get("buildingWarrant") or {}).get("recordId") or "").strip()
    if job_type == BUILDING_WARRANT_JOB_TYPE:
        application_id, conflicting_id = warrant_id, planning_id
    else:
        application_id, conflicting_id = planning_id, warrant_id
    if not application_id or conflicting_id:
        raise PortalHandoffError(
            "This desktop job is missing its exact application record and cannot be opened safely."
        )
    for required in ("organisation", "project", "site", "applicant", "documents", "preflight"):
        if required not in snapshot:
            raise PortalHandoffError(f"This automation job is incomplete: {required} is missing.")
    if not isinstance(snapshot.get("documents"), list):
        raise PortalHandoffError("This automation job contains invalid document data.")


def _portal_job_v1_to_values(job, snapshot):
    snapshot = job.get("dataSnapshot") or {}
    project = snapshot.get("project") or {}
    client = snapshot.get("client") or {}
    site = snapshot.get("site") or {}
    planning = snapshot.get("planningApplication") or {}
    warrant = snapshot.get("buildingWarrantApplication") or {}
    application_questions = snapshot.get("applicationQuestions") or {}
    first_name, last_name = split_name(client.get("name"))
    description = project.get("notes") or planning.get("notes") or warrant.get("notes") or ""
    is_householder = job.get("type") in PLANNING_JOB_TYPES
    values = {
        portal_answers.APPLICATION_TYPE_KEY: (
            portal_answers.HOUSEHOLDER_TYPE
            if is_householder
            else portal_answers.BUILDING_WARRANT_TYPE
        ),
        "Description of Work": description,
        "Applicant First Name": first_name,
        "Applicant Last Name": last_name,
        "Applicant Email": client.get("email") or "",
        "Applicant Mobile Number": client.get("phone") or "",
        "Applicant Address 1": client.get("address") or site.get("addressLine1") or project.get("siteAddress") or "",
        "Applicant Town/City": site.get("townCity") or "",
        "Applicant Postcode": site.get("postcode") or "",
        "Applicant Country": "United Kingdom",
        "Site Address": _site_address_value(site) or project.get("siteAddress") or "",
        "Site Postcode": site.get("postcode") or "",
        "Automation Job ID": job.get("id") or "",
        "Project ID": job.get("projectId") or project.get("id") or "",
        "Application Record ID": planning.get("id") or warrant.get("id") or "",
    }
    if is_householder:
        values.update({
            key: value
            for key, value in application_questions.items()
            if str(key).startswith("Householder ")
        })
    else:
        profile = application_questions.get(portal_answers.PROFILE_KEY)
        if profile not in portal_answers.PROFILES:
            profile = infer_profile(project.get("projectType"))
        proposed_work = {
            portal_answers.CONVERSION_PROFILE: "Convert",
            portal_answers.DEMOLITION_PROFILE: "Demolish",
        }.get(profile, "Construct")
        values[portal_answers.PROFILE_KEY] = profile
        values["Proposed Work"] = proposed_work
        values.update(application_questions)
    return {key: value for key, value in values.items() if value not in (None, "")}


def _portal_job_v2_to_values(job, snapshot):
    _validate_snapshot_v2(job, snapshot)
    organisation = snapshot.get("organisation") or {}
    agent = organisation.get("agent") or {}
    agent_address = agent.get("address") or {}
    project = snapshot.get("project") or {}
    site = snapshot.get("site") or {}
    site_address = site.get("address") or {}
    applicant = snapshot.get("applicant") or {}
    applicant_address = applicant.get("address") or {}
    planning = snapshot.get("planning") or {}
    warrant = snapshot.get("buildingWarrant") or {}
    job_type = (snapshot.get("metadata") or {}).get("applicationType")

    values = {
        portal_answers.APPLICATION_TYPE_KEY: (
            portal_answers.HOUSEHOLDER_TYPE
            if job_type in PLANNING_JOB_TYPES
            else portal_answers.BUILDING_WARRANT_TYPE
        ),
        "Site Address": _site_address_value(site_address),
        "Site Postcode": site_address.get("postcode") or "",
        "Automation Job ID": job.get("id") or "",
        "Project ID": (snapshot.get("metadata") or {}).get("projectId") or "",
        "Application Record ID": (
            planning.get("recordId") if job_type in PLANNING_JOB_TYPES else warrant.get("recordId")
        ) or "",
    }
    if job_type in PLANNING_JOB_TYPES:
        fee_minor_units = planning.get("feeMinorUnits")
        if isinstance(fee_minor_units, int) and not isinstance(fee_minor_units, bool) and 0 <= fee_minor_units <= 999999999:
            values[CALCULATED_FEE_MINOR_UNITS_KEY] = fee_minor_units
    if job_type not in PLANNING_JOB_TYPES:
        profiles = _warrant_profiles(project, warrant)
        values[portal_answers.PROFILE_KEY] = profiles[0]
        values[portal_answers.TYPE_OF_WORKS_KEY] = " | ".join(profiles)
        values["Proposed Work"] = portal_answers.proposed_work_for_profiles(profiles)
        fee_minor_units = _calculated_building_warrant_fee_minor_units(snapshot)
        if fee_minor_units is not None:
            values[CALCULATED_FEE_MINOR_UNITS_KEY] = fee_minor_units

    for key, value in {
        "Agent First Name": agent.get("firstName"),
        "Agent Last Name": agent.get("lastName"),
        "Agent Telephone Number": agent.get("phone"),
        "Agent Email Address": agent.get("email"),
        "Agent Building Number": agent.get("buildingNumber"),
        "Agent Address 1": agent_address.get("addressLine1"),
        "Agent Town/City": agent_address.get("townCity"),
        "Agent Country": agent_address.get("country"),
        "Agent Postcode": agent_address.get("postcode"),
        "Applicant Title": applicant.get("title"),
        "Applicant Other Title": applicant.get("otherTitle"),
        "Applicant First Name": applicant.get("firstName"),
        "Applicant Last Name": applicant.get("lastName"),
        "Applicant Mobile Number": applicant.get("phone"),
        "Applicant Email": applicant.get("email"),
        "Applicant Building Number": applicant.get("buildingNumber"),
        "Applicant Address 1": applicant_address.get("addressLine1") or site_address.get("addressLine1"),
        "Applicant Town/City": applicant_address.get("townCity") or site_address.get("townCity"),
        "Applicant Country": applicant_address.get("country") or site_address.get("country") or "United Kingdom",
        "Applicant Postcode": applicant_address.get("postcode") or site_address.get("postcode"),
        "Applicant Company": applicant.get("companyName"),
    }.items():
        _set_if_present(values, key, value)

    if job_type in PLANNING_JOB_TYPES:
        _set_if_present(values, "Description of Work", planning.get("description"))
        answers = planning.get("answers") or {}
        values.update({
            "Householder Discussed With Planning Authority": _yes_no(
                answers.get("discussedWithPlanningAuthority")
            ),
            "Householder Trees On Site": _yes_no(answers.get("treesOnOrAdjacentToSite")),
            "Householder New Or Altered Vehicle Access": _yes_no(
                answers.get("newOrAlteredVehicleAccess")
            ),
        })
        if answers.get("soleOwner") is not None:
            values["Householder Sole Owner"] = _yes_no(answers.get("soleOwner"))
        if answers.get("agriculturalHolding") is not None:
            values["Householder Agricultural Holding"] = _yes_no(
                answers.get("agriculturalHolding")
            )
        _set_if_present(
            values,
            "Householder Current Parking Spaces",
            answers.get("currentParkingSpaces"),
        )
        _set_if_present(
            values,
            "Householder Proposed Parking Spaces",
            answers.get("proposedParkingSpaces"),
        )
    else:
        _set_if_present(values, "Description of Work", warrant.get("description"))
        _set_if_present(values, "Estimated Work Value", warrant.get("estimatedValue"))
        _set_if_present(values, "Current Use", warrant.get("currentUse"))
        _set_if_present(values, "Proposed Use", warrant.get("proposedUse"))
        unusual = warrant.get("unusualAnswers") or {}
        values.update({
            "Applicant Is Owner": _yes_no(unusual.get("applicantIsOwner")),
            "Application Staged": _yes_no(unusual.get("applicationIsStaged")),
            "Limited Life Building": _yes_no(unusual.get("intendedLifeFiveYearsOrLess")),
            "Fire Rescue Enforcing Authority": _yes_no(
                unusual.get("fireAndRescueServiceEnforcingAuthority")
            ),
            "Listed Or Conservation Area": _yes_no(
                unusual.get("listedBuildingOrConservationArea")
            ),
            "Other Historical Importance": _yes_no(
                unusual.get("otherHistoricalImportance")
            ),
            "Relaxation Direction": _yes_no(
                unusual.get("scottishMinistersRelaxationDirection")
            ),
            "Dangerous Building Notice": _yes_no(
                unusual.get("dangerousBuildingNotice")
            ),
            "Approved Certifier Construction": _yes_no(
                unusual.get("approvedCertifierOfConstruction")
            ),
            "STAS": _yes_no(unusual.get("coveredBySTAS")),
            "Public Inspection Restricted": _yes_no(
                unusual.get("restrictPublicInspection")
            ),
        })
        certifier = warrant.get("certifier") or {}
        for key, value in {
            "Scheme Type": certifier.get("schemeType"),
            "Registration Number (A) Part 1": certifier.get("registrationAPart1"),
            "Registration Number (A) Part 2": certifier.get("registrationAPart2"),
            "Name of Certifier": certifier.get("certifierName") or certifier.get("displayName"),
            "Registration Number (B) Part 1": certifier.get("registrationBPart1"),
            "Registration Number (B) Part 2": certifier.get("registrationBPart2"),
            "Name of Approved Body": certifier.get("approvedBody"),
        }.items():
            _set_if_present(values, key, value)

    return values


def validate_portal_job(job):
    snapshot = job.get("dataSnapshot") or {}
    if snapshot.get("contractVersion") or "snapshotVersion" in snapshot:
        _validate_snapshot_v2(job, snapshot)
        return 2
    if snapshot.get("schemaVersion") not in (None, 1):
        raise PortalHandoffError(
            "This automation job uses a legacy snapshot version that this desktop app cannot open."
        )
    job_type = str(job.get("type") or "").strip()
    if job_type not in SUPPORTED_JOB_TYPES:
        raise PortalHandoffError(
            "This desktop job is missing its application type and cannot be opened safely."
        )
    planning_id = str((snapshot.get("planningApplication") or {}).get("id") or "").strip()
    warrant_id = str((snapshot.get("buildingWarrantApplication") or {}).get("id") or "").strip()
    application_id = warrant_id if job_type == BUILDING_WARRANT_JOB_TYPE else planning_id
    conflicting_id = planning_id if job_type == BUILDING_WARRANT_JOB_TYPE else warrant_id
    if not application_id or conflicting_id:
        raise PortalHandoffError(
            "This legacy desktop job has ambiguous application identity and cannot be opened safely."
        )
    return 1


def application_type_from_job(job):
    validate_portal_job(job)
    job_type = str(job.get("type") or "").strip()
    if job_type in PLANNING_JOB_TYPES:
        return portal_answers.HOUSEHOLDER_TYPE
    if job_type == BUILDING_WARRANT_JOB_TYPE:
        return portal_answers.BUILDING_WARRANT_TYPE
    raise PortalHandoffError(
        "This desktop job is missing its application type and cannot be opened safely."
    )


def application_identity_from_job(job):
    snapshot = job.get("dataSnapshot") or {}
    version = validate_portal_job(job)
    if version == 2:
        metadata = snapshot.get("metadata") or {}
        application_type = metadata.get("applicationType")
        application_id = (
            (snapshot.get("buildingWarrant") or {}).get("recordId")
            if application_type == BUILDING_WARRANT_JOB_TYPE
            else (snapshot.get("planning") or {}).get("recordId")
        )
        project_id = metadata.get("projectId")
    else:
        application_type = job.get("type")
        application_id = (
            (snapshot.get("buildingWarrantApplication") or {}).get("id")
            if application_type == BUILDING_WARRANT_JOB_TYPE
            else (snapshot.get("planningApplication") or {}).get("id")
        )
        project_id = job.get("projectId") or (snapshot.get("project") or {}).get("id")
    return {
        "job_id": job.get("id"),
        "project_id": project_id,
        "application_type": application_type,
        "application_id": application_id,
        "snapshot_version": version,
        "selected_automation": (
            "BUILDING_WARRANT"
            if application_type == BUILDING_WARRANT_JOB_TYPE
            else "PLANNING"
        ),
    }


def portal_job_to_values(job):
    snapshot = job.get("dataSnapshot") or {}
    snapshot_version = validate_portal_job(job)
    if snapshot_version == 2:
        return _portal_job_v2_to_values(job, snapshot)
    return _portal_job_v1_to_values(job, snapshot)


def document_bucket_map(documents):
    buckets = {key: [] for key in ["location_plan", "proposed", "existing", "elevations", "sections", "details", "calcs", "specs", "photos", "other"]}
    for item in documents:
        item["type"] = normalise_document_category(
            item.get("categoryKey") or item.get("type") or item.get("categoryLabel")
        )
    true_locations = [item for item in documents if item.get("type") == "LOCATION_PLAN" and item.get("localPath", "").lower().endswith(".pdf")]
    fallbacks = [item for item in documents if item.get("type") in {"SITE_PLAN", "BLOCK_PLAN"} and item.get("localPath", "").lower().endswith(".pdf")]
    selected_location = (true_locations or fallbacks)[:1]
    if selected_location:
        buckets["location_plan"].append(selected_location[0]["localName"])
    selected_id = selected_location[0].get("id") if selected_location else None
    mapping = {
        "PROPOSED_DRAWING": "proposed", "EXISTING_DRAWING": "existing", "ELEVATION": "elevations",
        "SECTION": "sections", "DETAILS": "details", "CALCULATIONS": "calcs",
        "STRUCTURAL": "calcs", "ENERGY": "calcs", "SPECIFICATIONS": "specs",
        "DRAINAGE": "specs", "CERTIFICATE": "specs", "PHOTO": "photos",
    }
    for item in documents:
        if not item.get("localPath", "").lower().endswith(".pdf") or item.get("id") == selected_id:
            continue
        bucket = mapping.get(item.get("type"), "other")
        buckets[bucket].append(item["localName"])
    return buckets


def normalise_portal_job(job, downloaded_documents=None, download_failures=None):
    snapshot_version = validate_portal_job(job)
    values = portal_job_to_values(job)
    documents = list(downloaded_documents or [])
    failures = list(download_failures or [])
    buckets = document_bucket_map(documents)
    blocking = [
        f"Document download failed: {item.get('name') or 'Unknown document'}"
        for item in failures
    ]
    snapshot = job.get("dataSnapshot") or {}
    if (
        snapshot_version == 2
        and str(job.get("type") or "").strip() == BUILDING_WARRANT_JOB_TYPE
        and _calculated_building_warrant_fee_minor_units(snapshot) is None
    ):
        blocking.append(MISSING_BUILDING_WARRANT_FEE_MESSAGE)
    if str(job.get("type") or "").strip() in PLANNING_JOB_TYPES and CALCULATED_FEE_MINOR_UNITS_KEY not in values:
        blocking.append("Enter the planning application fee in Architect Pro and prepare a fresh attempt.")
    review = []
    supported = {
        "LOCATION_PLAN", "SITE_PLAN", "BLOCK_PLAN", "PROPOSED_DRAWING",
        "EXISTING_DRAWING", "ELEVATION", "SECTION", "DETAILS", "CALCULATIONS",
        "STRUCTURAL", "ENERGY", "SPECIFICATIONS", "DRAINAGE", "CERTIFICATE",
        "PHOTO", "SUPPORTING_DOCUMENT", "CORRESPONDENCE", "OTHER",
    }
    for document in documents:
        category = normalise_document_category(document.get("type"))
        if category not in supported:
            review.append(
                f"{document.get('localName') or document.get('originalName') or 'Document'} "
                f"has unsupported category {category!r} and was placed in Other."
            )
    return PortalJobState(
        snapshot_version=snapshot_version,
        form_values=values,
        documents=documents,
        document_buckets=buckets,
        blocking_issues=blocking,
        review_issues=review,
    )


def build_review_summary(job, values, buckets, failures):
    snapshot = job.get("dataSnapshot") or {}
    if snapshot.get("snapshotVersion") == 2:
        project = snapshot.get("project") or {}
        site = snapshot.get("site") or {}
        address_data = site.get("address") or {}
        applicant = snapshot.get("applicant") or {}
        preflight = snapshot.get("preflight") or {}
        address = ", ".join(filter(None, [
            address_data.get("addressLine1"),
            address_data.get("addressLine2"),
            address_data.get("townCity"),
            address_data.get("postcode"),
        ])) or "Not provided"
        missing = [
            item.get("message") or item.get("field") or "Incomplete portal field"
            for item in preflight.get("missing") or []
        ]
        if failures:
            missing.append(f"{len(failures)} document download(s) failed")
        lines = [
            f"Project: {project.get('name') or job.get('title') or 'Untitled project'}",
            f"Site: {address}",
            f"Application: {values.get(portal_answers.APPLICATION_TYPE_KEY, 'Not set')}",
            f"Applicant: {applicant.get('displayName') or 'Not provided'}",
            f"Description: {values.get('Description of Work') or 'Not provided'}",
            f"Portal preflight: {preflight.get('status') or 'Not checked'}",
            "",
            "Documents:",
        ]
        labels = {
            "location_plan": "Location Plan",
            "proposed": "Proposed Plans",
            "existing": "Existing Plans",
            "elevations": "Elevations",
            "sections": "Sections",
            "details": "Details",
            "calcs": "Calculations",
            "specs": "Specifications / Reports",
            "photos": "Photos",
            "other": "Other",
        }
        lines.extend(
            f"  {labels[key]}: {len(names)}"
            for key, names in buckets.items()
            if names
        )
        if failures:
            lines.extend(
                ["", "Failed downloads:"]
                + [f"  {item['name']}: {item['error']}" for item in failures]
            )
        warnings = preflight.get("warnings") or []
        if warnings:
            lines.extend(
                ["", "Warnings:"]
                + [
                    f"  {item.get('message') or item.get('field') or 'Review required'}"
                    for item in warnings
                ]
            )
        if missing:
            lines.extend(["", "Needs review:"] + [f"  {item}" for item in missing])
        return "\n".join(lines), missing

    project = snapshot.get("project") or {}
    site = snapshot.get("site") or {}
    client = snapshot.get("client") or {}
    address = ", ".join(filter(None, [site.get("addressLine1"), site.get("addressLine2"), site.get("townCity"), site.get("postcode")])) or project.get("siteAddress") or "Not provided"
    missing = []
    if not client.get("name"):
        missing.append("Applicant name")
    if not client.get("email"):
        missing.append("Applicant email")
    if not values.get("Description of Work"):
        missing.append("Description of work")
    if not buckets.get("location_plan"):
        missing.append("Location Plan")
    if not values.get("Email"):
        missing.append("Portal login email")
    lines = [
        f"Project: {project.get('name') or job.get('title') or 'Untitled project'}",
        f"Site: {address}",
        f"Application: {values.get(portal_answers.APPLICATION_TYPE_KEY, 'Not set')}",
        f"Applicant: {client.get('name') or 'Not provided'}",
        f"Description: {values.get('Description of Work') or 'Not provided'}",
        "",
        "Documents:",
    ]
    labels = {"location_plan": "Location Plan", "proposed": "Proposed Plans", "existing": "Existing Plans", "elevations": "Elevations", "sections": "Sections", "details": "Details", "calcs": "Calculations", "specs": "Specifications / Reports", "photos": "Photos", "other": "Other"}
    lines.extend(f"  {labels[key]}: {len(names)}" for key, names in buckets.items() if names)
    if failures:
        lines.extend(["", "Failed downloads:"] + [f"  {item['name']}: {item['error']}" for item in failures])
    if missing:
        lines.extend(["", "Needs review:"] + [f"  {item}" for item in missing])
    return "\n".join(lines), missing

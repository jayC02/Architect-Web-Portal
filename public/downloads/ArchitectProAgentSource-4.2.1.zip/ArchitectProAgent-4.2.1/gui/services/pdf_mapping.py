import json
import os
import re
import warnings
import logging

from PyPDF2 import PdfReader
from PySide6.QtWidgets import QMessageBox
from PySide6.QtCore import Qt

from . import storage_paths


FILENAME_ROLE = Qt.UserRole + 1
CONFIDENCE_ROLE = Qt.UserRole + 2


def read_pdf_first_page_text(pdf_path, log):
    try:
        with open(pdf_path, "rb") as handle:
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message=r".*Multiple definitions in dictionary.*")
                loggers = [logging.getLogger("PyPDF2"), logging.getLogger("PyPDF2._reader")]
                levels = [logger.level for logger in loggers]
                for logger in loggers:
                    logger.setLevel(logging.ERROR)
                try:
                    reader = PdfReader(handle)
                    if reader.is_encrypted:
                        try:
                            reader.decrypt("")
                        except Exception:
                            log(f"Autosort warning: could not decrypt {os.path.basename(pdf_path)}.")
                            return ""
                    return reader.pages[0].extract_text() if reader.pages else ""
                finally:
                    for logger, level in zip(loggers, levels):
                        logger.setLevel(level)
    except Exception as exc:
        log(f"Autosort warning: could not read {os.path.basename(pdf_path)}. Error: {exc}")
        return ""


def normalise(text):
    return re.sub(r"\s+", " ", (text or "").lower().replace("&", " and ")).strip()


def score_pdf(base_folder, filename, log):
    pdf_text = normalise(read_pdf_first_page_text(os.path.join(base_folder, filename), log))
    name = normalise(os.path.splitext(filename)[0])
    text = f"{name} {pdf_text}"
    fallback_rules = [
        ("location_plan_fallback", 86, ["site plan", "block plan"]),
    ]
    rules = [
        ("location_plan", 110, ["site location plan", "location plan", "ordnance survey", "ukplanningmaps"]),
        ("proposed", 90, ["proposed plans", "proposed plan", "floor plan as proposed", "proposed floor"]),
        ("existing", 90, ["existing plans", "existing plan", "existing elevations"]),
        ("elevations", 85, ["elevations", "elevation"]),
        ("sections", 85, ["sections", "section"]),
        ("details", 80, ["details", "detail", "typical detail"]),
        ("calcs", 80, ["u-value", "u value", "sap", "structural", "calculation", "calculations"]),
        ("specs", 80, ["specification", "report", "statement", "ser"]),
        ("photos", 75, ["photo", "photos", "image", "pic"]),
    ]
    best = (None, 0, "no usable filename/PDF text match")
    for bucket, points, phrases in rules + fallback_rules:
        for phrase in phrases:
            if phrase in text:
                score = points + (20 if phrase in name else 0)
                if score > best[1]:
                    best = (bucket, score, f"matched '{phrase}'")
                break
    bucket, score, reason = best
    if score >= 100:
        return bucket, "High", reason
    if score >= 80:
        return bucket, "Medium", reason
    if score > 0:
        return bucket, "Low", reason
    return None, "Low", reason


def list_items(list_widget):
    return [
        list_widget.item(i).data(FILENAME_ROLE) or list_widget.item(i).text()
        for i in range(list_widget.count())
    ]


def find_item_by_filename(list_widget, filename):
    for row in range(list_widget.count()):
        item = list_widget.item(row)
        if (item.data(FILENAME_ROLE) or item.text()) == filename:
            return item
    return None


def build_snapshot(pdf_folder_path, bucket_lists):
    bucket_map = {key: tuple(list_items(widget)) for key, widget in bucket_lists.items()}
    return (pdf_folder_path, tuple(sorted(bucket_map.items())))


def save_mapping(parent, script_dir, pdf_folder_path, bucket_defs, bucket_lists):
    if not pdf_folder_path:
        QMessageBox.warning(parent, "No PDFs", "Select PDFs first.")
        return None
    mapping = {
        "pdf_folder_path": pdf_folder_path,
        "buckets": {},
        "bucket_labels": {},
    }
    for key, label, required, max_files in bucket_defs:
        mapping["buckets"][key] = list_items(bucket_lists[key])
        mapping["bucket_labels"][key] = label
    for key, label, required, max_files in bucket_defs:
        if required and max_files is not None and len(mapping["buckets"][key]) != max_files:
            QMessageBox.warning(parent, "Missing required document", f"'{label}' must contain exactly {max_files} file(s).")
            return None
    out_path = storage_paths.runtime_path("supporting_docs.json", script_dir)
    with open(out_path, "w", encoding="utf-8") as handle:
        json.dump(mapping, handle, indent=2)
    return out_path


def autosort_pdfs(pdf_folder_path, inbox_list, bucket_lists, log):
    if not pdf_folder_path or not os.path.isdir(pdf_folder_path):
        return {"sorted": 0, "review": 0, "warnings": ["Select valid PDFs first."]}
    names = list_items(inbox_list)
    sorted_count = 0
    review_count = 0
    warnings_found = []
    location_fallback_candidates = []

    def take(name):
        item = find_item_by_filename(inbox_list, name)
        if item is None:
            return None
        inbox_list.takeItem(inbox_list.row(item))
        return item

    for name in names:
        bucket, confidence, reason = score_pdf(pdf_folder_path, name, log)
        if bucket == "location_plan_fallback" and confidence in {"High", "Medium"}:
            location_fallback_candidates.append((name, confidence, reason))
            review_count += 1
            log(f"Autosort: {name} held as Location Plan fallback | {confidence} | {reason}.")
            continue
        if bucket and confidence in {"High", "Medium"}:
            item = take(name)
            if item is None:
                continue
            if bucket == "location_plan" and bucket_lists["location_plan"].count() > 0:
                inbox_list.addItem(item)
                review_count += 1
                warning = f"Autosort warning: {name} left in Inbox because Location Plan already has a file."
                warnings_found.append(warning)
                log(warning)
                continue
            item.setData(FILENAME_ROLE, name)
            item.setData(CONFIDENCE_ROLE, confidence)
            bucket_lists[bucket].addItem(item)
            sorted_count += 1
            log(f"Autosort: {name} -> {bucket} | {confidence} | {reason}.")
        else:
            review_count += 1
            log(f"Autosort: {name} -> Needs manual review | {confidence} | {reason}.")
    if bucket_lists["location_plan"].count() == 0 and location_fallback_candidates:
        name, confidence, reason = location_fallback_candidates[0]
        item = take(name)
        if item is not None:
            item.setData(FILENAME_ROLE, name)
            item.setData(CONFIDENCE_ROLE, "Medium")
            bucket_lists["location_plan"].addItem(item)
            sorted_count += 1
            review_count = max(0, review_count - 1)
            log(f"Autosort: {name} -> location_plan | Medium | fallback because no true Location Plan was found; {reason}.")
    return {"sorted": sorted_count, "review": review_count, "warnings": warnings_found}

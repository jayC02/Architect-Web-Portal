SERVICE_NAME = "NinetyOneArchitects Building Portal"
AGENT_CREDENTIAL_NAME = "architectpro-background-agent"
UNAVAILABLE_MESSAGE = "Password saving is not available on this device, but you can still enter it manually."


def credential_name(email):
    return f"portal-login:{str(email or '').strip().lower()}"


def ai_credential_name(provider):
    return f"ai-api:{str(provider or '').strip().lower()}"


def _load_keyring():
    try:
        import keyring
    except Exception as exc:
        return None, exc
    return keyring, None


def availability():
    keyring, error = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.get_password(SERVICE_NAME, "__availability_probe__")
    except Exception:
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def get_login_password(email):
    keyring, error = _load_keyring()
    if keyring is None:
        return None, False, UNAVAILABLE_MESSAGE
    try:
        return keyring.get_password(SERVICE_NAME, credential_name(email)), True, ""
    except Exception:
        return None, False, UNAVAILABLE_MESSAGE


def save_login_password(email, password):
    password = str(password or "")
    if not password:
        return False, "Enter a password before saving it securely."
    keyring, error = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.set_password(SERVICE_NAME, credential_name(email), password)
    except Exception:
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def delete_login_password(email):
    keyring, error = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.delete_password(SERVICE_NAME, credential_name(email))
    except Exception as exc:
        errors = getattr(keyring, "errors", None)
        delete_error = getattr(errors, "PasswordDeleteError", None)
        if delete_error and isinstance(exc, delete_error):
            return True, ""
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def get_ai_api_key(provider):
    keyring, error = _load_keyring()
    if keyring is None:
        return None, False, UNAVAILABLE_MESSAGE
    try:
        return keyring.get_password(SERVICE_NAME, ai_credential_name(provider)), True, ""
    except Exception:
        return None, False, UNAVAILABLE_MESSAGE


def save_ai_api_key(provider, api_key):
    api_key = str(api_key or "").strip()
    if not api_key:
        return False, "Enter an API key before saving it securely."
    keyring, error = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.set_password(SERVICE_NAME, ai_credential_name(provider), api_key)
    except Exception:
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def delete_ai_api_key(provider):
    keyring, error = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.delete_password(SERVICE_NAME, ai_credential_name(provider))
    except Exception as exc:
        errors = getattr(keyring, "errors", None)
        delete_error = getattr(errors, "PasswordDeleteError", None)
        if delete_error and isinstance(exc, delete_error):
            return True, ""
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def get_agent_credential():
    keyring, _ = _load_keyring()
    if keyring is None:
        return None, False, UNAVAILABLE_MESSAGE
    try:
        return keyring.get_password(SERVICE_NAME, AGENT_CREDENTIAL_NAME), True, ""
    except Exception:
        return None, False, UNAVAILABLE_MESSAGE


def save_agent_credential(credential):
    credential = str(credential or "").strip()
    if not credential.startswith("apa_"):
        return False, "The portal did not return a valid Agent credential."
    keyring, _ = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.set_password(SERVICE_NAME, AGENT_CREDENTIAL_NAME, credential)
    except Exception:
        return False, UNAVAILABLE_MESSAGE
    return True, ""


def delete_agent_credential():
    keyring, _ = _load_keyring()
    if keyring is None:
        return False, UNAVAILABLE_MESSAGE
    try:
        keyring.delete_password(SERVICE_NAME, AGENT_CREDENTIAL_NAME)
    except Exception as exc:
        errors = getattr(keyring, "errors", None)
        delete_error = getattr(errors, "PasswordDeleteError", None)
        if not (delete_error and isinstance(exc, delete_error)):
            return False, UNAVAILABLE_MESSAGE
    return True, ""

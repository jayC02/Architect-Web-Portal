"""One running Agent per Windows user, with protocol launches routed to it."""
import hashlib
import json
from PySide6.QtCore import QLockFile, QObject, Signal
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from . import storage_paths

class AgentInstance(QObject):
    launch_received = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        identity = hashlib.sha256(storage_paths.app_data_dir().lower().encode('utf-8')).hexdigest()[:24]
        self.name = 'ArchitectProAgent-' + identity
        self.lock = QLockFile(storage_paths.runtime_path('agent-process.lock'))
        self.lock.setStaleLockTime(0)
        self.server = QLocalServer(self)
        self.server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        self.server.newConnection.connect(self._receive)
        self.pending = []
        self.handler = None

    def acquire(self, launch_url=''):
        if not self.lock.tryLock(0):
            socket = QLocalSocket()
            socket.connectToServer(self.name)
            if not socket.waitForConnected(3000):
                raise RuntimeError('The Agent is still opening. Wait a moment, then open it again.')
            socket.write(json.dumps({'launch': str(launch_url or '')}).encode('utf-8') + b'\n')
            if socket.bytesToWrite() and not socket.waitForBytesWritten(3000):
                raise RuntimeError('The running Agent could not receive this request. Open it from the Windows tray.')
            socket.disconnectFromServer()
            return False
        QLocalServer.removeServer(self.name)
        if not self.server.listen(self.name):
            self.lock.unlock()
            raise RuntimeError('The Agent could not open its local connection.')
        return True

    def _receive(self):
        while self.server.hasPendingConnections():
            socket = self.server.nextPendingConnection()
            socket.setProperty('message', b'')
            socket.readyRead.connect(lambda socket=socket: self._read(socket))
            socket.disconnected.connect(socket.deleteLater)
            self._read(socket)

    def _read(self, socket):
        data = bytes(socket.property('message') or b'') + bytes(socket.readAll())
        if len(data) > 4096:
            socket.abort(); return
        socket.setProperty('message', data)
        if b'\n' not in data:
            return
        try:
            launch = json.loads(data.split(b'\n', 1)[0]).get('launch', '')
            if isinstance(launch, str):
                if self.handler: self.handler(launch)
                else: self.pending.append(launch)
        except (ValueError, AttributeError):
            pass
        socket.disconnectFromServer()

    def set_handler(self, handler):
        self.handler = handler
        for launch in self.pending: handler(launch)
        self.pending.clear()

    def close(self):
        self.server.close()
        self.lock.unlock()

"""Versioned Desktop Agent -> Architect Pro callback contract mapping.

Runner outcomes are intentionally translated here so Python implementation
details never become part of the web API contract.
"""

from __future__ import annotations

from datetime import datetime, timezone
import math
import uuid


CALLBACK_CONTRACT_VERSION = 1


def _utc_iso(value=None):
    if value is None:
        value = datetime.now(timezone.utc)
    if isinstance(value, str):
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    elif isinstance(value, datetime):
        parsed = value
    else:
        raise TypeError("occurred_at must be an ISO timestamp or datetime")
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat()


def _safe_timings(raw_timings):
    values = {}
    for key, value in dict(raw_timings or {}).items():
        try:
            seconds = float(value)
        except (TypeError, ValueError):
            continue
        if not math.isfinite(seconds) or seconds < 0:
            continue
        values[str(key)[:80]] = round(seconds, 4)
    total = values.pop("overall", None)
    if total is None and not values:
        return None
    return {
        **({"totalSeconds": total} if total is not None else {}),
        "stageDurationsSeconds": values,
    }


def build_callback_payload(
    *,
    job_id,
    status,
    event_type,
    callback_id=None,
    occurred_at=None,
    result_summary="",
    error="",
    last_checkpoint="",
    result=None,
):
    payload = {
        "version": CALLBACK_CONTRACT_VERSION,
        "jobId": str(job_id),
        "callbackId": str(callback_id or uuid.uuid4()),
        "occurredAt": _utc_iso(occurred_at),
        "status": str(status),
        "eventType": str(event_type),
    }
    if result_summary:
        payload["resultSummary"] = str(result_summary)[:1000]
    if error:
        payload["error"] = str(error)[:500]
    if last_checkpoint:
        payload["lastCheckpoint"] = str(last_checkpoint)[:100]
    if result:
        payload["result"] = dict(result)
    return payload


def build_started_callback(job_id, *, callback_id=None, occurred_at=None):
    return build_callback_payload(
        job_id=job_id,
        status="IN_PROGRESS",
        event_type="started",
        callback_id=callback_id,
        occurred_at=occurred_at,
        result_summary="Desktop automation started.",
        last_checkpoint="automation_started",
    )


def map_runner_result_callback(result, *, callback_id=None, occurred_at=None, include_browser_metadata=False):
    outcome = str(getattr(result, "outcome", ""))
    stage = str(getattr(result, "last_stage", "") or "automation_started")
    message = str(getattr(result, "message", "") or "Desktop automation finished.")
    timings = _safe_timings(getattr(result, "timings", {}))

    if outcome == "user_action_required":
        contract_outcome = (
            "awaiting_user_portal_review" if stage == "fee" else "paused_for_manual_input"
        )
        status = "AWAITING_PORTAL_REVIEW"
        result_payload = {
            "outcome": contract_outcome,
            "lastCompletedStep": None,
            "currentSection": stage,
            "warnings": [],
            "userActionRequired": message,
            "safeRetryPoint": None,
            "errorCode": None,
            "errorSummary": None,
        }
        error = ""
    elif outcome == "success":
        status = "COMPLETED"
        result_payload = {
            "outcome": "completed_to_final_review",
            "lastCompletedStep": stage,
            "currentSection": "final_review",
            "warnings": [],
            "userActionRequired": None,
            "safeRetryPoint": None,
            "errorCode": None,
            "errorSummary": None,
        }
        error = ""
    elif outcome == "failure":
        retry_safe = bool(getattr(result, "retry_safe", False))
        recovery_action = str(getattr(result, "recovery_action", "") or ("retry" if retry_safe else "review_portal"))
        status = "FAILED_RETRYABLE" if retry_safe else "FAILED_FINAL"
        result_payload = {
            "outcome": "failed_retryable" if retry_safe else "failed_final",
            "lastCompletedStep": None,
            "currentSection": stage,
            "warnings": [],
            "userActionRequired": (
                "Review the issue, then retry the application."
                if retry_safe
                else "Review the current portal state before starting another attempt."
            ),
            "safeRetryPoint": stage if retry_safe else None,
            "errorCode": getattr(result, "error_code", None),
            "errorSummary": message,
            "failureCategory": getattr(result, "failure_category", None) or getattr(result, "error_code", None),
            "errorHeadline": getattr(result, "error_headline", None) or None,
            "stageDescription": getattr(result, "stage_description", None) or None,
            "progressionMessage": getattr(result, "progression_message", None) or None,
            "nextAction": getattr(result, "next_action", None) or None,
            "recoveryAction": recovery_action,
            "retrySafe": retry_safe,
            "recoveryFields": list(getattr(result, "recovery_fields", ()) or ()),
        }
        error = message
    elif outcome == "cancelled":
        status = "CANCELLED"
        result_payload = {
            "outcome": "cancelled",
            "lastCompletedStep": None,
            "currentSection": stage,
            "warnings": [],
            "userActionRequired": None,
            "safeRetryPoint": stage,
            "errorCode": None,
            "errorSummary": None,
        }
        error = ""
    else:
        raise ValueError(f"Unsupported automation runner outcome: {outcome or '<empty>'}")

    if timings:
        result_payload["timings"] = timings
    browser_session_id = getattr(result, "browser_session_id", None)
    if include_browser_metadata and isinstance(browser_session_id, str) and 0 < len(browser_session_id) <= 200:
        result_payload["browserSessionId"] = browser_session_id

    return build_callback_payload(
        job_id=getattr(result, "job_id", ""),
        status=status,
        event_type="result",
        callback_id=callback_id,
        occurred_at=occurred_at,
        result_summary=message,
        error=error,
        last_checkpoint=stage,
        result=result_payload,
    )

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QDialog, QFrame, QHBoxLayout, QLabel, QSizePolicy, QVBoxLayout

from .services import portal_answers


class ApplicationChoiceCard(QFrame):
    clicked = Signal(str)

    def __init__(self, title, eyebrow, body, value, parent=None):
        super().__init__(parent)
        self.value = value
        self.setObjectName("ApplicationChoiceCard")
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(235)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(10)

        eyebrow_label = QLabel(eyebrow)
        eyebrow_label.setObjectName("ApplicationChoiceEyebrow")
        eyebrow_label.setWordWrap(True)
        title_label = QLabel(title)
        title_label.setObjectName("ApplicationChoiceTitle")
        title_label.setWordWrap(True)
        body_label = QLabel(body)
        body_label.setObjectName("ApplicationChoiceBody")
        body_label.setWordWrap(True)
        action = QLabel("Select application")
        action.setObjectName("ApplicationChoiceAction")
        action.setAlignment(Qt.AlignCenter)

        layout.addWidget(eyebrow_label)
        layout.addWidget(title_label)
        layout.addWidget(body_label)
        layout.addStretch(1)
        layout.addWidget(action, 0, Qt.AlignLeft)

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit(self.value)
        super().mouseReleaseEvent(event)


class ApplicationSelectorDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.selected_application_type = None
        self.setWindowTitle("Choose application type")
        self.setModal(True)
        self.setFixedSize(860, 500)
        self.setObjectName("ApplicationSelectorDialog")
        self._build()

    def _build(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 28, 28, 28)
        layout.setSpacing(18)

        title = QLabel("Choose application type")
        title.setObjectName("ApplicationSelectorTitle")
        subtitle = QLabel("Start with the right workflow. The app will only show the questions and pages needed for that application.")
        subtitle.setObjectName("ApplicationSelectorSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        choices = QHBoxLayout()
        choices.setSpacing(18)
        choices.addWidget(self._choice_card(
            "Householder Application (Planning)",
            "ePlanning",
            "Planning application workflow for householder proposals.",
            portal_answers.HOUSEHOLDER_TYPE,
        ), 1)
        choices.addWidget(self._choice_card(
            "Building Warrant",
            "eBuilding Standards",
            "Building standards workflow for warrant submissions.",
            portal_answers.BUILDING_WARRANT_TYPE,
        ), 1)
        layout.addLayout(choices, 1)

    def _choice_card(self, title, eyebrow, body, value):
        card = ApplicationChoiceCard(title, eyebrow, body, value)
        card.clicked.connect(self._choose)
        return card

    def _choose(self, value):
        self.selected_application_type = value
        self.accept()

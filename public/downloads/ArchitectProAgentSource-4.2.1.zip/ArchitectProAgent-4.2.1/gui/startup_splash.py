# -*- coding: utf-8 -*-
import math
import os
import sys
import time

from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QColor, QGuiApplication, QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGraphicsDropShadowEffect,
    QLabel,
    QProgressBar,
    QVBoxLayout,
    QWidget,
)


STARTUP_STAGES = {
    "starting": (18, "Starting automation agent…"),
    "loading_agent": (58, "Loading secure services…"),
    "opening_agent": (92, "Opening Architect Pro…"),
}


def packaged_asset_path(filename):
    bundled_root = getattr(sys, "_MEIPASS", None)
    if bundled_root:
        return os.path.join(bundled_root, "assets", filename)
    return os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "assets",
        filename,
    )


class StartupTimingEstimate:
    AVERAGE_KEY = "startup/average_seconds"
    SAMPLE_COUNT_KEY = "startup/sample_count"

    def __init__(self, settings=None):
        self.settings = settings or QSettings("Architect Pro", "Desktop")

    def text(self):
        try:
            average = float(self.settings.value(self.AVERAGE_KEY, 0) or 0)
            samples = int(self.settings.value(self.SAMPLE_COUNT_KEY, 0) or 0)
        except (TypeError, ValueError):
            average = 0
            samples = 0
        if samples < 1 or average <= 0:
            return "Measuring startup time"
        lower = max(1, math.floor(average * 0.8))
        upper = max(lower + 1, math.ceil(average * 1.2))
        return f"Usually ready in {lower}-{upper} seconds"

    def record(self, duration_seconds):
        duration = max(0.1, float(duration_seconds))
        try:
            average = float(self.settings.value(self.AVERAGE_KEY, 0) or 0)
            samples = int(self.settings.value(self.SAMPLE_COUNT_KEY, 0) or 0)
        except (TypeError, ValueError):
            average = 0
            samples = 0
        new_average = duration if samples < 1 else ((average * min(samples, 4)) + duration) / (min(samples, 4) + 1)
        self.settings.setValue(self.AVERAGE_KEY, round(new_average, 2))
        self.settings.setValue(self.SAMPLE_COUNT_KEY, min(samples + 1, 5))


class StartupSplash(QWidget):
    def __init__(self, settings=None, clock=None):
        super().__init__(None, Qt.SplashScreen | Qt.FramelessWindowHint)
        self._clock = clock or time.perf_counter
        self._started_at = self._clock()
        self._timing = StartupTimingEstimate(settings)
        self._timing_recorded = False

        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setFixedSize(468, 254)
        self.setObjectName("StartupSplash")

        outer = QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)

        panel = QFrame()
        panel.setObjectName("SplashPanel")
        shadow = QGraphicsDropShadowEffect(panel)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 3)
        shadow.setColor(QColor(32, 35, 31, 24))
        panel.setGraphicsEffect(shadow)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(42, 27, 42, 25)
        layout.setSpacing(0)

        logo = QLabel()
        logo.setObjectName("SplashLogo")
        logo.setFixedSize(44, 44)
        logo.setAlignment(Qt.AlignCenter)
        pixmap = QPixmap(packaged_asset_path("architect-pro-mark.png"))
        if not pixmap.isNull():
            logo.setPixmap(pixmap.scaled(44, 44, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            logo.setText("AP")
        layout.addWidget(logo, 0, Qt.AlignHCenter)
        layout.addSpacing(9)

        title = QLabel("Architect Pro")
        title.setObjectName("SplashTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        layout.addSpacing(8)

        self.status_label = QLabel()
        self.status_label.setObjectName("SplashStatus")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)
        layout.addSpacing(17)

        self.progress = QProgressBar()
        self.progress.setObjectName("SplashProgress")
        self.progress.setRange(0, 100)
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(5)
        layout.addWidget(self.progress)
        layout.addSpacing(10)

        self.estimate_label = QLabel(self._timing.text())
        self.estimate_label.setObjectName("SplashEstimate")
        self.estimate_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.estimate_label)

        outer.addWidget(panel)
        self.setStyleSheet("""
            QWidget#StartupSplash { background: transparent; }
            QFrame#SplashPanel {
                background: #FBFAF6;
                border: 1px solid #DEDAD1;
                border-radius: 12px;
            }
            QLabel#SplashLogo { background: transparent; }
            QLabel#SplashTitle {
                color: #20231F;
                font-family: "Segoe UI Variable Display", "Segoe UI";
                font-size: 22px;
                font-weight: 650;
            }
            QLabel#SplashStatus {
                color: #4F514C;
                font-family: "Segoe UI Variable Text", "Segoe UI";
                font-size: 13px;
            }
            QLabel#SplashEstimate {
                color: #858078;
                font-family: "Segoe UI Variable Text", "Segoe UI";
                font-size: 11px;
            }
            QProgressBar#SplashProgress {
                background: #E7E4DD;
                border: 0;
                border-radius: 2px;
            }
            QProgressBar#SplashProgress::chunk {
                background: #4B7F62;
                border-radius: 2px;
            }
        """)
        self.set_stage("starting")

    def set_stage(self, stage):
        if stage not in STARTUP_STAGES:
            raise ValueError(f"Unknown startup stage: {stage}")
        progress, message = STARTUP_STAGES[stage]
        self.progress.setValue(progress)
        self.status_label.setText(message)

    def record_startup_complete(self):
        if self._timing_recorded:
            return
        self._timing.record(self._clock() - self._started_at)
        self._timing_recorded = True

    def showEvent(self, event):
        screen = QGuiApplication.screenAt(self.frameGeometry().center()) or QGuiApplication.primaryScreen()
        if screen:
            geometry = self.frameGeometry()
            geometry.moveCenter(screen.availableGeometry().center())
            self.move(geometry.topLeft())
        super().showEvent(event)


def update_startup_splash(splash, stage, app=None):
    if splash is None:
        return
    splash.set_stage(stage)
    if app is not None:
        app.processEvents()


def close_startup_splash(splash, app=None):
    if splash is None:
        return
    splash.hide()
    splash.close()
    splash.deleteLater()
    if app is not None:
        app.processEvents()


def show_window_after_splash(window, splash=None, app=None):
    if splash is not None:
        if hasattr(splash, "record_startup_complete"):
            splash.record_startup_complete()
        splash.hide()
    window.show()
    if splash is not None:
        splash.close()
        splash.deleteLater()
    if app is not None:
        app.processEvents()

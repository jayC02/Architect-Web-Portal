from PySide6.QtCore import QRectF, QSize, Qt
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QPushButton,
    QScrollArea,
    QStyledItemDelegate,
    QStyle,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .theme import SPACING

try:
    import qtawesome as qta
except Exception:
    qta = None


def repolish(widget):
    widget.style().unpolish(widget)
    widget.style().polish(widget)


def awesome_icon(name, color="#1F211D"):
    if qta is None:
        return QIcon()
    try:
        return qta.icon(name, color=color)
    except Exception:
        return QIcon()


def themed_icon(name, color="#1F211D"):
    pixmap = QPixmap(16, 16)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    pen = QPen(QColor(color), 1.7)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)

    if name == "folder":
        painter.drawLine(2.0, 5.0, 6.2, 5.0)
        painter.drawLine(6.2, 5.0, 7.7, 6.6)
        painter.drawLine(7.7, 6.6, 14.0, 6.6)
        painter.drawRoundedRect(QRectF(2.0, 5.0, 12.0, 8.5), 1.8, 1.8)
    elif name == "magic":
        painter.drawLine(4.0, 12.0, 12.0, 4.0)
        painter.drawLine(9.8, 3.1, 12.9, 6.2)
        painter.drawLine(3.0, 3.0, 3.0, 5.8)
        painter.drawLine(1.6, 4.4, 4.4, 4.4)
        painter.drawLine(13.0, 10.2, 13.0, 12.8)
        painter.drawLine(11.7, 11.5, 14.3, 11.5)
    elif name == "save":
        painter.drawRoundedRect(QRectF(2.5, 2.0, 11.0, 12.0), 1.8, 1.8)
        painter.drawLine(5.0, 2.0, 5.0, 6.0)
        painter.drawLine(10.8, 2.0, 10.8, 6.0)
        painter.drawLine(5.0, 6.0, 10.8, 6.0)
        painter.drawRoundedRect(QRectF(5.0, 10.0, 6.0, 4.0), 1.0, 1.0)
    elif name == "check":
        painter.drawLine(3.0, 8.4, 6.4, 11.4)
        painter.drawLine(6.4, 11.4, 13.2, 4.8)
    painter.end()
    return QIcon(pixmap)


class PresetSelectorFrame(QFrame):
    def __init__(self, combo, parent=None):
        super().__init__(parent)
        self.combo = combo
        self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, event):
        self.combo.showPopup()
        event.accept()


def button(text, variant="secondary", icon=None, icon_color=None, awesome=None, icon_size=16):
    btn = QPushButton(text)
    names = {
        "primary": "PrimaryButton",
        "secondary": "SecondaryButton",
        "ghost": "GhostButton",
    }
    btn.setObjectName(names.get(variant, "SecondaryButton"))
    btn.setCursor(Qt.PointingHandCursor)
    if awesome:
        icon_obj = awesome_icon(awesome, icon_color or "#1F211D")
        if not icon_obj.isNull():
            btn.setIcon(icon_obj)
            btn.setIconSize(QSize(icon_size, icon_size))
    elif icon:
        btn.setIcon(themed_icon(icon, icon_color or "#1F211D"))
        btn.setIconSize(QSize(icon_size, icon_size))
    return btn


def badge(text, kind="info"):
    label = QLabel(text)
    names = {
        "info": "InfoBadge",
        "success": "SuccessBadge",
        "warning": "WarningBadge",
        "required": "RequiredBadge",
        "error": "ErrorBadge",
    }
    label.setObjectName(names.get(kind, "InfoBadge"))
    label.setAlignment(Qt.AlignCenter)
    return label


class ElidedLabel(QLabel):
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.full_text = text
        self.setToolTip(text)

    def setText(self, text):
        self.full_text = text
        self.setToolTip(text)
        super().setText(text)

    def paintEvent(self, event):
        painter = QPainter(self)
        metrics = QFontMetrics(self.font())
        text = metrics.elidedText(self.full_text, Qt.ElideRight, self.width())
        painter.setPen(self.palette().windowText().color())
        painter.drawText(self.rect(), self.alignment() or Qt.AlignVCenter | Qt.AlignLeft, text)


def file_row_widget(filename, size_text="", confidence=None, row_height=30):
    row = QWidget()
    row.setObjectName("FileRow")
    row.setFixedHeight(row_height)
    row.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    layout = QHBoxLayout(row)
    layout.setContentsMargins(7, 1, 7, 1)
    layout.setSpacing(6)
    icon = QLabel("PDF")
    icon.setObjectName("PdfIcon")
    icon.setAlignment(Qt.AlignCenter)
    icon.setFixedSize(18, 18)
    layout.addWidget(icon)
    name = ElidedLabel(filename)
    name.setObjectName("FileName")
    name.setWordWrap(False)
    name.setMinimumHeight(row_height - 4)
    layout.addWidget(name, 1)
    if size_text:
        size = QLabel(size_text)
        size.setObjectName("FileSize")
        size.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(size)
    if confidence:
        kind = "success" if confidence == "High" else "warning" if confidence == "Medium" else "error"
        layout.addWidget(badge(confidence, kind))
    return row


def card(object_name="Card"):
    frame = QFrame()
    frame.setObjectName(object_name)
    layout = QVBoxLayout(frame)
    if object_name == "FormCard":
        layout.setContentsMargins(28, 24, 28, 28)
        layout.setSpacing(22)
    else:
        layout.setContentsMargins(SPACING["lg"], SPACING["md"], SPACING["lg"], SPACING["lg"])
        layout.setSpacing(SPACING["md"])
    return frame, layout


def vector_icon_label(icon_name, color="#4F6748", box_size=42, icon_size=20, object_name="VectorIcon"):
    label = QLabel()
    label.setObjectName(object_name)
    label.setAlignment(Qt.AlignCenter)
    label.setFixedSize(box_size, box_size)
    icon = awesome_icon(icon_name, color)
    if icon.isNull():
        label.setText("")
    else:
        label.setPixmap(icon.pixmap(QSize(icon_size, icon_size)))
    return label


def header_card(title, description, icon_text, actions=None):
    frame, layout = card("HeaderCard")
    layout.setContentsMargins(SPACING["md"], SPACING["md"], SPACING["md"], SPACING["md"])
    row = QHBoxLayout()
    row.setSpacing(SPACING["sm"])

    icon = QLabel(icon_text)
    icon.setObjectName("IconTile")
    icon.setAlignment(Qt.AlignCenter)
    icon.setFixedSize(52, 52)
    icon.setFont(QFont("Segoe UI", 15, QFont.Bold))
    row.addWidget(icon)

    copy = QVBoxLayout()
    copy.setSpacing(4)
    title_label = QLabel(title)
    title_label.setObjectName("PageTitle")
    desc_label = QLabel(description)
    desc_label.setObjectName("Muted")
    desc_label.setWordWrap(True)
    copy.addWidget(title_label)
    copy.addWidget(desc_label)
    row.addLayout(copy, 1)

    for action in actions or []:
        row.addWidget(action)

    layout.addLayout(row)
    return frame


def preset_selector(combo, placeholder_text, width=320, height=50):
    combo.setProperty("placeholder_text", placeholder_text)
    if hasattr(combo, "setPlaceholderText"):
        combo.setPlaceholderText(placeholder_text)
    combo.setObjectName("PresetCombo")
    combo.setFixedHeight(height - 2)
    if combo.count() == 0:
        combo.setCurrentIndex(-1)

    frame = PresetSelectorFrame(combo)
    frame.setObjectName("PresetSelector")
    frame.setFixedSize(width, height)
    layout = QHBoxLayout(frame)
    layout.setContentsMargins(16, 0, 10, 0)
    layout.setSpacing(10)
    layout.addWidget(vector_icon_label("fa5s.upload", "#6F6A62", 20, 16, "PresetSelectorIcon"))
    layout.addWidget(combo, 1)
    arrow = vector_icon_label("fa5s.chevron-down", "#6F6A62", 18, 12, "PresetSelectorIcon")
    arrow.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    layout.addWidget(arrow)
    return frame


def style_dropdown(combo, prominent=False):
    is_prominent = prominent or combo.objectName() == "PrimaryDropdownCombo"
    if combo.objectName() not in {"PresetCombo", "PrimaryDropdownCombo"}:
        combo.setObjectName("PrimaryDropdownCombo" if is_prominent else "DropdownCombo")
    combo.setCursor(Qt.PointingHandCursor)
    combo.setMinimumHeight(50 if is_prominent else 42)
    combo.view().setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
    return combo


def preset_header_card(title, description, page_icon, preset_combo, preset_text, save_callback):
    frame, layout = card("HeaderCard")
    frame.setFixedHeight(154)
    layout.setContentsMargins(28, 24, 28, 24)
    layout.setSpacing(0)

    row = QHBoxLayout()
    row.setSpacing(20)
    row.addWidget(vector_icon_label(page_icon, "#4F6748", 64, 28, "PageIconTile"))

    copy = QVBoxLayout()
    copy.setSpacing(8)
    title_label = QLabel(title)
    title_label.setObjectName("PageTitle")
    desc_label = QLabel(description)
    desc_label.setObjectName("Muted")
    desc_label.setWordWrap(True)
    copy.addStretch(1)
    copy.addWidget(title_label)
    copy.addWidget(desc_label)
    copy.addStretch(1)
    row.addLayout(copy, 1)

    presets = QVBoxLayout()
    presets.setSpacing(8)
    preset_label = QLabel("Presets")
    preset_label.setObjectName("PresetLabel")
    preset_row = QHBoxLayout()
    preset_row.setSpacing(12)
    preset_row.addWidget(preset_selector(preset_combo, preset_text))
    save = button("  Save as Preset", "primary", awesome="fa5s.save", icon_color="#FFFFFF", icon_size=16)
    save.setObjectName("HeaderSavePresetButton")
    save.setFixedSize(210, 50)
    save.clicked.connect(save_callback)
    preset_row.addWidget(save)
    presets.addWidget(preset_label)
    presets.addLayout(preset_row)
    row.addLayout(presets, 0)

    layout.addLayout(row)
    return frame


def form_section_header(title, icon_name, actions=None):
    row = QHBoxLayout()
    row.setSpacing(12)
    row.addWidget(vector_icon_label(icon_name, "#4F6748", 42, 18, "FormSectionIcon"))
    label = QLabel(title)
    label.setObjectName("FormSectionTitle")
    row.addWidget(label)
    row.addStretch(1)
    for action in actions or []:
        row.addWidget(action)
    return row


def section_header(title, subtitle=None, actions=None):
    row = QHBoxLayout()
    copy = QVBoxLayout()
    copy.setSpacing(3)
    title_label = QLabel(title)
    title_label.setObjectName("CardTitle")
    copy.addWidget(title_label)
    if subtitle:
        subtitle_label = QLabel(subtitle)
        subtitle_label.setObjectName("Muted")
        subtitle_label.setWordWrap(True)
        copy.addWidget(subtitle_label)
    row.addLayout(copy, 1)
    for action in actions or []:
        row.addWidget(action)
    return row


def scroll_page():
    scroll = QScrollArea()
    scroll.setObjectName("PageScroll")
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.NoFrame)
    scroll.setLineWidth(0)
    scroll.viewport().setObjectName("PageScrollViewport")
    scroll.viewport().setAutoFillBackground(False)
    page = QWidget()
    page.setObjectName("PageCanvas")
    page.setAutoFillBackground(False)
    layout = QVBoxLayout(page)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(SPACING["md"])
    scroll.setWidget(page)
    return scroll, layout


def configure_field(widget, placeholder="", required=False):
    widget.setProperty("required", bool(required))
    widget.setProperty("touched", False)
    widget.setProperty("invalid", "false")
    if isinstance(widget, QLineEdit):
        widget.setPlaceholderText(placeholder)
        widget.editingFinished.connect(lambda w=widget: mark_touched(w))
    elif isinstance(widget, QTextEdit):
        widget.setPlaceholderText(placeholder)
        widget.textChanged.connect(lambda w=widget: mark_touched(w, validate=False))
    elif isinstance(widget, QComboBox):
        style_dropdown(widget)
        widget.currentIndexChanged.connect(lambda _=0, w=widget: mark_touched(w))
    return widget


def mark_touched(widget, validate=True):
    widget.setProperty("touched", True)
    if validate:
        validate_field(widget)


def validate_field(widget, force=False):
    if not widget.property("required"):
        widget.setProperty("invalid", "false")
        repolish(widget)
        return True
    should_show = force or bool(widget.property("touched"))
    value = ""
    if isinstance(widget, QLineEdit):
        value = widget.text().strip()
    elif isinstance(widget, QTextEdit):
        value = widget.toPlainText().strip()
    elif isinstance(widget, QComboBox):
        value = widget.currentText().strip()
    invalid = should_show and not value
    widget.setProperty("invalid", "true" if invalid else "false")
    repolish(widget)
    return bool(value)


def field_block(label_text, widget, required=False):
    layout = QVBoxLayout()
    layout.setSpacing(6)
    label = QLabel(label_text + (" *" if required else ""))
    label.setObjectName("FieldLabel")
    layout.addWidget(label)
    layout.addWidget(widget)
    return layout


def action_bar(back_callback=None, next_callback=None, preset_callback=None, primary_text="Next"):
    frame, layout = card("ActionBar")
    frame.setFixedHeight(88)
    layout.setContentsMargins(SPACING["lg"], 14, SPACING["lg"], 14)
    row = QHBoxLayout()
    row.setSpacing(14)
    if back_callback:
        back = button("  Back", "ghost", awesome="fa5s.arrow-left", icon_color="#4F4A43", icon_size=16)
        back.setObjectName("ActionBackButton")
        back.setFixedSize(116, 50)
        back.clicked.connect(back_callback)
        row.addWidget(back)
    saved = QFrame()
    saved.setObjectName("SaveStatus")
    saved_layout = QHBoxLayout(saved)
    saved_layout.setContentsMargins(16, 0, 18, 0)
    saved_layout.setSpacing(10)
    saved_layout.addWidget(vector_icon_label("fa5s.check", "#166534", 22, 12, "SaveStatusIcon"))
    saved_text = QLabel("All changes saved")
    saved_text.setObjectName("SaveStatusText")
    saved_layout.addWidget(saved_text)
    saved.setFixedHeight(50)
    row.addWidget(saved)
    row.addStretch(1)
    if preset_callback:
        preset = button("  Save as Preset", "secondary", awesome="fa5s.save", icon_color="#4F4A43", icon_size=16)
        preset.setObjectName("ActionPresetButton")
        preset.setFixedSize(210, 50)
        preset.clicked.connect(preset_callback)
        row.addWidget(preset)
    if next_callback:
        next_btn = button(f"{primary_text}  ", "primary", awesome="fa5s.arrow-right", icon_color="#FFFFFF", icon_size=16)
        next_btn.setObjectName("ActionNextButton")
        next_btn.setFixedSize(140, 50)
        next_btn.setLayoutDirection(Qt.RightToLeft)
        next_btn.clicked.connect(next_callback)
        row.addWidget(next_btn)
    layout.addLayout(row)
    return frame


def form_grid(items, columns=2):
    grid = QGridLayout()
    grid.setHorizontalSpacing(SPACING["lg"])
    grid.setVerticalSpacing(SPACING["md"])
    for index, (label, widget, required) in enumerate(items):
        grid.addLayout(field_block(label, widget, required), index // columns, index % columns)
    return grid


class CompactListWidget(QListWidget):
    def __init__(self, placeholder_text="", parent=None):
        super().__init__(parent)
        self.placeholder_text = placeholder_text
        self.setSelectionMode(QListWidget.ExtendedSelection)
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDropIndicatorShown(True)
        self.setDefaultDropAction(Qt.MoveAction)
        self.setDragDropMode(QListWidget.DragDrop)
        self.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)


class PdfFileDelegate(QStyledItemDelegate):
    def __init__(self, filename_role, size_role, confidence_role=None, row_height=32, parent=None):
        super().__init__(parent)
        self.filename_role = filename_role
        self.size_role = size_role
        self.confidence_role = confidence_role
        self.row_height = row_height

    def sizeHint(self, option, index):
        return QSize(0, self.row_height)

    def paint(self, painter, option, index):
        painter.save()
        bucket_list = bool(self.parent() and self.parent().property("bucketList") == "true")
        row_rect = option.rect.adjusted(0, 0, 0, 0) if bucket_list else option.rect.adjusted(3, 1, -3, -1)
        selected = bool(option.state & QStyle.State_Selected)
        hover = bool(option.state & QStyle.State_MouseOver)
        painter.setRenderHint(QPainter.Antialiasing)
        if bucket_list and not selected and not hover:
            painter.setPen(Qt.NoPen)
            painter.setBrush(Qt.NoBrush)
        else:
            fill = QColor("#EEF3EA" if selected else "#FFFFFF" if hover else "#FFFFFF")
            border = QColor("#B7C9AF" if selected else "#E4DDD2" if hover else "#E9E2D8")
            painter.setPen(QPen(border, 1))
            painter.setBrush(fill)
            painter.drawRoundedRect(QRectF(row_rect), 7, 7)

        filename = index.data(self.filename_role) or index.data(Qt.DisplayRole) or ""
        size_text = index.data(self.size_role) or ""

        icon_rect = QRectF(row_rect.left() + 7, row_rect.top() + (row_rect.height() - 18) / 2, 18, 18)
        painter.setPen(QPen(QColor("#FCA5A5"), 1))
        painter.setBrush(QColor("#EF4444"))
        painter.drawRoundedRect(icon_rect, 4, 4)
        painter.setPen(QColor("#FFFFFF"))
        icon_font = QFont("Segoe UI", 5, QFont.Black)
        painter.setFont(icon_font)
        painter.drawText(icon_rect, Qt.AlignCenter, "PDF")

        size_width = 58 if size_text else 0
        menu_width = 0
        text_rect = row_rect.adjusted(34, 0, -(size_width + menu_width + 8), 0)
        text_font = QFont("Segoe UI")
        text_font.setPointSizeF(9.2)
        painter.setFont(text_font)
        painter.setPen(QColor("#1F211D"))
        metrics = QFontMetrics(text_font)
        painter.drawText(text_rect, Qt.AlignVCenter | Qt.AlignLeft, metrics.elidedText(filename, Qt.ElideRight, text_rect.width()))

        if size_text:
            size_rect = QRectF(row_rect.right() - size_width - 8, row_rect.top(), size_width, row_rect.height())
            painter.setPen(QColor("#8A8176"))
            painter.drawText(size_rect, Qt.AlignVCenter | Qt.AlignRight, size_text)

        painter.restore()

@echo off
setlocal

call "%~dp0build_exe.bat"
if errorlevel 1 exit /b %errorlevel%

set "ISCC_PATH="
where ISCC.exe >nul 2>nul && set "ISCC_PATH=ISCC.exe"
if not defined ISCC_PATH if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC_PATH=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not defined ISCC_PATH if exist "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe" set "ISCC_PATH=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"

if not defined ISCC_PATH (
  echo Inno Setup 6 was not found. Install it, then run this script again.
  exit /b 1
)

"%ISCC_PATH%" "%~dp0installer\ArchitectProAgent.iss"
exit /b %errorlevel%

#define MyAppName "Architect Pro Agent"
#define MyAppVersion "4.2.1"
#define MyAppPublisher "Ninety One Architects"
#define MyAppExeName "ArchitectPortalAutomation.exe"
#ifndef MyAppSourceDir
  #define MyAppSourceDir "..\Releases\_dist\ArchitectPortalAutomation"
#endif

[Setup]
AppId={{7D61568B-AB50-4E36-9397-8A8323A195E5}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Architect Pro Agent
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\Releases\_installer
OutputBaseFilename=ArchitectProAgentSetup-{#MyAppVersion}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
CloseApplications=yes
SetupLogging=yes
RestartApplications=no
CloseApplicationsFilter=*.exe,*.dll,*.pyd

[Files]
Source: "{#MyAppSourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Registry]
Root: HKCU; Subkey: "Software\Classes\architectpro"; ValueType: string; ValueName: ""; ValueData: "URL:Architect Pro Agent Protocol"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\architectpro"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""
Root: HKCU; Subkey: "Software\Classes\architectpro\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0"
Root: HKCU; Subkey: "Software\Classes\architectpro\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExeName}"" ""%1"""
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "ArchitectProAgent"; ValueData: """{app}\{#MyAppExeName}"""; Flags: uninsdeletevalue

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent

; Updater restarts the installed version after the old process has exited.
Filename: "{app}\{#MyAppExeName}"; Flags: nowait; Check: RestartAgentAfterUpdate

[UninstallRun]
Filename: "{app}\{#MyAppExeName}"; Parameters: "--uninstall-cleanup"; Flags: runhidden waituntilterminated skipifdoesntexist; RunOnceId: "ArchitectProAgentCleanup"

[Code]
function RestartAgentAfterUpdate: Boolean;
begin
  Result := WizardSilent and (ExpandConstant('{param:RESTARTAGENT|0}') = '1');
end;

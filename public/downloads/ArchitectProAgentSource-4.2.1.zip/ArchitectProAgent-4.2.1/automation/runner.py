"""Canonical GUI-independent automation entrypoint."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
import logging
import threading
import time
import traceback
from typing import Any, Callable, Mapping

from automation.common.driver import BrowserComponentError, BrowserMode, create_managed_chrome
from automation.common.handoff import UserActionRequired
from automation.common.performance import PerformanceRecorder
from automation.common.proposal_creation import (
    AddressPostcodeCorrectionRequired,
    ManualAddressResolutionRequired,
    ProposalCreationError,
    ProposalCreationUncertain,
)
from automation.models import PLANNING_TYPES, RuntimeJob


logger = logging.getLogger("architectpro.automation")


class ProgressStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    USER_ACTION_REQUIRED = "user_action_required"


@dataclass(frozen=True, slots=True)
class ProgressEvent:
    stage: str
    status: ProgressStatus
    message: str


@dataclass(frozen=True, slots=True)
class AutomationResult:
    outcome: str
    job_id: str
    application_type: str
    message: str
    last_stage: str
    timings: Mapping[str, float] = field(default_factory=dict)
    technical_details: str = ""
    error_code: str | None = None
    error_headline: str = ""
    stage_description: str = ""
    progression_message: str = ""
    next_action: str = ""
    recovery_action: str = "close"
    retry_safe: bool = False
    failure_category: str = ""
    recovery_fields: tuple[str, ...] = ()
    address_correction_postcode: str = ""
    fresh_retry_job_id: str = ""
    browser_session_id: str | None = None


class CancellationToken:
    def __init__(self) -> None:
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self.cancelled:
            raise AutomationCancelled("Automation cancelled")


class AutomationCancelled(RuntimeError):
    pass


def domain_error(error: Exception) -> tuple[str, str]:
    if isinstance(error, BrowserComponentError):
        return error.user_message, "BROWSER_COMPONENT_STARTUP_FAILED"
    text = str(error or "").lower()
    if any(token in text for token in ("invalid session id", "devtools", "browser has closed", "disconnected")):
        return "The browser connection was interrupted. No further portal actions were taken.", "BROWSER_CONNECTION_INTERRUPTED"
    if any(token in text for token in ("incorrect password", "invalid password", "authentication", "authenticated", "could not sign in", "login failed", "credentials", "portal login")):
        return "Architect Pro could not sign in to eDevelopment. Update the saved login and try again.", "AUTHENTICATION_FAILED"
    if isinstance(error, ProposalCreationError) and any(
        token in str(getattr(error, "step", "")).lower()
        for token in ("address", "postcode")
    ):
        return "Architect Pro could not safely resolve the property address returned by the portal.", "ADDRESS_RESOLUTION_FAILED"
    if any(token in text for token in ("net::err_", "name not resolved", "connection reset", "connection refused", "network")):
        return "Architect Pro lost its connection to the portal. No further portal actions were taken.", "NETWORK_INTERRUPTED"
    if any(token in text for token in ("location plan", "supporting document", "upload", "document set")):
        return "The portal did not confirm a supporting document upload, so Architect Pro stopped before continuing.", "DOCUMENT_UPLOAD_FAILED"
    if any(token in text for token in ("type of work", "typeofwork", "type_of_work")):
        return "Select at least one type of work before running the application.", "TYPE_OF_WORK_REQUIRED"
    if any(token in text for token in ("applicant", "client title", "client first name", "client last name")):
        return "Architect Pro needs the applicant information before it can continue.", "APPLICANT_DATA_INVALID"
    if any(token in text for token in ("agent first name", "agent last name", "agent email", "agent address", "practice name")):
        return "Architect Pro needs the practice or agent information before it can continue.", "AGENT_DATA_INVALID"
    if any(token in text for token in ("site postcode", "site address", "property postcode")):
        return "Architect Pro needs the saved site information before it can continue.", "SITE_DATA_INVALID"
    if "timeout" in text or "timed out" in text:
        return "The portal took too long to confirm the current step. No further portal actions were taken.", "PORTAL_TIMEOUT"
    if any(token in text for token in ("not recognised", "not recognized", "unexpected page", "portal structure may have changed")):
        return "Architect Pro reached a portal page it did not recognise and stopped rather than entering information in the wrong place.", "UNEXPECTED_PORTAL_PAGE"
    if "did not confirm" in text:
        return "The portal did not confirm the current step. No further portal actions were taken.", "PORTAL_CONFIRMATION_FAILED"
    if isinstance(error, ValueError):
        return str(error), "JOB_CONFIGURATION_ERROR"
    return "Automation stopped before the portal confirmed completion. Review technical details before retrying.", "AUTOMATION_FAILED"


@dataclass(frozen=True, slots=True)
class FailureDetails:
    category: str
    stage: str
    headline: str
    stage_description: str
    progression_message: str
    next_action: str
    recovery_action: str
    retry_safe: bool
    recovery_fields: tuple[str, ...]


def describe_failure(error: Exception, stage: str) -> FailureDetails:
    _message, code = domain_error(error)
    stage_labels = {
        "validation": "Validating the prepared application",
        "browser": "Starting the secure browser",
        "login": "Signing in to eDevelopment",
        "proposal": "Creating the portal proposal",
        "address_selection": "Selecting the property address",
        "applicant_details": "Completing applicant details",
        "agent_details": "Completing agent details",
        "main_details": "Completing application details",
        "ownership": "Completing ownership information",
        "documents": "Uploading supporting documents",
        "declaration": "Completing the declaration",
        "fee": "Opening the fee page",
    }
    presentations = {
        "AUTHENTICATION_FAILED": (
            "Couldn't sign in to eDevelopment",
            "The application did not progress beyond sign-in.",
            "Update the saved login, then try again.",
            "update_login",
        ),
        "ADDRESS_RESOLUTION_FAILED": (
            "Property address could not be resolved",
            "Architect Pro stopped rather than selecting the wrong property.",
            "Review the saved project address and start a new safe attempt.",
            "review_address",
        ),
        "PORTAL_TIMEOUT": (
            "The portal stopped responding",
            "The portal may have accepted the previous action. Architect Pro stopped to avoid repeating it.",
            "Review the current portal state before attempting the action again.",
            "close",
        ),
        "DOCUMENT_UPLOAD_FAILED": (
            "Supporting documents need review",
            "The document set may be incomplete. Architect Pro stopped before continuing.",
            "Review the project documents before starting another attempt.",
            "review_documents",
        ),
        "TYPE_OF_WORK_REQUIRED": (
            "Type of work required",
            "No portal application action was performed.",
            "Select at least one type of work, then start a new safe attempt.",
            "review_type_of_work",
        ),
        "APPLICANT_DATA_INVALID": (
            "Applicant information required",
            "No portal application action was performed.",
            "Correct the applicant information, then start a new safe attempt.",
            "review_applicant",
        ),
        "AGENT_DATA_INVALID": (
            "Agent information required",
            "No portal application action was performed.",
            "Correct the practice or agent information, then start a new safe attempt.",
            "review_agent",
        ),
        "SITE_DATA_INVALID": (
            "Site information required",
            "No portal application action was performed.",
            "Correct the site information, then start a new safe attempt.",
            "review_site",
        ),
        "UNEXPECTED_PORTAL_PAGE": (
            "The portal changed unexpectedly",
            "The current portal state is not known, so Architect Pro did not continue.",
            "Review the portal state and technical details before starting again.",
            "close",
        ),
        "NETWORK_INTERRUPTED": (
            "Connection lost",
            "The portal state could not be confirmed after the connection was interrupted.",
            "Check the internet connection, then review the portal before retrying.",
            "close",
        ),
        "BROWSER_CONNECTION_INTERRUPTED": (
            "Secure browser connection was interrupted",
            "The current portal state could not be confirmed after the browser disconnected.",
            "Review the portal state and technical details before starting again.",
            "close",
        ),
        "PORTAL_CONFIRMATION_FAILED": (
            "The portal did not confirm the last step",
            "The portal may have accepted the previous action. Architect Pro stopped to avoid repeating it.",
            "Review the current portal state before attempting the action again.",
            "close",
        ),
        "BROWSER_COMPONENT_STARTUP_FAILED": (
            "Secure browser could not start",
            "No portal application action was performed.",
            "Close other browser setup tasks and try again.",
            "retry",
        ),
        "JOB_CONFIGURATION_ERROR": (
            "Prepared application needs attention",
            "No portal application action was performed.",
            "Correct the prepared application or login details, then try again.",
            "retry",
        ),
    }
    headline, progression, next_action, action = presentations.get(code, (
        "Application automation stopped",
        "The portal may have partially progressed. Architect Pro stopped rather than repeat an unconfirmed action.",
        "Review the technical details and current portal state before trying again.",
        "close",
    ))
    uncertain = isinstance(error, ProposalCreationUncertain) or bool(
        getattr(error, "confirmation_required", False)
    )
    inferred_stage = {
        "AUTHENTICATION_FAILED": "login",
        "ADDRESS_RESOLUTION_FAILED": "address_selection",
        "DOCUMENT_UPLOAD_FAILED": "documents",
        "TYPE_OF_WORK_REQUIRED": "main_details",
        "APPLICANT_DATA_INVALID": "applicant_details",
        "AGENT_DATA_INVALID": "agent_details",
        "SITE_DATA_INVALID": "address_selection",
    }.get(code, stage)
    safe_before_portal_action = inferred_stage in {"validation", "browser", "login"}
    controlled_address_failure = (
        code == "ADDRESS_RESOLUTION_FAILED"
        and isinstance(error, ProposalCreationError)
        and bool(getattr(error, "retryable", False))
        and not bool(getattr(error, "confirmation_required", False))
    )
    fixable_canonical_failure = code in {
        "TYPE_OF_WORK_REQUIRED",
        "APPLICANT_DATA_INVALID",
        "AGENT_DATA_INVALID",
        "SITE_DATA_INVALID",
    } and stage == "validation"
    fixable_login_failure = code == "AUTHENTICATION_FAILED" and inferred_stage in {"validation", "login"}
    retry_safe = not uncertain and (
        (action == "retry" and safe_before_portal_action)
        or controlled_address_failure
        or fixable_canonical_failure
        or fixable_login_failure
    )
    if action == "retry" and not retry_safe:
        action = "review_portal"
    recovery_fields = {
        "ADDRESS_RESOLUTION_FAILED": ("buildingNumber", "addressLine1", "townCity", "postcode"),
        "SITE_DATA_INVALID": ("buildingNumber", "addressLine1", "townCity", "postcode"),
        "APPLICANT_DATA_INVALID": ("title", "firstName", "lastName", "email", "phone"),
        "AGENT_DATA_INVALID": ("practiceName", "agentFirstName", "agentLastName", "agentEmail", "agentPhone"),
        "TYPE_OF_WORK_REQUIRED": ("typeOfWorkKeys",),
    }.get(code, ())
    return FailureDetails(
        category=code,
        stage=inferred_stage,
        headline=headline,
        stage_description=stage_labels.get(
            inferred_stage,
            inferred_stage.replace("_", " ").title(),
        ),
        progression_message=progression,
        next_action=next_action,
        recovery_action=action,
        retry_safe=retry_safe,
        recovery_fields=recovery_fields,
    )


ProgressCallback = Callable[[ProgressEvent], None]
Workflow = Callable[..., Any]


def _workflow_for(application_type: str) -> Workflow:
    if application_type in PLANNING_TYPES:
        from automation.householder.run import main as workflow
        return workflow
    from automation.building_warrant.run import main as workflow
    return workflow


def run_automation(
    job_snapshot: RuntimeJob | Mapping[str, Any],
    *,
    browser_mode: BrowserMode | str = BrowserMode.AUTO,
    progress_callback: ProgressCallback | None = None,
    cancellation_token: CancellationToken | None = None,
    password: str = "",
    driver_factory: Callable[[BrowserMode], Any] = create_managed_chrome,
    workflow_registry: Mapping[str, Workflow] | None = None,
    address_resolution_callback: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
    applicant_title_resolution_callback: Callable[[Mapping[str, Any]], Mapping[str, Any]] | None = None,
) -> AutomationResult:
    """Validate and execute one frozen job without importing any GUI module."""
    job = job_snapshot if isinstance(job_snapshot, RuntimeJob) else RuntimeJob.from_mapping(job_snapshot)
    token = cancellation_token or CancellationToken()
    mode = BrowserMode.parse(browser_mode)
    recorder = PerformanceRecorder()
    last_stage = "validation"
    stage_started: dict[str, float] = {}

    def emit(stage: str, status: ProgressStatus | str, message: str) -> None:
        nonlocal last_stage
        status = ProgressStatus(status)
        last_stage = stage
        if status is ProgressStatus.RUNNING:
            stage_started.setdefault(stage, time.perf_counter())
        elif stage in stage_started:
            recorder.timings[f"stage_{stage}"] = round(time.perf_counter() - stage_started.pop(stage), 4)
        if progress_callback:
            progress_callback(ProgressEvent(stage, status, message))
        if status is ProgressStatus.RUNNING:
            token.raise_if_cancelled()

    managed = None
    succeeded = False
    handed_off = False

    def resolve_address(request):
        if address_resolution_callback is None:
            return None
        emit(
            "address_selection",
            ProgressStatus.USER_ACTION_REQUIRED,
            "Select the correct property address to continue.",
        )
        logger.info(
            "automation_user_action workflow=%s stage=address_selection state=paused",
            job.application_type,
        )
        response = dict(address_resolution_callback(request) or {})
        if response.get("action") == "cancel":
            raise AutomationCancelled("Address resolution cancelled")
        emit(
            "address_selection",
            ProgressStatus.RUNNING,
            "Address confirmed. Continuing automation.",
        )
        logger.info(
            "automation_user_action workflow=%s stage=address_selection state=resumed action=%s",
            job.application_type,
            response.get("action"),
        )
        return response

    def resolve_applicant_title(request):
        if applicant_title_resolution_callback is None:
            return None
        emit(
            "applicant_details",
            ProgressStatus.USER_ACTION_REQUIRED,
            "Applicant title required to continue.",
        )
        logger.info(
            "automation_user_action workflow=%s stage=applicant_details state=paused",
            job.application_type,
        )
        response = dict(applicant_title_resolution_callback(request) or {})
        if response.get("action") == "cancel":
            raise AutomationCancelled("Applicant title selection cancelled")
        emit(
            "applicant_details",
            ProgressStatus.RUNNING,
            "Applicant title confirmed. Continuing automation.",
        )
        logger.info(
            "automation_user_action workflow=%s stage=applicant_details state=resumed",
            job.application_type,
        )
        return response

    try:
        with recorder.stage("snapshot_validation"):
            emit("validation", ProgressStatus.RUNNING, "Validating prepared job")
            inputs = job.mutable_inputs()
            mapping = job.mutable_document_mapping()
            if not inputs.get("Email"):
                raise ValueError("Portal login email is not configured on this machine.")
            if not password:
                raise ValueError("Portal login password is not configured on this machine.")
            if mode is BrowserMode.HEADLESS and workflow_registry is None:
                raise ValueError(
                    "HEADLESS cannot reveal the prepared application for review. Use AUTO for production or VISIBLE for troubleshooting."
                )
            emit("validation", ProgressStatus.COMPLETED, "Prepared job validated")

        with recorder.stage("browser_startup"):
            emit("browser", ProgressStatus.RUNNING, "Starting browser")
            managed = driver_factory(mode)
            if hasattr(managed, "bind_to_job"):
                managed.bind_to_job(job.job_id)
            driver = managed.start() if hasattr(managed, "start") else managed
            emit("browser", ProgressStatus.COMPLETED, "Browser started")

        workflow = (workflow_registry or {}).get(job.application_type) or _workflow_for(job.application_type)
        with recorder.stage("workflow"):
            emit("workflow", ProgressStatus.RUNNING, f"Running {job.application_type}")
            workflow_result = workflow(
                user_inputs=inputs,
                password=password,
                driver=driver,
                document_mapping=mapping,
                progress=emit,
                cancellation_token=token,
                address_resolution_callback=(
                    resolve_address if address_resolution_callback is not None else None
                ),
                applicant_title_resolution_callback=(
                    resolve_applicant_title
                    if applicant_title_resolution_callback is not None
                    else None
                ),
            )
            emit("workflow", ProgressStatus.COMPLETED, "Automated preparation complete")
        if isinstance(workflow_result, UserActionRequired):
            if not hasattr(managed, "handoff_to_user"):
                raise RuntimeError("The managed browser cannot perform the Fee handoff.")
            managed.handoff_to_user()
            handed_off = True
            emit(workflow_result.stage, ProgressStatus.USER_ACTION_REQUIRED, workflow_result.message)
            timings = recorder.finish()
            return AutomationResult(
                "user_action_required",
                job.job_id,
                job.application_type,
                workflow_result.message,
                workflow_result.stage,
                timings,
                browser_session_id=getattr(getattr(managed, "driver", None), "session_id", None),
            )
        if not hasattr(managed, "handoff_to_user"):
            raise RuntimeError("The managed browser cannot reveal the prepared application.")
        managed.handoff_to_user()
        handed_off = True
        succeeded = True
        timings = recorder.finish()
        return AutomationResult(
            "success",
            job.job_id,
            job.application_type,
            "Application prepared",
            "final_review",
            timings,
            browser_session_id=getattr(getattr(managed, "driver", None), "session_id", None),
        )
    except ManualAddressResolutionRequired as exc:
        if not hasattr(managed, "handoff_to_user"):
            raise RuntimeError("The managed browser cannot reveal the current address page.") from exc
        managed.handoff_to_user()
        handed_off = True
        emit("address_selection", ProgressStatus.USER_ACTION_REQUIRED, str(exc).split(" Retry:", 1)[0].split(": ", 1)[-1])
        timings = recorder.finish()
        return AutomationResult(
            "user_action_required",
            job.job_id,
            job.application_type,
            "Resolve the property address in the browser. Architect Pro has paused portal interaction.",
            "address_selection",
            timings,
            browser_session_id=getattr(getattr(managed, "driver", None), "session_id", None),
        )
    except AutomationCancelled as exc:
        timings = recorder.finish()
        emit(last_stage, ProgressStatus.CANCELLED, str(exc))
        return AutomationResult("cancelled", job.job_id, job.application_type, str(exc), last_stage, timings)
    except Exception as exc:
        timings = recorder.finish()
        message, error_code = domain_error(exc)
        details = describe_failure(exc, last_stage)
        emit(details.stage, ProgressStatus.FAILED, message)
        logger.error(
            "automation_failure workflow=%s stage=%s category=%s exception=%s "
            "checkpoint=%s outcome=%s retry_safety=%s",
            job.application_type,
            details.stage,
            details.category,
            type(exc).__name__,
            last_stage,
            "known" if details.retry_safe else "uncertain_or_not_retryable",
            "safe" if details.retry_safe else "blocked",
        )
        return AutomationResult(
            "failure",
            job.job_id,
            job.application_type,
            message,
            last_stage,
            timings,
            traceback.format_exc(),
            error_code,
            details.headline,
            details.stage_description,
            details.progression_message,
            details.next_action,
            details.recovery_action,
            details.retry_safe,
            details.category,
            details.recovery_fields,
            getattr(exc, "corrected_postcode", ""),
        )
    finally:
        if managed is not None and hasattr(managed, "close"):
            managed.close(preserve_visible=handed_off or (succeeded and mode is BrowserMode.VISIBLE))

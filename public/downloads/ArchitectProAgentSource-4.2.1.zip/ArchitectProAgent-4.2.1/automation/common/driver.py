# -*- coding: utf-8 -*-
import ctypes
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from .runtime import SCRIPT_DIR
from .browser_mode import BrowserMode
from .storage import app_data_dir
from .window_control import OwnedChromeWindow


_HANDED_OFF_BROWSERS = {}
_HANDED_OFF_BROWSERS_BY_JOB = {}
_DRIVER_VERSION_PATTERN = re.compile(r"ChromeDriver\s+(\d+(?:\.\d+){1,3})", re.IGNORECASE)


class BrowserComponentError(RuntimeError):
    """Clean Agent-facing browser startup failure with a chained technical cause."""

    user_message = "Architect Pro couldn't start its browser automation component."

    def __init__(self):
        super().__init__(self.user_message)


class DriverResolutionError(RuntimeError):
    pass


class DriverCacheLockedError(DriverResolutionError):
    pass


@dataclass(frozen=True)
class DriverResolution:
    path: str
    source: str
    browser_version: str | None
    driver_version: str | None
    acquired: bool = False


def _version_major(version):
    match = re.match(r"\s*(\d+)", str(version or ""))
    return int(match.group(1)) if match else None


def _windows_file_version(path):
    """Read a Windows executable version without launching it."""
    if os.name != "nt":
        return None

    class VS_FIXEDFILEINFO(ctypes.Structure):
        _fields_ = [
            ("dwSignature", ctypes.c_uint32), ("dwStrucVersion", ctypes.c_uint32),
            ("dwFileVersionMS", ctypes.c_uint32), ("dwFileVersionLS", ctypes.c_uint32),
            ("dwProductVersionMS", ctypes.c_uint32), ("dwProductVersionLS", ctypes.c_uint32),
            ("dwFileFlagsMask", ctypes.c_uint32), ("dwFileFlags", ctypes.c_uint32),
            ("dwFileOS", ctypes.c_uint32), ("dwFileType", ctypes.c_uint32),
            ("dwFileSubtype", ctypes.c_uint32), ("dwFileDateMS", ctypes.c_uint32),
            ("dwFileDateLS", ctypes.c_uint32),
        ]

    size = ctypes.windll.version.GetFileVersionInfoSizeW(str(path), None)
    if not size:
        return None
    buffer = ctypes.create_string_buffer(size)
    if not ctypes.windll.version.GetFileVersionInfoW(str(path), 0, size, buffer):
        return None
    value = ctypes.c_void_p()
    value_size = ctypes.c_uint()
    if not ctypes.windll.version.VerQueryValueW(buffer, "\\", ctypes.byref(value), ctypes.byref(value_size)):
        return None
    info = ctypes.cast(value, ctypes.POINTER(VS_FIXEDFILEINFO)).contents
    return ".".join(str(part) for part in (
        info.dwFileVersionMS >> 16,
        info.dwFileVersionMS & 0xFFFF,
        info.dwFileVersionLS >> 16,
        info.dwFileVersionLS & 0xFFFF,
    ))


def installed_chrome_version():
    candidates = [
        Path(os.environ.get("PROGRAMFILES", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", "")) / "Google/Chrome/Application/chrome.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe",
    ]
    for candidate in candidates:
        if candidate.is_file():
            version = _windows_file_version(candidate)
            if version:
                return version
    return None


def chromedriver_version(path):
    creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    completed = subprocess.run(
        [str(path), "--version"],
        capture_output=True,
        text=True,
        timeout=10,
        check=False,
        creationflags=creation_flags,
    )
    match = _DRIVER_VERSION_PATTERN.search(f"{completed.stdout}\n{completed.stderr}")
    return match.group(1) if match else None


def _is_cache_lock(error):
    return isinstance(error, PermissionError) or getattr(error, "winerror", None) in {5, 32, 33}


def _is_version_mismatch(error):
    text = str(error or "").lower()
    return "only supports chrome version" in text or (
        "session not created" in text and "chrome version" in text
    )


class ChromeDriverResolver:
    """Resolve immutable compatible drivers; acquire into an isolated cache once."""

    def __init__(
        self,
        *,
        browser_version_provider=installed_chrome_version,
        version_reader=chromedriver_version,
        packaged_candidates=None,
        owned_cache_root=None,
        shared_cache_root=None,
        acquirer=None,
    ):
        self.browser_version_provider = browser_version_provider
        self.version_reader = version_reader
        self.packaged_candidates = packaged_candidates
        self.owned_cache_root = Path(owned_cache_root or Path(app_data_dir()) / "drivers/chromedriver")
        self.shared_cache_root = Path(shared_cache_root or Path.home() / ".wdm/drivers/chromedriver")
        self.acquirer = acquirer or self._acquire_with_webdriver_manager
        self._acquisition_attempted = False

    def _packaged_paths(self):
        if self.packaged_candidates is not None:
            return [Path(path) for path in self.packaged_candidates]
        paths = [Path(get_local_chromedriver_path())]
        bundle_root = getattr(sys, "_MEIPASS", None)
        if bundle_root:
            paths.append(Path(bundle_root) / "chromedriver.exe")
        return paths

    @staticmethod
    def _cached_paths(root):
        if not root.is_dir():
            return []
        return sorted(root.rglob("chromedriver.exe"), key=lambda path: path.stat().st_mtime, reverse=True)

    def _existing_candidates(self):
        seen = set()
        groups = (
            ("packaged", self._packaged_paths()),
            ("architect-pro-cache", self._cached_paths(self.owned_cache_root)),
            ("shared-cache", self._cached_paths(self.shared_cache_root)),
        )
        for source, paths in groups:
            for path in paths:
                normalized = os.path.normcase(os.path.abspath(path))
                if normalized not in seen and path.is_file():
                    seen.add(normalized)
                    yield source, path

    def resolve(self, *, force_acquire=False):
        browser_version = self.browser_version_provider()
        browser_major = _version_major(browser_version)
        if not force_acquire:
            for source, path in self._existing_candidates():
                try:
                    driver_version = self.version_reader(path)
                except OSError as exc:
                    if _is_cache_lock(exc):
                        continue
                    raise DriverResolutionError(f"Could not inspect ChromeDriver '{path}': {exc}") from exc
                if driver_version and (browser_major is None or _version_major(driver_version) == browser_major):
                    print(f"Using {source} ChromeDriver {driver_version}: {path}")
                    return DriverResolution(str(path), source, browser_version, driver_version)
        return self._acquire(browser_version)

    def _acquire(self, browser_version):
        if self._acquisition_attempted:
            raise DriverResolutionError("ChromeDriver acquisition was already attempted for this startup.")
        self._acquisition_attempted = True
        self.owned_cache_root.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix=".acquire-", dir=self.owned_cache_root))
        try:
            acquired = Path(self.acquirer(browser_version, staging))
            driver_version = self.version_reader(acquired)
            if not driver_version:
                raise DriverResolutionError(f"The acquired ChromeDriver version could not be read: {acquired}")
            if _version_major(browser_version) not in (None, _version_major(driver_version)):
                raise DriverResolutionError(
                    f"Acquired ChromeDriver {driver_version} is incompatible with Chrome {browser_version}."
                )
            destination_dir = self.owned_cache_root / driver_version
            destination_dir.mkdir(parents=True, exist_ok=True)
            destination = destination_dir / "chromedriver.exe"
            if destination.exists():
                existing_version = self.version_reader(destination)
                if existing_version == driver_version:
                    return DriverResolution(str(destination), "architect-pro-cache", browser_version, driver_version)
                raise DriverCacheLockedError(f"Refusing to replace existing ChromeDriver cache file: {destination}")
            try:
                with acquired.open("rb") as source, destination.open("xb") as target:
                    shutil.copyfileobj(source, target)
            except OSError as exc:
                if _is_cache_lock(exc):
                    raise DriverCacheLockedError(
                        "The Architect Pro ChromeDriver cache is locked by another process."
                    ) from exc
                raise
            print(f"Acquired ChromeDriver {driver_version} into version-specific cache: {destination}")
            return DriverResolution(str(destination), "acquired", browser_version, driver_version, True)
        except DriverResolutionError:
            raise
        except OSError as exc:
            if _is_cache_lock(exc):
                raise DriverCacheLockedError(
                    "The ChromeDriver cache is locked. Architect Pro did not retry or replace the executable."
                ) from exc
            raise DriverResolutionError(f"ChromeDriver acquisition failed: {exc}") from exc
        except Exception as exc:
            raise DriverResolutionError(f"ChromeDriver acquisition failed: {exc}") from exc
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    @staticmethod
    def _acquire_with_webdriver_manager(browser_version, staging):
        from webdriver_manager.chrome import ChromeDriverManager
        from webdriver_manager.core.driver_cache import DriverCacheManager

        # Chrome-for-Testing driver patch versions do not necessarily equal the
        # installed Chrome patch (for example Chrome 150.0.7871.182 uses driver
        # 150.0.7871.124). Let webdriver_manager choose within the installed
        # major, then validate the acquired executable before publishing it.
        del browser_version
        return ChromeDriverManager(
            cache_manager=DriverCacheManager(root_dir=str(staging))
        ).install()


def chrome_options_for_mode(mode=BrowserMode.AUTO):
    mode = BrowserMode.parse(mode)
    options = webdriver.ChromeOptions()
    if mode is BrowserMode.HEADLESS:
        options.add_argument("--headless=new")
    else:
        options.add_experimental_option("detach", True)
        if mode is BrowserMode.AUTO:
            # Minimise launch flash only; Win32 ownership control immediately
            # removes the owned window from the desktop and taskbar.
            options.add_argument("--start-minimized")
    options.add_argument("--window-size=1440,1000")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-default-apps")
    options.add_argument("--no-first-run")
    options.add_argument("--no-default-browser-check")
    options.add_argument("--disable-notifications")
    options.add_experimental_option("prefs", {
        "profile.default_content_setting_values.notifications": 2,
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False,
    })
    return options


def get_local_chromedriver_path():
    """Returns the expected bundled chromedriver path beside SCRIPT_DIR."""
    return os.path.join(SCRIPT_DIR, "chromedriver.exe")


def create_chrome_driver(chrome_options, *, resolver=None):
    """Start an explicitly resolved driver, with one mismatch-only acquisition fallback."""
    resolver = resolver or ChromeDriverResolver()
    try:
        resolution = resolver.resolve()
        try:
            return webdriver.Chrome(service=Service(resolution.path), options=chrome_options)
        except Exception as first_error:
            if resolution.acquired or not _is_version_mismatch(first_error):
                raise
            fallback = resolver.resolve(force_acquire=True)
            return webdriver.Chrome(service=Service(fallback.path), options=chrome_options)
    except Exception as exc:
        raise BrowserComponentError() from exc


class ManagedChrome:
    """Own exactly one driver and never touch unrelated browser processes."""

    def __init__(self, mode=BrowserMode.AUTO, *, window_factory=OwnedChromeWindow):
        self.mode = BrowserMode.parse(mode)
        self.driver = None
        self.window_factory = window_factory
        self.window = None
        self.handed_off = False
        self.job_id = None

    def bind_to_job(self, job_id):
        self.job_id = str(job_id or "").strip() or None
        return self

    def start(self):
        self.driver = create_chrome_driver(chrome_options_for_mode(self.mode))
        self.driver.set_page_load_timeout(60)
        if self.mode is BrowserMode.AUTO:
            self.window = self.window_factory(self.driver)
            self.window.hide()
        elif self.mode is BrowserMode.VISIBLE:
            self.window = self.window_factory(self.driver)
            self.driver.maximize_window()
        return self.driver

    def handoff_to_user(self):
        if self.mode is BrowserMode.HEADLESS or self.window is None:
            raise RuntimeError("HEADLESS mode cannot reveal the prepared application. Use AUTO or VISIBLE.")
        session_id = str(self.driver.session_id)
        self.window.reveal_and_focus()
        if str(self.driver.session_id) != session_id:
            raise RuntimeError("The browser session changed during application handoff.")
        self.handed_off = True
        _HANDED_OFF_BROWSERS[session_id] = self
        if self.job_id:
            _HANDED_OFF_BROWSERS_BY_JOB[self.job_id] = self

    def close(self, *, preserve_visible=False):
        if self.driver is None:
            return
        if preserve_visible or self.handed_off:
            _HANDED_OFF_BROWSERS[str(self.driver.session_id)] = self
            if self.job_id:
                _HANDED_OFF_BROWSERS_BY_JOB[self.job_id] = self
            return
        try:
            self.driver.quit()
        finally:
            self.driver = None
            self.window = None


def create_managed_chrome(mode=BrowserMode.AUTO):
    return ManagedChrome(mode)


def reveal_handed_off_browser(job_id):
    """Focus the exact retained Chrome session for one automation job."""
    managed = _HANDED_OFF_BROWSERS_BY_JOB.get(str(job_id or "").strip())
    if not managed or not managed.handed_off or managed.driver is None:
        raise RuntimeError("The retained application browser is not available.")
    managed.handoff_to_user()
    return str(managed.driver.session_id)

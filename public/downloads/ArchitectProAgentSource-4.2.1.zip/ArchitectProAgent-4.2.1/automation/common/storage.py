"""GUI-independent runtime storage for the local automation agent."""

from __future__ import annotations

import json
import os


APP_VENDOR = "NinetyOneArchitects"
APP_NAME = "Building Portal"
SENSITIVE_FIELD_NAMES = {"Password", "password"}


def app_data_dir() -> str:
    root = os.environ.get("APPDATA") or os.path.expanduser("~")
    folder = os.path.join(root, APP_VENDOR, APP_NAME)
    os.makedirs(folder, exist_ok=True)
    return folder


def runtime_path(filename: str, base_dir: str | None = None) -> str:
    del base_dir
    return os.path.join(app_data_dir(), filename)


def scrub_sensitive_fields(value):
    if isinstance(value, dict):
        return {
            key: scrub_sensitive_fields(child)
            for key, child in value.items()
            if key not in SENSITIVE_FIELD_NAMES
        }
    if isinstance(value, list):
        return [scrub_sensitive_fields(item) for item in value]
    return value


def migrate_json_if_missing(filename, base_dir=None, scrubber=None, log=None):
    modern = runtime_path(filename)
    if os.path.exists(modern) or not base_dir:
        return modern, False
    legacy = os.path.join(base_dir, filename)
    if not os.path.exists(legacy):
        return modern, False
    try:
        with open(legacy, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return modern, False
        with open(modern, "w", encoding="utf-8") as handle:
            json.dump((scrubber or scrub_sensitive_fields)(data), handle, indent=2)
    except (OSError, json.JSONDecodeError) as exc:
        if log:
            log(f"Could not migrate {filename}: {exc}")
        return modern, False
    return modern, True

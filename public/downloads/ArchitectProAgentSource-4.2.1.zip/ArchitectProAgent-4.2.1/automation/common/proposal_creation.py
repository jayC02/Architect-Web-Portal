# -*- coding: utf-8 -*-
import json
import inspect
import os
import re
import time
import unicodedata
from dataclasses import dataclass

from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, is_detached_node_error
from automation.common.runtime import PROPOSAL_STATE_FILE


BUILDING_WARRANT = "Building Warrant"
HOUSEHOLDER = "Householder Application (Planning)"
SUPPORTED_APPLICATION_TYPES = {BUILDING_WARRANT, HOUSEHOLDER}

HOUSEHOLDER_INITIAL_OPTION = "1. Making an application for permissions or consent"
BUILDING_WARRANT_FORM = "Application for Building Warrant"
HOUSEHOLDER_FORM = "Householder Application"

NEW_PROPOSAL_ID = "MainContent_newProposal"
POSTCODE_INPUT_ID = "MainContent_CreateProposalWizard_txtPostcode1"
POSTCODE_SEARCH_ID = "MainContent_CreateProposalWizard_btnPostcodeSearch"
POSTCODE_SEARCH_NAME = "ctl00$MainContent$CreateProposalWizard$btnPostcodeSearch"
REFINE_RESULTS_ID = "MainContent_CreateProposalWizard_btnRefineSearch"
BUILDING_NAME_ID = "MainContent_CreateProposalWizard_txtBuildingName"
BUILDING_NUMBER_ID = "MainContent_CreateProposalWizard_txtBuildingNo"
STREET_ID = "MainContent_CreateProposalWizard_txtStreet"
TOWN_ID = "MainContent_CreateProposalWizard_txtTown"
EXACT_POSTCODE_ID = "MainContent_CreateProposalWizard_txtPostcode2"
EXACT_ADDRESS_SEARCH_ID = "MainContent_CreateProposalWizard_btnAddrSearch"
ADDRESS_RESULTS_ID = "MainContent_CreateProposalWizard_dgAddressResults"
CONFIRM_ADDRESS_ID = "MainContent_CreateProposalWizard_btnConfirmAddr"
LOCAL_AUTHORITY_NEXT_ID = "MainContent_CreateProposalWizard_btnNext2"
PROPOSAL_NAME_ID = "MainContent_CreateProposalWizard_txtProposalName"
PROPOSAL_DETAILS_ID = "MainContent_CreateProposalWizard_txtProposalDetails"
CONFIRM_DETAILS_ID = "MainContent_CreateProposalWizard_btnNext3"
SELECT_FORMS_FROM_LIST_ID = "MainContent_CreateProposalWizard_UseList"
FORM_SELECTION_NEXT_ID = "MainContent_CreateProposalWizard_btnNext4"
ADD_FORMS_ID = "MainContent_CreateProposalWizard_btnAddForms"
CREATE_PROPOSAL_ID = "MainContent_CreateProposalWizard_btnCreate"


class ProposalCreationError(RuntimeError):
    def __init__(self, step, message, *, retryable=True, confirmation_required=False):
        super().__init__(
            f"{step}: {message} Retry: {'yes' if retryable else 'no'}. "
            f"User confirmation required: {'yes' if confirmation_required else 'no'}."
        )
        self.step = step
        self.retryable = retryable
        self.confirmation_required = confirmation_required


class ProposalCreationUncertain(ProposalCreationError):
    pass


class ProposalNameInUse(ProposalCreationError):
    pass


class SavedProposalNotFoundError(ProposalCreationError):
    pass


class ManualAddressResolutionRequired(ProposalCreationError):
    """The user chose to continue address resolution in the owned browser."""

    def __init__(self):
        super().__init__(
            "Address selection",
            "Resolve the property address in the browser. Architect Pro has paused portal interaction.",
            retryable=False,
            confirmation_required=True,
        )


class AddressPostcodeCorrectionRequired(ProposalCreationError):
    """Stop this frozen run so the corrected postcode can seed a fresh job."""

    def __init__(self, postcode):
        self.corrected_postcode = normalise_postcode(postcode)
        super().__init__(
            "Address search",
            "The corrected postcode must be saved to Architect Pro before a fresh automation attempt starts.",
            retryable=True,
        )


@dataclass(frozen=True)
class ProposalContext:
    application_type: str
    site_address: str
    postcode: str
    description: str
    job_key: str
    project_reference: str


@dataclass(frozen=True)
class AddressOption:
    display: str
    element_id: str = ""
    page_number: int = 1
    selection_value: str = ""


@dataclass(frozen=True)
class AddressMatch:
    status: str
    option: AddressOption | None = None
    plausible: tuple[AddressOption, ...] = ()


def address_resolution_request(context, postcode, options):
    """Return GUI-safe candidate data while retaining locators inside this module."""
    candidates = []
    for index, option in enumerate(options):
        postcode_match = re.search(
            r"[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b",
            option.display,
            re.I,
        )
        candidates.append({
            "candidate_id": f"portal-address-{index + 1}",
            "display_text": option.display,
            "address_lines": [
                part.strip()
                for part in str(option.display or "").split(",")
                if part.strip()
            ],
            "postcode": normalise_postcode(postcode_match.group(0)) if postcode_match else "",
        })
    return {
        "stage": "address_selection",
        "project_address": context.site_address,
        "project_postcode": context.postcode,
        "searched_postcode": normalise_postcode(postcode),
        "candidates": candidates,
        "actions": ["select", "change_postcode", "manual", "cancel"],
    }


def _save_proposal_state(state_store, context, reference, proposal_name, portal_address):
    parameters = inspect.signature(state_store.save).parameters
    if "portal_address" in parameters or len(parameters) >= 4:
        state_store.save(context, reference, proposal_name, portal_address)
    else:
        state_store.save(context, reference, proposal_name)


def normalise_postcode(value):
    compact = re.sub(r"\s+", "", str(value or "").upper())
    if len(compact) > 3:
        return f"{compact[:-3]} {compact[-3:]}"
    return compact


def _normalise_address_words(value):
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = re.sub(r"[\s\u00a0\u2007\u202f]+", " ", text).strip().upper()
    text = re.sub(r"[,.;:/\\()'\-]+", " ", text)
    replacements = {
        "RD": "ROAD",
        "ST": "STREET",
        "AVE": "AVENUE",
        "AV": "AVENUE",
        "LN": "LANE",
        "DR": "DRIVE",
        "CT": "COURT",
        "PL": "PLACE",
        "APT": "FLAT",
        "APARTMENT": "FLAT",
    }
    words = [replacements.get(word, word) for word in re.findall(r"[A-Z0-9]+", text)]
    return words


def normalise_address(value):
    return " ".join(_normalise_address_words(value))


def _address_comparison_key(value):
    """Formatting-only comparison; never infer missing or conflicting address text.

    Keep this separate from legacy proposal-name normalization, which is also
    used to recover saved proposals. In particular, flat separators and property
    suffixes are identity, and ST inside a name must not become STREET.
    """
    text = unicodedata.normalize("NFC", str(value or "")).upper().strip()
    suffixes = {
        "RD": "ROAD", "ST": "STREET", "AVE": "AVENUE", "AV": "AVENUE",
        "LN": "LANE", "DR": "DRIVE", "CT": "COURT", "PL": "PLACE",
    }
    # Only expand a suffix at the end of an address line, not inside a name.
    text = re.sub(
        r"(?<=\w)[ \t]+(RD|ST|AVE|AV|LN|DR|CT|PL)\.?(?=[ \t]*(?:,|\r|\n|$))",
        lambda match: " " + suffixes[match.group(1)],
        text,
    )
    text = re.sub(r"[,\s]+", " ", text).strip().rstrip(".").strip()
    postcode = re.search(r"\b([A-Z]{1,2}\d[A-Z\d]?)\s*(\d[A-Z]{2})$", text)
    if not postcode or not text[:postcode.start()].strip():
        return None
    return text[:postcode.start()].rstrip() + " " + " ".join(postcode.groups())


def canonical_site_address(value):
    parts = [re.sub(r"\s+", " ", part).strip() for part in str(value or "").split(",") if part.strip()]
    if len(parts) >= 2:
        building_number = re.match(r"^(\d+[A-Z]?)\b", parts[0], re.I)
        if building_number and parts[1].upper() == building_number.group(1).upper():
            parts.pop(1)
    return ", ".join(parts)


def confirmed_postal_address(body_text):
    match = re.search(r"Postal Address:\s*(.*?)\s*Easting:", str(body_text or ""), re.I | re.S)
    if not match:
        return ""
    address = match.group(1).strip()
    postcode = re.search(r"[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b", address, re.I)
    return address[:postcode.end()].strip() if postcode else address


def page_size_value(value="", element_id="", name=""):
    for candidate in (value, element_id, name):
        text = str(candidate or "").strip()
        if text.isdigit() and int(text) > 0:
            return int(text)
        match = re.search(r"btnPageSize(\d+)$", text, re.I)
        if match and int(match.group(1)) > 0:
            return int(match.group(1))
    return None


def exact_address_fields(site_address, postcode):
    parts = [
        re.sub(r"\s+", " ", part).strip()
        for part in str(site_address or "").split(",")
        if part.strip()
    ]
    normalised_postcode = normalise_postcode(postcode)
    if parts and normalise_postcode(parts[-1]) == normalised_postcode:
        parts.pop()
    if len(parts) < 2 or not normalised_postcode:
        return None

    town = parts.pop()
    street_line = parts.pop()
    street_match = re.fullmatch(r"(\d+[A-Z]?)\s+(.+)", street_line, re.I)
    if not street_match or not town:
        return None
    return {
        "building_name": ", ".join(parts),
        "building_number": street_match.group(1),
        "street": street_match.group(2),
        "town": town,
        "postcode": normalised_postcode,
    }


def _address_parts(value):
    words = _normalise_address_words(value)
    match = re.search(r"[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}\b", str(value or "").upper())
    postcode = normalise_postcode(match.group(0)) if match else ""
    property_numbers = tuple(word for word in words if re.fullmatch(r"\d+[A-Z]?", word))
    unit_markers = []
    for index, word in enumerate(words):
        if word in {"FLAT", "UNIT"} and index + 1 < len(words):
            unit_markers.append(f"{word} {words[index + 1]}")
        if word in {"GROUND", "FIRST", "SECOND", "THIRD"} and index + 1 < len(words) and words[index + 1] == "FLOOR":
            unit_markers.append(f"{word} FLOOR")
    alpha = {word for word in words if len(word) >= 3 and not re.fullmatch(r"\d+", word)}
    return postcode, property_numbers, tuple(unit_markers), alpha


def match_address(site_address, options):
    target = _address_comparison_key(site_address)
    target_postcode, target_numbers, target_units, target_alpha = _address_parts(site_address)
    exact = [
        option for option in options
        if target is not None and _address_comparison_key(option.display) == target
    ]
    if len(exact) == 1:
        return AddressMatch("exact", exact[0])
    if len(exact) > 1:
        return AddressMatch("ambiguous", plausible=tuple(exact))

    # Suggestions are only for the chooser. Even one plausible row is not proof
    # of equivalence and must never bypass explicit user review.
    plausible = []
    for option in options:
        postcode, numbers, units, alpha = _address_parts(option.display)
        if target_postcode and postcode != target_postcode:
            continue
        if target_units and units != target_units:
            continue
        if target_numbers and numbers != target_numbers:
            continue
        shared_street_words = target_alpha.intersection(alpha) - {
            "FLAT", "UNIT", "FLOOR", "SCOTLAND", "UNITED", "KINGDOM",
        }
        if len(shared_street_words) >= 1:
            plausible.append(option)
    if plausible:
        return AddressMatch("ambiguous", plausible=tuple(plausible))
    return AddressMatch("missing")


def build_context(user_inputs, application_type=None):
    selected_type = str(application_type or user_inputs.get("Application Type") or "").strip()
    if selected_type not in SUPPORTED_APPLICATION_TYPES:
        raise ProposalCreationError(
            "Preflight",
            "The application type is missing or unsupported. Choose Building Warrant or Householder Application.",
            retryable=False,
        )
    site_address = canonical_site_address(user_inputs.get("Site Address"))
    postcode = normalise_postcode(user_inputs.get("Site Postcode"))
    description = re.sub(r"\s+", " ", str(user_inputs.get("Description of Work") or "")).strip()
    if not postcode:
        raise ProposalCreationError("Preflight", "A site postcode is required before the proposal can be created.")
    if not re.fullmatch(r"[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}", postcode):
        raise ProposalCreationError("Preflight", "The stored site postcode is not a valid UK postcode.")
    if not site_address:
        raise ProposalCreationError("Preflight", "A full site address is required before the proposal can be created.")
    if not description:
        raise ProposalCreationError(
            "Preflight",
            "Proposal details are required before the eDevelopment proposal can be created.",
        )
    if len(description) > 240:
        raise ProposalCreationError(
            "Preflight",
            "Proposal details exceed the portal's 240 character limit. Shorten the stored work description.",
        )
    job_id = str(user_inputs.get("Automation Job ID") or "").strip()
    project_id = str(user_inputs.get("Project ID") or "").strip()
    application_id = str(user_inputs.get("Application Record ID") or "").strip()
    if not any([job_id, project_id, application_id]):
        raise ProposalCreationError(
            "Preflight",
            "The project or automation-job reference is missing, so duplicate proposal protection cannot run.",
            retryable=False,
        )
    job_key = job_id or ":".join(filter(None, [project_id, selected_type, application_id]))
    return ProposalContext(
        application_type=selected_type,
        site_address=site_address,
        postcode=postcode,
        description=description,
        job_key=job_key,
        project_reference=project_id or application_id or job_id,
    )


class ProposalStateStore:
    def __init__(self, path=PROPOSAL_STATE_FILE):
        self.path = path

    def _read(self):
        if not os.path.exists(self.path):
            return {"jobs": {}}
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            raise ProposalCreationError("Resume", "The saved proposal state could not be read safely.") from exc
        return payload if isinstance(payload, dict) else {"jobs": {}}

    def get(self, context):
        state = (self._read().get("jobs") or {}).get(context.job_key)
        if not isinstance(state, dict):
            return None
        if state.get("applicationType") != context.application_type:
            return None
        if normalise_address(state.get("siteAddress")) != normalise_address(context.site_address):
            return None
        return state

    def save(self, context, proposal_reference, proposal_name, portal_address=""):
        payload = self._read()
        jobs = payload.setdefault("jobs", {})
        jobs[context.job_key] = {
            "proposalReference": str(proposal_reference),
            "proposalName": str(proposal_name),
            "applicationType": context.application_type,
            "siteAddress": context.site_address,
            "resolvedPortalAddress": str(portal_address or proposal_name),
            "projectReference": context.project_reference,
            "updatedAt": time.time(),
        }
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        temporary = f"{self.path}.tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        os.replace(temporary, self.path)

    def clear(self, context, proposal_reference):
        payload = self._read()
        jobs = payload.get("jobs") or {}
        state = jobs.get(context.job_key)
        if not isinstance(state, dict) or str(state.get("proposalReference") or "") != str(proposal_reference):
            return False
        del jobs[context.job_key]
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        temporary = f"{self.path}.tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(payload, handle)
        os.replace(temporary, self.path)
        return True


def _visible_text(element):
    return re.sub(r"\s+", " ", str(element.text or element.get_attribute("value") or "")).strip()


class SeleniumProposalPortal:
    def __init__(self, driver, application_type, timeout=30):
        self.driver = driver
        self.application_type = application_type
        self.timeout = timeout

    def _wait(self, condition, timeout=None):
        return WebDriverWait(self.driver, timeout or self.timeout, poll_frequency=0.2).until(condition)

    def _session_active(self):
        url = (self.driver.current_url or "").lower()
        if "login.aspx" in url:
            raise ProposalCreationError("Session", "The portal session expired. Sign in again, then retry.")

    def _click_id(self, element_id, step):
        self._session_active()
        try:
            return click_when_clickable(
                self.driver,
                By.ID,
                element_id,
                timeout=self.timeout,
            )
        except TimeoutException as exc:
            raise ProposalCreationError(step, f"The expected portal control '{element_id}' was not found. The portal structure may have changed.") from exc

    def _wait_postback(self, old_element, condition, step):
        def target_state(driver):
            self._session_active()
            try:
                return bool(condition(driver))
            except WebDriverException as exc:
                if is_detached_node_error(exc):
                    return False
                raise

        try:
            self._wait(target_state)
        except TimeoutException as exc:
            raise ProposalCreationError(step, "The portal did not finish updating after the action.") from exc

    def open_new_proposal(self):
        self._click_id(NEW_PROPOSAL_ID, "Create New Proposal")
        if self.application_type == HOUSEHOLDER:
            self._wait(lambda driver: bool(driver.find_elements(By.ID, POSTCODE_INPUT_ID)) or any(
                _visible_text(label) == HOUSEHOLDER_INITIAL_OPTION
                for label in driver.find_elements(By.CSS_SELECTOR, "label")
            ))
            if not self.driver.find_elements(By.ID, POSTCODE_INPUT_ID):
                self._select_householder_initial_category()
            return
        try:
            self._wait(EC.presence_of_element_located((By.ID, POSTCODE_INPUT_ID)))
        except TimeoutException as exc:
            raise ProposalCreationError("Create New Proposal", "The postcode stage did not open. The portal structure may have changed.") from exc

    def _select_householder_initial_category(self):
        label = self._find_exact_label(HOUSEHOLDER_INITIAL_OPTION, "Householder category")
        control_id = label.get_attribute("for")
        label.click()

        def category_selected_or_postcode(driver):
            if driver.find_elements(By.ID, POSTCODE_INPUT_ID):
                return True
            controls = driver.find_elements(By.ID, control_id)
            if not controls:
                return False
            try:
                return controls[0].is_selected()
            except WebDriverException as exc:
                if is_detached_node_error(exc):
                    return False
                raise

        try:
            self._wait(category_selected_or_postcode, timeout=5)
        except TimeoutException as exc:
            raise ProposalCreationError("Householder category", "The required permissions-or-consent option could not be confirmed.") from exc
        if self.driver.find_elements(By.ID, POSTCODE_INPUT_ID):
            return
        candidates = self.driver.find_elements(
            By.CSS_SELECTOR,
            "[id^='MainContent_CreateProposalWizard_'] input[type='submit'], input[id^='MainContent_CreateProposalWizard_'][type='submit']",
        )
        next_buttons = [item for item in candidates if _visible_text(item) in {"Next", "Continue", "Select"}]
        if len(next_buttons) != 1:
            raise ProposalCreationError("Householder category", "The category continuation control could not be identified safely.")
        old = next_buttons[0]
        old.click()
        self._wait_postback(old, lambda driver: bool(driver.find_elements(By.ID, POSTCODE_INPUT_ID)), "Householder category")

    def search_postcode(self, postcode):
        try:
            field = self._wait(EC.presence_of_element_located((By.ID, POSTCODE_INPUT_ID)))
        except TimeoutException as exc:
            raise ProposalCreationError("Postcode search", "The postcode input was not found.") from exc
        field.clear()
        field.send_keys(postcode)
        buttons = self.driver.find_elements(By.ID, POSTCODE_SEARCH_ID)
        if not buttons:
            buttons = self.driver.find_elements(By.NAME, POSTCODE_SEARCH_NAME)
        if not buttons:
            raise ProposalCreationError("Postcode search", "The Postcode Search control was not found.")
        old = buttons[0]
        old.click()
        self._wait_postback(
            old,
            lambda driver: bool(driver.find_elements(By.ID, ADDRESS_RESULTS_ID))
            or "no address" in driver.page_source.lower()
            or "validation" in driver.page_source.lower(),
            "Postcode search",
        )

    def read_addresses(self):
        tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
        if not tables:
            page = self.driver.page_source.lower()
            if "no address" in page or "no result" in page:
                return []
            raise ProposalCreationError("Address results", "The postcode search result state was not recognised. The portal structure may have changed.")
        options = []
        for row in tables[0].find_elements(By.CSS_SELECTOR, "tr"):
            buttons = row.find_elements(By.CSS_SELECTOR, "input[name*='$lnkBtnAddress']")
            if not buttons:
                continue
            button = buttons[0]
            button_text = re.sub(r"\s+", " ", str(button.get_attribute("value") or "")).strip()
            cells = [re.sub(r"\s+", " ", cell.text).strip() for cell in row.find_elements(By.CSS_SELECTOR, "td")]
            parts = [button_text] + [part for part in cells if part and part != button_text]
            display = ", ".join(part for part in parts if part)
            options.append(AddressOption(
                display=display,
                element_id=button.get_attribute("id") or "",
                selection_value=button_text,
            ))
        return options

    def collect_address_options(self, site_address):
        values, selected_size, already_active = self._select_largest_page_size()
        if values:
            print(f"Address search page sizes: {', '.join(str(value) for value in values)}.")
            print(
                f"Address search maximum page size: {selected_size} "
                f"({'already active' if already_active else 'selected'})."
            )

        all_options = []
        seen_signatures = set()
        visited_numeric_pages = {1}
        pages_inspected = 0
        self._address_results_page = 1

        while True:
            signature = self._results_table_signature()
            if signature in seen_signatures:
                raise ProposalCreationError(
                    "Address results", "The result pages repeated before all candidates could be checked safely."
                )
            seen_signatures.add(signature)
            pages_inspected += 1

            current_options = [
                AddressOption(option.display, option.element_id, self._address_results_page, option.selection_value)
                for option in self.read_addresses()
            ]
            # Do not collapse separate portal rows with identical labels: they
            # are ambiguous candidates, not proof of a unique property.
            all_options.extend(current_options)

            outcome = match_address(site_address, all_options)
            next_control, next_page_number = self._next_result_page_control(visited_numeric_pages)
            if next_control is None:
                print(
                    f"Address search inspected {pages_inspected} page(s) and "
                    f"{len(all_options)} row(s); match outcome: {outcome.status}."
                )
                return all_options, outcome
            if next_page_number is not None:
                visited_numeric_pages.add(next_page_number)
            self._click_results_refresh(next_control, "Address results pagination")
            self._address_results_page = next_page_number or self._address_results_page + 1

    def exact_address_search(self, site_address, postcode):
        fields = exact_address_fields(site_address, postcode)
        if fields is None:
            return False

        old = self._click_id(REFINE_RESULTS_ID, "Exact address search")
        self._wait_postback(
            old,
            lambda driver: bool(driver.find_elements(By.ID, EXACT_ADDRESS_SEARCH_ID)),
            "Exact address search",
        )
        for field_id, key in (
            (BUILDING_NAME_ID, "building_name"),
            (BUILDING_NUMBER_ID, "building_number"),
            (STREET_ID, "street"),
            (TOWN_ID, "town"),
            (EXACT_POSTCODE_ID, "postcode"),
        ):
            element = self.driver.find_element(By.ID, field_id)
            element.clear()
            if fields[key]:
                element.send_keys(fields[key])

        old = self._click_id(EXACT_ADDRESS_SEARCH_ID, "Exact address search")
        self._wait_postback(
            old,
            lambda driver: bool(driver.find_elements(By.ID, ADDRESS_RESULTS_ID))
            or "no address" in driver.find_element(By.TAG_NAME, "body").text.lower(),
            "Exact address search",
        )
        print("Address search used the portal's exact-address fallback.")
        return True

    def _page_size_controls(self):
        selector = (
            "input[type='submit'][id^='MainContent_CreateProposalWizard_btnPageSize'], "
            "input[type='submit'][name^='ctl00$MainContent$CreateProposalWizard$btnPageSize']"
        )
        controls = []
        seen = set()
        for element in self.driver.find_elements(By.CSS_SELECTOR, selector):
            identity = element.get_attribute("id") or element.get_attribute("name") or id(element)
            if identity in seen:
                continue
            seen.add(identity)
            size = page_size_value(
                element.get_attribute("value"),
                element.get_attribute("id"),
                element.get_attribute("name"),
            )
            if size is not None:
                controls.append((size, element))
        return controls

    def _select_largest_page_size(self):
        controls = self._page_size_controls()
        if not controls:
            return [], None, False
        values = sorted({size for size, _element in controls})
        maximum = max(values)
        maximum_controls = [element for size, element in controls if size == maximum]
        if len(maximum_controls) != 1:
            raise ProposalCreationError("Address results", "The largest address page-size control was not unique.")
        control = maximum_controls[0]
        already_active = not control.is_enabled() or control.get_attribute("disabled") is not None
        if not already_active:
            self._click_results_refresh(control, "Address results page size")
        return values, maximum, already_active

    def _results_table_signature(self):
        for _attempt in range(3):
            tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
            if not tables:
                return "missing"
            try:
                return normalise_address(tables[0].text)
            except StaleElementReferenceException:
                continue
        return None

    def _click_results_refresh(self, control, step):
        tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
        old_table = tables[0] if tables else None
        old_signature = self._results_table_signature()
        control.click()

        def refreshed(driver):
            self._session_active()
            if old_table is not None and _is_stale(old_table):
                return bool(driver.find_elements(By.ID, ADDRESS_RESULTS_ID))
            signature = self._results_table_signature()
            return signature is not None and signature != old_signature

        try:
            self._wait(refreshed)
            self._wait(EC.visibility_of_element_located((By.ID, ADDRESS_RESULTS_ID)))
        except TimeoutException as exc:
            raise ProposalCreationError(step, "The address-results table did not refresh after the portal postback.") from exc

    def _next_result_page_control(self, visited_numeric_pages):
        tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
        if not tables:
            return None, None
        candidates = []
        for element in tables[0].find_elements(By.CSS_SELECTOR, "a"):
            postback = " ".join(filter(None, [
                element.get_attribute("href"),
                element.get_attribute("onclick"),
            ]))
            if "dgAddressResults" not in postback or "Page$" not in postback:
                continue
            text = _visible_text(element)
            argument = re.search(r"Page\$(Next|\d+)", postback, re.I)
            if not argument:
                continue
            token = argument.group(1)
            if token.lower() == "next" or text.lower() in {"next", ">", "›", "»"}:
                return element, None
            page_number = int(token)
            if page_number not in visited_numeric_pages:
                candidates.append((page_number, element))
        for element in tables[0].find_elements(
            By.CSS_SELECTOR,
            "input[type='submit'][id*='_dgAddressResults_'][id*='_BtnPage_'], "
            "input[type='submit'][name*='$dgAddressResults$'][name*='$BtnPage']",
        ):
            if not element.is_enabled() or element.get_attribute("disabled") is not None:
                continue
            value = str(element.get_attribute("value") or "").strip()
            if value.isdigit() and int(value) not in visited_numeric_pages:
                candidates.append((int(value), element))
        if not candidates:
            return None, None
        page_number, element = min(candidates, key=lambda item: item[0])
        return element, page_number

    def select_address(self, option, expected_address=None):
        # Collection inspects every page. ASP.NET reuses row IDs on other pages,
        # so the presence of an ID does not prove the chosen row is still live.
        if getattr(self, "_address_results_page", option.page_number) != option.page_number:
            self._open_result_page(option.page_number)
            self._address_results_page = option.page_number
        refreshed = [
            candidate for candidate in self.read_addresses()
            if candidate.display == option.display and candidate.selection_value == option.selection_value
        ]
        if len(refreshed) != 1:
            raise ProposalCreationError("Address selection", "The chosen address could not be found uniquely again on its result page.")
        option = refreshed[0]
        tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
        value_controls = []
        if tables and option.selection_value:
            value_controls = [
                control
                for control in tables[0].find_elements(By.CSS_SELECTOR, "input[name*='$lnkBtnAddress']")
                if str(control.get_attribute("value") or "").strip() == option.selection_value.strip()
            ]
        if len(value_controls) == 1:
            old = value_controls[0]
            old.click()
        elif option.element_id:
            old = self._click_id(option.element_id, "Address selection")
        else:
            raise ProposalCreationError("Address selection", "The matched address control could not be identified uniquely.")
        self._wait_postback(old, lambda driver: bool(driver.find_elements(By.ID, CONFIRM_ADDRESS_ID)), "Address selection")
        body_text = self.driver.find_element(By.TAG_NAME, "body").text
        selected_address = confirmed_postal_address(body_text)
        if expected_address:
            if not selected_address:
                raise ProposalCreationError("Confirm address", "The selected portal address could not be read back safely.")
            selected_match = match_address(expected_address, [AddressOption(selected_address)])
            if selected_match.status not in {"exact", "equivalent"}:
                raise ProposalCreationError(
                    "Confirm address",
                    "The portal's selected-address confirmation no longer matches the authoritative site address.",
                )
        confirm = self._click_id(CONFIRM_ADDRESS_ID, "Confirm address")
        self._wait_postback(confirm, lambda driver: bool(driver.find_elements(By.ID, LOCAL_AUTHORITY_NEXT_ID)), "Confirm address")
        next_button = self._click_id(LOCAL_AUTHORITY_NEXT_ID, "Confirm local authority")
        self._wait_postback(next_button, lambda driver: bool(driver.find_elements(By.ID, PROPOSAL_NAME_ID)), "Confirm local authority")
        print(f"Address search selected address: {option.display}.")
        return option.display

    def _open_result_page(self, page_number):
        tables = self.driver.find_elements(By.ID, ADDRESS_RESULTS_ID)
        if not tables:
            raise ProposalCreationError("Address selection", "The address results table is no longer available.")
        for element in tables[0].find_elements(By.CSS_SELECTOR, "a"):
            postback = " ".join(filter(None, [element.get_attribute("href"), element.get_attribute("onclick")]))
            if re.search(rf"Page\${page_number}(?:\D|$)", postback, re.I):
                self._click_results_refresh(element, "Address results pagination")
                return
        for element in tables[0].find_elements(
            By.CSS_SELECTOR,
            "input[type='submit'][id*='_dgAddressResults_'][id*='_BtnPage_'], "
            "input[type='submit'][name*='$dgAddressResults$'][name*='$BtnPage']",
        ):
            if str(element.get_attribute("value") or "").strip() == str(page_number):
                self._click_results_refresh(element, "Address results pagination")
                return
        raise ProposalCreationError("Address selection", "The selected address result page could not be reopened safely.")

    def enter_proposal_details(self, proposal_name, description):
        try:
            name = self._wait(EC.presence_of_element_located((By.ID, PROPOSAL_NAME_ID)))
            details = self.driver.find_element(By.ID, PROPOSAL_DETAILS_ID)
        except (TimeoutException, Exception) as exc:
            raise ProposalCreationError("Proposal details", "The proposal name or details field was not found.") from exc
        name.clear()
        name.send_keys(proposal_name)
        details.clear()
        details.send_keys(description)
        old = self._click_id(CONFIRM_DETAILS_ID, "Proposal details")
        self._wait_postback(
            old,
            lambda driver: bool(driver.find_elements(By.ID, SELECT_FORMS_FROM_LIST_ID))
            or "the name of the proposal is already in use" in driver.page_source.lower(),
            "Proposal details",
        )
        if "the name of the proposal is already in use" in self.driver.page_source.lower():
            raise ProposalNameInUse(
                "Proposal details",
                "The portal already has a draft using this exact proposal name. The proposal list must be checked before creating anything else.",
            )

    def select_form(self):
        form_label = BUILDING_WARRANT_FORM if self.application_type == BUILDING_WARRANT else HOUSEHOLDER_FORM
        use_list_label = self._find_exact_label("Select forms from a list", "Form selection")
        use_list_label.click()
        use_list = self.driver.find_element(By.ID, SELECT_FORMS_FROM_LIST_ID)
        if not use_list.is_selected():
            raise ProposalCreationError("Form selection", "Select forms from a list could not be confirmed.")
        old = self._click_id(FORM_SELECTION_NEXT_ID, "Form selection")
        self._wait_postback(old, lambda driver: any(
            _visible_text(label) == form_label for label in driver.find_elements(By.CSS_SELECTOR, "label")
        ), "Form selection")
        label = self._find_exact_label(form_label, "Form selection")
        control_id = label.get_attribute("for")
        label.click()
        if not self.driver.find_element(By.ID, control_id).is_selected():
            raise ProposalCreationError("Form selection", f"The exact {form_label} option could not be confirmed.")
        old = self._click_id(ADD_FORMS_ID, "Add Forms")
        self._wait_postback(old, lambda driver: bool(driver.find_elements(By.ID, CREATE_PROPOSAL_ID)), "Add Forms")
        if form_label not in self.driver.page_source:
            raise ProposalCreationError("Add Forms", f"The exact {form_label} form was not added.")

    def create_proposal(self):
        old = self._click_id(CREATE_PROPOSAL_ID, "Create Proposal")
        try:
            self._wait(lambda driver: _is_stale(old) and "createnewproposal.aspx" not in (driver.current_url or "").lower(), timeout=45)
        except TimeoutException as exc:
            raise ProposalCreationUncertain(
                "Create Proposal",
                "The portal did not provide a reliable creation result. The proposal list must be checked before retrying.",
            ) from exc
        reference = self.current_proposal_reference()
        if not reference:
            raise ProposalCreationUncertain(
                "Create Proposal",
                "The proposal page opened without a readable proposal reference. Check the proposal list before retrying.",
            )
        return reference

    def current_proposal_reference(self):
        match = re.search(r"Proposal Reference\s*:?\s*(\d+)", self.driver.find_element(By.TAG_NAME, "body").text, re.I)
        return match.group(1) if match else ""

    def find_matching_draft(self, proposal_name):
        self._open_proposal_list()
        candidates = []
        unstable = False
        for element in self.driver.find_elements(By.CSS_SELECTOR, "input[type='submit'], button"):
            try:
                if normalise_address(_visible_text(element)) != normalise_address(proposal_name):
                    continue
                container = self._proposal_container(element)
                if container is None:
                    continue
                match = re.search(r"Proposal Reference\s*:?\s*(\d+)", container.text, re.I)
            except WebDriverException as exc:
                if is_detached_node_error(exc):
                    unstable = True
                    continue
                raise
            if match:
                candidates.append((match.group(1), element))
        if unstable:
            raise ProposalCreationError(
                "Duplicate protection",
                "The proposal list changed while matching the newly created draft. Retry without creating another proposal.",
            )
        if len(candidates) == 1:
            return candidates[0][0]
        if len(candidates) > 1:
            raise ProposalCreationError("Duplicate protection", "Several matching drafts exist. User confirmation is required.", confirmation_required=True)
        return ""

    def _proposal_container(self, element):
        selectors = (
            "ancestor::tr[contains(normalize-space(.), 'Proposal Reference:')][1]",
            "ancestor::div[contains(normalize-space(.), 'Proposal Reference:') and "
            "(.//a or .//button or .//input[@type='submit'])][1]",
        )
        for selector in selectors:
            try:
                return element.find_element(By.XPATH, selector)
            except NoSuchElementException:
                continue
        return None

    def _proposal_open_control(self, container, proposal_name=""):
        controls = container.find_elements(By.CSS_SELECTOR, "a, input[type='submit'], button")
        visible = []
        for control in controls:
            if not control.is_displayed() or not control.is_enabled():
                continue
            text = _visible_text(control)
            if proposal_name and text == proposal_name:
                return control
            if any(blocked in text.lower() for blocked in ("additional forms", "delete", "share", "withdraw")):
                continue
            visible.append(control)
        return visible[0] if len(visible) == 1 else None

    def open_existing_proposal(self, proposal_reference, proposal_name=""):
        for attempt in range(2):
            self._open_proposal_list()
            matching_container_found = False
            unstable = False
            try:
                for element in self.driver.find_elements(By.XPATH, "//*[contains(normalize-space(.), 'Proposal Reference:')]"):
                    try:
                        match = re.search(r"Proposal Reference\s*:?\s*(\d+)", element.text, re.I)
                        if not match or match.group(1) != str(proposal_reference):
                            continue
                        container = self._proposal_container(element)
                        if container is None:
                            continue
                        matching_container_found = True
                        control = self._proposal_open_control(container, proposal_name)
                        if control is None:
                            continue
                        control.click()
                        return
                    except WebDriverException as exc:
                        if is_detached_node_error(exc):
                            unstable = True
                            continue
                        raise
            except WebDriverException as exc:
                if not is_detached_node_error(exc):
                    raise
                unstable = True
            if unstable:
                if attempt == 0:
                    continue
                raise ProposalCreationError(
                    "Resume",
                    "The proposal list changed while the saved draft was being checked. Retry without creating another proposal.",
                )
            if matching_container_found:
                raise ProposalCreationError(
                    "Resume",
                    "The saved proposal was found, but its exact open control was unavailable. Retry after the proposal list finishes loading.",
                )
        raise SavedProposalNotFoundError(
            "Resume",
            "The saved proposal reference was absent from two fully loaded proposal lists and no longer exists.",
        )

    def open_added_form(self):
        expected = BUILDING_WARRANT_FORM if self.application_type == BUILDING_WARRANT else HOUSEHOLDER_FORM
        summary_path = "/Applications/FormSummary.aspx".lower()
        if summary_path in (self.driver.current_url or "").lower():
            return
        for _attempt in range(3):
            unstable = False
            try:
                elements = self.driver.find_elements(By.CSS_SELECTOR, "a, input[type='submit'], button")
            except WebDriverException as exc:
                if not is_detached_node_error(exc):
                    raise
                unstable = True
                elements = []
            for element in elements:
                try:
                    if _visible_text(element) != expected:
                        continue
                    element.click()
                    self._wait(lambda driver: summary_path in (driver.current_url or "").lower())
                    return
                except TimeoutException as exc:
                    raise ProposalCreationError("Open application form", "The added application form did not open at the expected entrypoint.") from exc
                except WebDriverException as exc:
                    if not is_detached_node_error(exc):
                        raise
                    unstable = True
            if not unstable:
                break
        raise ProposalCreationError("Open application form", f"The added {expected} form could not be found in the created proposal.")

    def _open_proposal_list(self):
        domain = "www.ebuildingstandards.scot" if self.application_type == BUILDING_WARRANT else "www.eplanning.scot"
        client = "eBuildingStandardsClient" if self.application_type == BUILDING_WARRANT else "ePlanningClient"
        self.driver.get(f"https://{domain}/{client}/customPages/myproposals.aspx")
        self._session_active()
        try:
            self._wait(EC.presence_of_element_located((By.ID, NEW_PROPOSAL_ID)))
        except TimeoutException as exc:
            raise ProposalCreationError("Proposal list", "The proposal list could not be opened.") from exc

    def _find_exact_label(self, text, step):
        matches = [label for label in self.driver.find_elements(By.CSS_SELECTOR, "label") if _visible_text(label) == text]
        if len(matches) != 1:
            raise ProposalCreationError(step, f"The exact portal option '{text}' was not found uniquely.")
        return matches[0]


def _is_stale(element):
    try:
        element.is_enabled()
        return False
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return True
        raise


def browser_address_selection(driver, options, timeout=600):
    labels = [option.display for option in options]
    driver.execute_script(
        """
        const labels = arguments[0];
        document.getElementById('architect-pro-address-choice')?.remove();
        window.__architectProAddressChoice = null;
        const root = document.createElement('div');
        root.id = 'architect-pro-address-choice';
        root.setAttribute('role', 'dialog');
        root.setAttribute('aria-modal', 'true');
        root.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:rgba(0,0,0,.45);display:grid;place-items:center;padding:24px';
        const panel = document.createElement('div');
        panel.style.cssText = 'max-width:720px;width:100%;max-height:80vh;overflow:auto;background:white;color:#20231f;border-radius:8px;padding:24px;font:16px Arial,sans-serif';
        panel.innerHTML = '<h2 style="margin:0 0 8px">Choose the project address</h2><p style="margin:0 0 16px">Several portal addresses could match. Select the exact property to continue.</p>';
        labels.forEach((label, index) => {
          const button = document.createElement('button');
          button.type = 'button'; button.textContent = label;
          button.style.cssText = 'display:block;width:100%;text-align:left;margin:8px 0;padding:12px;border:1px solid #777;background:white;border-radius:4px';
          button.onclick = () => { window.__architectProAddressChoice = index; root.remove(); };
          panel.appendChild(button);
        });
        root.appendChild(panel); document.body.appendChild(root); panel.querySelector('button')?.focus();
        """,
        labels,
    )
    try:
        choice = WebDriverWait(driver, timeout, poll_frequency=0.25).until(
            lambda current: current.execute_script("return window.__architectProAddressChoice")
        )
    except TimeoutException as exc:
        raise ProposalCreationError("Address selection", "Address selection timed out without creating a proposal.", confirmation_required=True) from exc
    return int(choice)


def proposal_name_after_deleted_collision(address, application_type, collision_number=1):
    suffix = "Householder" if application_type == HOUSEHOLDER else "Building Warrant"
    if collision_number > 1:
        suffix = f"{suffix} {collision_number}"
    return f"{str(address or '').strip()} - {suffix}"


def create_proposal_and_resume(
    driver,
    user_inputs,
    resume,
    *,
    application_type=None,
    portal=None,
    state_store=None,
    address_selector=None,
    address_resolver=None,
):
    context = build_context(user_inputs, application_type)
    portal = portal or SeleniumProposalPortal(driver, context.application_type)
    state_store = state_store or ProposalStateStore()
    address_selector = address_selector or (lambda options: browser_address_selection(driver, options))

    existing = state_store.get(context)
    if existing and existing.get("proposalReference"):
        try:
            portal.open_existing_proposal(
                existing["proposalReference"],
                existing.get("proposalName", ""),
            )
        except SavedProposalNotFoundError:
            state_store.clear(context, existing["proposalReference"])
        else:
            portal.open_added_form()
            return resume()

    proposal_name_override = ""
    resolved_portal_address = ""
    search_postcode = context.postcode
    maximum_name_attempts = 5
    for proposal_attempt in range(maximum_name_attempts):
        user_confirmed = False
        while True:
            portal.open_new_proposal()
            print(f"Address search postcode: {search_postcode}.")
            portal.search_postcode(search_postcode)
            if hasattr(portal, "collect_address_options"):
                options, match = portal.collect_address_options(context.site_address)
            else:
                options = portal.read_addresses()
                match = match_address(context.site_address, options)
            if (
                match.status == "missing"
                and search_postcode == context.postcode
                and hasattr(portal, "exact_address_search")
            ):
                if portal.exact_address_search(context.site_address, context.postcode):
                    fallback_options, match = portal.collect_address_options(context.site_address)
                    combined = {normalise_address(option.display): option for option in options}
                    combined.update({normalise_address(option.display): option for option in fallback_options})
                    options = list(combined.values())

            if match.status in {"exact", "equivalent"}:
                selected = match.option
                break

            if address_resolver is None:
                if not options:
                    raise ProposalCreationError(
                        "Address results",
                        f"No addresses were returned for postcode {search_postcode}. Correct the site information and retry.",
                    )
                if match.status != "ambiguous":
                    safe_options = "; ".join(option.display for option in options)
                    raise ProposalCreationError(
                        "Address selection",
                        f"No returned address safely matched the stored site. Returned options: {safe_options}. Correct the site information and retry.",
                    )
                candidates = list(match.plausible)
                choice = address_selector(candidates)
                if choice is None:
                    raise ProposalCreationError(
                        "Address selection",
                        "Several addresses could match and no property was selected.",
                        confirmation_required=True,
                    )
                selected = candidates[int(choice)]
                user_confirmed = True
                break

            response = address_resolver(address_resolution_request(context, search_postcode, options)) or {}
            action = str(response.get("action") or "cancel")
            if action == "select":
                candidate_id = str(response.get("candidate_id") or "")
                candidate_map = {
                    f"portal-address-{index + 1}": option
                    for index, option in enumerate(options)
                }
                if candidate_id not in candidate_map:
                    raise ProposalCreationError(
                        "Address selection",
                        "The chosen portal address was no longer part of this address request.",
                        retryable=False,
                    )
                selected = candidate_map[candidate_id]
                user_confirmed = True
                break
            if action in {"change_postcode", "alternate_postcode"}:
                alternate = normalise_postcode(response.get("postcode"))
                if not re.fullmatch(r"[A-Z]{1,2}\d[A-Z\d]? \d[A-Z]{2}", alternate):
                    raise ProposalCreationError(
                        "Address search",
                        "Enter a valid UK postcode to search the portal again.",
                        retryable=False,
                    )
                raise AddressPostcodeCorrectionRequired(alternate)
            if action == "manual":
                raise ManualAddressResolutionRequired()
            raise ProposalCreationError(
                "Address selection",
                "Address resolution was cancelled before the portal address was selected.",
                retryable=False,
            )

        expected_selected_address = selected.display if user_confirmed else context.site_address
        selected_address = portal.select_address(selected, expected_selected_address)
        resolved_portal_address = selected_address
        proposal_name = proposal_name_override or selected_address
        try:
            portal.enter_proposal_details(proposal_name, context.description)
            break
        except ProposalNameInUse:
            reference = portal.find_matching_draft(proposal_name)
            if reference:
                _save_proposal_state(
                    state_store,
                    context,
                    reference,
                    proposal_name,
                    resolved_portal_address,
                )
                portal.open_existing_proposal(reference, proposal_name)
                portal.open_added_form()
                return resume()
            if proposal_attempt < maximum_name_attempts - 1:
                proposal_name_override = proposal_name_after_deleted_collision(
                    selected_address,
                    context.application_type,
                    collision_number=proposal_attempt + 1,
                )
                continue
            raise ProposalCreationError(
                "Duplicate protection",
                "All bounded proposal-name candidates are reserved, but no unique exact active draft could be recovered. Review My Proposals before retrying.",
                confirmation_required=True,
            )
    portal.select_form()
    try:
        reference = portal.create_proposal()
    except ProposalCreationUncertain:
        reference = portal.find_matching_draft(proposal_name)
        if not reference:
            raise
        portal.open_existing_proposal(reference, proposal_name)
    _save_proposal_state(
        state_store,
        context,
        reference,
        proposal_name,
        resolved_portal_address,
    )
    if portal.current_proposal_reference() != reference:
        portal.open_existing_proposal(reference, proposal_name)
    portal.open_added_form()
    return resume()

"""Workflow-level result contracts that do not depend on a GUI."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class UserActionRequired:
    stage: str
    message: str


FEE_HANDOFF = UserActionRequired(
    stage="fee",
    message="Complete the fee in the browser.",
)

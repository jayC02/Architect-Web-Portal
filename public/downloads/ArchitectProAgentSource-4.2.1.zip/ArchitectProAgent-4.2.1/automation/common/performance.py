"""Low-overhead, non-sensitive stage timing for automation runs."""

from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
import json
import logging
import time


@dataclass
class PerformanceRecorder:
    logger: logging.Logger = field(default_factory=lambda: logging.getLogger("architectpro.performance"))
    started_at: float = field(default_factory=time.perf_counter)
    timings: dict[str, float] = field(default_factory=dict)

    @contextmanager
    def stage(self, name: str):
        started = time.perf_counter()
        try:
            yield
        finally:
            elapsed = time.perf_counter() - started
            self.timings[name] = round(elapsed, 4)
            self.logger.info(json.dumps({"event": "automation_timing", "stage": name, "seconds": round(elapsed, 4)}))

    def finish(self) -> dict[str, float]:
        self.timings["overall"] = round(time.perf_counter() - self.started_at, 4)
        return dict(self.timings)

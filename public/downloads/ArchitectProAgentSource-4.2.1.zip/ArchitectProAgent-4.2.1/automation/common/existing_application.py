"""Open one previously prepared portal application without creating or editing it."""

from __future__ import annotations

from selenium.webdriver.common.by import By

from automation.common.actions import click_when_clickable, type_into
from automation.common.declaration import declaration_selectors_for, verify_application_main_page
from automation.common.proposal_creation import (
    BUILDING_WARRANT,
    HOUSEHOLDER,
    ProposalCreationError,
    ProposalStateStore,
    SavedProposalNotFoundError,
    SeleniumProposalPortal,
    build_context,
)
from automation.common.uploads import dismiss_gdpr_modal_if_present
from automation.building_warrant.login import submit_login_and_wait_for_home
from automation.models import PLANNING_TYPES


class ExistingApplicationNotFound(RuntimeError):
    pass


def _portal_type(application_type: str) -> str:
    return HOUSEHOLDER if application_type in PLANNING_TYPES else BUILDING_WARRANT


def _login(driver, application_type: str, email: str, password: str) -> None:
    driver.get("https://www.edevelopment.scot/eDevelopmentClient/default.aspx")
    click_when_clickable(driver, By.ID, "Banner_btnLogin")
    type_into(
        driver,
        By.ID,
        "MainContent_UclLogin_LoginWizard_TbxEmail",
        email,
        clear_first=False,
    )
    type_into(
        driver,
        By.ID,
        "MainContent_UclLogin_LoginWizard_TbxPassword",
        password,
        clear_first=False,
    )
    sidebar_name = "ctl00$sideBar$ctl13" if application_type in PLANNING_TYPES else "ctl00$sideBar$ctl11"
    submit_login_and_wait_for_home(
        driver,
        authenticated_control_name=sidebar_name,
    )
    dismiss_gdpr_modal_if_present(driver)
    click_when_clickable(driver, By.NAME, sidebar_name)


def open_existing_application(
    driver,
    application_type: str,
    user_inputs,
    *,
    password: str,
    state_store=None,
    portal=None,
    timeout: float = 45,
) -> str:
    """Open the exact saved proposal/form and stop on its Form Summary page."""
    email = str((user_inputs or {}).get("Email") or "").strip()
    if not email or not password:
        raise ValueError("Saved portal credentials are required to open this application.")
    portal_type = _portal_type(application_type)
    context = build_context(user_inputs, portal_type)
    state_store = state_store or ProposalStateStore()
    saved = state_store.get(context)
    if not saved or not saved.get("proposalReference"):
        raise ExistingApplicationNotFound(
            "Architect Pro could not find saved portal identity for this application."
        )

    if portal is None:
        _login(driver, application_type, email, password)
        portal = SeleniumProposalPortal(driver, portal_type)
    try:
        portal.open_existing_proposal(
            saved["proposalReference"],
            saved.get("proposalName", ""),
        )
        portal.open_added_form()
    except SavedProposalNotFoundError as exc:
        raise ExistingApplicationNotFound(
            "Architect Pro could not find the existing application in the government portal."
        ) from exc
    except ProposalCreationError as exc:
        raise ExistingApplicationNotFound(str(exc).split(" Retry:", 1)[0]) from exc

    selectors = declaration_selectors_for(application_type)
    verify_application_main_page(driver, selectors, timeout=timeout)
    return str(saved["proposalReference"])

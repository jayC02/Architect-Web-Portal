# -*- coding: utf-8 -*-
import os
import re

import PyPDF2

from automation.common import storage as storage_paths

from .runtime import SCRIPT_DIR, SUPPORTING_DOCS_JSON, load_required_json


def get_paper_size_from_pdf(pdf_path):
    """Looks for A0-A6 in the first page of the PDF's text."""
    try:
        with open(pdf_path, 'rb') as pdf_file:
            reader = PyPDF2.PdfReader(pdf_file)
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception:
                    print(f"Warning: Could not decrypt PDF for paper size, using default: {pdf_path}")
                    return "Not Applicable"
            if not reader.pages:
                print(f"Warning: PDF has no pages, using default paper size: {pdf_path}")
                return "Not Applicable"
            first_page_text = reader.pages[0].extract_text() or ""

            for size in ["A0", "A1", "A2", "A3", "A4", "A5", "A6"]:
                if size in first_page_text:
                    return size
    except Exception as e:
        print(f"Warning: Could not read PDF paper size for '{pdf_path}'. Using default. Error: {e}")
    return "Not Applicable"


def get_document_type_from_pdf(pdf_path):
    """
    Attempts to guess 'Drawing', 'Report', 'Photo', or 'Other'
    from the first page text or the filename.
    """
    filename_lower = os.path.basename(pdf_path).lower()
    text_lower = ""
    try:
        with open(pdf_path, 'rb') as pdf_file:
            reader = PyPDF2.PdfReader(pdf_file)
            if reader.is_encrypted:
                try:
                    reader.decrypt("")
                except Exception:
                    print(f"Warning: Could not decrypt PDF for document type, using filename fallback: {pdf_path}")
            if reader.pages:
                page_text = reader.pages[0].extract_text() or ""
                text_lower = page_text.lower()
            else:
                print(f"Warning: PDF has no pages, using filename fallback for document type: {pdf_path}")
    except Exception as e:
        print(f"Warning: Could not read PDF document type for '{pdf_path}'. Using filename fallback. Error: {e}")

    keywords_for_drawing = ["plan", "drawing", "elevation", "ground floor", "location plan"]
    if any(kw in text_lower for kw in keywords_for_drawing) or any(
        kw in filename_lower for kw in ["plan", "drawing", "elevation", "section"]
    ):
        return "Drawing"
    if any(kw in text_lower for kw in ["report", "analysis"]) or any(
        kw in filename_lower for kw in ["report", "analysis", "spec"]
    ):
        return "Report"
    if any(kw in text_lower for kw in ["photo", "image"]) or any(
        kw in filename_lower for kw in ["photo", "image", "pic"]
    ):
        return "Photo"
    return "Other"


def load_supporting_docs_upload_list(pdf_folder_path: str, mapping_data=None):
    """
    Uses supporting_docs.json if present (from GUI).
    Returns:
      entries: list of (filename, bucket_key)
      location_plan_file: str|None
      effective_folder: str
      bucket_labels: dict[bucket_key] = display label
    """
    if mapping_data is None:
        storage_paths.migrate_json_if_missing(
            "supporting_docs.json",
            SCRIPT_DIR,
            scrubber=storage_paths.scrub_sensitive_fields,
            log=print,
        )
        mapping = load_required_json(
            SUPPORTING_DOCS_JSON,
            required_keys=["pdf_folder_path", "buckets", "bucket_labels"]
        )
    else:
        mapping = dict(mapping_data)
        missing = [key for key in ("pdf_folder_path", "buckets", "bucket_labels") if key not in mapping]
        if missing:
            raise RuntimeError(f"Prepared document mapping is missing: {', '.join(missing)}")

    effective_folder = mapping.get("pdf_folder_path") or pdf_folder_path
    if not effective_folder or not os.path.isdir(effective_folder):
        raise RuntimeError(
            f"PDF folder from supporting_docs.json is missing or invalid: '{effective_folder}'"
        )

    buckets = mapping.get("buckets", {})
    bucket_labels = mapping.get("bucket_labels", {})
    if not isinstance(buckets, dict):
        raise RuntimeError("supporting_docs.json key 'buckets' must be an object.")
    if not isinstance(bucket_labels, dict):
        raise RuntimeError("supporting_docs.json key 'bucket_labels' must be an object.")

    upload_order = [
        "proposed",
        "existing",
        "elevations",
        "sections",
        "details",
        "calcs",
        "specs",
        "photos",
        "other",
    ]

    location_plan_list = buckets.get("location_plan", [])
    if not isinstance(location_plan_list, list):
        raise RuntimeError("supporting_docs.json bucket 'location_plan' must be a list.")
    location_plan_file = location_plan_list[0] if location_plan_list else None

    entries = []
    for bucket_key in upload_order:
        bucket_files = buckets.get(bucket_key, [])
        if not isinstance(bucket_files, list):
            raise RuntimeError(f"supporting_docs.json bucket '{bucket_key}' must be a list.")
        for fn in bucket_files:
            entries.append((fn, bucket_key))

    files_to_check = list(entries)
    if location_plan_file:
        if not isinstance(location_plan_file, str):
            raise RuntimeError("supporting_docs.json location_plan entry must be a filename string.")
        files_to_check.append((location_plan_file, "location_plan"))

    missing = []
    for fn, bucket_key in files_to_check:
        if not isinstance(fn, str) or not fn.strip():
            raise RuntimeError(
                f"supporting_docs.json bucket '{bucket_key}' contains an invalid filename: {fn!r}"
            )
        full_path = os.path.join(effective_folder, fn)
        if not os.path.exists(full_path):
            missing.append(f"{bucket_key}: {full_path}")

    if missing:
        raise FileNotFoundError(
            "These files are listed in supporting_docs.json but were not found:\n"
            + "\n".join(missing)
        )

    print(f"Using PDF folder: {effective_folder}")
    print(f"Prepared {len(entries)} supporting document upload(s).")
    return entries, location_plan_file, effective_folder, bucket_labels


# Patterns used to derive drawing metadata from filenames and PDF text.
REV_PAT = re.compile(r'(?i)\b(rev(?:ision)?|r)\s*[-_ ]?\s*([a-z0-9]{1,3})\b')
SHEET_PAT = re.compile(r'(?i)\b(sheet|sh)\s*[-_ ]?\s*(\d{1,3})\b')
DATE_PAT = re.compile(r'\b(20\d{2}[-_ ]?(0[1-9]|1[0-2])[-_ ]?(0[1-9]|[12]\d|3[01]))\b')
SCALE_PAT = re.compile(r'(?i)\b(scale|1:\s*\d+)\b')

REF_CANDIDATE_PATTERNS = [
    re.compile(r'\b(?=[A-Z0-9\-_]*\d)[A-Z0-9]{1,6}(?:[-_][A-Z0-9]{1,6}){1,8}\b'),
    re.compile(r'\b[A-Z]{1,3}[-_ ]?\d{1,4}\b'),
    re.compile(r'\b(?:SK|GA|DR|DRG|DWG|PL|EX|PR|P)\s*[-_ ]?\s*\d{1,4}\b', re.IGNORECASE),
]

TITLE_HINTS = [
    "drawing title", "title", "project", "description", "proposed",
    "existing", "floor plan", "elevation", "section", "location plan", "site plan"
]


def _normalise_spaces(s: str) -> str:
    s = re.sub(r'\s+', ' ', s)
    return s.strip(" -_.,;:()[]{}")


def _clean_filename_tokens(raw: str) -> str:
    # Replace common separators with spaces
    s = re.sub(r'[_\.]+', ' ', raw)
    s = re.sub(r'[-]{2,}', '-', s)
    s = s.replace('-', ' ')
    s = _normalise_spaces(s)

    # Remove common noise
    s = REV_PAT.sub('', s)
    s = SHEET_PAT.sub('', s)
    s = DATE_PAT.sub('', s)
    s = SCALE_PAT.sub('', s)
    s = _normalise_spaces(s)

    return s


def _extract_pdf_first_page_text(pdf_path: str) -> str:
    try:
        with open(pdf_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            t = (reader.pages[0].extract_text() or "").strip()
            return t
    except Exception:
        return ""


def _best_description_from_pdf_text(pdf_text: str) -> str:
    if not pdf_text:
        return ""

    low = pdf_text.lower()

    # If any hint exists, grab a nearby line-ish chunk
    if any(h in low for h in TITLE_HINTS):
        # Split lines and pick the best “human” line
        lines = [l.strip() for l in pdf_text.splitlines() if l.strip()]
        # Prefer longer, non-numeric, non-boilerplate lines
        candidates = []
        for l in lines[:80]:  # don’t scan the entire page forever
            if len(l) < 6:
                continue
            if sum(ch.isdigit() for ch in l) > len(l) * 0.6:
                continue
            # avoid pure headers like "A1" "REV"
            if re.fullmatch(r'[A-Z0-9\-_/ ]{1,10}', l):
                continue
            candidates.append(l)

        if candidates:
            # pick the longest reasonable line
            candidates.sort(key=lambda x: len(x), reverse=True)
            return _normalise_spaces(candidates[0])

    return ""


def _best_ref_from_text(text: str) -> str:
    if not text:
        return ""
    # Search in uppercased version but keep original token-ish
    t = text.upper()
    for pat in REF_CANDIDATE_PATTERNS:
        m = pat.search(t)
        if m:
            return _normalise_spaces(m.group(0))
    return ""


def extract_title_and_description(pdf_filename: str, pdf_path: str) -> tuple[str, str]:
    base = os.path.splitext(os.path.basename(pdf_filename))[0]

    # 1) Pull first page text (best source of truth)
    pdf_text = _extract_pdf_first_page_text(pdf_path)

    # 2) Title/ref: prefer something reference-like from filename, else from PDF text
    title = _best_ref_from_text(base)
    if not title:
        title = _best_ref_from_text(pdf_text)

    # 3) Description: prefer a human-readable line from PDF, else cleaned filename
    filename_desc = _clean_filename_tokens(base)
    pdf_desc = _best_description_from_pdf_text(pdf_text)

    # Use PDF-derived description only if it's likely a drawing title
    drawing_words = ("plan", "elevation", "section", "layout", "details", "schedule", "site", "location")
    if pdf_desc and any(w in pdf_desc.lower() for w in drawing_words) and len(pdf_desc) <= 120:
        description = pdf_desc
    else:
        description = filename_desc

    # 4) Final fallbacks
    if not title:
        # Keep it short-ish for the portal field
        title = _clean_filename_tokens(base)[:40] or base[:40]
    if not description:
        description = base

    return title, description

# -*- coding: utf-8 -*-
from selenium.common.exceptions import NoSuchElementException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from .actions import get_when_clickable, is_detached_node_error, wait_dom_ready


PORTAL_APPLICANT_TITLES = ("Mr", "Mrs", "Miss", "Ms", "Other")


class ApplicantTitleResolutionRequired(RuntimeError):
    pass


def _title_token(value):
    return str(value or "").strip().rstrip(".").casefold()


def _validated_other_title(value):
    value = str(value or "").strip()
    if not value or value.casefold() == "other":
        return ""
    return value


def normalise_applicant_title(title):
    title = str(title or "").strip()
    supported = {_title_token(option): option for option in PORTAL_APPLICANT_TITLES}
    if _title_token(title) in supported:
        return supported[_title_token(title)]
    if title and _title_token(title) != _title_token("Please Select One"):
        return "Other"
    return ""


def resolve_applicant_title(title, other_title="", resolver=None, applicant_name=""):
    raw_title = str(title or "").strip()
    portal_title = normalise_applicant_title(raw_title)
    resolved_other_title = _validated_other_title(other_title)

    # An explicit unsupported title such as "Professor" is itself the exact
    # Other-title value. A literal "Other" is only the dropdown choice and
    # never a valid value for the companion field.
    if portal_title == "Other" and _title_token(raw_title) != "other":
        resolved_other_title = raw_title

    needs_user = not portal_title or (portal_title == "Other" and not resolved_other_title)
    if needs_user:
        if resolver is None:
            raise ApplicantTitleResolutionRequired(
                "Architect Pro needs an explicit applicant title before it can continue."
            )
        response = dict(resolver({
            "stage": "applicant_details",
            "applicant_name": str(applicant_name or "").strip(),
            "options": list(PORTAL_APPLICANT_TITLES),
            "selected_title": portal_title,
        }) or {})
        portal_title = normalise_applicant_title(response.get("title"))
        resolved_other_title = _validated_other_title(response.get("other_title"))

    if portal_title not in PORTAL_APPLICANT_TITLES:
        raise ApplicantTitleResolutionRequired("Select an applicant title to continue.")
    if portal_title == "Other" and not resolved_other_title:
        raise ApplicantTitleResolutionRequired(
            "Enter the applicant's actual other title to continue."
        )
    return portal_title, resolved_other_title


def _other_title_locator_candidates(element_ids):
    for element_id in element_ids or ():
        if element_id:
            yield By.ID, element_id
    yield By.XPATH, (
        "//label[contains(translate(normalize-space(.), "
        "'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), 'other title')]"
        "/following::input[not(@type='hidden')][1]"
    )


def _find_visible_other_title_field(driver, element_ids):
    for by, locator in _other_title_locator_candidates(element_ids):
        try:
            field = driver.find_element(by, locator)
            if field.is_displayed() and field.is_enabled():
                return field
        except NoSuchElementException:
            continue
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    return False


def _fill_other_title(driver, value, element_ids, timeout):
    for _attempt in range(3):
        field = WebDriverWait(driver, timeout, poll_frequency=0.1).until(
            lambda current: _find_visible_other_title_field(current, element_ids)
        )
        try:
            field.clear()
            field.send_keys(value)
            break
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    else:
        raise RuntimeError("The portal's Other title field kept changing before it could be completed.")

    def other_title_accepted(current):
        try:
            live_field = _find_visible_other_title_field(current, element_ids)
            return bool(live_field) and live_field.get_attribute("value") == value
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                return False
            raise

    try:
        WebDriverWait(driver, timeout, poll_frequency=0.1).until(other_title_accepted)
    except TimeoutException as exc:
        raise RuntimeError("The portal did not accept the applicant's Other title value.") from exc


def select_applicant_title(
    driver,
    element_id,
    title,
    first_field_id,
    timeout=15,
    other_title="",
    other_title_element_ids=(),
    resolver=None,
    applicant_name="",
):
    title, other_title = resolve_applicant_title(
        title,
        other_title,
        resolver=resolver,
        applicant_name=applicant_name,
    )
    selected = False
    for _attempt in range(3):
        element = get_when_clickable(driver, By.ID, element_id, timeout=timeout)
        try:
            dropdown = Select(element)
            current = dropdown.first_selected_option.text.strip()
            if current != title:
                # Use Selenium's native select interaction so the ASP.NET
                # AutoPostBack runs exactly as it does in the visible workflow.
                dropdown.select_by_visible_text(title)
                try:
                    WebDriverWait(driver, 3, poll_frequency=0.1).until(
                        EC.staleness_of(element)
                    )
                except TimeoutException:
                    # Some portal versions update the form without replacing
                    # the select node. The state check below handles both paths.
                    pass
            selected = True
            break
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    if not selected:
        raise RuntimeError(f"Applicant title option '{title}' could not be selected.")
    wait_dom_ready(driver, timeout)

    def title_selected_and_form_ready(d):
        try:
            current = Select(d.find_element(By.ID, element_id)).first_selected_option.text.strip()
            first_field = d.find_element(By.ID, first_field_id)
            return current == title and first_field.is_displayed()
        except NoSuchElementException:
            return False
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                return False
            raise

    try:
        WebDriverWait(driver, timeout, poll_frequency=0.1).until(title_selected_and_form_ready)
    except TimeoutException as exc:
        raise RuntimeError(
            "Applicant details did not become ready after selecting the applicant title."
        ) from exc
    if title == "Other":
        # Selecting Other causes an ASP.NET postback. Never reuse the title
        # element captured before that rerender; find the new companion input.
        _fill_other_title(driver, other_title, other_title_element_ids, timeout)
    print(f"Selected applicant title: {title}")
    return title

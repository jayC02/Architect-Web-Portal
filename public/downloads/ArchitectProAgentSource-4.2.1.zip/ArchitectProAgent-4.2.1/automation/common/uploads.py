# -*- coding: utf-8 -*-
from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import is_detached_node_error


def show_browser_completion_toast(driver):
    """
    Inject a small, non-blocking completion toast into the current page.
    Idempotent: if already present, it will not create a duplicate.
    """
    driver.execute_script(
        """
        (function () {
            const existing = document.getElementById('bw-automation-complete-toast');
            if (existing) {
                return;
            }

            const toast = document.createElement('div');
            toast.id = 'bw-automation-complete-toast';
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            toast.style.cssText = [
                'position:fixed',
                'right:16px',
                'bottom:16px',
                'z-index:2147483647',
                'max-width:380px',
                'min-width:280px',
                'padding:12px 14px',
                'border-radius:10px',
                'background:#1f2937',
                'color:#f9fafb',
                'box-shadow:0 10px 26px rgba(0,0,0,0.28)',
                'font-family:Arial, Helvetica, sans-serif',
                'font-size:13px',
                'line-height:1.4',
                'pointer-events:auto',
                'opacity:0',
                'transform:translateY(8px)',
                'transition:opacity .2s ease, transform .2s ease'
            ].join(';');

            const title = document.createElement('div');
            title.textContent = 'Automation complete';
            title.style.cssText = 'font-weight:700;font-size:14px;margin:0 28px 6px 0;';

            const message = document.createElement('div');
            message.textContent = 'Complete any final manual steps here. Then return to the GUI if you want to prepare another application.';
            message.style.cssText = 'margin:0;opacity:0.95;';

            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.textContent = '×';
            closeBtn.setAttribute('aria-label', 'Dismiss notification');
            closeBtn.style.cssText = [
                'position:absolute',
                'top:6px',
                'right:8px',
                'width:22px',
                'height:22px',
                'border:none',
                'border-radius:999px',
                'background:transparent',
                'color:#e5e7eb',
                'cursor:pointer',
                'font-size:16px',
                'line-height:20px',
                'padding:0'
            ].join(';');

            function removeToast() {
                if (!toast || !toast.parentNode) return;
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(8px)';
                window.setTimeout(function () {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 180);
            }

            closeBtn.addEventListener('click', removeToast);

            toast.appendChild(title);
            toast.appendChild(message);
            toast.appendChild(closeBtn);

            document.body.appendChild(toast);

            window.requestAnimationFrame(function () {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });

            window.setTimeout(removeToast, 12000);
        })();
        """
    )


def dismiss_gdpr_modal_if_present(driver, timeout=2):
    """
    Safely closes the GDPR modal if it appears.
    Returns quickly when the modal is not present.
    Safe to call multiple times.
    """
    modal_selector = ".gdprModalWrapper.show"

    try:
        # Fast check first: if modal is not already present/visible, leave immediately.
        modals = driver.find_elements(By.CSS_SELECTOR, modal_selector)
        visible_modals = [m for m in modals if m.is_displayed()]
        if not visible_modals:
            return

        # Modal is present, now handle it properly.
        possible_xpaths = [
            "//button[contains(.,'Accept')]",
            "//button[contains(.,'I Agree')]",
            "//button[contains(.,'Agree')]",
            "//button[contains(.,'OK')]",
            "//a[contains(.,'Accept')]"
        ]

        clicked = False
        for xp in possible_xpaths:
            try:
                btn = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable((By.XPATH, xp))
                )
                btn.click()
                clicked = True
                break
            except Exception:
                continue

        # If we clicked something, wait briefly for the modal to disappear.
        if clicked:
            WebDriverWait(driver, timeout).until(
                EC.invisibility_of_element_located((By.CSS_SELECTOR, modal_selector))
            )
            print("Dismissed GDPR modal.")

    except Exception:
        # Stay non-fatal: this helper should never block the main flow.
        pass


def get_visible_portal_error(driver):
    """Return visible ASP.NET-style validation text if the portal exposes it."""
    selectors = [
        "#MainContent_validationSummary",
        ".alert-error",
        ".validation-summary-errors",
        ".field-validation-error",
        "[role='alert']",
    ]
    for selector in selectors:
        try:
            for element in driver.find_elements(By.CSS_SELECTOR, selector):
                if element.is_displayed():
                    text = element.text.strip()
                    if text:
                        return text
        except Exception:
            continue
    return ""


def wait_for_supporting_doc_upload_result(
    driver,
    pdf_file,
    timeout=30,
):
    """
    Wait for the supporting-doc upload to either return to the add-document
    state or show an obvious validation error.
    """
    add_doc_ids = (
        "MainContent_SupportingDocumentationWizard_btnAddDocumentation",
        "MainContent_btnAddDocumentation",
    )

    def upload_finished_or_failed(d):
        error_text = get_visible_portal_error(d)
        if error_text:
            return ("error", error_text)
        try:
            for add_doc_id in add_doc_ids:
                add_buttons = d.find_elements(By.ID, add_doc_id)
                for add_btn in add_buttons:
                    if add_btn.is_displayed() and add_btn.is_enabled():
                        return ("ready", add_btn)
        except StaleElementReferenceException:
            return False
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                return False
            raise
        return False

    result_type, result_value = WebDriverWait(driver, timeout).until(upload_finished_or_failed)
    if result_type == "error":
        raise RuntimeError(
            f"Portal showed a validation error after uploading '{pdf_file}': {result_value}"
        )
    return result_value

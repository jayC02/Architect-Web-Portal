# -*- coding: utf-8 -*-
import json
import os
import sys
import time

from automation.common import storage as storage_paths


def _default_script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))


SCRIPT_DIR = _default_script_dir()
USER_INPUTS_JSON = storage_paths.runtime_path("user_inputs.json", SCRIPT_DIR)
CONTINUE_FLAG_FILE = storage_paths.runtime_path("continue_flag.txt", SCRIPT_DIR)
SUPPORTING_DOCS_JSON = storage_paths.runtime_path("supporting_docs.json", SCRIPT_DIR)
AUTOMATION_CHECKPOINT_FILE = storage_paths.runtime_path("automation_checkpoint.json", SCRIPT_DIR)
PROPOSAL_STATE_FILE = storage_paths.runtime_path("proposal_state.json", SCRIPT_DIR)


def record_checkpoint(checkpoint, section, detail=""):
    """Persist non-sensitive progress for the GUI and durable portal callback."""
    payload = {
        "checkpoint": str(checkpoint),
        "section": str(section),
        "detail": str(detail)[:300],
        "recordedAt": time.time(),
    }
    temporary = f"{AUTOMATION_CHECKPOINT_FILE}.tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(payload, handle)
    os.replace(temporary, AUTOMATION_CHECKPOINT_FILE)


def clear_checkpoint():
    try:
        os.remove(AUTOMATION_CHECKPOINT_FILE)
    except FileNotFoundError:
        pass


def load_required_json(path, required_keys=None):
    """Load a required JSON object and raise clear errors for automation logs."""
    print(f"Loading JSON: {path}")
    if not os.path.exists(path):
        raise RuntimeError(f"Required JSON file is missing: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Invalid JSON in required file '{path}': {e}") from e
    except OSError as e:
        raise RuntimeError(f"Could not read required JSON file '{path}': {e}") from e

    if not isinstance(data, dict):
        raise RuntimeError(f"Required JSON file must contain an object: {path}")

    missing_keys = [key for key in (required_keys or []) if key not in data]
    if missing_keys:
        raise RuntimeError(
            f"Required JSON file '{path}' is missing key(s): {', '.join(missing_keys)}"
        )

    return data


def wait_for_continue(prompt_msg):
    """Fail clearly instead of coupling a background workflow to a GUI flag."""
    print("--------------------------------------------------------------------------------")
    print(prompt_msg)
    print("--------------------------------------------------------------------------------")

    raise RuntimeError(
        "The portal did not reach the expected page automatically. "
        "Stop this run, inspect the visible browser, and retry only after reconciling the current proposal state."
    )

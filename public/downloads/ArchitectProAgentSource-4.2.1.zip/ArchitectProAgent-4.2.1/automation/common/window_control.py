"""Windows ownership-safe Chrome window hiding and Fee handoff reveal."""

from __future__ import annotations

import ctypes
from ctypes import wintypes
import os
import time
from typing import Callable


TH32CS_SNAPPROCESS = 0x00000002
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
SW_HIDE = 0
SW_RESTORE = 9
HWND_TOP = 0
SWP_NOSIZE = 0x0001
SWP_NOMOVE = 0x0002
SWP_SHOWWINDOW = 0x0040


class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260),
    ]


class WindowsApi:
    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("Owned browser window control requires Windows.")
        self.user32 = ctypes.windll.user32
        self.kernel32 = ctypes.windll.kernel32

    def descendant_process_ids(self, root_pid: int) -> set[int]:
        snapshot = self.kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
        if snapshot == INVALID_HANDLE_VALUE:
            raise OSError("Could not inspect the owned Chrome process tree.")
        relationships: dict[int, tuple[int, str]] = {}
        entry = PROCESSENTRY32W(); entry.dwSize = ctypes.sizeof(PROCESSENTRY32W)
        try:
            if self.kernel32.Process32FirstW(snapshot, ctypes.byref(entry)):
                while True:
                    relationships[int(entry.th32ProcessID)] = (
                        int(entry.th32ParentProcessID),
                        str(entry.szExeFile).lower(),
                    )
                    if not self.kernel32.Process32NextW(snapshot, ctypes.byref(entry)):
                        break
        finally:
            self.kernel32.CloseHandle(snapshot)

        descendants = {int(root_pid)}
        changed = True
        while changed:
            changed = False
            for pid, (parent, _name) in relationships.items():
                if parent in descendants and pid not in descendants:
                    descendants.add(pid); changed = True
        return {
            pid for pid in descendants
            if pid == int(root_pid) or relationships.get(pid, (0, ""))[1] in {"chrome.exe", "chromedriver.exe"}
        }

    def chrome_windows_for_pids(self, process_ids: set[int]) -> list[int]:
        windows: list[int] = []
        callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

        @callback_type
        def callback(hwnd, _lparam):
            process_id = wintypes.DWORD()
            self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
            if int(process_id.value) in process_ids:
                class_name = ctypes.create_unicode_buffer(256)
                self.user32.GetClassNameW(hwnd, class_name, len(class_name))
                if class_name.value.startswith("Chrome_WidgetWin_"):
                    windows.append(int(hwnd))
            return True

        self.user32.EnumWindows(callback, 0)
        return windows

    def is_window(self, hwnd: int) -> bool:
        return bool(self.user32.IsWindow(hwnd))

    def is_visible(self, hwnd: int) -> bool:
        return bool(self.user32.IsWindowVisible(hwnd))

    def hide(self, hwnd: int) -> None:
        self.user32.ShowWindow(hwnd, SW_HIDE)

    def restore_and_foreground(self, hwnd: int) -> None:
        if not self.is_window(hwnd):
            raise RuntimeError("The owned Chrome window is no longer available.")
        current_thread = int(self.kernel32.GetCurrentThreadId())
        target_thread = int(self.user32.GetWindowThreadProcessId(hwnd, None))
        foreground = int(self.user32.GetForegroundWindow() or 0)
        foreground_thread = int(self.user32.GetWindowThreadProcessId(foreground, None)) if foreground else 0
        attached: list[int] = []
        try:
            for thread_id in {target_thread, foreground_thread} - {0, current_thread}:
                if self.user32.AttachThreadInput(current_thread, thread_id, True):
                    attached.append(thread_id)
            self.user32.ShowWindow(hwnd, SW_RESTORE)
            self.user32.SetWindowPos(hwnd, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW)
            self.user32.BringWindowToTop(hwnd)
            self.user32.SetForegroundWindow(hwnd)
            self.user32.SetFocus(hwnd)
        finally:
            for thread_id in attached:
                self.user32.AttachThreadInput(current_thread, thread_id, False)


class OwnedChromeWindow:
    def __init__(
        self,
        driver,
        *,
        api: WindowsApi | None = None,
        clock: Callable[[], float] | None = None,
        sleep: Callable[[float], None] | None = None,
    ):
        self.driver = driver
        self.api = api or WindowsApi()
        self.clock = clock or time.monotonic
        self.sleep = sleep or time.sleep
        service_process = getattr(getattr(driver, "service", None), "process", None)
        self.root_pid = int(getattr(service_process, "pid", 0) or 0)
        self.session_id = str(getattr(driver, "session_id", "") or "")
        if not self.root_pid or not self.session_id:
            raise RuntimeError("Could not establish ownership of the automation Chrome window.")
        self.hwnd: int | None = None

    def discover(self, timeout: float = 15) -> int:
        deadline = self.clock() + timeout
        while self.clock() < deadline:
            owned_pids = self.api.descendant_process_ids(self.root_pid)
            windows = self.api.chrome_windows_for_pids(owned_pids)
            if windows:
                self.hwnd = windows[0]
                return self.hwnd
            self.sleep(0.05)
        raise RuntimeError("The owned Chrome window did not become available.")

    def hide(self) -> None:
        hwnd = self.hwnd or self.discover()
        self.api.hide(hwnd)
        if self.api.is_visible(hwnd):
            raise RuntimeError("The owned Chrome window could not be hidden safely.")

    def reveal_and_focus(self) -> None:
        if str(getattr(self.driver, "session_id", "") or "") != self.session_id:
            raise RuntimeError("The automation browser session changed before Fee handoff.")
        hwnd = self.hwnd or self.discover()
        self.api.restore_and_foreground(hwnd)
        if not self.api.is_visible(hwnd):
            raise RuntimeError("The owned Chrome window could not be revealed for Fee handoff.")

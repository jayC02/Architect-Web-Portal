# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    WebDriverException,
)
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait


SHORT_TIMEOUT = 8
INTERACTION_TIMEOUT = 15
NAVIGATION_TIMEOUT = 30
POLL_FREQUENCY = 0.15


DETACHED_NODE_MESSAGES = (
    "node with given id does not belong to the document",
    "node is detached from document",
    "stale element reference",
)


def is_detached_node_error(error):
    return isinstance(error, StaleElementReferenceException) or (
        isinstance(error, WebDriverException)
        and any(message in str(error).lower() for message in DETACHED_NODE_MESSAGES)
    )


def _clickable_element(driver, by, locator):
    try:
        element = driver.find_element(by, locator)
        return element if element.is_displayed() and element.is_enabled() else False
    except NoSuchElementException:
        return False
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return False
        raise


def wait_dom_ready(driver, timeout=30):
    WebDriverWait(driver, timeout).until(
        lambda d: d.execute_script("return document.readyState") == "complete"
    )


def js_click_by_id(driver, element_id, timeout=30):
    # Wait for DOM ready and element presence
    wait_dom_ready(driver, timeout)
    el = WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.ID, element_id))
    )
    # Scroll into view (center) then JS click
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", el)
    driver.execute_script("arguments[0].click();", el)


def get_when_present(driver, by, locator, timeout=30):
    return WebDriverWait(driver, timeout, poll_frequency=POLL_FREQUENCY).until(
        EC.presence_of_element_located((by, locator))
    )


def get_when_clickable(driver, by, locator, timeout=30):
    return WebDriverWait(driver, timeout, poll_frequency=POLL_FREQUENCY).until(
        lambda current: _clickable_element(current, by, locator)
    )


def click_when_clickable(driver, by, locator, timeout=30):
    for _attempt in range(3):
        element = get_when_clickable(driver, by, locator, timeout=timeout)
        try:
            element.click()
            return element
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    raise StaleElementReferenceException(
        f"Element kept changing before it could be clicked: {by}={locator}"
    )


def type_into(driver, by, locator, value, timeout=30, clear_first=True):
    for _attempt in range(3):
        element = get_when_clickable(driver, by, locator, timeout=timeout)
        try:
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
            desired = str(value or "")
            current = element.get_attribute("value") if hasattr(element, "get_attribute") else None
            if (current or "") == desired:
                return element
            if clear_first:
                element.clear()
            if desired:
                element.send_keys(desired)
            return element
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    raise StaleElementReferenceException(
        f"Element kept changing before text could be entered: {by}={locator}"
    )


def select_by_text(driver, by, locator, visible_text, timeout=30):
    dropdown = Select(
        WebDriverWait(driver, timeout).until(
            EC.element_to_be_clickable((by, locator))
        )
    )
    if dropdown.first_selected_option.text.strip() != str(visible_text).strip():
        dropdown.select_by_visible_text(visible_text)
    return dropdown


def yes_no_answer(user_inputs, key, default="No"):
    value = user_inputs.get(key, default)
    if isinstance(value, bool):
        return "Yes" if value else "No"
    text = str(value or "").strip().lower()
    if text in {"yes", "y", "true", "1", "on"}:
        return "Yes"
    if text in {"no", "n", "false", "0", "off"}:
        return "No"
    return default


def click_yes_no_answer(driver, user_inputs, key, yes_label_id, no_label_id, default="No", timeout=30):
    answer = yes_no_answer(user_inputs, key, default)
    label_id = yes_label_id if answer == "Yes" else no_label_id
    print(f"Selecting '{answer}' for '{key}'.")
    label = WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((By.XPATH, f"//label[@for='{label_id}']"))
    )
    label.click()
    return answer


def set_text_value(driver, element, value):
    element.clear()
    element.send_keys(value)
    driver.execute_script(
        """
        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
        """,
        element,
    )


def select_option_by_id(driver, element_id, label, timeout=30):
    print(f"Selecting '{label}'.")
    wait_dom_ready(driver, timeout)
    element = WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.ID, element_id))
    )
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)

    click_attempts = [
        (By.XPATH, f"//label[@for='{element_id}']"),
        (By.ID, element_id),
    ]
    clicked = False
    for by, locator in click_attempts:
        try:
            target = WebDriverWait(driver, 5).until(EC.element_to_be_clickable((by, locator)))
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", target)
            target.click()
            clicked = True
            break
        except Exception:
            pass

    if not clicked:
        driver.execute_script("arguments[0].click();", element)

    driver.execute_script(
        """
        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('blur', { bubbles: true }));
        """,
        element,
    )

    selected = driver.execute_script(
        "return Boolean(arguments[0].checked || arguments[0].selected);",
        element,
    )
    if not selected:
        driver.execute_script(
            """
            arguments[0].checked = true;
            arguments[0].dispatchEvent(new Event('click', { bubbles: true }));
            arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
            arguments[0].dispatchEvent(new Event('blur', { bubbles: true }));
            """,
            element,
        )
        selected = driver.execute_script("return Boolean(arguments[0].checked);", element)

    if not selected:
        raise RuntimeError(f"Could not select '{label}' using portal field id '{element_id}'.")
    print(f"Selected '{label}'.")
    return element

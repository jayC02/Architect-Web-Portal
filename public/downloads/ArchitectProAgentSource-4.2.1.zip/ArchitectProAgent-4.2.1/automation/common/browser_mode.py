"""Lightweight browser-mode contract safe to import during GUI startup."""

from enum import Enum


class BrowserMode(str, Enum):
    AUTO = "AUTO"
    HEADLESS = "HEADLESS"
    VISIBLE = "VISIBLE"

    @classmethod
    def parse(cls, value):
        if isinstance(value, cls):
            return value
        try:
            return cls(str(value or cls.AUTO.value).upper())
        except ValueError as exc:
            raise ValueError("Browser mode must be AUTO, HEADLESS or VISIBLE.") from exc

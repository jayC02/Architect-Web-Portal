"""Postback-safe Declaration completion and verified Fee handoff."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Callable, Mapping
from urllib.parse import urlparse

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_when_clickable, select_option_by_id, yes_no_answer
from automation.common.handoff import FEE_HANDOFF, UserActionRequired
from automation.common.proposal_creation import (
    BUILDING_WARRANT as PORTAL_BUILDING_WARRANT,
    HOUSEHOLDER as PORTAL_HOUSEHOLDER,
)
from automation.models import PLANNING_TYPES, WARRANT_TYPES


DECLARATION_BUTTON_ID = "MainContent_FormSections_btnDeclaration"
RD1_CHECKBOX_ID = "MainContent_DeclarationWizard_cbAcceptRD1"
RD1_NEXT_ID = "MainContent_DeclarationWizard_btnNextRD1"
RD2_CHECKBOX_ID = "MainContent_DeclarationWizard_cbComplete"
RD2_NEXT_ID = "MainContent_DeclarationWizard_btnNextRD2"
RD3_NEXT_ID = "MainContent_DeclarationWizard_btnNextRD3"
FEE_BUTTON_ID = "MainContent_FormSections_btnFee"
BW_PERSON_ID = "MainContent_DeclarationWizard_ddlBuildingWarrant1"
BW_OWNERSHIP_ID = "MainContent_DeclarationWizard_ddlBuildingWarrant2"
BW_ACCEPT_CHECKBOX_ID = "MainContent_DeclarationWizard_cbAcceptBW"
BW_FIRST_NEXT_ID = "MainContent_DeclarationWizard_btnNextBW"

BW_SINGLE_OWNER = "I am the owner of the building"
BW_PLURAL_OWNER = "We are the owners of the building"
BW_NON_OWNER = "That the owner of the building is aware of this application"


class DeclarationHandoffError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class DeclarationSelectors:
    enter: str = DECLARATION_BUTTON_ID
    rd1_checkbox: str = RD1_CHECKBOX_ID
    rd1_next: str = RD1_NEXT_ID
    rd2_checkbox: str = RD2_CHECKBOX_ID
    rd2_next: str = RD2_NEXT_ID
    rd3_next: str = RD3_NEXT_ID
    fee: str = FEE_BUTTON_ID
    person_dropdown: str | None = None
    ownership_dropdown: str | None = None


HOUSEHOLDER_PLANNING_TYPE = "HOUSEHOLDER_PLANNING"
BUILDING_WARRANT_TYPE = "BUILDING_WARRANT"


# Canonical runtime application types own the configuration. Portal proposal
# labels are normalized once at this shared boundary because those are the
# values currently passed by the two workflow entrypoints.
_HOUSEHOLDER_DECLARATION_SELECTORS = DeclarationSelectors()
_BUILDING_WARRANT_DECLARATION_SELECTORS = DeclarationSelectors(
    rd1_checkbox=BW_ACCEPT_CHECKBOX_ID,
    rd1_next=BW_FIRST_NEXT_ID,
    person_dropdown=BW_PERSON_ID,
    ownership_dropdown=BW_OWNERSHIP_ID,
)
DECLARATION_SELECTORS = {
    HOUSEHOLDER_PLANNING_TYPE: _HOUSEHOLDER_DECLARATION_SELECTORS,
    BUILDING_WARRANT_TYPE: _BUILDING_WARRANT_DECLARATION_SELECTORS,
}

_DECLARATION_TYPE_ALIASES = {
    **{str(value).strip().casefold(): HOUSEHOLDER_PLANNING_TYPE for value in PLANNING_TYPES},
    **{str(value).strip().casefold(): BUILDING_WARRANT_TYPE for value in WARRANT_TYPES},
    PORTAL_HOUSEHOLDER.strip().casefold(): HOUSEHOLDER_PLANNING_TYPE,
    PORTAL_BUILDING_WARRANT.strip().casefold(): BUILDING_WARRANT_TYPE,
}


def _canonical_declaration_type(application_type) -> str:
    raw_value = getattr(application_type, "value", application_type)
    canonical = _DECLARATION_TYPE_ALIASES.get(str(raw_value or "").strip().casefold())
    if canonical is None:
        raise ValueError(
            f"Declaration is not configured for application type {raw_value!r}."
        )
    return canonical


def declaration_selectors_for(application_type: str) -> DeclarationSelectors:
    return DECLARATION_SELECTORS[_canonical_declaration_type(application_type)]


def _emit(progress: Callable | None, stage: str, status: str, message: str) -> None:
    if progress:
        progress(stage, status, message)


def _present(driver, element_id: str):
    elements = driver.find_elements(By.ID, element_id)
    return elements[0] if elements else False


def _wait_present(driver, element_id: str, timeout: float = 30):
    return WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.ID, element_id))
    )


def _selected_value(driver, element_id: str):
    try:
        element = _present(driver, element_id)
        if not element:
            return False
        selected = Select(element).first_selected_option
        return selected.get_attribute("value") or selected.text.strip()
    except StaleElementReferenceException:
        return False


def ensure_dropdown_selected(
    driver,
    element_id: str,
    expected_value: str,
    *,
    timeout: float = 30,
) -> None:
    """Select and positively verify a portal dropdown after any rerender."""
    if _selected_value(driver, element_id) != expected_value:
        for _attempt in range(3):
            try:
                dropdown = Select(_wait_present(driver, element_id, timeout))
                dropdown.select_by_value(expected_value)
                break
            except StaleElementReferenceException:
                continue
        else:
            raise DeclarationHandoffError(
                f"The portal kept replacing declaration dropdown '{element_id}'."
            )

    try:
        WebDriverWait(driver, timeout).until(
            lambda current: _selected_value(current, element_id) == expected_value
        )
    except TimeoutException as exc:
        raise DeclarationHandoffError(
            f"The portal did not confirm declaration dropdown '{element_id}'."
        ) from exc


def building_warrant_declaration_values(
    user_inputs: Mapping[str, object] | None,
) -> tuple[str, str]:
    """Map existing applicant/ownership data to the exact warrant options."""
    values = user_inputs or {}
    plural = bool(str(values.get("Applicant Company") or "").strip())
    person = "We" if plural else "I"
    is_owner = yes_no_answer(values, "Applicant Is Owner", default="Yes") == "Yes"
    if not is_owner:
        return person, BW_NON_OWNER
    return person, BW_PLURAL_OWNER if plural else BW_SINGLE_OWNER


def ensure_checkbox_checked(driver, element_id: str, *, timeout: float = 30) -> None:
    checkbox = _wait_present(driver, element_id, timeout)
    try:
        checked = checkbox.is_selected()
    except StaleElementReferenceException:
        checkbox = _wait_present(driver, element_id, timeout)
        checked = checkbox.is_selected()
    if not checked:
        # Portal checkbox inputs can be present but not natively interactable.
        # Reuse the established label/input/JS fallback used by existing forms.
        select_option_by_id(driver, element_id, "Declaration confirmation", timeout=timeout)

    def checked_after_reacquire(current):
        try:
            element = _present(current, element_id)
            return element if element and element.is_selected() else False
        except StaleElementReferenceException:
            return False

    try:
        WebDriverWait(driver, timeout).until(checked_after_reacquire)
    except TimeoutException as exc:
        raise DeclarationHandoffError(
            f"The portal did not confirm declaration checkbox '{element_id}'."
        ) from exc


def _advance_once(driver, button_id: str, next_element_id: str, *, timeout: float = 45) -> None:
    click_when_clickable(driver, By.ID, button_id, timeout=timeout)
    # Never click again on an uncertain postback. Reconcile only by reacquiring
    # the deterministic next-state control.
    try:
        WebDriverWait(driver, timeout).until(lambda current: _present(current, next_element_id))
    except TimeoutException as exc:
        if _present(driver, next_element_id):
            return
        raise DeclarationHandoffError(
            f"The portal did not confirm advancement from '{button_id}'."
        ) from exc


def verify_application_main_page(
    driver,
    selectors: DeclarationSelectors,
    *,
    timeout: float = 45,
) -> None:
    """Confirm the post-Declaration Form Summary without navigating further."""
    def main_page(current):
        try:
            path = PurePosixPath(urlparse(str(current.current_url or "")).path).name.casefold()
            return bool(
                path == "formsummary.aspx"
                and _present(current, selectors.enter)
                and _present(current, selectors.fee)
            )
        except StaleElementReferenceException:
            return False

    try:
        WebDriverWait(driver, timeout).until(main_page)
    except TimeoutException as exc:
        raise DeclarationHandoffError(
            "The portal did not confirm the application main page after Declaration."
        ) from exc


def complete_declaration(
    driver,
    application_type: str,
    *,
    user_inputs: Mapping[str, object] | None = None,
    progress: Callable | None = None,
    timeout: float = 45,
) -> DeclarationSelectors:
    selectors = declaration_selectors_for(application_type)
    _emit(progress, "declaration.open", "running", "Opening declaration")
    click_when_clickable(driver, By.ID, selectors.enter, timeout=timeout)
    first_control = selectors.person_dropdown or selectors.rd1_checkbox
    _wait_present(driver, first_control, timeout)
    _emit(progress, "declaration.open", "completed", "Declaration opened")

    if selectors.person_dropdown and selectors.ownership_dropdown:
        person, ownership = building_warrant_declaration_values(user_inputs)
        _emit(progress, "declaration.person", "running", "Setting declaration person")
        ensure_dropdown_selected(driver, selectors.person_dropdown, person, timeout=timeout)
        _emit(progress, "declaration.person", "completed", "Declaration person confirmed")
        _emit(progress, "declaration.ownership", "running", "Setting declaration ownership")
        ensure_dropdown_selected(
            driver,
            selectors.ownership_dropdown,
            ownership,
            timeout=timeout,
        )
        _emit(progress, "declaration.ownership", "completed", "Declaration ownership confirmed")
        _emit(progress, "declaration.accept", "running", "Confirming declaration")
        ensure_checkbox_checked(driver, selectors.rd1_checkbox, timeout=timeout)
        _emit(progress, "declaration.accept", "completed", "Declaration confirmation checked")
        _emit(progress, "declaration.next_1", "running", "Continuing declaration")
        _advance_once(driver, selectors.rd1_next, selectors.rd2_checkbox, timeout=timeout)
        _emit(progress, "declaration.next_1", "completed", "Declaration continued")
        _emit(progress, "declaration.complete", "running", "Completing declaration")
        ensure_checkbox_checked(driver, selectors.rd2_checkbox, timeout=timeout)
        _emit(progress, "declaration.complete", "completed", "Declaration completion checked")
        _emit(progress, "declaration.next_2", "running", "Continuing declaration")
        _advance_once(driver, selectors.rd2_next, selectors.rd3_next, timeout=timeout)
        _emit(progress, "declaration.next_2", "completed", "Final declaration step opened")
        _emit(progress, "declaration.next_3", "running", "Finishing declaration")
        _advance_once(driver, selectors.rd3_next, selectors.fee, timeout=timeout)
        verify_application_main_page(driver, selectors, timeout=timeout)
        _emit(progress, "declaration.next_3", "completed", "Declaration completed")
        return selectors

    # Preserve the proven Householder sequence and its existing progress contract.
    _emit(progress, "declaration.accept", "running", "Confirming declaration")
    ensure_checkbox_checked(driver, selectors.rd1_checkbox, timeout=timeout)
    _advance_once(driver, selectors.rd1_next, selectors.rd2_checkbox, timeout=timeout)
    ensure_checkbox_checked(driver, selectors.rd2_checkbox, timeout=timeout)
    _advance_once(driver, selectors.rd2_next, selectors.rd3_next, timeout=timeout)
    _emit(progress, "declaration.accept", "completed", "Declaration confirmed")
    _emit(progress, "declaration.complete", "running", "Completing declaration")
    _advance_once(driver, selectors.rd3_next, selectors.fee, timeout=timeout)
    verify_application_main_page(driver, selectors, timeout=timeout)
    _emit(progress, "declaration.complete", "completed", "Declaration completed")
    return selectors


def _fee_page_marker(driver) -> bool:
    path_name = PurePosixPath(urlparse(str(driver.current_url or "")).path).name.lower()
    if "fee" in path_name:
        return True
    fee_controls = driver.find_elements(
        By.CSS_SELECTOR,
        "[id*='FeeWizard'], [name*='FeeWizard']",
    )
    if fee_controls:
        return True
    headings = driver.find_elements(
        By.XPATH,
        "//*[self::h1 or self::h2 or self::h3 or self::legend]"
        "[normalize-space()='Fee' or contains(normalize-space(), 'Application Fee')]",
    )
    return bool(headings)


def open_fee_and_handoff(
    driver,
    application_type: str,
    *,
    declaration_complete: bool,
    progress: Callable | None = None,
    timeout: float = 45,
) -> UserActionRequired:
    if not declaration_complete:
        raise DeclarationHandoffError("Fee cannot open before Declaration is confirmed complete.")
    selectors = declaration_selectors_for(application_type)
    _emit(progress, "fee.open", "running", "Opening fee")
    fee_button = click_when_clickable(driver, By.ID, selectors.fee, timeout=timeout)

    def fee_confirmed(current):
        try:
            postback_complete = EC.staleness_of(fee_button)(current)
        except StaleElementReferenceException:
            postback_complete = True
        return bool(postback_complete and _fee_page_marker(current))

    try:
        WebDriverWait(driver, timeout).until(fee_confirmed)
    except TimeoutException as exc:
        raise DeclarationHandoffError(
            "The portal did not confirm that the Fee page opened."
        ) from exc
    _emit(progress, "fee.open", "completed", "Fee page opened")
    return FEE_HANDOFF

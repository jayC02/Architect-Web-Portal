"""Architect Pro API snapshot adapter; intentionally outside the runner core."""

from __future__ import annotations

import os

from automation.models import RuntimeJob


def runtime_job_from_portal(job, downloaded_documents, download_failures, *, login_email):
    # Portal transport/mapping remains an integration adapter. Selenium and the
    # runner never import this GUI-era service module.
    from gui.services import portal_handoff

    state = portal_handoff.normalise_portal_job(job, downloaded_documents, download_failures)
    if state.blocking_issues:
        raise ValueError("Prepared job is incomplete: " + "; ".join(state.blocking_issues))
    local_paths = [str(item.get("localPath") or "") for item in state.documents if item.get("localPath")]
    pdf_folder = os.path.dirname(local_paths[0]) if local_paths else ""
    inputs = dict(state.form_values)
    inputs["Email"] = str(login_email or "").strip()
    inputs["PDF Folder Path"] = pdf_folder
    labels = {
        "location_plan": "Location Plan", "proposed": "Proposed Plans",
        "existing": "Existing Plans", "elevations": "Elevations",
        "sections": "Sections", "details": "Details", "calcs": "Calculations",
        "specs": "Specifications", "photos": "Photos", "other": "Other",
    }
    identity = portal_handoff.application_identity_from_job(job)
    return RuntimeJob.from_mapping({
        "job_id": identity["job_id"],
        "application_type": job.get("type") or identity["application_type"],
        "site_label": inputs.get("Site Address") or job.get("title") or "Prepared application",
        "user_inputs": inputs,
        "document_mapping": {
            "pdf_folder_path": pdf_folder,
            "buckets": state.document_buckets,
            "bucket_labels": labels,
        },
        "metadata": {**identity, "state_model": dict(job.get("stateModel") or {})},
    })

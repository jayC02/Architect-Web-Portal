"""Immutable runtime contracts shared by GUI, CLI and Selenium workflows."""

from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping


PLANNING_TYPES = {"HOUSEHOLDER_PLANNING", "PLANNING_APPLICATION", "Householder / Planning"}
WARRANT_TYPES = {"BUILDING_WARRANT", "Building Warrant"}


@dataclass(frozen=True, slots=True)
class RuntimeJob:
    job_id: str
    application_type: str
    site_label: str
    user_inputs: Mapping[str, Any]
    document_mapping: Mapping[str, Any]
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> "RuntimeJob":
        application_type = str(value.get("application_type") or value.get("applicationType") or "").strip()
        if application_type not in PLANNING_TYPES | WARRANT_TYPES:
            raise ValueError("The prepared job has an unsupported application type.")
        job_id = str(value.get("job_id") or value.get("jobId") or "").strip()
        if not job_id:
            raise ValueError("The prepared job is missing its job identifier.")
        inputs = deepcopy(dict(value.get("user_inputs") or value.get("userInputs") or {}))
        documents = deepcopy(dict(value.get("document_mapping") or value.get("documentMapping") or {}))
        return cls(
            job_id=job_id,
            application_type=application_type,
            site_label=str(value.get("site_label") or value.get("siteLabel") or inputs.get("Site Address") or "Prepared application"),
            user_inputs=MappingProxyType(inputs),
            document_mapping=MappingProxyType(documents),
            metadata=MappingProxyType(deepcopy(dict(value.get("metadata") or {}))),
        )

    def mutable_inputs(self) -> dict[str, Any]:
        return deepcopy(dict(self.user_inputs))

    def mutable_document_mapping(self) -> dict[str, Any]:
        return deepcopy(dict(self.document_mapping))

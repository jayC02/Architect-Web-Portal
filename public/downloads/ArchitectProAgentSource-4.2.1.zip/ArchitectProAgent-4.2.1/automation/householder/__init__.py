"""Householder planning automation workflow."""

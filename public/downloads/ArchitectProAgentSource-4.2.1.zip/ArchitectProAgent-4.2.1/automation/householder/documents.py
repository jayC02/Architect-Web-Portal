# -*- coding: utf-8 -*-
import os
import re

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import (
    is_detached_node_error,
    select_by_text,
    select_option_by_id,
    type_into,
    wait_dom_ready,
)
from automation.common.documents import (
    _extract_pdf_first_page_text,
    extract_title_and_description,
    get_document_type_from_pdf,
    get_paper_size_from_pdf,
    load_supporting_docs_upload_list,
)
from automation.common.uploads import (
    dismiss_gdpr_modal_if_present,
    get_visible_portal_error,
    wait_for_supporting_doc_upload_result,
)
from automation.common.runtime import record_checkpoint
from automation.householder.navigation import (
    click_by_id,
    click_checklist_next,
    click_label_for_any,
)

HOUSEHOLDER_CHECKLIST_YES_IDS = [
    "MainContent_HouseholderApplicationChecklistWizard_rblWrittenDescription_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblPostalAddress_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblApplicantName_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblLocationPlan_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblCertificateOwnership_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblFeeProvided_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblOtherPlans_0",
]

HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS = {
    "elevations": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_0",
    "floor_plans": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_1",
    "sections": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_2",
    "site_or_block_plan": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_3",
    "roof_plan": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_4",
    "photos": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_5",
}

LOCATION_PLAN_SECTION_ID = "MainContent_FormSections_btnLocationPlan"
LOCATION_PLAN_CONTINUE_ID = "MainContent_LocationPlanWizard_btnContinueAddLocationPlan"
LOCATION_PLAN_UPLOADED_ID = "MainContent_LocationPlanWizard_rbUploaded"
LOCATION_PLAN_OPTIONS_CONTINUE_ID = "MainContent_LocationPlanWizard_btnContinueLocationPlanOptions"
LOCATION_PLAN_FILE_ID = "MainContent_LocationPlanWizard_LocPlanFileUpload"
LOCATION_PLAN_PAPER_SIZE_ID = "MainContent_LocationPlanWizard_ddlPaperSizeUploadLocPlan"
LOCATION_PLAN_DOCUMENT_TYPE_ID = "MainContent_LocationPlanWizard_ddlDocTypeUploadLocPlan"
LOCATION_PLAN_PRINTED_ID = "MainContent_LocationPlanWizard_cbFilePrinted"
LOCATION_PLAN_ANNOTATED_ID = "MainContent_LocationPlanWizard_cbFileAnnotated"
LOCATION_PLAN_SAVE_ID = "MainContent_LocationPlanWizard_btnUploadUploadLocationPlan"
LOCATION_PLAN_CONFIRM_ID = "MainContent_btnConfirm"


def _filename_has_any(filename, keywords):
    text = str(filename or "").lower()
    return any(keyword in text for keyword in keywords)


def normalise_supporting_document_title(filename):
    base = os.path.splitext(os.path.basename(str(filename or "")))[0]
    title = re.sub(r"[^A-Za-z0-9]+", "_", base).strip("_")
    if not title:
        raise RuntimeError(
            "Supporting document upload: the filename does not contain an alphanumeric title."
        )
    if not title[0].isalpha():
        title = f"D_{title}"
    return title


def normalise_supporting_document_description(description):
    value = re.sub(r"[^A-Za-z0-9 _]+", " ", str(description or ""))
    value = re.sub(r"\s+", " ", value).strip()
    if not value:
        raise RuntimeError(
            "Supporting document upload: the description does not contain alphanumeric text."
        )
    return value


def householder_electronic_document_ids(
    upload_entries,
    location_plan_file=None,
    pdf_folder_path=None,
):
    """
    Map the saved PDF buckets to the second Householder checklist page.
    Returns checkbox element IDs that should be selected.
    """
    entries = list(upload_entries or [])
    if location_plan_file:
        entries.append((location_plan_file, "location_plan"))

    bucket_files = {}
    for filename, bucket_key in entries:
        bucket_files.setdefault(str(bucket_key or ""), []).append(str(filename or ""))

    all_files = [filename for filenames in bucket_files.values() for filename in filenames]
    drawing_text = ""
    if pdf_folder_path:
        drawing_buckets = {"existing", "proposed", "elevations", "sections", "details", "other"}
        drawing_text = " ".join(
            _extract_pdf_first_page_text(os.path.join(pdf_folder_path, filename))
            for filename, bucket_key in entries
            if bucket_key in drawing_buckets
        ).lower()

    selected_keys = []

    if (
        bucket_files.get("elevations")
        or any(_filename_has_any(name, ["elevation"]) for name in all_files)
        or re.search(r"\belevations?\b", drawing_text)
    ):
        selected_keys.append("elevations")

    if (
        bucket_files.get("existing")
        or bucket_files.get("proposed")
        or any(_filename_has_any(name, ["floor", "existing plan", "proposed plan"]) for name in all_files)
    ):
        selected_keys.append("floor_plans")

    if (
        bucket_files.get("sections")
        or any(_filename_has_any(name, ["section"]) for name in all_files)
        or re.search(r"\b(?:cross\s+)?sections?\b", drawing_text)
    ):
        selected_keys.append("sections")

    if (
        any(_filename_has_any(name, ["site", "block", "layout", "access"]) for name in all_files)
        or re.search(r"\bsite\s+(?:layout\s+)?plans?\b|\bblock\s+plans?\b", drawing_text)
    ):
        selected_keys.append("site_or_block_plan")

    if (
        any(_filename_has_any(name, ["roof"]) for name in all_files)
        or re.search(r"\broof\s+plans?\b", drawing_text)
    ):
        selected_keys.append("roof_plan")

    if (
        bucket_files.get("photos")
        or any(_filename_has_any(name, ["photo", "photomontage"]) for name in all_files)
        or re.search(r"\bphotos?\b|\bphotomontages?\b", drawing_text)
    ):
        selected_keys.append("photos")

    return [HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS[key] for key in selected_keys]


def _optional_email_copy_state(driver):
    try:
        checkboxes = driver.find_elements(By.ID, "MainContent_cbUseEmail")
        if not checkboxes:
            return None
        return "selected" if checkboxes[0].is_selected() else "unselected"
    except StaleElementReferenceException:
        return None
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return None
        raise


def complete_email_notification(driver):
    click_by_id(driver, "MainContent_FormSections_btnEmailNotification", "Email Notification section", timeout=30)
    state = WebDriverWait(driver, 30, poll_frequency=0.1).until(_optional_email_copy_state)
    if state == "selected":
        click_label_for_any(
            driver,
            ["MainContent_cbUseEmail"],
            "Disable additional notification email copies",
        )
        WebDriverWait(driver, 5, poll_frequency=0.1).until(
            lambda current: _optional_email_copy_state(current) == "unselected"
        )
    click_by_id(driver, "MainContent_btnConfirm", "Email notification confirm", timeout=30)
    print("Email Notification complete.")


def complete_checklist(
    driver,
    upload_entries=None,
    location_plan_file=None,
    pdf_folder_path=None,
):
    click_by_id(driver, "MainContent_FormSections_btnChecklist", "Checklist section", timeout=30)

    for element_id in HOUSEHOLDER_CHECKLIST_YES_IDS:
        select_option_by_id(driver, element_id, f"Householder checklist yes: {element_id}", timeout=30)

    click_checklist_next(driver)

    electronic_document_ids = householder_electronic_document_ids(
        upload_entries,
        location_plan_file,
        pdf_folder_path,
    )
    if len(electronic_document_ids) < 2:
        raise RuntimeError(
            "Householder checklist: the prepared documents support fewer than two "
            "portal drawing categories. Review the document mapping before retrying."
        )

    for element_id in electronic_document_ids:
        select_option_by_id(driver, element_id, f"Householder electronic document: {element_id}", timeout=30)

    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationChecklistWizard_rblAdditionalSurveys_1",
        "Additional surveys: No",
        timeout=30,
    )
    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationChecklistWizard_rblSupportingStatement_1",
        "Supporting statement: No",
        timeout=30,
    )

    click_checklist_next(driver)
    click_checklist_next(driver, finish=True)
    try:
        WebDriverWait(driver, 30).until(
            lambda current: current.find_elements(
                By.ID,
                "MainContent_FormSections_btnSupportingDocumentation",
            )
        )
    except TimeoutException as exc:
        raise RuntimeError(
            "Householder checklist: the exact Finish Next control did not return to Form Summary."
        ) from exc
    print("Checklist complete.")


def prepare_supporting_document_upload(driver):
    click_by_id(driver, "MainContent_FormSections_btnSupportingDocumentation", "Supporting Documentation section", timeout=30)
    click_label_for_any(driver, ["MainContent_rbYes"], "Supporting documents: Yes")
    click_by_id(driver, "MainContent_btnContinue", "Supporting documents continue", timeout=30)
    click_by_id(driver, "MainContent_btnAddDocumentation", "Add supporting document", timeout=30)
    click_label_for_any(driver, ["MainContent_rbUploaded"], "Supporting document already uploaded")
    click_by_id(driver, "MainContent_btnAttachmentContinue", "Supporting document attachment continue", timeout=30)


def choose_next_supporting_document_upload(driver):
    click_by_id(driver, "MainContent_btnAddDocumentation", "Add another supporting document", timeout=30)
    click_label_for_any(driver, ["MainContent_rbUploaded"], "Supporting document already uploaded")
    click_by_id(driver, "MainContent_btnAttachmentContinue", "Supporting document attachment continue", timeout=30)


def upload_supporting_document_entries(driver, upload_entries, effective_pdf_folder, bucket_labels):
    for index, (pdf_file, bucket_key) in enumerate(upload_entries):
        attach_path = os.path.join(effective_pdf_folder, pdf_file)
        print(f"Uploading supporting document '{pdf_file}' from category '{bucket_key}'.")

        document_title = normalise_supporting_document_title(pdf_file)
        if bucket_key != "other":
            description = bucket_labels.get(bucket_key, bucket_key)
        else:
            _, description = extract_title_and_description(pdf_file, attach_path)
        description = normalise_supporting_document_description(description)

        type_into(driver, By.ID, "MainContent_edtDocumentTitle", document_title)
        type_into(driver, By.ID, "MainContent_edtDescription", description)
        select_by_text(driver, By.ID, "MainContent_lbPaperSize", get_paper_size_from_pdf(attach_path))
        select_by_text(driver, By.ID, "MainContent_lbDocumentType", get_document_type_from_pdf(attach_path))

        attach_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "MainContent_fuAttachFile"))
        )
        attach_input.send_keys(attach_path)

        select_option_by_id(
            driver,
            "MainContent_rbReadAndUnderstood",
            "Supporting document read and understood",
            timeout=30,
        )

        click_by_id(
            driver,
            "MainContent_btnSaveDocEdit",
            "Save supporting document",
            timeout=30,
            submit_fallback=False,
        )
        wait_for_supporting_doc_upload_result(
            driver,
            pdf_file,
            timeout=60,
        )
        print(f"Uploaded '{pdf_file}' successfully.")

        if index < len(upload_entries) - 1:
            choose_next_supporting_document_upload(driver)

    try:
        click_by_id(driver, "MainContent_btnCancelDocEdit", "Cancel supporting document editor", timeout=2)
    except Exception:
        print("No supporting document editor cancel button visible; continuing to finish.")

    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    click_label_for_any(driver, ["MainContent_rbFinished"], "Supporting documentation finished")
    click_by_id(driver, "MainContent_btnDocSave", "Save supporting documentation section", timeout=30)
    print("Supporting Documentation complete.")


def upload_supporting_documents(driver, upload_entries, effective_pdf_folder, bucket_labels):
    prepare_supporting_document_upload(driver)
    upload_supporting_document_entries(
        driver,
        upload_entries,
        effective_pdf_folder,
        bucket_labels,
    )


def load_prepared_householder_documents(pdf_folder_path, mapping_data=None):
    prepared = load_supporting_docs_upload_list(pdf_folder_path, mapping_data=mapping_data)
    upload_entries, location_plan_file, effective_pdf_folder, bucket_labels = prepared
    if not location_plan_file:
        raise FileNotFoundError(
            "A Location Plan is required before Householder automation can continue."
        )

    location_plan_path = os.path.join(effective_pdf_folder, location_plan_file)
    if not os.path.isfile(location_plan_path):
        raise FileNotFoundError(
            f"The Location Plan mapped for Householder automation was not found: {location_plan_path}"
        )
    return (
        upload_entries,
        location_plan_file,
        location_plan_path,
        effective_pdf_folder,
        bucket_labels,
    )


def prepare_location_plan_upload(driver):
    click_by_id(driver, LOCATION_PLAN_SECTION_ID, "Location Plan section", timeout=30)
    click_by_id(driver, LOCATION_PLAN_CONTINUE_ID, "Location plan continue", timeout=30)
    click_label_for_any(driver, [LOCATION_PLAN_UPLOADED_ID], "Location plan already uploaded")
    click_by_id(
        driver,
        LOCATION_PLAN_OPTIONS_CONTINUE_ID,
        "Location plan upload options continue",
        timeout=30,
    )


def upload_location_plan(driver, location_plan_path):
    dismiss_gdpr_modal_if_present(driver)
    wait_dom_ready(driver)
    prepare_location_plan_upload(driver)

    file_input = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, LOCATION_PLAN_FILE_ID))
    )
    file_input.send_keys(location_plan_path)
    print("Location Plan file selected.")

    select_by_text(driver, By.ID, LOCATION_PLAN_PAPER_SIZE_ID, get_paper_size_from_pdf(location_plan_path))
    select_by_text(driver, By.ID, LOCATION_PLAN_DOCUMENT_TYPE_ID, "OS Extract")
    select_option_by_id(driver, LOCATION_PLAN_PRINTED_ID, "Location plan printed and verified")
    select_option_by_id(driver, LOCATION_PLAN_ANNOTATED_ID, "Location plan file annotated")
    click_by_id(
        driver,
        LOCATION_PLAN_SAVE_ID,
        "Save location plan",
        timeout=30,
        submit_fallback=False,
    )
    try:
        WebDriverWait(driver, 60).until(EC.staleness_of(file_input))
    except TimeoutException as exc:
        error = get_visible_portal_error(driver)
        if error:
            raise RuntimeError(f"Location Plan upload failed: {error}") from exc
        raise RuntimeError(
            "Location Plan upload: the portal did not complete the upload postback."
        ) from exc

    error = get_visible_portal_error(driver)
    if error:
        raise RuntimeError(f"Location Plan upload failed: {error}")
    click_by_id(driver, LOCATION_PLAN_CONFIRM_ID, "Confirm saved location plan", timeout=30)
    WebDriverWait(driver, 30).until(
        lambda current: current.find_elements(By.ID, "MainContent_FormSections_btnDeclaration")
    )
    print("Location Plan complete.")


def open_declaration(driver):
    click_by_id(driver, "MainContent_FormSections_btnDeclaration", "Declaration section", timeout=30)
    print("Declaration opened.")


def complete_later_householder_sections(
    driver,
    pdf_folder_path,
    user_inputs,
    prepared_documents=None,
):
    (
        upload_entries,
        location_plan_file,
        location_plan_path,
        effective_pdf_folder,
        bucket_labels,
    ) = prepared_documents or load_prepared_householder_documents(pdf_folder_path)

    complete_email_notification(driver)
    record_checkpoint("email_notification_complete", "email_notification")
    complete_checklist(driver, upload_entries, location_plan_file, effective_pdf_folder)
    record_checkpoint("document_checklist_complete", "checklist")
    upload_supporting_documents(driver, upload_entries, effective_pdf_folder, bucket_labels)
    record_checkpoint("supporting_documents_uploaded", "supporting_documents")
    upload_location_plan(driver, location_plan_path)
    record_checkpoint("location_plan_uploaded", "location_plan")

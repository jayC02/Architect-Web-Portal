# -*- coding: utf-8 -*-
import time

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, is_detached_node_error
from automation.common.runtime import wait_for_continue

HOUSEHOLDER_NEXT_ID = "MainContent_HouseholderApplicationMainDetailsWizard_StepNavigationTemplateContainerID_btnNextChecklist"
HOUSEHOLDER_FINISH_ID = "MainContent_HouseholderApplicationMainDetailsWizard_FinishNavigationTemplateContainerID_btnNextChecklist"
OWNERSHIP_NEXT_ID = "MainContent_CertificateOfOwnershipWizard_StepNavigationTemplateContainerID_btnNext"
OWNERSHIP_FINISH_ID = "MainContent_CertificateOfOwnershipWizard_FinishNavigationTemplateContainerID_btnNext"
OWNERSHIP_HHPP_NEXT_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP0"
OWNERSHIP_HHPP_FIRST_NEXT_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP1"
OWNERSHIP_HHPP_NEXT_IDS = {
    "initial": OWNERSHIP_HHPP_NEXT_ID,
    "ownership": OWNERSHIP_HHPP_FIRST_NEXT_ID,
    "25%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP1D",
    "30%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP1E",
    "35%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP2",
    "40%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP3",
    "65%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPPCertC3",
    "70%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPPReasonableSteps",
    "75%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextCertificatesHHPP",
    "85%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP4",
    "100%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP5",
}


def click_first_available(driver, candidates, timeout=30):
    def first_clickable(current):
        for by, locator in candidates:
            for element in current.find_elements(by, locator):
                try:
                    if element.is_displayed() and element.is_enabled():
                        return element
                except WebDriverException as exc:
                    if not is_detached_node_error(exc):
                        raise
        return False

    try:
        element = WebDriverWait(driver, timeout, poll_frequency=0.15).until(first_clickable)
    except TimeoutException as exc:
        raise RuntimeError(f"Could not click any expected element: {candidates}.") from exc
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    element.click()
    return element


def click_by_id(driver, element_id, label, timeout=15, submit_fallback=True):
    element = click_when_clickable(driver, By.ID, element_id, timeout=timeout)
    print(f"Clicked: {label}")
    return element


def wait_for_checked_by_id(driver, element_id, label, timeout=5):
    WebDriverWait(driver, timeout, poll_frequency=0.1).until(
        lambda d: d.find_element(By.ID, element_id).is_selected()
    )
    print(f"Confirmed: {label}")


def click_householder_step_next(driver, timeout=15, expected_id=None):
    element = click_by_id(driver, HOUSEHOLDER_NEXT_ID, "Householder step next", timeout=timeout)
    if expected_id:
        def expected_state(current):
            try:
                return bool(current.find_elements(By.ID, expected_id))
            except StaleElementReferenceException:
                return False
            except WebDriverException as exc:
                if is_detached_node_error(exc):
                    return False
                raise

        try:
            WebDriverWait(driver, timeout, poll_frequency=0.1).until(expected_state)
        except TimeoutException as exc:
            raise RuntimeError(
                "Householder Main Details did not reach expected control "
                f"'{expected_id}' after clicking Next. Current page: {driver.current_url}"
            ) from exc
    return element


def click_householder_finish_next(driver, timeout=15):
    return click_by_id(driver, HOUSEHOLDER_FINISH_ID, "Householder finish next", timeout=timeout)


def click_ownership_hhpp_next(driver, step, timeout=15):
    try:
        element_id = OWNERSHIP_HHPP_NEXT_IDS[step]
    except KeyError as exc:
        raise ValueError(f"Unknown Householder Certificate of Ownership wizard step: {step}") from exc

    try:
        return click_by_id(
            driver,
            element_id,
            f"Certificate of Ownership {step} next",
            timeout=timeout,
        )
    except TimeoutException as exc:
        raise RuntimeError(
            "Certificate of Ownership navigation failed at "
            f"{step}. Expected Next control ID: {element_id}"
        ) from exc


def wait_for_householder_form_summary_then_open_main_details(driver, timeout=600):
    form_summary_path = "/ePlanningClient/CustomPages/Applications/FormSummary.aspx"
    main_details_button_id = "MainContent_FormSections_btnMainDetails"

    print("--------------------------------------------------------------------------------")
    print("Waiting for the newly created Householder Form Summary page.")
    print("The automation will continue automatically when the form is ready.")
    print("--------------------------------------------------------------------------------")
    proposed_work_id = "MainContent_HouseholderApplicationMainDetailsWizard_tbxProposedWork"

    def page_state(current):
        if current.find_elements(By.ID, HOUSEHOLDER_NEXT_ID) or current.find_elements(By.ID, proposed_work_id):
            return "main_details"
        if form_summary_path in (current.current_url or "") and current.find_elements(By.ID, main_details_button_id):
            return "form_summary"
        return False

    try:
        state = WebDriverWait(driver, timeout, poll_frequency=0.2, ignored_exceptions=(StaleElementReferenceException,)).until(page_state)
        if state == "main_details":
            return "resume"
        click_when_clickable(driver, By.ID, main_details_button_id, timeout=8)
        WebDriverWait(driver, 30, poll_frequency=0.2).until(
            lambda d: d.find_elements(By.ID, HOUSEHOLDER_NEXT_ID) or d.find_elements(By.ID, proposed_work_id)
        )
        print("Householder Main Details wizard loaded.")
        return "auto"
    except TimeoutException as exc:
        raise RuntimeError(
            "Timed out waiting for the ePlanning Householder Form Summary or Main Details page."
        ) from exc


def click_label_for_any(driver, label_for_ids, label, timeout=15):
    def first_clickable(current):
        for label_for_id in label_for_ids:
            for element in current.find_elements(By.XPATH, f"//label[@for='{label_for_id}']"):
                try:
                    if element.is_displayed() and element.is_enabled():
                        return element
                except WebDriverException as exc:
                    if not is_detached_node_error(exc):
                        raise
        return False

    try:
        element = WebDriverWait(driver, timeout, poll_frequency=0.1).until(first_clickable)
    except TimeoutException as exc:
        raise RuntimeError(f"Could not select {label}.") from exc
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    element.click()
    print(f"Selected: {label}")
    return element


def click_yes_for_question_text(driver, keyword_groups, label, timeout=15):
    deadline = time.monotonic() + timeout
    last_result = None
    while time.monotonic() < deadline:
        result = driver.execute_script(
            """
            const groups = arguments[0].map(group => group.map(value => String(value).toLowerCase()));

            function visible(el) {
                if (!el) return false;
                const style = window.getComputedStyle(el);
                const rect = el.getBoundingClientRect();
                return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
            }

            function textOf(el) {
                return (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim().toLowerCase();
            }

            function matches(text) {
                return groups.some(group => group.every(keyword => text.includes(keyword)));
            }

            const containers = Array.from(document.querySelectorAll('fieldset, tr, li, .form-group, .row, div, table'));
            const candidates = containers
                .filter(visible)
                .map(el => ({ el, text: textOf(el) }))
                .filter(item => item.text && matches(item.text));

            candidates.sort((a, b) => a.text.length - b.text.length);

            for (const candidate of candidates) {
                const radios = Array.from(candidate.el.querySelectorAll("input[type='radio']"));
                for (const radio of radios) {
                    const radioId = radio.getAttribute('id') || '';
                    const radioValue = String(radio.getAttribute('value') || '').toLowerCase();
                    const radioLabel = radioId
                        ? document.querySelector(`label[for="${CSS.escape(radioId)}"]`)
                        : null;
                    const radioLabelText = textOf(radioLabel);
                    const looksYes =
                        radioId.toLowerCase().endsWith('yes') ||
                        radioId.toLowerCase().includes('yes') ||
                        radioValue === 'yes' ||
                        radioValue === 'true' ||
                        radioLabelText === 'yes' ||
                        radioLabelText.includes('yes');

                    if (looksYes && visible(radio)) {
                        radio.scrollIntoView({ block: 'center' });
                        radio.click();
                        radio.dispatchEvent(new Event('input', { bubbles: true }));
                        radio.dispatchEvent(new Event('change', { bubbles: true }));
                        return { ok: true, id: radioId, text: candidate.text.slice(0, 220) };
                    }

                    if (looksYes && radioLabel && visible(radioLabel)) {
                        radioLabel.scrollIntoView({ block: 'center' });
                        radioLabel.click();
                        radio.dispatchEvent(new Event('input', { bubbles: true }));
                        radio.dispatchEvent(new Event('change', { bubbles: true }));
                        return { ok: true, id: radioId, text: candidate.text.slice(0, 220) };
                    }
                }
            }

            return {
                ok: false,
                visibleLabels: Array.from(document.querySelectorAll('label'))
                    .filter(visible)
                    .map(label => ({
                        forId: label.getAttribute('for') || '',
                        text: textOf(label)
                    }))
                    .filter(label => label.text)
                    .slice(0, 80)
            };
            """,
            keyword_groups,
        )
        last_result = result
        if result and result.get("ok"):
            print(f"Selected checklist answer '{label}' using radio id '{result.get('id')}'.")
            return result
        time.sleep(0.25)

    raise RuntimeError(f"Could not select checklist answer '{label}'. Last page labels: {last_result}")


def click_checklist_next(driver, finish=False, timeout=15):
    exact_ids = [
        "MainContent_BuildingWarrantChecklistWizard_FinishNavigationTemplateContainerID_btnNext" if finish else "MainContent_BuildingWarrantChecklistWizard_StepNavigationTemplateContainerID_btnNext",
        "MainContent_HouseholderAndPlanningChecklistWizard_FinishNavigationTemplateContainerID_btnNext" if finish else "MainContent_HouseholderAndPlanningChecklistWizard_StepNavigationTemplateContainerID_btnNext",
        "MainContent_PlanningChecklistWizard_FinishNavigationTemplateContainerID_btnNext" if finish else "MainContent_PlanningChecklistWizard_StepNavigationTemplateContainerID_btnNext",
        "MainContent_HouseholderApplicationChecklistWizard_FinishNavigationTemplateContainerID_btnNext" if finish else "MainContent_HouseholderApplicationChecklistWizard_StepNavigationTemplateContainerID_btnNext",
    ]
    for element_id in exact_ids:
        if driver.find_elements(By.ID, element_id):
            return click_by_id(
                driver,
                element_id,
                "Checklist finish next" if finish else "Checklist step next",
                timeout=timeout,
            )

    keyword = "FinishNavigationTemplateContainerID" if finish else "StepNavigationTemplateContainerID"
    button = WebDriverWait(driver, timeout, poll_frequency=0.1).until(
        lambda d: next(
            (
                el for el in d.find_elements(By.CSS_SELECTOR, "input[type='submit'], button")
                if el.is_displayed()
                and el.is_enabled()
                and "ChecklistWizard" in (el.get_attribute("id") or "")
                and keyword in (el.get_attribute("id") or "")
                and "next" in ((el.get_attribute("value") or el.text or "").lower())
            ),
            None,
        )
    )
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", button)
    button.click()
    print("Clicked: " + ("Checklist finish next" if finish else "Checklist step next"))
    return button

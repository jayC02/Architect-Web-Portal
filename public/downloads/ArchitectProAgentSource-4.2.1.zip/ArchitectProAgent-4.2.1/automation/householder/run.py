# -*- coding: utf-8 -*-
import os

from selenium import webdriver
from selenium.webdriver.common.by import By

from automation.common.actions import click_when_clickable, type_into
from automation.common.declaration import complete_declaration, open_fee_and_handoff
from automation.building_warrant.fee import enter_calculated_fee, require_calculated_fee_minor_units
from automation.common.driver import create_chrome_driver
from automation.common.runtime import USER_INPUTS_JSON, clear_checkpoint, load_required_json, record_checkpoint
from automation.common.proposal_creation import HOUSEHOLDER, create_proposal_and_resume
from automation.common.uploads import dismiss_gdpr_modal_if_present
from automation.building_warrant.login import submit_login_and_wait_for_home
from automation.householder.agent import fill_agent_details
from automation.householder.applicant import fill_applicant_details
from automation.householder.documents import (
    choose_next_supporting_document_upload,
    complete_checklist,
    complete_email_notification,
    complete_later_householder_sections,
    load_prepared_householder_documents,
    prepare_supporting_document_upload,
    upload_location_plan,
    upload_supporting_documents,
)
from automation.householder.fields import click_yes_no, force_text_by_id
from automation.householder.main_details import complete_householder_main_details
from automation.householder.navigation import (
    HOUSEHOLDER_FINISH_ID,
    HOUSEHOLDER_NEXT_ID,
    click_by_id,
    click_checklist_next,
    click_first_available,
    click_householder_finish_next,
    click_householder_step_next,
    click_label_for_any,
    click_yes_for_question_text,
    wait_for_checked_by_id,
    wait_for_householder_form_summary_then_open_main_details,
)
from automation.householder.ownership import (
    complete_certificate_of_ownership,
    validate_certificate_of_ownership_inputs,
)


def main(
    *,
    user_inputs=None,
    password=None,
    driver=None,
    document_mapping=None,
    progress=None,
    cancellation_token=None,
    address_resolution_callback=None,
    applicant_title_resolution_callback=None,
):
    def stage(name, status, message):
        if progress:
            progress(name, status, message)
        if cancellation_token:
            cancellation_token.raise_if_cancelled()

    clear_checkpoint()
    if user_inputs is None:
        user_inputs = load_required_json(
            USER_INPUTS_JSON,
            required_keys=["Email", "PDF Folder Path"],
        )
    calculated_fee_minor_units = require_calculated_fee_minor_units(user_inputs)
    username = user_inputs.get("Email", "")
    password = password if password is not None else os.environ.get("BUILDING_PORTAL_RUNTIME_PASSWORD", "")
    pdf_folder_path = user_inputs.get("PDF Folder Path", "")
    if not username or not password:
        raise RuntimeError("Email or runtime password is missing.")
    if not pdf_folder_path or not os.path.isdir(pdf_folder_path):
        raise RuntimeError(f"Invalid PDF folder path in user_inputs.json: '{pdf_folder_path}'")
    prepared_documents = load_prepared_householder_documents(pdf_folder_path, mapping_data=document_mapping)
    validate_certificate_of_ownership_inputs(user_inputs)

    if driver is None:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option("detach", True)
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-default-apps")
        chrome_options.add_argument("--no-first-run")
        chrome_options.add_argument("--disable-notifications")
        driver = create_chrome_driver(chrome_options)
        driver.maximize_window()

    try:
        stage("login", "running", "Logging in")
        driver.get("https://www.edevelopment.scot/eDevelopmentClient/default.aspx")
        print("Opened eDevelopment main page.")

        click_first_available(driver, [(By.ID, "Banner_btnLogin")])
        type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxEmail", username, clear_first=False)
        type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxPassword", password, clear_first=False)
        submit_login_and_wait_for_home(
            driver,
            authenticated_control_name="ctl00$sideBar$ctl13",
        )
        record_checkpoint("login_complete", "login", "Signed in to eDevelopment.")
        stage("login", "completed", "Logged in")
        print("Logged in.")

        dismiss_gdpr_modal_if_present(driver)
        click_when_clickable(driver, By.NAME, "ctl00$sideBar$ctl13")
        print("Clicked ePlanning.")

        stage("proposal", "running", "Opening proposal")
        create_proposal_and_resume(
            driver,
            user_inputs,
            lambda: wait_for_householder_form_summary_then_open_main_details(driver, timeout=120),
            application_type=HOUSEHOLDER,
            address_resolver=address_resolution_callback,
        )
        record_checkpoint("application_selected", "main_details", "Householder application selected.")
        stage("proposal", "completed", "Proposal opened")
        stage("main_details", "running", "Completing main details")
        complete_householder_main_details(
            driver,
            user_inputs,
            applicant_title_resolution_callback=applicant_title_resolution_callback,
        )
        record_checkpoint("main_details_complete", "main_details")
        stage("main_details", "completed", "Main details complete")
        stage("ownership", "running", "Completing ownership certificate")
        complete_certificate_of_ownership(driver, user_inputs)
        record_checkpoint("ownership_complete", "certificate_of_ownership")
        stage("ownership", "completed", "Ownership certificate complete")
        stage("documents", "running", "Uploading documents")
        complete_later_householder_sections(
            driver,
            pdf_folder_path,
            user_inputs,
            prepared_documents=prepared_documents,
        )
        record_checkpoint("documents_complete", "documents")
        stage("documents", "completed", "Documents complete")
        stage("declaration", "running", "Completing declaration")
        complete_declaration(driver, HOUSEHOLDER, progress=progress)
        stage("declaration", "completed", "Declaration completed")
        record_checkpoint("declaration_complete", "declaration")
        stage("final_review", "running", "Finalising application")
        # complete_declaration only returns after the Form Summary controls have
        # been reacquired following the final ASP.NET postback.
        fee_handoff = open_fee_and_handoff(driver, HOUSEHOLDER, declaration_complete=True, progress=progress)
        enter_calculated_fee(driver, calculated_fee_minor_units)
        stage("final_review", "completed", "Planning application fee confirmed")
        record_checkpoint("application_prepared", "final_review")
        print("Householder automated preparation complete with the fee entered for review.")
        return fee_handoff
    except Exception as exc:
        print("ERROR encountered:", repr(exc), flush=True)
        raise


if __name__ == "__main__":
    main()

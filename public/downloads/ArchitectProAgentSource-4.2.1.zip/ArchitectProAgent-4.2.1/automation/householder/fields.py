# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import select_option_by_id, yes_no_answer


def click_yes_no(driver, key, yes_id, no_id, user_inputs, default="No"):
    answer = yes_no_answer(user_inputs, key, default)
    select_option_by_id(driver, yes_id if answer == "Yes" else no_id, f"{key}: {answer}")
    return answer


def force_text_by_id(driver, element_id, value, label, timeout=30):
    value = str(value or "").strip()
    element = WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.ID, element_id))
    )
    driver.execute_script("arguments[0].scrollIntoView({block:'center'});", element)
    try:
        WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, element_id)))
        element.clear()
        element.send_keys(value)
    except Exception:
        driver.execute_script("arguments[0].value = '';", element)
        driver.execute_script("arguments[0].value = arguments[1];", element, value)

    driver.execute_script(
        """
        arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
        arguments[0].dispatchEvent(new Event('blur', { bubbles: true }));
        """,
        element,
    )
    actual = driver.execute_script("return arguments[0].value || '';", element)
    if str(actual).strip() != value:
        driver.execute_script("arguments[0].value = arguments[1];", element, value)
        driver.execute_script(
            """
            arguments[0].dispatchEvent(new Event('input', { bubbles: true }));
            arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
            arguments[0].dispatchEvent(new Event('blur', { bubbles: true }));
            """,
            element,
        )
        actual = driver.execute_script("return arguments[0].value || '';", element)
    if str(actual).strip() != value:
        raise RuntimeError(f"Could not fill {label}. Expected '{value}', portal field still contains '{actual}'.")
    print(f"Filled: {label}")
    return element

# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By

from automation.common.actions import select_option_by_id, type_into, yes_no_answer
from automation.common.runtime import wait_for_continue
from automation.householder.fields import click_yes_no
from automation.householder.navigation import (
    click_first_available,
    click_ownership_hhpp_next,
    wait_for_checked_by_id,
)


IDENTIFY_ALL_OTHER_OWNERS_YES_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbIdentifyAllOtherOwnersHHPPYes"
IDENTIFY_ALL_OTHER_OWNERS_NO_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbIdentifyAllOtherOwnersHHPPNo"
NOTICE_ONE_OWNER_YES_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbNoticeToOneOwnerHHPPYes"
NOTICE_ONE_OWNER_NO_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbNoticeToOneOwnerHHPPNo"
IDENTIFY_ALL_OTHER_OWNERS_KEY = "Householder Identify All Other Owners"
NOTICE_ONE_OWNER_KEY = "Householder Notice To One Owner"
REASONABLE_STEPS_KEY = "Householder Ownership Reasonable Steps"
REASONABLE_STEPS_ID = "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_txtReasonableStepsHHPP"


def required_yes_no_answer(user_inputs, key, step):
    value = user_inputs.get(key)
    text = str(value or "").strip().lower()
    if text not in {"yes", "y", "true", "1", "on", "no", "n", "false", "0", "off"}:
        raise RuntimeError(
            f"Certificate of Ownership {step}: '{key}' must be confirmed in Architect Pro before automation starts."
        )
    return yes_no_answer(user_inputs, key)


def open_certificate_of_ownership(driver):
    print("Opening Certificate of Ownership.")
    try:
        click_first_available(
            driver,
            [
                (By.ID, "MainContent_FormSections_btnCertificateofOwnership"),
                (By.ID, "MainContent_FormSections_btnCertificateOfOwnership"),
                (By.ID, "MainContent_FormSections_btnOwnershipCertificate"),
                (By.XPATH, "//input[contains(@id, 'Certificate') and contains(@id, 'Ownership')]"),
                (By.XPATH, "//button[contains(., 'Certificate of Ownership')]"),
                (By.XPATH, "//a[contains(., 'Certificate of Ownership')]"),
            ],
            timeout=5,
        )
    except Exception:
        wait_for_continue(
            "Could not open Certificate of Ownership automatically.\n"
            "Please open the Certificate of Ownership section manually, then click Manual Continue / Fallback."
        )


def complete_identify_all_other_owners_step(driver, user_inputs):
    prepared = required_yes_no_answer(user_inputs, IDENTIFY_ALL_OTHER_OWNERS_KEY, "25%")
    answer = click_yes_no(
        driver,
        IDENTIFY_ALL_OTHER_OWNERS_KEY,
        IDENTIFY_ALL_OTHER_OWNERS_YES_ID,
        IDENTIFY_ALL_OTHER_OWNERS_NO_ID,
        user_inputs,
        default=prepared,
    )
    click_ownership_hhpp_next(driver, "25%")
    return answer


def complete_notice_to_one_owner_step(driver, user_inputs):
    prepared = required_yes_no_answer(user_inputs, NOTICE_ONE_OWNER_KEY, "30%")
    answer = click_yes_no(
        driver,
        NOTICE_ONE_OWNER_KEY,
        NOTICE_ONE_OWNER_YES_ID,
        NOTICE_ONE_OWNER_NO_ID,
        user_inputs,
        default=prepared,
    )
    click_ownership_hhpp_next(driver, "30%")
    return answer


def required_reasonable_steps(user_inputs):
    value = str(user_inputs.get(REASONABLE_STEPS_KEY) or "").strip()
    if not value:
        raise RuntimeError(
            "Certificate of Ownership 70%: reasonable steps taken are required "
            "when the other owners cannot be identified or notified. Add this "
            "answer in Architect Pro before starting automation."
        )
    if len(value) > 500:
        raise RuntimeError(
            "Certificate of Ownership 70%: reasonable steps taken must be 500 characters or fewer."
        )
    return value


def fill_reasonable_steps(driver, value):
    field = type_into(driver, By.ID, REASONABLE_STEPS_ID, value)
    actual = str(field.get_attribute("value") or "").strip()
    if actual != value:
        raise RuntimeError(
            "Certificate of Ownership 70%: the reasonable-steps field did not retain the prepared answer."
        )
    print("Filled: Certificate of Ownership reasonable steps")


def validate_certificate_of_ownership_inputs(user_inputs):
    sole_owner = yes_no_answer(user_inputs, "Householder Sole Owner", "Yes")
    if sole_owner == "Yes":
        return sole_owner, None, None, None

    identify_all = required_yes_no_answer(
        user_inputs,
        IDENTIFY_ALL_OTHER_OWNERS_KEY,
        "25%",
    )
    if identify_all == "Yes":
        return sole_owner, identify_all, None, None

    notice_one = required_yes_no_answer(user_inputs, NOTICE_ONE_OWNER_KEY, "30%")
    reasonable_steps = required_reasonable_steps(user_inputs) if notice_one == "No" else None
    return sole_owner, identify_all, notice_one, reasonable_steps


def complete_certificate_of_ownership(driver, user_inputs):
    sole_owner, _identify_all, _notice_one, reasonable_steps = (
        validate_certificate_of_ownership_inputs(user_inputs)
    )

    open_certificate_of_ownership(driver)
    click_ownership_hhpp_next(driver, "initial")

    click_yes_no(
        driver,
        "Householder Sole Owner",
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbSoleOwnerGroupHHPPYes",
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbSoleOwnerGroupHHPPNo",
        user_inputs,
        default="Yes",
    )
    click_yes_no(
        driver,
        "Householder Agricultural Holding",
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbAnyAgriculturalLandYes",
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_rbAnyAgriculturalLandNo",
        user_inputs,
        default="No",
    )
    click_ownership_hhpp_next(driver, "ownership")

    if sole_owner == "Yes":
        click_ownership_hhpp_next(driver, "35%")
        click_ownership_hhpp_next(driver, "40%")
    else:
        identify_all_other_owners = complete_identify_all_other_owners_step(driver, user_inputs)
        if identify_all_other_owners == "Yes":
            click_ownership_hhpp_next(driver, "35%")
            click_ownership_hhpp_next(driver, "40%")
        else:
            notice_to_one_owner = complete_notice_to_one_owner_step(driver, user_inputs)
            click_ownership_hhpp_next(driver, "35%")
            click_ownership_hhpp_next(driver, "40%")
            if notice_to_one_owner == "No":
                click_ownership_hhpp_next(driver, "65%")
                fill_reasonable_steps(driver, reasonable_steps)
                click_ownership_hhpp_next(driver, "70%")
                click_ownership_hhpp_next(driver, "75%")

    select_option_by_id(
        driver,
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_cbAcceptanceHHPP",
        "Certificate of Ownership acceptance",
    )
    wait_for_checked_by_id(
        driver,
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_cbAcceptanceHHPP",
        "Certificate of Ownership acceptance checked",
    )
    click_ownership_hhpp_next(driver, "85%")
    click_ownership_hhpp_next(driver, "100%")
    print("Certificate of Ownership complete.")

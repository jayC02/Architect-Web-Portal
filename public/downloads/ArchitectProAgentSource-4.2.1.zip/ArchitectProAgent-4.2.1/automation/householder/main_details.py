# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By

from automation.common.actions import select_option_by_id, type_into
from automation.householder.agent import fill_agent_details
from automation.householder.applicant import fill_applicant_details
from automation.householder.fields import click_yes_no
from automation.householder.navigation import (
    HOUSEHOLDER_FINISH_ID,
    click_householder_finish_next,
    click_householder_step_next,
)


def complete_householder_main_details(driver, user_inputs, applicant_title_resolution_callback=None):
    print("Starting Householder Main Details.")
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_tbxProposedWork",
    )

    description = str(user_inputs.get("Description of Work") or "").strip()
    if not description:
        raise RuntimeError("Description of Work is required. Review the prepared application before running automation.")
    description = description[:500]
    type_into(driver, By.ID, "MainContent_HouseholderApplicationMainDetailsWizard_tbxProposedWork", description)
    select_option_by_id(driver, "MainContent_HouseholderApplicationMainDetailsWizard_rblWorkStarted_0", "Work started/completed: No")
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_ApplicantOrAgent1_rbAgent",
    )

    select_option_by_id(driver, "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantOrAgent1_rbAgent", "Agent")
    select_option_by_id(driver, "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantOrAgent1_rbAccountYes", "Registered account")
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentFirstName",
    )

    fill_agent_details(driver, user_inputs)
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantFirstName",
    )

    fill_applicant_details(driver, user_inputs, applicant_title_resolution_callback)
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_rblDiscussedWithPA_0",
    )

    click_yes_no(
        driver,
        "Householder Discussed With Planning Authority",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblDiscussedWithPA_0",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblDiscussedWithPA_1",
        user_inputs,
        default="No",
    )
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_rblTreesOnSite_0",
    )

    click_yes_no(
        driver,
        "Householder Trees On Site",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblTreesOnSite_0",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblTreesOnSite_1",
        user_inputs,
        default="No",
    )
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_rblNewAlteredSpaces_0",
    )

    vehicle_access = click_yes_no(
        driver,
        "Householder New Or Altered Vehicle Access",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblNewAlteredSpaces_0",
        "MainContent_HouseholderApplicationMainDetailsWizard_rblNewAlteredSpaces_1",
        user_inputs,
        default="No",
    )
    if vehicle_access == "Yes":
        type_into(
            driver,
            By.ID,
            "MainContent_HouseholderApplicationMainDetailsWizard_tbxCurrentParkingSpaces",
            str(user_inputs.get("Householder Current Parking Spaces") or "0"),
        )
        type_into(
            driver,
            By.ID,
            "MainContent_HouseholderApplicationMainDetailsWizard_tbxProposedParkingSpaces",
            str(user_inputs.get("Householder Proposed Parking Spaces") or "0"),
        )
    click_householder_step_next(
        driver,
        expected_id="MainContent_HouseholderApplicationMainDetailsWizard_rblEmployeeMemberInterest_1",
    )

    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationMainDetailsWizard_rblEmployeeMemberInterest_1",
        "Staff/elected member interest: No",
    )
    click_householder_step_next(driver, expected_id=HOUSEHOLDER_FINISH_ID)
    click_householder_finish_next(driver)
    print("Householder Main Details complete.")

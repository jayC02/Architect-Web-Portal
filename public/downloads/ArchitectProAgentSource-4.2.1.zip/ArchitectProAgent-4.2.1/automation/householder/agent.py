# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import select_option_by_id
from automation.householder.fields import force_text_by_id


def fill_agent_details(driver, user_inputs):
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentFirstName"))
    )

    agent_field_ids = {
        "Agent First Name": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentFirstName",
        "Agent Last Name": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentSurname",
        "Agent Telephone Number": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentTelNo",
        "Agent Email Address": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentEmailAddress",
        "Agent Address 1": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentAddress1",
        "Agent Building Number": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentBuildingNo",
        "Agent Town/City": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentTown",
        "Agent Country": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentCountry",
        "Agent Postcode": "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentPostcode",
    }
    for field, element_id in agent_field_ids.items():
        value = str(user_inputs.get(field, "United Kingdom" if field == "Agent Country" else "")).strip()
        if value:
            force_text_by_id(driver, element_id, value, field, timeout=20)
        else:
            print(f"Skipped blank Householder agent field: {field}")

    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_rblIndividualOrOrganisation_0",
        "Agent individual",
    )

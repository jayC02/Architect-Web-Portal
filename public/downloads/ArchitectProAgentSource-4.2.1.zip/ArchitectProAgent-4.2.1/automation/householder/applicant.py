# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.forms import select_applicant_title
from automation.householder.fields import force_text_by_id
from automation.householder.navigation import click_first_available


def fill_applicant_details(driver, user_inputs, applicant_title_resolution_callback=None):
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantFirstName"))
    )

    clear_candidates = [
        (By.ID, "MainContent_HouseholderApplicationMainDetailsWizard_StepNavigationTemplateContainerID_btnClearPage"),
        (By.ID, "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_btnClearPage"),
    ]
    try:
        click_first_available(driver, clear_candidates, timeout=5)
    except Exception:
        print("No clear button found for Householder Applicant Details; continuing.")

    select_applicant_title(
        driver,
        "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_ddlApplicantTitle",
        user_inputs.get("Applicant Title", ""),
        "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantFirstName",
        timeout=15,
        other_title=user_inputs.get("Applicant Other Title", ""),
        other_title_element_ids=(
            "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantOtherTitle",
            "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtOtherTitle",
        ),
        resolver=applicant_title_resolution_callback,
        applicant_name=f"{user_inputs.get('Applicant First Name', '')} {user_inputs.get('Applicant Last Name', '')}".strip(),
    )

    applicant_field_ids = {
        "Applicant First Name": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantFirstName",
        "Applicant Last Name": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantLastName",
        "Applicant Company": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantCompany",
        "Applicant Email": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantEmailAddr",
        "Applicant Mobile Number": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantMobileNumber",
        "Applicant Building Name": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantBuildingName",
        "Applicant Building Number": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantBuildingNo",
        "Applicant Address 1": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantAddress1",
        "Applicant Town/City": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantTown",
        "Applicant Country": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantCountry",
        "Applicant Postcode": "MainContent_HouseholderApplicationMainDetailsWizard_ApplicantDetails1_txtApplicantPostcode",
    }
    for field, element_id in applicant_field_ids.items():
        value = str(user_inputs.get(field, "United Kingdom" if field == "Applicant Country" else "")).strip()
        if value:
            force_text_by_id(driver, element_id, value, field, timeout=20)
        else:
            print(f"Skipped blank Householder applicant field: {field}")

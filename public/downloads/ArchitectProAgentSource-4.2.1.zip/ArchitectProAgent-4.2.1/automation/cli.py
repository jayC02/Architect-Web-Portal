"""Developer entrypoint for running the same automation engine without Qt."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from automation.common.browser_mode import BrowserMode
from automation.models import RuntimeJob
from automation.runner import run_automation


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Run an Architect Pro prepared automation job")
    parser.add_argument("--job", type=Path, required=True, help="Canonical runtime job JSON")
    parser.add_argument("--browser-mode", choices=[mode.value for mode in BrowserMode], default="AUTO")
    parser.add_argument("--validate-only", action="store_true")
    args = parser.parse_args(argv)
    payload = json.loads(args.job.read_text(encoding="utf-8"))
    job = RuntimeJob.from_mapping(payload)
    if args.validate_only:
        print(json.dumps({"jobId": job.job_id, "applicationType": job.application_type, "valid": True}))
        return 0
    result = run_automation(
        job,
        browser_mode=args.browser_mode,
        password=os.environ.get("BUILDING_PORTAL_RUNTIME_PASSWORD", ""),
        progress_callback=lambda event: print(json.dumps({
            "stage": event.stage, "status": event.status.value, "message": event.message,
        })),
    )
    print(json.dumps({
        "outcome": result.outcome, "jobId": result.job_id,
        "message": result.message, "timings": dict(result.timings),
    }))
    return 0 if result.outcome == "success" else 2


if __name__ == "__main__":
    raise SystemExit(main())

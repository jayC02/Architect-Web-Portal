# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import select_option_by_id, set_text_value


def fill_description_and_proposed_work(driver, user_inputs, timeout=30):
    desc_work = str(user_inputs.get("Description of Work") or "").strip()
    if not desc_work:
        desc_work = "Building warrant works as described in the submitted drawings and supporting documents."

    work_type_map = {
        "Construct": "MainContent_BuildingWarrantAppWizard_W1",
        "Convert": "MainContent_BuildingWarrantAppWizard_W2",
        "Provide Services": "MainContent_BuildingWarrantAppWizard_W3",
        "Demolish": "MainContent_BuildingWarrantAppWizard_W4",
    }
    aliases = {
        "Domestic alteration / extension": "Construct",
        "New build": "Construct",
        "Conversion / change of use": "Convert",
        "Demolition": "Demolish",
    }
    proposed_work = str(user_inputs.get("Proposed Work") or "").strip()
    proposed_work = aliases.get(proposed_work, proposed_work)
    proposed_work = proposed_work if proposed_work in work_type_map else "Construct"

    page_ready_locators = [
        (By.ID, "MainContent_BuildingWarrantAppWizard_txtDescWork"),
        *[(By.ID, element_id) for element_id in work_type_map.values()],
    ]
    WebDriverWait(driver, timeout).until(
        lambda d: any(d.find_elements(by, locator) for by, locator in page_ready_locators)
    )

    desc_field = WebDriverWait(driver, timeout).until(
        EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_txtDescWork"))
    )
    set_text_value(driver, desc_field, desc_work)
    print(f"Entered Description of Work: {desc_work}")

    select_option_by_id(driver, work_type_map[proposed_work], proposed_work, timeout=timeout)
    return proposed_work

# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, get_when_present, type_into
from automation.common.forms import select_applicant_title


def fill_applicant_details(driver, user_inputs, applicant_title_resolution_callback=None):
    print("Step 15: Starting Applicant Details section...")

    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located(
            (By.ID, "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantFirstName")
        )
    )

    click_when_clickable(
        driver,
        By.ID,
        "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnClearPage",
        timeout=10,
    )
    print("Cleared the Applicant Details form.")

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located(
            (By.ID, "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantFirstName")
        )
    )
    select_applicant_title(
        driver,
        "MainContent_BuildingWarrantAppWizard_ApplicantDetails_ddlApplicantTitle",
        user_inputs.get("Applicant Title", ""),
        "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantFirstName",
        timeout=15,
        other_title=user_inputs.get("Applicant Other Title", ""),
        other_title_element_ids=(
            "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantOtherTitle",
            "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtOtherTitle",
        ),
        resolver=applicant_title_resolution_callback,
        applicant_name=f"{user_inputs.get('Applicant First Name', '')} {user_inputs.get('Applicant Last Name', '')}".strip(),
    )

    applicant_fields = {
        "Applicant First Name": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantFirstName",
        "Applicant Last Name": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantLastName",
        "Applicant Company": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantCompany",
        "Applicant Email": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantEmailAddr",
        "Applicant Mobile Number": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantMobileNumber",
        "Applicant Building Name": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantBuildingName",
        "Applicant Building Number": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantBuildingNo",
        "Applicant Address 1": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantAddress1",
        "Applicant Town/City": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantTown",
        "Applicant Country": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantCountry",
        "Applicant Postcode": "MainContent_BuildingWarrantAppWizard_ApplicantDetails_txtApplicantPostcode",
    }

    for field, element_id in applicant_fields.items():
        try:
            value = user_inputs.get(field, "United Kingdom" if field == "Applicant Country" else "")
            if value.strip():
                type_into(driver, By.ID, element_id, value.strip(), timeout=10)
                print(f"Filled: {field}")
            else:
                get_when_present(driver, By.ID, element_id, timeout=10)
                print(f"Skipped blank field: {field}")
        except Exception as e:
            print(f"Error setting '{field}': {e}")

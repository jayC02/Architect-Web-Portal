# -*- coding: utf-8 -*-
import os
import time

from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import (
    click_when_clickable,
    click_yes_no_answer,
    get_when_present,
    js_click_by_id,
    select_by_text,
    select_option_by_id,
    set_text_value,
    type_into,
    wait_dom_ready,
    yes_no_answer,
)
from automation.common.documents import (
    extract_title_and_description,
    get_document_type_from_pdf,
    get_paper_size_from_pdf,
    load_supporting_docs_upload_list,
)
from automation.common.driver import create_chrome_driver, get_local_chromedriver_path
from automation.common.forms import normalise_applicant_title, select_applicant_title
from automation.common.runtime import (
    clear_checkpoint,
    CONTINUE_FLAG_FILE,
    record_checkpoint,
    SCRIPT_DIR,
    SUPPORTING_DOCS_JSON,
    USER_INPUTS_JSON,
    load_required_json,
    wait_for_continue,
)
from automation.common.declaration import complete_declaration, open_fee_and_handoff
from automation.common.proposal_creation import BUILDING_WARRANT, create_proposal_and_resume
from automation.common.uploads import (
    dismiss_gdpr_modal_if_present,
    get_visible_portal_error,
    wait_for_supporting_doc_upload_result,
)
from automation.building_warrant.agent import fill_agent_details
from automation.building_warrant.applicant import fill_applicant_details
from automation.building_warrant.login import login_to_ebuilding
from automation.building_warrant.main_details import fill_description_and_proposed_work
from automation.building_warrant.navigation import (
    click_next,
    pause_after_unsupported_yes,
    wait_for_form_summary_then_open_main_details,
)
from automation.building_warrant.fee import (
    enter_calculated_fee,
    require_calculated_fee_minor_units,
)


########################################################################
# Main Script
########################################################################

def main(
    *,
    user_inputs=None,
    password=None,
    driver=None,
    document_mapping=None,
    progress=None,
    cancellation_token=None,
    address_resolution_callback=None,
    applicant_title_resolution_callback=None,
):
    def stage(name, status, message):
        if progress:
            progress(name, status, message)
        if cancellation_token:
            cancellation_token.raise_if_cancelled()

    clear_checkpoint()
    # -----------------------------------------------------
    # A) Load user inputs from JSON (written by the GUI)
    # -----------------------------------------------------
    if user_inputs is None:
        user_inputs = load_required_json(
            USER_INPUTS_JSON,
            required_keys=["Email", "PDF Folder Path"]
        )

    # Unpack relevant fields
    username             = user_inputs.get("Email", "")
    password             = password if password is not None else os.environ.get("BUILDING_PORTAL_RUNTIME_PASSWORD", "")
    proposed_use         = user_inputs.get("Proposed Use", "Residential Dwelling")
    current_use          = user_inputs.get("Current Use", "Residential Dwelling")
    estimated_work_value = user_inputs.get("Estimated Work Value", "10000")
    pdf_folder_path      = user_inputs.get("PDF Folder Path", "")
    calculated_fee_minor_units = require_calculated_fee_minor_units(user_inputs)

    if not username or not password:
        raise RuntimeError("Email or runtime password is missing.")
    if not pdf_folder_path or not os.path.isdir(pdf_folder_path):
        raise RuntimeError(f"Invalid PDF folder path in user_inputs.json: '{pdf_folder_path}'")
        
    upload_entries, location_plan_file, effective_pdf_folder, bucket_labels = load_supporting_docs_upload_list(pdf_folder_path, mapping_data=document_mapping)

    if not location_plan_file:
        raise FileNotFoundError("No Location Plan PDF found in the 'Location Plan' bucket.")

    location_plan_path = os.path.join(effective_pdf_folder, location_plan_file)
    if not os.path.exists(location_plan_path):
        raise FileNotFoundError(f"Location Plan PDF not found on disk: {location_plan_path}")

    print(f"Location plan chosen: {location_plan_path}")
    
    location_plan_paper_size = get_paper_size_from_pdf(location_plan_path)
    location_plan_doc_type   = "OS Extract"
    print("Location plan detected:", location_plan_paper_size, location_plan_doc_type)

    # -----------------------------------------------------
    # B) Initialize WebDriver
    # -----------------------------------------------------
    chrome_options = webdriver.ChromeOptions()

    # ✅ Keep Chrome open after the script finishes
    chrome_options.add_experimental_option("detach", True)
    # Conservative startup optimisations (no behavioural flow changes).
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-default-apps")
    chrome_options.add_argument("--no-first-run")
    chrome_options.add_argument("--disable-notifications")

    if driver is None:
        driver = create_chrome_driver(chrome_options)
        driver.maximize_window()
        print("Initialized Chrome WebDriver.")

    try:
        # -------------------------------------------------
        # Step 0: Open main page, log in with user’s creds
        # -------------------------------------------------
        stage("login", "running", "Logging in")
        login_to_ebuilding(driver, username, password)
        record_checkpoint("login_complete", "login", "Signed in to eBuilding Standards.")
        stage("login", "completed", "Logged in")

        stage("proposal", "running", "Opening proposal")
        create_proposal_and_resume(
            driver,
            user_inputs,
            lambda: wait_for_form_summary_then_open_main_details(driver, timeout=120),
            application_type=BUILDING_WARRANT,
            address_resolver=address_resolution_callback,
        )
        record_checkpoint("application_selected", "main_details", "Building Warrant application selected.")
        stage("proposal", "completed", "Proposal opened")
        stage("main_details", "running", "Completing application details")

        print("Attempting to click 'Next' on the Main Details page...")
        click_next(driver)
        print("Clicked 'Next' on Main Details.")

        # ----------------------------------------------------------------
        # Steps 10… (Detailed yes/no and text filling)
        # ----------------------------------------------------------------

        # Step 10: Tick "No" for 'Work Completed'
        print("Ticking 'No' for 'Work Completed'.")
        no_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_rbWorkCompletedNo']"))
        )
        no_radio_label.click()

        # Next
        click_next(driver)
        print("Confirmed 'No' for Work Completed. Next clicked.")

        # Step 11: Tick "No" for 'Has work started?'
        print("Ticking 'No' for 'Work Started'.")
        no_radio_label_2 = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_rbWorkStartedNo']"))
        )
        no_radio_label_2.click()

        # Next
        click_next(driver)

        # Step 12: Select 'Agent'
        print("Selecting 'Agent' radio button.")
        agent_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_ApplicantOrAgent_rbAgent']"))
        )
        agent_radio_label.click()

        # Step 13: Use Registered Account details => Yes
        print("Selecting 'Registered Account' radio button.")
        registered_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_ApplicantOrAgent_rbAccountYes']"))
        )
        registered_radio_label.click()

        # Next
        click_next(driver, timeout=10)
        
        fill_agent_details(driver, user_inputs)
        record_checkpoint("agent_complete", "agent_details")

        # Step 14: Another 'Next' (skipping some manual step)
        click_next(driver)
        print("Clicked 'Next' again.")
        
        fill_applicant_details(driver, user_inputs, applicant_title_resolution_callback)
        record_checkpoint("applicant_complete", "applicant_details")

        # Step 14: Another 'Next' (skipping some manual step)
        click_next(driver)
        print("Clicked 'Next' again.")        
        
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerYes"))
)
        # Step 15: "Are you the applicant owner?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Applicant Is Owner",
            "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerYes",
            "MainContent_BuildingWarrantAppWizard_rbApplicantOwnerNo",
            default="Yes",
        )

        # Next
        click_next(driver)

        # Step 16: "Include Construction?"
        include_construction = click_yes_no_answer(
            driver,
            user_inputs,
            "Includes New Building Or Extension",
            "MainContent_BuildingWarrantAppWizard_rbIncludeConstructionYes",
            "MainContent_BuildingWarrantAppWizard_rbIncludeConstructionNo",
            default="Yes",
        )

        # Next
        click_next(driver)

        if include_construction == "Yes":
            # Step 17: Proposed Use (from JSON)
            print(f"Entering Proposed Use: {proposed_use}")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtProposedUse", proposed_use)

            # Next
            click_next(driver)

        # Step 18: "Work to existing building?"
        existing_work = click_yes_no_answer(
            driver,
            user_inputs,
            "Includes Existing Building Work",
            "MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbWorkExistingBuildingNo",
            default="Yes",
        )

        # Next
        click_next(driver)

        if existing_work == "Yes":
            # Step 19: Current Use
            print(f"Entering Current Use: {current_use}")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtCurrentUse", current_use)

            # Step 20: Proposed Use (Existing)
            print(f"Entering Proposed Use (Existing) same as Proposed Use: {proposed_use}")
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtProposedUseExisting", proposed_use)

            # Next
            click_next(driver)

        # Step 21: Conversion Regs
        click_yes_no_answer(
            driver,
            user_inputs,
            "Conversion Regulations",
            "MainContent_BuildingWarrantAppWizard_rbConversionRegsYes",
            "MainContent_BuildingWarrantAppWizard_rbConversionRegsNo",
            default="No",
        )

        # Next
        click_next(driver)
        
        # Read the "Description of Work" text from user_inputs
        desc_work = str(user_inputs.get("Description of Work") or "").strip()
        if not desc_work:
            raise RuntimeError("Description of Work is required. Review the prepared application before running automation.")

        type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtDescWork", desc_work)
        print(f"Entered Description of Work: {desc_work}")
        
        # Step 22: Tick correct "Proposed Work" box
        proposed_work = user_inputs.get("Proposed Work", "Construct")
        work_type_map = {
            "Construct": "MainContent_BuildingWarrantAppWizard_W1",
            "Convert": "MainContent_BuildingWarrantAppWizard_W2",
            "Provide Services": "MainContent_BuildingWarrantAppWizard_W3",
            "Demolish": "MainContent_BuildingWarrantAppWizard_W4",
        }

        work_id = work_type_map.get(proposed_work)
        if work_id:
            print(f"Ticking '{proposed_work}' box for Type of Work.")
            label = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.ID, work_id))
            )
            driver.execute_script("arguments[0].scrollIntoView({block:'center'});", label)
            try:
                label.click()
            except Exception:
                driver.execute_script("arguments[0].click();", label)
            work_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, work_id))
            )
            if not driver.execute_script("return Boolean(arguments[0].checked);", work_input):
                driver.execute_script(
                    """
                    arguments[0].checked = true;
                    arguments[0].dispatchEvent(new Event('click', { bubbles: true }));
                    arguments[0].dispatchEvent(new Event('change', { bubbles: true }));
                    """,
                    work_input,
                )
            if not driver.execute_script("return Boolean(arguments[0].checked);", work_input):
                raise RuntimeError(f"Could not select proposed work type '{proposed_work}'.")
        else:
            print(f"⚠ Unknown proposed work type: '{proposed_work}', no box ticked.")

        # Next
        click_next(driver)

        # Step 23: "Application to be staged?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Application Staged",
            "MainContent_BuildingWarrantAppWizard_rbApplicationStagedYes",
            "MainContent_BuildingWarrantAppWizard_rbApplicationStagedNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Application Staged", "the demolition question")

        # Step 24: "Demolition?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Includes Demolition",
            "MainContent_BuildingWarrantAppWizard_rbDemolitionOfBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbDemolitionOfBuildingNo",
            default="No",
        )

        # Next
        click_next(driver)

        # Step 25: "Limited Life Building?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Limited Life Building",
            "MainContent_BuildingWarrantAppWizard_rbIntendedLifeYes",
            "MainContent_BuildingWarrantAppWizard_rbIntendedLifeNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Limited Life Building", "the Fire and Rescue Service question")

        # Step 26: "Under Fire Authority?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Fire Rescue Enforcing Authority",
            "MainContent_BuildingWarrantAppWizard_rbUnderFireRescueYes",
            "MainContent_BuildingWarrantAppWizard_rbUnderFireRescueNo",
            default="Yes",
        )

        # Next
        click_next(driver)

        # Step 27: "Listed Building?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Listed Or Conservation Area",
            "MainContent_BuildingWarrantAppWizard_rbListedBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbListedBuildingNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Listed Or Conservation Area", "the historical importance question")

        # Step 28: "Historical Building?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Other Historical Importance",
            "MainContent_BuildingWarrantAppWizard_rbHistoricalYes",
            "MainContent_BuildingWarrantAppWizard_rbHistoricalNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Other Historical Importance", "the relaxation direction question")

        # Step 29: "Relaxation Direction?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Relaxation Direction",
            "MainContent_BuildingWarrantAppWizard_rbRelaxationDirectionYes",
            "MainContent_BuildingWarrantAppWizard_rbRelaxationDirectionNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Relaxation Direction", "the notices page")

        # Step 30: "Building Reg Compliance Notice" => "N/A"
        compliance_field = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_txtBuildingRegComplianceNotice"))
        )
        compliance_field.send_keys("N/A")

        # Step 31: "Warrant Enforcement Notice" => "N/A"
        enforcement_field = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_txtBuildingWarrantEnforcementNotice"))
        )
        enforcement_field.send_keys("N/A")

        # Step 32: "Defective Buildings Notice" => "N/A"
        defective_field = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.ID, "MainContent_BuildingWarrantAppWizard_txtDefectiveBuildingsNotice"))
        )
        defective_field.send_keys("N/A")

        # Step 33: "Dangerous Building?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Dangerous Building Notice",
            "MainContent_BuildingWarrantAppWizard_rbDangerousBuildingYes",
            "MainContent_BuildingWarrantAppWizard_rbDangerousBuildingNo",
            default="No",
        )

        # Next
        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Dangerous Building Notice", "the estimated work value page")

        # Step 34: "Estimated Work Value" => from JSON
        print(f"Entering Estimated Work Value: {estimated_work_value}")
        # Some forms place it here, some place it earlier—adapt as needed:
        try:
            type_into(driver, By.ID, "MainContent_BuildingWarrantAppWizard_txtEstimatedValue", estimated_work_value)
        except Exception:
            print("Could not find 'Estimated Work Value' field at this exact step. Check the page flow.")

        # Next
        click_next(driver)

        # Step 35: "Certificates of Design?"
        cert_design_answer = click_yes_no_answer(
            driver,
            user_inputs,
            "Approved Certifier Design",
            "MainContent_BuildingWarrantAppWizard_CertificatesRegisterQuestion_rbCertificatesAccompanyYes",
            "MainContent_BuildingWarrantAppWizard_CertificatesRegisterQuestion_rbCertificatesAccompanyNo",
            default="Yes",
        )

        # Next
        click_next(driver)

        if cert_design_answer == "Yes":
            # Step 36: "Upload Certificate of Design with application?" => No
            cert_upload_no = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_rbUploadCertificateOfDesignWithApplicationNo']"))
            )
            cert_upload_no.click()

            # "Upload post-submission?" => Yes
            post_upload_yes = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantAppWizard_rbUploadCertificateOfDesignFollowingApplicationYes']"))
            )
            post_upload_yes.click()

            # Next
            click_next(driver)
            
            #################################################################
            #                    CERTIFICATES                               #
            #                                                               #
            #################################################################

            # Select "Design"
            scheme_type_dropdown = Select(WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_ddlSchemeType"))
            ))
            scheme_type_dropdown.select_by_visible_text("Design")
            print("Selected 'Design' for Scheme Type.")
            
            # Get the full value from part 1 (e.g., "SER1") from user_inputs
            part1_prefix = user_inputs.get("Registration Number (A) Part 1", "").strip() or "SER1"

            # Select the matching option from the dropdown
            cert_reg1_dropdown = Select(WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_ddlCertifierRegNo1"))
            ))
            cert_reg1_dropdown.select_by_visible_text(part1_prefix)
            print(f"Selected Certifier Registration Part 1: {part1_prefix}")

            # Select "D" in second dropdown (Part 2)
            reg2_dropdown = Select(WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_ddlCertifierRegNo2"))
            ))
            reg2_dropdown.select_by_visible_text("D")

            driver.execute_script(
                "__doPostBack('ctl00$MainContent$BuildingWarrantAppWizard$CertificatesRegister1$ddlCertifierRegNo2','')"
            )
            
            # Get the suffix (Part 2) from user_inputs
            suffix = user_inputs.get("Registration Number (A) Part 2", "").strip()

            # Wait for the suffix field to become clickable
            suffix_input = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_txtCertifierRegNo"))
            )
            suffix_input.clear()
            suffix_input.send_keys(suffix)
            print(f"Entered Certifier Registration Part 2: {suffix}")

            # Step 5: Enter Name of Certifier
            certifier_name = user_inputs.get("Name of Certifier", "").strip()

            # Enter the certifier's name into the appropriate field
            certifier_name_input = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "txtCertifierName"))
            )
            certifier_name_input.clear()
            certifier_name_input.send_keys(certifier_name)
            print(f"Entered Name of Certifier: {certifier_name}")
            
            # === Registration Number (B) Dropdown Part 1 ===
            reg_b_prefix = user_inputs.get("Registration Number (B) Part 1", "").strip() or "SER1"
            reg_b_dropdown_1 = Select(WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_ddlApprovedBodyRegNo1"))
            ))
            reg_b_dropdown_1.select_by_visible_text(reg_b_prefix)
            print(f"Selected Registration Number (B) Part 1: {reg_b_prefix}")

            # === Always "DB" for middle part ===
            reg_b_dropdown_2 = Select(WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_ddlApprovedBodyRegNo2"))
            ))
            reg_b_dropdown_2.select_by_visible_text("DB")
            print("Selected Registration Number (B) Part 2: DB")

            # === Suffix Text Input ===
            reg_b_suffix = user_inputs.get("Registration Number (B) Part 2", "").strip()
            reg_b_input = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_CertificatesRegister1_txtApprovedBodyRegNo"))
            )
            reg_b_input.clear()
            reg_b_input.send_keys(reg_b_suffix)
            print(f"Entered Registration Number (B) Part 3: {reg_b_suffix}")
            
            # Enter the approved body's name into the appropriate field
            approved_body = user_inputs.get("Name of Approved Body", "").strip()
            approved_body_input = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "txtCertificateANameOfApprovedBody"))
            )
            approved_body_input.clear()
            approved_body_input.send_keys(approved_body)
            print(f"Entered Name of Approved Body: {approved_body}")

            # Step 8: Click the "Validation Check" button
            validate_button = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.ID, "txtCertificateANameOfApprovedBody"))
            )
            validate_button.click()
            print("Clicked 'Validation Check' button.")

             # Next
            click_next(driver)
        else:
            print("Approved Certifier Design is No. Skipping design certificate details.")
        
        # "Certificates of Construction?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "Approved Certifier Construction",
            "MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyYes",
            "MainContent_BuildingWarrantAppWizard_rbCertificateAccompanyNo",
            default="No",
        )

        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Approved Certifier Construction", "the new building construction question")

        # Step 38: "Sustainability?"/new building construction
        click_yes_no_answer(
            driver,
            user_inputs,
            "New Building Construction",
            "MainContent_BuildingWarrantAppWizard_rbNewBuildingConstructionYes",
            "MainContent_BuildingWarrantAppWizard_rbNewBuildingConstructionNo",
            default="No",
        )

        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "New Building Construction", "the STAS question")

        # Step 39: "STAS?"
        click_yes_no_answer(
            driver,
            user_inputs,
            "STAS",
            "MainContent_BuildingWarrantAppWizard_rbSTASYes",
            "MainContent_BuildingWarrantAppWizard_rbSTASNo",
            default="No",
        )

        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "STAS", "the public inspection question")

        # Step 40: Public inspection restriction
        click_yes_no_answer(
            driver,
            user_inputs,
            "Public Inspection Restricted",
            "MainContent_BuildingWarrantAppWizard_rbPublicInspectionYes",
            "MainContent_BuildingWarrantAppWizard_rbPublicInspectionNo",
            default="No",
        )

        click_next(driver)
        pause_after_unsupported_yes(user_inputs, "Public Inspection Restricted", "Main Details Complete")

        # Step 41: Next => Main Details Complete
        final_next_main = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantAppWizard_FinishNavigationTemplateContainerID_btnNext"))
        )
        final_next_main.click()

        # Step 42: Email Notification => Click
        email_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnEmailNotification"))
        )
        email_button.click()
        print("Clicked Email Notification button.")
        record_checkpoint("main_details_complete", "main_details")
        stage("main_details", "completed", "Application details complete")
        stage("documents", "running", "Uploading supporting documents")

        # Step 43: "No" for Email? or Uncheck? Adapt as needed:
        email_no_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_cbUseEmail']"))
        )
        email_no_label.click()

        confirm_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_btnConfirm"))
        )
        confirm_button.click()
        print("Confirmed email choice.")

        # Step 44: Checklist
        checklist_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnChecklist"))
        )
        checklist_button.click()
        print("Clicked Checklist button.")

        # "Yes" for location block plan, supporting docs, email notification, etc.
        # This is all fairly site-specific. We'll do a few:
        block_location_yes = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantChecklistWizard_rbBlockLocationYes']"))
        )
        block_location_yes.click()

        supporting_docs_yes = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantChecklistWizard_rbSupportingDocsYes']"))
        )
        supporting_docs_yes.click()

        checklist_email_yes = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BuildingWarrantChecklistWizard_rbEmailNotificationYes']"))
        )
        checklist_email_yes.click()

        # Next
        checklist_next = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantChecklistWizard_StepNavigationTemplateContainerID_btnNext"))
        )
        checklist_next.click()

        # Finish the Checklist wizard (next button)
        checklist_finish = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BuildingWarrantChecklistWizard_FinishNavigationTemplateContainerID_btnNext"))
        )
        checklist_finish.click()
        record_checkpoint("document_checklist_complete", "checklist")
        
         # Click supporting documentation button
        supporting_next = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnSupportingDocumentation"))
        )
        supporting_next.click()
        
        #Select Yes fir supporting documentation
        yes_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbYes']"))
        )
        yes_radio_label.click()
        print("Selected 'Yes' for 'Work to existing building'.")

        # Select continue for supporting documentation
        supporting_yes_next = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnContinueOptions"))
        )
        supporting_yes_next.click()
        
        # Select continue for supporting documentation
        add_doc = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAddDocumentation"))
        )
        add_doc.click()
        
        #Select Yes fir supporting documentation
        upload_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbUploaded']"))
        )
        upload_radio_label.click()
        
        # Select continue for supporting documentation
        attach_yes_next = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAttachmentContinue"))
        )
        attach_yes_next.click()
    
       # Step 46: Finally, move to "Supporting Documentation" for uploading PDFs
        upload_entries, location_plan_file, effective_pdf_folder, bucket_labels = load_supporting_docs_upload_list(pdf_folder_path)

        for pdf_file, bucket_key in upload_entries:
            attach_path = os.path.join(effective_pdf_folder, pdf_file)
            print(f"Uploading supporting document '{pdf_file}' from category '{bucket_key}'.")

            # Title (keep your existing logic if you want)
            base_no_ext = os.path.splitext(os.path.basename(pdf_file))[0]

            if bucket_key != "other":
                # Description comes directly from bucket
                description = bucket_labels.get(bucket_key, bucket_key)
            else:
                # Only infer for "other"
                _, description = extract_title_and_description(pdf_file, attach_path)

            title = base_no_ext

            type_into(driver, By.ID, "MainContent_SupportingDocumentationWizard_edtUniqueDrawingReferenceNumber", title)

            type_into(driver, By.ID, "MainContent_SupportingDocumentationWizard_edtDescription", description)

            # Paper Size
            paper_size = get_paper_size_from_pdf(attach_path)
            select_by_text(driver, By.ID, "MainContent_SupportingDocumentationWizard_lbPaperSize", paper_size)

            # Doc Type
            doc_type = get_document_type_from_pdf(attach_path)
            select_by_text(driver, By.ID, "MainContent_SupportingDocumentationWizard_lbDocumentType", doc_type)

            # Attach
            attach_input = WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.ID, "MainContent_SupportingDocumentationWizard_fuAttachFile"))
            )
            attach_input.send_keys(attach_path)

            # "Read and Understood" if required
            try:
                read_label = WebDriverWait(driver, 20).until(
                    EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbReadAndUnderstood']"))
                )
                read_label.click()
            except Exception:
                pass

            # Upload
            upload_btn = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnSaveDocEdit"))
            )
            upload_btn.click()
            wait_for_supporting_doc_upload_result(driver, pdf_file, timeout=30)
            print(f"Uploaded '{pdf_file}' successfully.")
            
            #Add documentation
            click_when_clickable(
                driver,
                By.ID,
                "MainContent_SupportingDocumentationWizard_btnAddDocumentation"
            )
            
            #Upload Yes
            upload_radio_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbUploaded']"))
            )
            upload_radio_label.click()
            
            # Select continue for supporting documentation
            attach_yes_next = WebDriverWait(driver, 30).until(
                EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnAttachmentContinue"))
            )
            attach_yes_next.click()
            
            # Wait for page to refresh
            WebDriverWait(driver, 30).until(
                EC.url_to_be("https://www.ebuildingstandards.scot/eBuildingStandardsClient/CustomPages/Applications/SupportingDocumentation.aspx")
            )

        print("All PDFs uploaded. Automation steps complete.")
        record_checkpoint("supporting_documents_uploaded", "supporting_documents")
        print("The browser will remain open for you to continue manually or close at your discretion.\n")
        
        # Cancel
        cancel_btn = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnCancelDocEdit"))
        )
        cancel_btn.click()
        
        # Scroll down so buttons become visible
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

        # Finish documentation section
        addmore_radio_label = WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_SupportingDocumentationWizard_rbFinished']"))
        )
        addmore_radio_label.click()

        # Click "Save" button
        save_button = WebDriverWait(driver, 15).until(
            EC.element_to_be_clickable((By.ID, "MainContent_SupportingDocumentationWizard_btnDocSave"))
        )
        save_button.click()
        print("💾 Saved and exited documentation section.")
        
       # Enter into the "Block/Location Plan" section
        dismiss_gdpr_modal_if_present(driver)
        wait_dom_ready(driver)

        print("Clicking Block/Location Plan...")
        js_click_by_id(driver, "MainContent_FormSections_btnBlock/LocationPlan", timeout=30)
        print("Clicked Block/Location Plan.")

        # Click the "Attach Location plan" option
        location_plan_label = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_rbAttachBlockPlan']"))
        )
        location_plan_label.click()

        # Click the "Continue" button
        continue_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnContinueAddBlockPlan"))
        )
        continue_button.click()

        #Click uploaded location plan option
        location_plan_label_uploaded = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_rbUploaded']"))
        )
        location_plan_label_uploaded.click()

        continue_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnContinueBlockPlanOptions"))
        )
        continue_button.click()

        # Upload the Location Plan file
        file_input = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//input[@type='file']"))
        )

        # In case it's hidden/overlaid
        driver.execute_script(
            "arguments[0].style.display='block'; arguments[0].style.visibility='visible';",
            file_input
        )

        file_input.send_keys(location_plan_path)
        print("Location Plan file selected in file input.")
        
        # Paper size
        paper_size_dropdown = Select(WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_ddlPaperSizeUploadBlockPlan"))
        ))
        paper_size_dropdown.select_by_visible_text(location_plan_paper_size)

        # Doc type
        doc_type_dropdown = Select(WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_ddlDocTypeUploadBlockPlan"))
        ))
        doc_type_dropdown.select_by_visible_text(location_plan_doc_type)


        annotated_checkbox = WebDriverWait(driver, 30).until(
            EC.presence_of_element_located((By.XPATH, "//label[@for='MainContent_BlockPlanWizard_cbFileAnnotated']"))
        )
        annotated_checkbox.click()

        upload_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnUploadUploadBlockPlan"))
        )
        upload_button.click()

        confirm_button = WebDriverWait(driver, 30).until(
            EC.element_to_be_clickable((By.ID, "MainContent_BlockPlanWizard_btnConfirmSavedBlockPlan"))
        )
        confirm_button.click()
        record_checkpoint("location_plan_uploaded", "location_plan")
        stage("documents", "completed", "Documents uploaded")
        
        stage("declaration", "running", "Completing declaration")
        complete_declaration(
            driver,
            BUILDING_WARRANT,
            user_inputs=user_inputs,
            progress=progress,
        )
        stage("declaration", "completed", "Declaration completed")
        record_checkpoint("declaration_complete", "declaration")
        stage("final_review", "running", "Finalising application")
        # complete_declaration only returns after the Form Summary controls have
        # been reacquired following the final ASP.NET postback.
        fee_handoff = open_fee_and_handoff(
            driver,
            BUILDING_WARRANT,
            declaration_complete=True,
            progress=progress,
        )
        enter_calculated_fee(driver, calculated_fee_minor_units)
        stage("final_review", "completed", "Calculated application fee confirmed")
        record_checkpoint("application_prepared", "final_review")
        print("Building Warrant automated preparation complete on the fee page.")
        return fee_handoff
        


    except Exception as e:
        print("ERROR encountered:", repr(e), flush=True)
        raise

# Standard Python entrypoint
if __name__ == "__main__":
    main()

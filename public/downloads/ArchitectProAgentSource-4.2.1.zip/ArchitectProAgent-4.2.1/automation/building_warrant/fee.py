"""Verified Building Warrant fee entry from an immutable Web snapshot value."""

from __future__ import annotations

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import type_into


FEE_FIELD_ID = "MainContent_txtEnterFee"
CALCULATED_FEE_MINOR_UNITS_KEY = "Calculated Fee Minor Units"
MISSING_FEE_MESSAGE = (
    "The application fee could not be calculated because required fee information is missing. "
    "Review the relevant fee inputs in Architect Pro and start a fresh retry."
)


class BuildingWarrantFeeError(ValueError):
    pass


def require_calculated_fee_minor_units(user_inputs) -> int:
    value = (user_inputs or {}).get(CALCULATED_FEE_MINOR_UNITS_KEY)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise BuildingWarrantFeeError(MISSING_FEE_MESSAGE)
    return value


def format_fee_minor_units(minor_units: int) -> str:
    if isinstance(minor_units, bool) or not isinstance(minor_units, int) or minor_units < 0:
        raise BuildingWarrantFeeError(MISSING_FEE_MESSAGE)
    pounds, pennies = divmod(minor_units, 100)
    return f"{pounds}.{pennies:02d}"


def _confirmed_fee_value(driver, expected_value: str):
    try:
        field = driver.find_element(By.ID, FEE_FIELD_ID)
        return field if str(field.get_attribute("value") or "") == expected_value else False
    except (StaleElementReferenceException, WebDriverException):
        return False


def enter_calculated_fee(driver, minor_units: int, *, timeout: float = 30) -> str:
    """Enter and positively verify the Web-calculated fee without navigation retries."""
    expected_value = format_fee_minor_units(minor_units)
    type_into(driver, By.ID, FEE_FIELD_ID, expected_value, timeout=timeout, clear_first=True)
    try:
        WebDriverWait(driver, timeout).until(
            lambda current: _confirmed_fee_value(current, expected_value)
        )
    except TimeoutException as exc:
        raise BuildingWarrantFeeError(
            "The portal did not confirm the calculated application fee. "
            "No further portal action was taken."
        ) from exc
    return expected_value

# -*- coding: utf-8 -*-
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, get_when_present, type_into


def fill_agent_details(driver, user_inputs):
    WebDriverWait(driver, 30).until(
        EC.presence_of_element_located(
            (By.ID, "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentFirstName")
        )
    )

    click_when_clickable(
        driver,
        By.ID,
        "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnClearPage",
        timeout=10,
    )

    agent_field_ids = {
        "Agent First Name": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentFirstName",
        "Agent Last Name": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentSurname",
        "Agent Telephone Number": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentTelNo",
        "Agent Email Address": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentEmailAddress",
        "Agent Building Number": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentBuildingNo",
        "Agent Address 1": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentAddress1",
        "Agent Town/City": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentTown",
        "Agent Country": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentCountry",
        "Agent Postcode": "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentPostcode",
    }

    for field, element_id in agent_field_ids.items():
        try:
            value = user_inputs.get(field, "")
            if value.strip():
                type_into(driver, By.ID, element_id, value.strip())
                print(f"Filled: {field}")
            else:
                get_when_present(driver, By.ID, element_id)
                print(f"Skipping {field} (blank value)")
        except Exception as e:
            print(f"Could not locate Agent field '{field}': {str(e)}")

    print("Selecting 'Yes' for 'Applicant is owner'.")
    applicant_owner_label = WebDriverWait(driver, 30).until(
        EC.element_to_be_clickable(
            (
                By.XPATH,
                "//label[@for='MainContent_BuildingWarrantAppWizard_AgentDetails_rblIndividualOrOrganisation_0']",
            )
        )
    )
    applicant_owner_label.click()

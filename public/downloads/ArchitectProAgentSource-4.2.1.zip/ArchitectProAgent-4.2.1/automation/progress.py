"""GUI-independent stage progress, ETA estimation and anonymous timing history."""

from __future__ import annotations

from dataclasses import dataclass
import json
import os
import statistics
import time
from typing import Callable, Mapping

from automation.common import storage
from automation.models import PLANNING_TYPES


HISTORY_VERSION = 1
MAX_SUCCESSFUL_RUNS = 10

# Conservative first-run seconds. Successful local runs replace these with a
# rolling median; portal postconditions, never elapsed time, complete a stage.
DEFAULT_STAGE_SECONDS = {
    "planning": {
        "validation": 1.0,
        "browser": 5.0,
        "login": 8.0,
        "proposal": 15.0,
        "main_details": 15.0,
        "ownership": 10.0,
        "documents": 50.0,
        "declaration": 15.0,
        "final_review": 5.0,
    },
    "building_warrant": {
        "validation": 1.0,
        "browser": 5.0,
        "login": 8.0,
        "proposal": 15.0,
        "main_details": 60.0,
        "documents": 60.0,
        "declaration": 15.0,
        "final_review": 5.0,
    },
}


USER_STAGE_LABELS = {
    "validation": "Starting automation…",
    "browser": "Starting secure browser",
    "login": "Signing in",
    "proposal": "Opening proposal",
    "main_details": "Completing application details",
    "ownership": "Completing ownership and certificates",
    "documents": "Uploading supporting documents",
    "declaration": "Completing declaration",
    "final_review": "Finalising application",
}


def workflow_key(application_type: str) -> str:
    return "planning" if application_type in PLANNING_TYPES else "building_warrant"


def workflow_stages(application_type: str) -> tuple[str, ...]:
    return tuple(DEFAULT_STAGE_SECONDS[workflow_key(application_type)])


@dataclass(frozen=True, slots=True)
class ProgressSnapshot:
    workflow: str
    status: str
    stage: str
    stage_label: str
    stage_state: str
    progress_percent: int
    elapsed_seconds: float
    estimated_seconds_remaining: float | None
    message: str

    def as_payload(self) -> dict[str, object]:
        return {
            "workflow": self.workflow,
            "status": self.status,
            "stage": self.stage,
            "stageLabel": self.stage_label,
            "stageState": self.stage_state,
            "progressPercent": self.progress_percent,
            "estimatedSecondsRemaining": (
                round(self.estimated_seconds_remaining)
                if self.estimated_seconds_remaining is not None
                else None
            ),
            "message": self.message,
        }


class TimingHistoryStore:
    def __init__(self, path: str | None = None):
        self.path = path or storage.runtime_path("automation_timing_history.json")

    def load(self) -> dict:
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                value = json.load(handle)
        except (OSError, json.JSONDecodeError):
            return {"version": HISTORY_VERSION, "profiles": {}}
        if not isinstance(value, dict) or value.get("version") != HISTORY_VERSION:
            return {"version": HISTORY_VERSION, "profiles": {}}
        profiles = value.get("profiles")
        return value if isinstance(profiles, dict) else {"version": HISTORY_VERSION, "profiles": {}}

    def expected_stage_seconds(self, application_type: str) -> dict[str, float]:
        key = workflow_key(application_type)
        defaults = dict(DEFAULT_STAGE_SECONDS[key])
        runs = self.load().get("profiles", {}).get(key, [])
        if not isinstance(runs, list):
            return defaults
        for stage in defaults:
            samples = [
                float(run.get("stages", {}).get(stage))
                for run in runs
                if isinstance(run, dict)
                and isinstance(run.get("stages"), dict)
                and isinstance(run["stages"].get(stage), (int, float))
                and 0 < float(run["stages"][stage]) < 7200
            ]
            if samples:
                defaults[stage] = statistics.median(samples[-MAX_SUCCESSFUL_RUNS:])
        return defaults

    def has_successful_history(self, application_type: str) -> bool:
        key = workflow_key(application_type)
        runs = self.load().get("profiles", {}).get(key, [])
        if not isinstance(runs, list):
            return False
        return any(
            isinstance(run, dict)
            and isinstance(run.get("overall"), (int, float))
            and float(run["overall"]) > 0
            and isinstance(run.get("stages"), dict)
            and bool(run["stages"])
            for run in runs
        )

    def record_success(self, application_type: str, timings: Mapping[str, float]) -> bool:
        stages = {}
        for stage in workflow_stages(application_type):
            value = timings.get(f"stage_{stage}")
            if isinstance(value, (int, float)) and 0 < float(value) < 7200:
                stages[stage] = round(float(value), 3)
        overall = timings.get("overall")
        if not stages or not isinstance(overall, (int, float)) or float(overall) <= 0:
            return False
        data = self.load()
        profiles = data.setdefault("profiles", {})
        runs = profiles.setdefault(workflow_key(application_type), [])
        if not isinstance(runs, list):
            runs = profiles[workflow_key(application_type)] = []
        # Anonymous performance data only: no job, project, address, user or credential fields.
        runs.append({"overall": round(float(overall), 3), "stages": stages})
        del runs[:-MAX_SUCCESSFUL_RUNS]
        directory = os.path.dirname(self.path)
        if directory:
            os.makedirs(directory, exist_ok=True)
        temporary = f"{self.path}.tmp"
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2, sort_keys=True)
        os.replace(temporary, self.path)
        return True


class ProgressEstimator:
    def __init__(
        self,
        application_type: str,
        *,
        history: TimingHistoryStore | None = None,
        clock: Callable[[], float] | None = None,
    ):
        self.application_type = application_type
        self.history = history or TimingHistoryStore()
        self.clock = clock or time.monotonic
        self.expected = self.history.expected_stage_seconds(application_type)
        self.has_timing_history = self.history.has_successful_history(application_type)
        self.stages = workflow_stages(application_type)
        self.started_at = self.clock()
        self.current_stage = self.stages[0]
        self.current_started_at = self.started_at
        self.completed: set[str] = set()
        self.status = "running"
        self.message = USER_STAGE_LABELS[self.current_stage]
        # The click-to-running transition has a small honest allocation inside
        # validation while the runner prepares its first structured event.
        self._last_percent = 1

    def consume(self, event) -> ProgressSnapshot:
        stage = str(getattr(event, "stage", "") or "")
        status = str(getattr(getattr(event, "status", ""), "value", getattr(event, "status", "")))
        if (
            workflow_key(self.application_type) == "building_warrant"
            and (stage.startswith("declaration.") or stage == "fee.open")
        ):
            # `fee.open` is retained for callbacks from older agent builds. New
            # runs finish on the application summary and use `final_review`.
            canonical_stage = "final_review" if stage == "fee.open" else "declaration"
            now = self.clock()
            if self.current_stage != canonical_stage:
                self.current_started_at = now
            self.current_stage = canonical_stage
            self.message = str(getattr(event, "message", "") or USER_STAGE_LABELS[canonical_stage])
            if status in {"failed", "cancelled"}:
                self.status = status
            return self.snapshot()
        if stage == "address_selection":
            now = self.clock()
            if status == "user_action_required":
                self.status = status
                self.message = str(
                    getattr(event, "message", "")
                    or "Select the correct property address to continue."
                )
            elif status == "running":
                self.status = "running"
                self.current_stage = "proposal"
                self.current_started_at = now
                self.message = "Address confirmed. Continuing automation."
            elif status in {"failed", "cancelled"}:
                self.status = status
                self.message = str(getattr(event, "message", "") or "Automation stopped")
            return self.snapshot()
        if stage == "workflow" or stage not in self.stages:
            return self.snapshot()
        now = self.clock()
        if status == "running":
            self.current_stage = stage
            self.current_started_at = now
            self.message = USER_STAGE_LABELS.get(stage, str(getattr(event, "message", "") or stage))
        elif status == "completed":
            self.completed.add(stage)
            self.message = USER_STAGE_LABELS.get(stage, stage)
            current_index = self.stages.index(stage)
            if current_index + 1 < len(self.stages):
                self.current_stage = self.stages[current_index + 1]
                self.current_started_at = now
                self.message = USER_STAGE_LABELS[self.current_stage]
        elif status in {"failed", "cancelled"}:
            self.status = status
            self.message = str(getattr(event, "message", "") or "Automation stopped")
        elif status == "user_action_required":
            self.status = status
            self.current_stage = stage
            self.completed.update(self.stages)
            self._last_percent = 100
            self.message = str(getattr(event, "message", "") or "Complete the fee in the browser.")
        return self.snapshot()

    def snapshot(self) -> ProgressSnapshot:
        now = self.clock()
        elapsed = max(0.0, now - self.started_at)
        total_expected = sum(self.expected.values())
        completed_expected = sum(self.expected[stage] for stage in self.completed)
        current_expected = self.expected.get(self.current_stage, 1.0)
        current_elapsed = max(0.0, now - self.current_started_at)
        if self.current_stage in self.completed or self.status != "running":
            within_fraction = 0.0
        else:
            # Move within the active allocation but never infer completion.
            within_fraction = min(0.9, current_elapsed / max(current_expected * 1.5, 1.0))
        estimated_completed = completed_expected + (current_expected * within_fraction)
        calculated = int((estimated_completed / max(total_expected, 1.0)) * 100)
        cap = (
            100
            if self.status == "user_action_required" and self.current_stage == "fee"
            else (98 if self.status in {"running", "user_action_required"} else 99)
        )
        percent = max(self._last_percent, min(cap, calculated))
        self._last_percent = percent

        future = sum(
            self.expected[stage]
            for stage in self.stages
            if stage not in self.completed and self.stages.index(stage) > self.stages.index(self.current_stage)
        )
        adjusted_current = max(current_expected, current_elapsed * 1.25)
        remaining = max(0.0, adjusted_current - current_elapsed) + future
        if self.status == "user_action_required":
            remaining = None
        elif not self.has_timing_history:
            remaining = None
        stage_state = "completed" if self.current_stage in self.completed else self.status
        return ProgressSnapshot(
            workflow=workflow_key(self.application_type),
            status=self.status,
            stage=self.current_stage,
            stage_label=USER_STAGE_LABELS.get(self.current_stage, self.message),
            stage_state=stage_state,
            progress_percent=percent,
            elapsed_seconds=elapsed,
            estimated_seconds_remaining=remaining,
            message=self.message,
        )

    def complete(self, timings: Mapping[str, float]) -> ProgressSnapshot:
        self.status = "success"
        self.completed.update(self.stages)
        self._last_percent = 100
        self.history.record_success(self.application_type, timings)
        elapsed = max(0.0, self.clock() - self.started_at)
        return ProgressSnapshot(
            workflow=workflow_key(self.application_type),
            status="success",
            stage="complete",
            stage_label="Complete",
            stage_state="completed",
            progress_percent=100,
            elapsed_seconds=elapsed,
            estimated_seconds_remaining=0.0,
            message="Application prepared",
        )

    def handoff(self, timings: Mapping[str, float]) -> ProgressSnapshot:
        self.status = "user_action_required"
        self.current_stage = "fee"
        self.completed.update(self.stages)
        self._last_percent = 100
        self.history.record_success(self.application_type, timings)
        elapsed = max(0.0, self.clock() - self.started_at)
        return ProgressSnapshot(
            workflow=workflow_key(self.application_type),
            status="user_action_required",
            stage="fee",
            stage_label="Fee — Complete in browser",
            stage_state="user_action_required",
            progress_percent=100,
            elapsed_seconds=elapsed,
            estimated_seconds_remaining=None,
            message="Complete the fee in the browser.",
        )

    def stop(self, status: str, message: str) -> ProgressSnapshot:
        if status not in {"failed", "cancelled"}:
            raise ValueError("Stopped progress must be failed or cancelled.")
        self.status = status
        self.message = message
        return self.snapshot()


def format_remaining(seconds: float | None) -> str:
    if seconds is None:
        return "Estimating time remaining…"
    seconds = max(0, int(round(seconds)))
    if seconds <= 15:
        return "Finishing up…"
    if seconds < 60:
        return "Less than a minute remaining"
    minutes = max(1, round(seconds / 60))
    return f"About {minutes} minute{'s' if minutes != 1 else ''} remaining"

@echo off
setlocal EnableExtensions

set "APP_NAME=ArchitectPortalAutomation"
set "ROOT_DIR=%~dp0"
set "RELEASES_DIR=%ROOT_DIR%Releases"
set "BUILD_DIR=%RELEASES_DIR%\_build\%APP_NAME%"
set "DIST_DIR=%RELEASES_DIR%\_dist"
set "APP_DIST=%DIST_DIR%\%APP_NAME%"
set "VERSION_FILE=%ROOT_DIR%version_info.txt"

cd /d "%ROOT_DIR%"

set "ICON_ARGS="
for %%I in (*.ico) do (
    set "ICON_ARGS=--icon=%%~fI"
    goto :found_icon
)
:found_icon

echo [1/5] Preparing clean release build folders...
if not exist "%RELEASES_DIR%" mkdir "%RELEASES_DIR%"
tasklist /FI "IMAGENAME eq %APP_NAME%.exe" 2>NUL | find /I "%APP_NAME%.exe" >NUL
if not errorlevel 1 (
    echo Build stopped: Architect Pro Agent is still running.
    echo Closing the window keeps the Agent active in the notification area.
    echo Right-click the Architect Pro Agent tray icon, choose Quit, then run this build again.
    exit /b 1
)
if exist "%BUILD_DIR%" rmdir /s /q "%BUILD_DIR%"
if exist "%APP_DIST%" rmdir /s /q "%APP_DIST%"
if exist "%APP_DIST%" (
    echo Build stopped: the existing release output is still in use.
    echo Quit Architect Pro Agent from its notification-area icon and close any Explorer window in the release folder.
    echo If Windows still holds _internal\certifi\cacert.pem, restart Windows and run this build again.
    exit /b 1
)

echo [2/5] Building %APP_NAME% with PyInstaller...
pyinstaller ^
  --noconfirm ^
  --clean ^
  --windowed ^
  --onedir ^
  --noupx ^
  --workpath "%BUILD_DIR%" ^
  --distpath "%DIST_DIR%" ^
  --specpath "%BUILD_DIR%" ^
  --name "%APP_NAME%" ^
  --version-file "%VERSION_FILE%" ^
  --add-data "%ROOT_DIR%assets;assets" ^
  --hidden-import automation.runner ^
  --hidden-import automation.progress ^
  --hidden-import automation.common.declaration ^
  --hidden-import automation.common.existing_application ^
  --hidden-import automation.common.handoff ^
  --hidden-import automation.common.window_control ^
  --hidden-import automation.householder.run ^
  --hidden-import automation.building_warrant.run ^
  --hidden-import automation.portal_adapter ^
  --hidden-import gui.agent_app ^
  --hidden-import gui.services.portal_answers ^
  --hidden-import gui.services.portal_handoff ^
  --hidden-import gui.services.callback_outbox ^
  --hidden-import gui.services.secure_credentials ^
  --hidden-import gui.services.storage_paths ^
  --hidden-import keyring ^
  --hidden-import keyring.backends.Windows ^
  --hidden-import keyring.errors ^
  --hidden-import PySide6.QtCore ^
  --hidden-import PySide6.QtGui ^
  --hidden-import PySide6.QtWidgets ^
  --hidden-import PyPDF2 ^
  --hidden-import selenium ^
  --hidden-import selenium.webdriver.chrome.service ^
  --hidden-import webdriver_manager.chrome ^
  --exclude-module gui.app ^
  --exclude-module gui.pages ^
  --exclude-module gui.controllers ^
  --exclude-module gui.application_selector ^
  --exclude-module gui.sidebar ^
  --exclude-module gui.stepper ^
  %ICON_ARGS% ^
  Gui.py
if errorlevel 1 (
    echo Build failed.
    exit /b 1
)

echo [3/5] Removing private/runtime files from distributable...
for %%F in (
    user_inputs.json
    supporting_docs.json
    continue_flag.txt
    login_presets.json
    agent_presets.json
    applicant_presets.json
    cert_presets.json
    ai_settings.json
    "Service key - OpenAI.txt"
) do (
    if exist "%APP_DIST%\%%~F" del /q "%APP_DIST%\%%~F"
)

echo [4/5] Writing tester readme...
(
    echo Architect Portal Automation - test build
    echo.
    echo Run:
    echo 1. Keep this whole folder together.
    echo 2. Open %APP_NAME%.exe once to register web portal links.
    echo 3. In ArchitectPro Web Portal, open a project or prepared desktop job.
    echo 4. Select Open in desktop app. The prepared immutable job and documents load automatically.
    echo 5. Select Start Automation.
    echo.
echo Requirements:
echo - Windows.
echo - Google Chrome installed.
echo - Internet access for eDevelopment/ePlanning/eBuildingStandards.
echo.
    echo Notes:
    echo - Do not send only the .exe file. The _internal folder is required.
    echo - No saved passwords, API keys, runtime JSON, or preset JSON files are included.
    echo - Runtime data is created under %%APPDATA%%\NinetyOneArchitects\Building Portal.
    echo - Remembered portal passwords use Windows Credential Manager when available.
    echo - Opening the app once registers architectpro:// links for the current Windows user.
    echo - The desktop is an execution agent. Correct application data in ArchitectPro and prepare a new job.
    echo - Web Portal handoff is automatic. Users do not need to copy or enter connection codes.
    echo - Each web handoff link is short-lived, single-use and restricted to the selected job.
) > "%APP_DIST%\README_TEST_BUILD.txt"

echo [5/5] Build complete.
echo Send this folder:
echo   %APP_DIST%
echo Or zip that folder before sending.

endlocal

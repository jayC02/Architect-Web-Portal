from types import SimpleNamespace

import pytest

from automation.common.browser_mode import BrowserMode
from automation.common.driver import ManagedChrome, reveal_handed_off_browser
from automation.common.window_control import OwnedChromeWindow


class FakeApi:
    def __init__(self):
        self.visible = {101: True, 999: True}
        self.hidden = []
        self.foregrounded = []

    def descendant_process_ids(self, root_pid):
        assert root_pid == 50
        return {50, 51}

    def chrome_windows_for_pids(self, process_ids):
        assert process_ids == {50, 51}
        return [101]

    def hide(self, hwnd):
        self.hidden.append(hwnd); self.visible[hwnd] = False

    def is_visible(self, hwnd):
        return self.visible[hwnd]

    def is_window(self, hwnd):
        return hwnd in self.visible

    def restore_and_foreground(self, hwnd):
        self.foregrounded.append(hwnd); self.visible[hwnd] = True


class FakeDriver:
    def __init__(self):
        self.session_id = "same-session"
        self.service = SimpleNamespace(process=SimpleNamespace(pid=50))
        self.quit_calls = 0
        self.maximise_calls = 0

    def set_page_load_timeout(self, _timeout):
        pass

    def maximize_window(self):
        self.maximise_calls += 1

    def quit(self):
        self.quit_calls += 1


def test_owned_window_is_hidden_then_restored_and_foregrounded_without_touching_unrelated_window():
    driver = FakeDriver(); api = FakeApi()
    window = OwnedChromeWindow(driver, api=api)
    window.hide()
    assert api.hidden == [101]
    assert api.visible[101] is False
    assert api.visible[999] is True

    window.reveal_and_focus()
    assert api.foregrounded == [101]
    assert api.visible[101] is True
    assert api.visible[999] is True
    assert driver.session_id == "same-session"


def test_session_change_blocks_reveal():
    driver = FakeDriver(); window = OwnedChromeWindow(driver, api=FakeApi())
    window.hide(); driver.session_id = "different-session"
    with pytest.raises(RuntimeError, match="session changed"):
        window.reveal_and_focus()


def test_managed_auto_browser_hides_and_preserves_exact_session_at_handoff(monkeypatch):
    driver = FakeDriver(); api = FakeApi(); created = []
    monkeypatch.setattr("automation.common.driver.create_chrome_driver", lambda _options: (created.append(driver) or driver))
    managed = ManagedChrome(
        BrowserMode.AUTO,
        window_factory=lambda active: OwnedChromeWindow(active, api=api),
    ).bind_to_job("job-fee-1")
    assert managed.start() is driver
    assert created == [driver]
    assert api.hidden == [101]
    managed.handoff_to_user()
    managed.close(preserve_visible=True)
    assert api.foregrounded == [101]
    assert driver.quit_calls == 0
    assert created == [driver]
    assert reveal_handed_off_browser("job-fee-1") == "same-session"
    assert api.foregrounded == [101, 101]


def test_reveal_is_job_scoped_and_never_starts_or_replaces_a_browser():
    with pytest.raises(RuntimeError, match="not available"):
        reveal_handed_off_browser("another-job")

import json
import os
import tempfile
import unittest
from unittest.mock import patch

from automation.common import runtime


class AutomationCheckpointTests(unittest.TestCase):
    def test_checkpoint_is_non_sensitive_and_replaced_atomically(self):
        with tempfile.TemporaryDirectory() as temp, patch.object(
            runtime,
            "AUTOMATION_CHECKPOINT_FILE",
            os.path.join(temp, "automation_checkpoint.json"),
        ):
            runtime.record_checkpoint("main_details_complete", "main_details", "Main details completed.")
            with open(runtime.AUTOMATION_CHECKPOINT_FILE, encoding="utf-8") as handle:
                saved = json.load(handle)

            self.assertEqual(saved["checkpoint"], "main_details_complete")
            self.assertEqual(saved["section"], "main_details")
            self.assertNotIn("password", json.dumps(saved).lower())
            self.assertFalse(os.path.exists(f"{runtime.AUTOMATION_CHECKPOINT_FILE}.tmp"))

            runtime.clear_checkpoint()
            self.assertFalse(os.path.exists(runtime.AUTOMATION_CHECKPOINT_FILE))


if __name__ == "__main__":
    unittest.main()

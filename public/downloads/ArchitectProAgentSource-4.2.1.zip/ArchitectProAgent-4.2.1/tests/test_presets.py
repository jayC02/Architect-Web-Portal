import json
import os

from gui.services import presets, storage_paths


def test_scrub_legacy_passwords_removes_password_fields():
    data = {
        "user@example.com": {"Email": "user@example.com", "Password": "secret"},
        "other@example.com": {"Email": "other@example.com"},
    }

    assert presets.scrub_legacy_passwords(data) is True
    assert data["user@example.com"] == {"Email": "user@example.com"}
    assert "Password" not in data["other@example.com"]


def test_save_json_writes_to_appdata(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))

    presets.save_json(str(source), "login_presets.json", {"a": {"Email": "a@example.com"}})

    expected = appdata / storage_paths.APP_VENDOR / storage_paths.APP_NAME / "login_presets.json"
    assert expected.exists()
    assert json.loads(expected.read_text(encoding="utf-8")) == {"a": {"Email": "a@example.com"}}


def test_load_json_reads_legacy_file_if_appdata_missing(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))
    legacy = source / "agent_presets.json"
    legacy.write_text(json.dumps({"legacy": {"Agent First Name": "Jay"}}), encoding="utf-8")

    assert presets.load_json(str(source), "agent_presets.json") == {"legacy": {"Agent First Name": "Jay"}}
    migrated = appdata / storage_paths.APP_VENDOR / storage_paths.APP_NAME / "agent_presets.json"
    assert migrated.exists()


def test_legacy_login_preset_migration_scrubs_password(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))
    legacy = source / "login_presets.json"
    legacy.write_text(
        json.dumps({"user@example.com": {"Email": "user@example.com", "Password": "secret"}}),
        encoding="utf-8",
    )

    loaded = presets.load_json(str(source), "login_presets.json")
    migrated = appdata / storage_paths.APP_VENDOR / storage_paths.APP_NAME / "login_presets.json"

    assert loaded == {"user@example.com": {"Email": "user@example.com"}}
    assert json.loads(migrated.read_text(encoding="utf-8")) == loaded
    assert "Password" in json.loads(legacy.read_text(encoding="utf-8"))["user@example.com"]


def test_invalid_legacy_json_is_not_migrated(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))
    (source / "login_presets.json").write_text("{not json", encoding="utf-8")

    assert presets.load_json(str(source), "login_presets.json") == {}
    assert not (appdata / storage_paths.APP_VENDOR / storage_paths.APP_NAME / "login_presets.json").exists()


def test_user_inputs_is_not_auto_migrated(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))
    (source / "user_inputs.json").write_text(
        json.dumps({"Email": "user@example.com", "Password": "secret"}),
        encoding="utf-8",
    )

    runtime = storage_paths.runtime_path("user_inputs.json", str(source))

    assert not os.path.exists(runtime)

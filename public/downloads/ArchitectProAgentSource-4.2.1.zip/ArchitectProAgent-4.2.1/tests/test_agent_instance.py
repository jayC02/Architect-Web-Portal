import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
from PySide6.QtWidgets import QApplication
from gui.services.agent_instance import AgentInstance

def test_second_launch_routes_to_existing_process_and_lock_releases(monkeypatch,tmp_path):
    from gui.services import storage_paths
    monkeypatch.setattr(storage_paths,'app_data_dir',lambda:str(tmp_path))
    monkeypatch.setattr(storage_paths,'runtime_path',lambda name:str(tmp_path/name))
    app=QApplication.instance() or QApplication([])
    first=AgentInstance(); second=AgentInstance()
    try:
        assert first.acquire()
        received=[]; first.set_handler(received.append)
        import subprocess, sys, time
        code = """import sys
from PySide6.QtCore import QCoreApplication
from gui.services import storage_paths
from gui.services.agent_instance import AgentInstance
from pathlib import Path
storage_paths.app_data_dir=lambda:sys.argv[1]
storage_paths.runtime_path=lambda name:str(Path(sys.argv[1])/name)
app=QCoreApplication([]); client=AgentInstance()
assert not client.acquire('architectpro://update')
"""
        child=subprocess.Popen([sys.executable,'-c',code,str(tmp_path)])
        deadline=time.monotonic()+10
        while child.poll() is None and time.monotonic()<deadline:
            app.processEvents(); time.sleep(0.01)
        if child.poll() is None: child.kill()
        assert child.wait()==0
        for _ in range(10): app.processEvents()
        assert received==['architectpro://update']
    finally:
        first.close(); second.close()
    third=AgentInstance()
    try: assert third.acquire()
    finally: third.close()

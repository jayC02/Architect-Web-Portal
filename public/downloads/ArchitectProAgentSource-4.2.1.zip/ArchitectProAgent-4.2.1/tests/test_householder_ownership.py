import importlib

import pytest
from selenium.common.exceptions import TimeoutException

from automation.householder import navigation, ownership


VERIFIED_NEXT_IDS = {
    "25%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP1D",
    "30%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP1E",
    "35%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP2",
    "40%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP3",
    "65%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPPCertC3",
    "70%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPPReasonableSteps",
    "75%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextCertificatesHHPP",
    "85%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP4",
    "100%": "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_btnNextHHPP5",
}


def test_householder_startup_module_imports_with_current_navigation_api():
    run_module = importlib.import_module("automation.householder.run")

    assert run_module.complete_certificate_of_ownership is ownership.complete_certificate_of_ownership


def test_verified_householder_ownership_navigation_mapping(monkeypatch):
    clicked = []

    def click_by_id(_driver, element_id, label, timeout=15, submit_fallback=True):
        clicked.append((element_id, label, timeout, submit_fallback))
        return object()

    monkeypatch.setattr(navigation, "click_by_id", click_by_id)

    for step in VERIFIED_NEXT_IDS:
        navigation.click_ownership_hhpp_next(object(), step, timeout=7)

    assert navigation.OWNERSHIP_HHPP_NEXT_IDS | VERIFIED_NEXT_IDS == navigation.OWNERSHIP_HHPP_NEXT_IDS
    assert [item[0] for item in clicked] == list(VERIFIED_NEXT_IDS.values())
    assert all(item[2] == 7 for item in clicked)
    assert all(element_id.startswith(
        "MainContent_CertificateOfOwnershipWizard_HouseholderAndPlanningWizard_"
    ) for element_id in VERIFIED_NEXT_IDS.values())


def test_missing_householder_next_reports_step_and_expected_id(monkeypatch):
    def missing(*_args, **_kwargs):
        raise TimeoutException("missing")

    monkeypatch.setattr(navigation, "click_by_id", missing)

    with pytest.raises(RuntimeError) as error:
        navigation.click_ownership_hhpp_next(object(), "25%")

    message = str(error.value)
    assert "25%" in message
    assert VERIFIED_NEXT_IDS["25%"] in message


def test_identify_all_other_owners_uses_stored_answer_and_25_percent_next(monkeypatch):
    selected = []
    clicked_steps = []

    def select_answer(_driver, key, yes_id, no_id, user_inputs, default=None):
        answer = user_inputs.get(key, default)
        selected.append(yes_id if answer == "Yes" else no_id)
        return answer

    monkeypatch.setattr(ownership, "click_yes_no", select_answer)
    monkeypatch.setattr(
        ownership,
        "click_ownership_hhpp_next",
        lambda _driver, step: clicked_steps.append(step),
    )

    answer = ownership.complete_identify_all_other_owners_step(
        object(),
        {ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY: "No"},
    )

    assert answer == "No"
    assert selected == [ownership.IDENTIFY_ALL_OTHER_OWNERS_NO_ID]
    assert clicked_steps == ["25%"]


def test_notice_to_one_owner_uses_prepared_answer_and_30_percent_next(monkeypatch):
    selected = []
    clicked_steps = []

    def select_answer(_driver, key, yes_id, no_id, user_inputs, default=None):
        answer = user_inputs.get(key, default)
        selected.append(yes_id if answer == "Yes" else no_id)
        return answer

    monkeypatch.setattr(ownership, "click_yes_no", select_answer)
    monkeypatch.setattr(
        ownership,
        "click_ownership_hhpp_next",
        lambda _driver, step: clicked_steps.append(step),
    )

    answer = ownership.complete_notice_to_one_owner_step(
        object(),
        {ownership.NOTICE_ONE_OWNER_KEY: "No"},
    )

    assert answer == "No"
    assert selected == [ownership.NOTICE_ONE_OWNER_NO_ID]
    assert clicked_steps == ["30%"]


def test_missing_reasonable_steps_stops_before_portal_interaction(monkeypatch):
    opened = []
    monkeypatch.setattr(ownership, "open_certificate_of_ownership", lambda _driver: opened.append(True))

    with pytest.raises(RuntimeError, match="reasonable steps taken are required"):
        ownership.complete_certificate_of_ownership(
            object(),
            {
                "Householder Sole Owner": "No",
                ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY: "No",
                ownership.NOTICE_ONE_OWNER_KEY: "No",
                "Householder Agricultural Holding": "No",
            },
        )

    assert opened == []


def test_reasonable_steps_fill_uses_exact_70_percent_textarea(monkeypatch):
    class Field:
        def get_attribute(self, name):
            assert name == "value"
            return "Contacted the available records office."

    calls = []
    monkeypatch.setattr(
        ownership,
        "type_into",
        lambda driver, by, locator, value: calls.append((driver, by, locator, value)) or Field(),
    )

    ownership.fill_reasonable_steps(object(), "Contacted the available records office.")

    assert calls[0][1:] == (
        ownership.By.ID,
        ownership.REASONABLE_STEPS_ID,
        "Contacted the available records office.",
    )


def test_sole_owner_skips_other_owner_questions_and_advances_certificate_a(monkeypatch):
    clicked_steps = []

    monkeypatch.setattr(ownership, "open_certificate_of_ownership", lambda _driver: None)
    monkeypatch.setattr(ownership, "click_yes_no", lambda *_args, **kwargs: kwargs.get("default"))
    monkeypatch.setattr(
        ownership,
        "complete_identify_all_other_owners_step",
        lambda *_args, **_kwargs: pytest.fail("sole owner must not enter the other-owner branch"),
    )
    monkeypatch.setattr(
        ownership,
        "complete_notice_to_one_owner_step",
        lambda *_args, **_kwargs: pytest.fail("sole owner must not enter the notice branch"),
    )
    monkeypatch.setattr(ownership, "select_option_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(ownership, "wait_for_checked_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        ownership,
        "click_ownership_hhpp_next",
        lambda _driver, step: clicked_steps.append(step),
    )

    ownership.complete_certificate_of_ownership(
        object(),
        {
            "Householder Sole Owner": "Yes",
            "Householder Agricultural Holding": "No",
        },
    )

    assert clicked_steps == ["initial", "ownership", "35%", "40%", "85%", "100%"]


@pytest.mark.parametrize(
    "answers",
    [
        {
            "Householder Sole Owner": "No",
            ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY: "Yes",
        },
        {
            "Householder Sole Owner": "No",
            ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY: "No",
            ownership.NOTICE_ONE_OWNER_KEY: "Yes",
        },
    ],
)
def test_non_owner_only_requires_answers_for_the_selected_branch(answers):
    sole_owner, identify_all, notice_one, reasonable_steps = (
        ownership.validate_certificate_of_ownership_inputs(answers)
    )

    assert sole_owner == "No"
    assert identify_all == answers[ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY]
    assert notice_one == answers.get(ownership.NOTICE_ONE_OWNER_KEY)
    assert reasonable_steps is None


@pytest.mark.parametrize(
    ("identify_answer", "notice_answer", "branch_steps"),
    [
        ("Yes", "No", ["35%", "40%"]),
        ("No", "Yes", ["30%", "35%", "40%"]),
        ("No", "No", ["30%", "35%", "40%", "65%", "70%", "75%"]),
    ],
)
def test_certificate_navigation_uses_only_the_current_ownership_branch(
    monkeypatch,
    identify_answer,
    notice_answer,
    branch_steps,
):
    clicked_steps = []

    def select_answer(_driver, _key, yes_id, _no_id, _user_inputs, default=None):
        if yes_id == ownership.IDENTIFY_ALL_OTHER_OWNERS_YES_ID:
            return identify_answer
        if yes_id == ownership.NOTICE_ONE_OWNER_YES_ID:
            return notice_answer
        return default

    monkeypatch.setattr(ownership, "open_certificate_of_ownership", lambda _driver: None)
    monkeypatch.setattr(ownership, "click_yes_no", select_answer)
    monkeypatch.setattr(ownership, "select_option_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(ownership, "wait_for_checked_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(ownership, "fill_reasonable_steps", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        ownership,
        "click_ownership_hhpp_next",
        lambda _driver, step: clicked_steps.append(step),
    )

    ownership.complete_certificate_of_ownership(
        object(),
        {
            "Householder Sole Owner": "No",
            ownership.IDENTIFY_ALL_OTHER_OWNERS_KEY: identify_answer,
            ownership.NOTICE_ONE_OWNER_KEY: notice_answer,
            "Householder Agricultural Holding": "No",
            "Householder Ownership Reasonable Steps": "Checked the available ownership records.",
        },
    )

    assert clicked_steps == [
        "initial",
        "ownership",
        "25%",
        *branch_steps,
        "85%",
        "100%",
    ]


def test_non_owner_requires_explicit_identify_all_answer_before_portal_interaction(monkeypatch):
    opened = []
    monkeypatch.setattr(ownership, "open_certificate_of_ownership", lambda _driver: opened.append(True))

    with pytest.raises(RuntimeError, match="must be confirmed"):
        ownership.complete_certificate_of_ownership(
            object(),
            {
                "Householder Sole Owner": "No",
                "Householder Agricultural Holding": "No",
            },
        )

    assert opened == []

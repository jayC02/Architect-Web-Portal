import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QWidget

from gui.startup_splash import (
    STARTUP_STAGES,
    StartupTimingEstimate,
    close_startup_splash,
    packaged_asset_path,
    show_window_after_splash,
)


class MemorySettings:
    def __init__(self, values=None):
        self.values = dict(values or {})

    def value(self, key, default=None):
        return self.values.get(key, default)

    def setValue(self, key, value):
        self.values[key] = value


class LifecycleObject:
    def __init__(self, name, events):
        self.name = name
        self.events = events

    def hide(self):
        self.events.append(f"{self.name}:hide")

    def show(self):
        self.events.append(f"{self.name}:show")

    def close(self):
        self.events.append(f"{self.name}:close")

    def deleteLater(self):
        self.events.append(f"{self.name}:delete")


class FakeApplication:
    def __init__(self, events):
        self.events = events

    def processEvents(self):
        self.events.append("app:process")


def test_splash_hides_before_main_window_and_is_always_closed():
    events = []
    splash = LifecycleObject("splash", events)
    window = LifecycleObject("window", events)
    app = FakeApplication(events)

    show_window_after_splash(window, splash, app)

    assert events == [
        "splash:hide",
        "window:show",
        "splash:close",
        "splash:delete",
        "app:process",
    ]

    events.clear()
    close_startup_splash(splash, app)
    assert events == ["splash:hide", "splash:close", "splash:delete", "app:process"]


def test_real_splash_does_not_remain_visible_after_main_window_opens():
    from gui.startup_splash import StartupSplash

    app = QApplication.instance() or QApplication([])
    splash = StartupSplash(settings=MemorySettings())
    window = QWidget()
    splash.show()
    app.processEvents()
    assert splash.isVisible()

    show_window_after_splash(window, splash, app)

    assert window.isVisible()
    assert not splash.isVisible()
    window.close()


def test_splash_uses_current_brand_and_real_startup_stages():
    from gui.startup_splash import StartupSplash

    app = QApplication.instance() or QApplication([])
    settings = MemorySettings()
    ticks = iter([10.0, 16.0])
    splash = StartupSplash(settings=settings, clock=lambda: next(ticks))

    assert splash.size().width() == 468
    assert splash.size().height() == 254
    assert packaged_asset_path("architect-pro-mark.png").endswith(
        os.path.join("assets", "architect-pro-mark.png")
    )
    assert os.path.exists(packaged_asset_path("architect-pro-mark.png"))
    assert "91architects" not in open("Gui.spec", encoding="utf-8").read().lower()
    assert splash.estimate_label.text() == "Measuring startup time"

    for stage, (progress, message) in STARTUP_STAGES.items():
        splash.set_stage(stage)
        assert splash.progress.value() == progress
        assert splash.status_label.text() == message

    splash.record_startup_complete()
    estimate = StartupTimingEstimate(settings).text()
    assert estimate == "Usually ready in 4-8 seconds"
    splash.close()

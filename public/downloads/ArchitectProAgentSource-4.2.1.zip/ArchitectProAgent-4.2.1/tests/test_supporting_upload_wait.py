from selenium.common.exceptions import (
    StaleElementReferenceException,
    WebDriverException,
)

import automation.common.uploads as uploads
from automation.common.uploads import wait_for_supporting_doc_upload_result
from automation.householder import documents as householder_documents


class ReadyButton:
    def is_displayed(self):
        return True

    def is_enabled(self):
        return True


class ReplacingDriver:
    def __init__(self, first_error=None):
        self.first_error = first_error
        self.polls = 0
        self.ready_button = ReadyButton()

    def find_elements(self, by, locator):
        if by == uploads.By.CSS_SELECTOR:
            return []
        if by != uploads.By.ID or locator != "MainContent_btnAddDocumentation":
            return []
        self.polls += 1
        if self.polls == 1 and self.first_error is not None:
            error = self.first_error

            class DetachedButton:
                def is_displayed(self):
                    raise error

            return [DetachedButton()]
        return [self.ready_button]


def test_supporting_upload_result_succeeds_normally():
    driver = ReplacingDriver()

    assert wait_for_supporting_doc_upload_result(
        driver, "drawing.pdf", timeout=1
    ) is driver.ready_button


def test_supporting_upload_result_reacquires_after_stale_postback():
    driver = ReplacingDriver(
        StaleElementReferenceException("replaced by ASP.NET postback")
    )

    assert wait_for_supporting_doc_upload_result(
        driver, "drawing.pdf", timeout=1
    ) is driver.ready_button
    assert driver.polls == 2


def test_supporting_upload_result_reacquires_after_chromedriver_detached_node():
    driver = ReplacingDriver(
        WebDriverException("Node with given id does not belong to the document")
    )

    assert wait_for_supporting_doc_upload_result(
        driver, "drawing.pdf", timeout=1
    ) is driver.ready_button
    assert driver.polls == 2


def test_supporting_upload_result_propagates_unrelated_webdriver_error():
    driver = ReplacingDriver(WebDriverException("Chrome renderer disconnected"))

    try:
        wait_for_supporting_doc_upload_result(driver, "drawing.pdf", timeout=1)
    except WebDriverException as exc:
        assert "renderer disconnected" in str(exc)
    else:
        raise AssertionError("An unrelated WebDriverException must propagate")


def test_dom_replacement_does_not_upload_the_same_document_twice(monkeypatch, tmp_path):
    pdf_path = tmp_path / "drawing.pdf"
    pdf_path.write_bytes(b"%PDF-1.4\n%%EOF")
    sent_paths = []
    save_clicks = []
    driver = ReplacingDriver(
        WebDriverException("Node with given id does not belong to the document")
    )
    driver.execute_script = lambda *_args: None

    class FileInput:
        def send_keys(self, value):
            sent_paths.append(value)

    class ImmediateWait:
        def __init__(self, _driver, _timeout):
            pass

        def until(self, _condition):
            return FileInput()

    monkeypatch.setattr(householder_documents, "WebDriverWait", ImmediateWait)
    monkeypatch.setattr(householder_documents, "type_into", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "select_by_text", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "select_option_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "click_label_for_any", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "get_paper_size_from_pdf", lambda _path: "A4")
    monkeypatch.setattr(householder_documents, "get_document_type_from_pdf", lambda _path: "PDF")
    monkeypatch.setattr(
        householder_documents,
        "click_by_id",
        lambda _driver, element_id, *_args, **_kwargs: save_clicks.append(element_id),
    )

    householder_documents.upload_supporting_document_entries(
        driver,
        [("drawing.pdf", "plans")],
        str(tmp_path),
        {"plans": "Plans"},
    )

    assert sent_paths == [str(pdf_path)]
    assert save_clicks.count("MainContent_btnSaveDocEdit") == 1

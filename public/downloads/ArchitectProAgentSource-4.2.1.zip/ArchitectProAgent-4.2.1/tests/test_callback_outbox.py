import json
import os
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from unittest.mock import patch


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from gui.services import callback_outbox, portal_handoff


class FakeClient:
    def __init__(self, fail=False):
        self.fail = fail
        self.calls = []

    def send_callback(self, job_id, payload):
        self.calls.append((job_id, payload))
        if self.fail:
            raise portal_handoff.PortalHandoffError("offline")
        return {"ok": True}


class CallbackOutboxTests(unittest.TestCase):
    def test_failed_callback_is_retained_without_secrets(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {"APPDATA": temp}):
            event = callback_outbox.build_event(
                job_id="job_123456",
                status="FAILED_RETRYABLE",
                event_type="result",
                error="Safe summary",
            )

            delivered = callback_outbox.deliver_event(event, client=FakeClient(fail=True))

            self.assertFalse(delivered)
            pending = callback_outbox.pending_events()
            self.assertEqual(len(pending), 1)
            self.assertEqual(pending[0]["payload"]["callbackId"], event["id"])
            stored = json.dumps(pending[0])
            self.assertNotIn("apd_", stored)
            self.assertNotIn("token", stored.lower())

    def test_successful_retry_removes_the_event(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {"APPDATA": temp}):
            event = callback_outbox.build_event(
                job_id="job_123456",
                status="AWAITING_PORTAL_REVIEW",
                event_type="result",
            )
            event["nextAttemptAt"] = (
                datetime.now(timezone.utc) - timedelta(seconds=1)
            ).isoformat()
            callback_outbox.save_event(event)
            client = FakeClient()
            with patch.object(portal_handoff, "get_job_access_token", return_value="apd_" + ("a" * 40)):
                with patch.object(portal_handoff, "PortalClient", return_value=client):
                    result = callback_outbox.retry_pending()

            self.assertEqual(result, {"delivered": 1, "retained": 0})
            self.assertEqual(len(client.calls), 1)
            self.assertEqual(callback_outbox.pending_events(), [])

    def test_backoff_is_capped_and_idempotency_key_is_reused(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {"APPDATA": temp}):
            now = datetime(2026, 7, 26, tzinfo=timezone.utc)
            event = callback_outbox.build_event(
                job_id="job_123456",
                status="IN_PROGRESS",
                event_type="checkpoint",
            )
            original_key = event["payload"]["callbackId"]
            original_occurred_at = event["payload"]["occurredAt"]
            client = FakeClient(fail=True)

            for _ in range(len(callback_outbox.BACKOFF_SECONDS) + 2):
                callback_outbox.deliver_event(event, client=client, now=now)
                event = callback_outbox.pending_events()[0]

            self.assertEqual(event["payload"]["callbackId"], original_key)
            self.assertEqual(event["payload"]["occurredAt"], original_occurred_at)
            expected = now + timedelta(seconds=callback_outbox.BACKOFF_SECONDS[-1])
            actual = datetime.fromisoformat(event["nextAttemptAt"])
            self.assertEqual(actual, expected)

    def test_pending_callback_survives_restart_and_reuses_one_semantic_identity(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(os.environ, {"APPDATA": temp}):
            occurred_at = datetime(2026, 8, 17, 9, 0, tzinfo=timezone.utc).isoformat()
            event = callback_outbox.build_event(
                job_id="job_123456",
                status="AWAITING_PORTAL_REVIEW",
                event_type="result",
                occurred_at=occurred_at,
                result={"outcome": "awaiting_user_portal_review"},
            )
            callback_outbox.deliver_event(event, client=FakeClient(fail=True))

            reloaded = callback_outbox.pending_events()[0]
            reloaded["nextAttemptAt"] = (
                datetime.now(timezone.utc) - timedelta(seconds=1)
            ).isoformat()
            callback_outbox.save_event(reloaded)
            client = FakeClient()
            with patch.object(portal_handoff, "get_job_access_token", return_value="apd_" + ("a" * 40)):
                with patch.object(portal_handoff, "PortalClient", return_value=client):
                    callback_outbox.retry_pending()

            self.assertEqual(len(client.calls), 1)
            delivered_payload = client.calls[0][1]
            self.assertEqual(delivered_payload["callbackId"], event["id"])
            self.assertEqual(delivered_payload["occurredAt"], occurred_at)
            self.assertEqual(callback_outbox.pending_events(), [])


if __name__ == "__main__":
    unittest.main()

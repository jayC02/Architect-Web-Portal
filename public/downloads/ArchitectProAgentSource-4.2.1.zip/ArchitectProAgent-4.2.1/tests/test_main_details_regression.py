from types import SimpleNamespace

from selenium.common.exceptions import StaleElementReferenceException

from automation.common import forms
from automation.householder import applicant, main_details


class _Element:
    def __init__(self, driver, kind, generation=None):
        self.driver = driver
        self.kind = kind
        self.generation = driver.generation if generation is None else generation

    def is_enabled(self):
        if self.generation != self.driver.generation:
            raise StaleElementReferenceException("postback replaced the title control")
        return True

    def is_displayed(self):
        return self.is_enabled()


class _Driver:
    def __init__(self):
        self.generation = 0
        self.title = "Please Select One"

    def find_element(self, _by, locator):
        kind = "title" if locator.endswith("ddlApplicantTitle") else "field"
        return _Element(self, kind)

    def execute_script(self, script, *_args):
        return "complete" if "document.readyState" in script else None


class _Select:
    def __init__(self, element):
        self.element = element

    @property
    def first_selected_option(self):
        return SimpleNamespace(text=self.element.driver.title)

    def select_by_visible_text(self, title):
        self.element.driver.title = title
        self.element.driver.generation += 1


class _Wait:
    def __init__(self, driver, _timeout, **_kwargs):
        self.driver = driver

    def until(self, condition):
        value = condition(self.driver)
        if not value:
            raise AssertionError("the simulated portal condition was not satisfied")
        return value


def test_planning_main_details_reacquires_applicant_form_after_title_postback(monkeypatch):
    """The background Planning path must continue beyond applicant details."""
    driver = _Driver()
    next_controls = []
    filled_applicant_fields = []

    monkeypatch.setattr(forms, "Select", _Select)
    monkeypatch.setattr(forms, "WebDriverWait", _Wait)
    monkeypatch.setattr(forms, "get_when_clickable", lambda current, *_args, **_kwargs: _Element(current, "title"))
    monkeypatch.setattr(forms, "wait_dom_ready", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(applicant, "WebDriverWait", _Wait)
    monkeypatch.setattr(applicant, "click_first_available", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(
        applicant,
        "force_text_by_id",
        lambda _driver, element_id, *_args, **_kwargs: filled_applicant_fields.append(element_id),
    )
    monkeypatch.setattr(main_details, "fill_agent_details", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(main_details, "type_into", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(main_details, "select_option_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(main_details, "click_yes_no", lambda *_args, **_kwargs: "No")
    monkeypatch.setattr(
        main_details,
        "click_householder_step_next",
        lambda _driver, **kwargs: next_controls.append(kwargs.get("expected_id")),
    )
    monkeypatch.setattr(main_details, "click_householder_finish_next", lambda *_args, **_kwargs: None)

    main_details.complete_householder_main_details(driver, {
        "Description of Work": "Alter dwelling",
        "Applicant Title": "Ms",
        "Applicant First Name": "Applicant",
        "Applicant Last Name": "Example",
        "Applicant Email": "applicant@example.test",
        "Applicant Address 1": "High Street",
        "Applicant Building Number": "10",
        "Applicant Town/City": "Edinburgh",
        "Applicant Country": "United Kingdom",
        "Applicant Postcode": "EH1 1AA",
    })

    assert driver.title == "Ms"
    assert any(field.endswith("txtApplicantFirstName") for field in filled_applicant_fields)
    assert "MainContent_HouseholderApplicationMainDetailsWizard_rblDiscussedWithPA_0" in next_controls

from types import SimpleNamespace

from PySide6.QtWidgets import QApplication, QLabel, QScrollArea

from automation.common.proposal_creation import AddressPostcodeCorrectionRequired
from automation.runner import AutomationResult, run_automation
from gui import agent_app


def runtime_job(application_type="HOUSEHOLDER_PLANNING"):
    return {
        "job_id": "job_address_123456",
        "application_type": application_type,
        "site_label": "Flat 1, 22 Example Road",
        "user_inputs": {
            "Email": "test@example.com",
            "PDF Folder Path": "C:/test",
            "Site Postcode": "G41 5BZ",
        },
        "document_mapping": {"pdf_folder_path": "C:/test", "buckets": {}, "bucket_labels": {}},
    }


def test_change_postcode_returns_safe_correction_without_mutating_frozen_inputs():
    source = runtime_job()
    original_inputs = dict(source["user_inputs"])

    def workflow(**_kwargs):
        raise AddressPostcodeCorrectionRequired("g41 5aa")

    result = run_automation(
        source,
        password="secret",
        driver_factory=lambda _mode: SimpleNamespace(
            start=lambda: object(),
            close=lambda **_kwargs: None,
        ),
        workflow_registry={"HOUSEHOLDER_PLANNING": workflow},
    )

    assert result.outcome == "failure"
    assert result.retry_safe is True
    assert result.failure_category == "ADDRESS_RESOLUTION_FAILED"
    assert result.address_correction_postcode == "G41 5AA"
    assert source["user_inputs"] == original_inputs


def test_worker_records_old_result_before_requesting_canonical_fresh_retry(monkeypatch, tmp_path):
    monkeypatch.setenv("APPDATA", str(tmp_path))
    actions = []
    result = AutomationResult(
        "failure",
        "job_address_123456",
        "HOUSEHOLDER_PLANNING",
        "Address correction required",
        "address_selection",
        retry_safe=True,
        failure_category="ADDRESS_RESOLUTION_FAILED",
        address_correction_postcode="G41 5AA",
    )

    class Client:
        def send_callback(self, job_id, payload):
            actions.append(("callback", payload["status"]))
            return {"ok": True, "status": payload["status"]}

        def correct_address_and_restart(self, job_id, postcode):
            actions.append(("restart", job_id, postcode))
            return {"job": {"id": "job_fresh_123456"}}

    monkeypatch.setattr("automation.runner.run_automation", lambda *_args, **_kwargs: result)
    thread = agent_app.AutomationThread(
        SimpleNamespace(job_id="job_address_123456"),
        "secret",
        "AUTO",
        Client(),
    )
    completed = []
    thread.completed.connect(completed.append)

    thread.run()

    assert actions == [
        ("callback", "IN_PROGRESS"),
        ("callback", "FAILED_RETRYABLE"),
        ("restart", "job_address_123456", "G41 5AA"),
    ]
    assert completed[0].fresh_retry_job_id == "job_fresh_123456"


def test_native_chooser_scrolls_all_candidates_and_zero_state_offers_postcode_change():
    QApplication.instance() or QApplication([])
    candidates = [
        {"candidate_id": f"portal-address-{index}", "display_text": f"{index} Example Road, Glasgow, G41 5BZ"}
        for index in range(1, 41)
    ]
    chooser = agent_app.AddressResolutionDialog({
        "project_address": "Flat 1, 22 Example Road, Glasgow, G41 5BZ",
        "searched_postcode": "G41 5BZ",
        "candidates": candidates,
    })
    empty = agent_app.AddressResolutionDialog({
        "project_address": "Flat 1, 22 Example Road, Glasgow, G41 5BZ",
        "searched_postcode": "G41 5BZ",
        "candidates": [],
    })
    try:
        assert len(chooser.candidate_group.buttons()) == 40
        assert chooser.findChild(QScrollArea) is not None
        assert chooser.continue_button.isEnabled() is False
        assert any(label.text() == "No addresses found" for label in empty.findChildren(QLabel))
        empty.alternate_postcode.setText("G41 5AA")
        empty.use_alternate_postcode()
        assert empty.response == {"action": "change_postcode", "postcode": "G41 5AA"}
    finally:
        chooser.close()
        empty.close()

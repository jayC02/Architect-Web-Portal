from types import SimpleNamespace
from gui.services.desktop_callback_contract import map_runner_result_callback


def result(**changes):
    fields = dict(outcome='success', job_id='job_phase_zero', last_stage='final_review', message='Prepared', timings={}, browser_session_id='selenium-original')
    return SimpleNamespace(**{**fields, **changes})


def test_old_server_receives_exact_legacy_contract():
    callback = map_runner_result_callback(result())
    assert 'browserSessionId' not in callback['result']
    assert callback['status'] == 'COMPLETED'
    assert callback['result']['outcome'] == 'completed_to_final_review'


def test_new_server_receives_retained_browser_identity_only_when_negotiated():
    callback = map_runner_result_callback(result(), include_browser_metadata=True)
    assert callback['result']['browserSessionId'] == 'selenium-original'
    assert 'agentRunId' not in callback  # server derives ownership from authenticated claim
    assert 'SUBMITTED' not in str(callback)


def test_missing_browser_metadata_keeps_legacy_result_valid():
    callback = map_runner_result_callback(result(browser_session_id=None), include_browser_metadata=True)
    assert 'browserSessionId' not in callback['result']


def test_manual_input_is_not_mislabeled_as_prepared():
    callback = map_runner_result_callback(result(outcome='user_action_required', last_stage='address_selection'), include_browser_metadata=True)
    assert callback['result']['outcome'] == 'paused_for_manual_input'
    assert callback['result']['browserSessionId'] == 'selenium-original'

import json

from gui.services import ai_intake, portal_answers, secure_credentials


def test_normalise_result_keeps_allowed_fields_and_rejects_invalid_yes_no():
    result = ai_intake.normalise_result(
        {
            "values": [
                {
                    "key": "Description of Work",
                    "value": "Single storey extension",
                    "confidence": "HIGH",
                    "source": "pdf_text",
                    "reason": "Found in planning statement",
                },
                {
                    "key": "Includes Demolition",
                    "value": "Maybe",
                    "confidence": "high",
                    "source": "notes",
                    "reason": "Ambiguous",
                },
                {
                    "key": "Not A Real Field",
                    "value": "Ignored",
                    "confidence": "high",
                    "source": "notes",
                    "reason": "Invalid key",
                },
            ],
            "missing_required_fields": ["Applicant Email"],
            "warnings": [],
            "summary": "Test",
        },
        ai_intake.allowed_field_keys(portal_answers.BUILDING_WARRANT_TYPE),
    )

    assert result["values"] == [
        {
            "key": "Description of Work",
            "value": "Single storey extension",
            "confidence": "high",
            "source": "pdf_text",
            "reason": "Found in planning statement",
        }
    ]
    assert "Rejected invalid yes/no value for Includes Demolition." in result["warnings"]
    assert result["missing_required_fields"] == ["Applicant Email"]


def test_estimate_payload_caps_large_pdf_sets():
    estimate = ai_intake.estimate_payload("short notes", [f"file-{i}.pdf" for i in range(35)])

    assert estimate["pdf_count"] == 35
    assert estimate["size"] in {"Medium", "Large"}


def test_legacy_ai_settings_migration_keeps_provider_but_scrubs_keys(monkeypatch, tmp_path):
    appdata = tmp_path / "appdata"
    source = tmp_path / "source"
    source.mkdir()
    monkeypatch.setenv("APPDATA", str(appdata))
    saved_keys = {}
    monkeypatch.setattr(
        secure_credentials,
        "save_ai_api_key",
        lambda provider, value: (saved_keys.__setitem__(provider, value) is None, ""),
    )
    monkeypatch.setattr(
        secure_credentials,
        "get_ai_api_key",
        lambda provider: (saved_keys.get(provider), True, ""),
    )
    (source / ai_intake.AI_SETTINGS_FILENAME).write_text(
        json.dumps(
            {
                "provider": ai_intake.PROVIDER_GEMINI,
                "gemini_api_key": "secret-gemini",
                "gemini_model": "gemini-test",
                "openai_api_key": "secret-openai",
            }
        ),
        encoding="utf-8",
    )

    settings = ai_intake.load_settings(str(source))

    assert settings["provider"] == ai_intake.PROVIDER_GEMINI
    assert settings["gemini_model"] == "gemini-test"
    assert settings["api_key"] == "secret-gemini"
    assert settings["gemini_api_key"] == "secret-gemini"
    assert settings["openai_api_key"] == "secret-openai"
    stored = json.loads((source / ai_intake.AI_SETTINGS_FILENAME).read_text(encoding="utf-8"))
    assert stored["gemini_api_key"] == ""
    assert stored["openai_api_key"] == ""


def test_save_settings_writes_only_non_secret_values(monkeypatch, tmp_path):
    monkeypatch.setenv("APPDATA", str(tmp_path / "appdata"))
    saved_keys = {}
    monkeypatch.setattr(
        secure_credentials,
        "save_ai_api_key",
        lambda provider, value: (saved_keys.__setitem__(provider, value) is None, ""),
    )
    monkeypatch.setattr(
        secure_credentials,
        "get_ai_api_key",
        lambda provider: (saved_keys.get(provider), True, ""),
    )

    ai_intake.save_settings(str(tmp_path), ai_intake.PROVIDER_GEMINI, "secret", "gemini-test")

    stored = json.loads(open(ai_intake.settings_path(str(tmp_path)), encoding="utf-8").read())
    assert stored == {
        "provider": ai_intake.PROVIDER_GEMINI,
        "openai_model": ai_intake.DEFAULT_MODEL,
        "gemini_model": "gemini-test",
    }
    assert saved_keys[ai_intake.PROVIDER_GEMINI] == "secret"


def test_save_settings_refuses_plaintext_fallback(monkeypatch, tmp_path):
    monkeypatch.setenv("APPDATA", str(tmp_path / "appdata"))
    monkeypatch.setattr(secure_credentials, "get_ai_api_key", lambda provider: (None, False, "unavailable"))
    monkeypatch.setattr(secure_credentials, "save_ai_api_key", lambda provider, value: (False, "unavailable"))

    try:
        ai_intake.save_settings(str(tmp_path), ai_intake.PROVIDER_GEMINI, "secret")
    except RuntimeError as exc:
        assert "unavailable" in str(exc)
    else:
        raise AssertionError("save_settings should refuse insecure fallback")

    assert not (tmp_path / "appdata" / "NinetyOneArchitects" / "Building Portal" / "ai_settings.json").exists()

from types import SimpleNamespace

from gui.services import secure_credentials


class FakeKeyring:
    def __init__(self):
        self.values = {}
        self.errors = SimpleNamespace(PasswordDeleteError=KeyError)

    def get_password(self, service, username):
        return self.values.get((service, username))

    def set_password(self, service, username, password):
        self.values[(service, username)] = password

    def delete_password(self, service, username):
        if (service, username) not in self.values:
            raise KeyError(username)
        del self.values[(service, username)]


def test_credential_name_is_stable_and_normalised():
    assert secure_credentials.credential_name("  User@Example.COM ") == "portal-login:user@example.com"


def test_save_load_and_delete_login_password(monkeypatch):
    fake = FakeKeyring()
    monkeypatch.setattr(secure_credentials, "_load_keyring", lambda: (fake, None))

    ok, message = secure_credentials.save_login_password("user@example.com", "secret")
    assert ok is True
    assert message == ""

    password, available, message = secure_credentials.get_login_password("USER@example.com")
    assert available is True
    assert message == ""
    assert password == "secret"

    ok, message = secure_credentials.delete_login_password("user@example.com")
    assert ok is True
    assert message == ""

    password, available, message = secure_credentials.get_login_password("user@example.com")
    assert available is True
    assert password is None


def test_keyring_unavailable_does_not_raise(monkeypatch):
    monkeypatch.setattr(secure_credentials, "_load_keyring", lambda: (None, RuntimeError("no backend")))

    assert secure_credentials.availability() == (False, secure_credentials.UNAVAILABLE_MESSAGE)
    assert secure_credentials.get_login_password("user@example.com") == (None, False, secure_credentials.UNAVAILABLE_MESSAGE)
    assert secure_credentials.save_login_password("user@example.com", "secret") == (False, secure_credentials.UNAVAILABLE_MESSAGE)
    assert secure_credentials.delete_login_password("user@example.com") == (False, secure_credentials.UNAVAILABLE_MESSAGE)


def test_empty_password_is_rejected_without_calling_keyring(monkeypatch):
    fake = FakeKeyring()
    monkeypatch.setattr(secure_credentials, "_load_keyring", lambda: (fake, None))

    ok, message = secure_credentials.save_login_password("user@example.com", "")

    assert ok is False
    assert "Enter a password" in message
    assert fake.values == {}


def test_save_load_and_delete_ai_api_key(monkeypatch):
    fake = FakeKeyring()
    monkeypatch.setattr(secure_credentials, "_load_keyring", lambda: (fake, None))

    ok, message = secure_credentials.save_ai_api_key("Gemini", "gemini-secret")
    assert ok is True
    assert message == ""
    assert secure_credentials.get_ai_api_key("GEMINI") == ("gemini-secret", True, "")

    ok, message = secure_credentials.delete_ai_api_key("gemini")
    assert ok is True
    assert message == ""
    assert secure_credentials.get_ai_api_key("Gemini") == (None, True, "")

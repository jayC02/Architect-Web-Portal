import inspect
from pathlib import Path

import pytest

from automation.common import driver as driver_module
from automation.common.browser_mode import BrowserMode
from automation.common.driver import (
    BrowserComponentError,
    ChromeDriverResolver,
    DriverCacheLockedError,
    DriverResolution,
    DriverResolutionError,
    ManagedChrome,
    create_chrome_driver,
)
from automation.runner import run_automation


def _touch(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(b"driver")
    return path


def _resolver(tmp_path, *, packaged=(), versions=None, acquirer=None):
    versions = versions or {}
    return ChromeDriverResolver(
        browser_version_provider=lambda: "150.0.7871.182",
        version_reader=lambda path: versions.get(str(path)) or versions.get(Path(path).name),
        packaged_candidates=packaged,
        owned_cache_root=tmp_path / "owned",
        shared_cache_root=tmp_path / "shared",
        acquirer=acquirer,
    )


def test_valid_existing_driver_is_reused_without_acquisition(tmp_path):
    cached = _touch(tmp_path / "shared/150.0.7871.124/chromedriver.exe")
    calls = []
    resolver = _resolver(
        tmp_path,
        versions={str(cached): "150.0.7871.124"},
        acquirer=lambda *_args: calls.append("acquire"),
    )

    result = resolver.resolve()

    assert result.path == str(cached)
    assert result.source == "shared-cache"
    assert calls == []


def test_compatible_packaged_driver_is_preferred(tmp_path):
    packaged = _touch(tmp_path / "package/chromedriver.exe")
    cached = _touch(tmp_path / "shared/150/chromedriver.exe")
    resolver = _resolver(
        tmp_path,
        packaged=[packaged],
        versions={str(packaged): "150.0.7871.124", str(cached): "150.0.7871.100"},
        acquirer=lambda *_args: pytest.fail("acquisition was not required"),
    )

    result = resolver.resolve()

    assert result.path == str(packaged)
    assert result.source == "packaged"


def test_fallback_acquisition_happens_only_when_no_compatible_driver_exists(tmp_path):
    incompatible = _touch(tmp_path / "shared/149/chromedriver.exe")
    calls = []

    def acquire(version, staging):
        calls.append(version)
        return _touch(staging / "download/chromedriver.exe")

    resolver = _resolver(
        tmp_path,
        versions={str(incompatible): "149.0.0.0", "chromedriver.exe": "150.0.7871.124"},
        acquirer=acquire,
    )

    result = resolver.resolve()

    assert result.acquired is True
    assert result.source == "acquired"
    assert Path(result.path).is_file()
    assert calls == ["150.0.7871.182"]


def test_acquired_version_specific_driver_is_reused_on_the_next_start(tmp_path):
    calls = []

    def acquire(_version, staging):
        calls.append("acquire")
        return _touch(staging / "download/chromedriver.exe")

    versions = {"chromedriver.exe": "150.0.7871.124"}
    first = _resolver(tmp_path, versions=versions, acquirer=acquire).resolve()
    second = _resolver(
        tmp_path,
        versions=versions,
        acquirer=lambda *_args: pytest.fail("second startup must reuse the owned cache"),
    ).resolve()

    assert first.acquired is True
    assert second.source == "architect-pro-cache"
    assert second.path == first.path
    assert calls == ["acquire"]


def test_locked_acquisition_is_not_retried(tmp_path):
    calls = []

    def locked(*_args):
        calls.append("attempt")
        error = PermissionError("[WinError 5] Access is denied: chromedriver.exe")
        error.winerror = 5
        raise error

    resolver = _resolver(tmp_path, acquirer=locked)
    with pytest.raises(DriverCacheLockedError, match="locked"):
        resolver.resolve()
    with pytest.raises(DriverResolutionError, match="already attempted"):
        resolver.resolve()
    assert calls == ["attempt"]


def test_version_mismatch_uses_one_controlled_fallback(monkeypatch):
    class Resolver:
        def __init__(self):
            self.calls = []

        def resolve(self, *, force_acquire=False):
            self.calls.append(force_acquire)
            return DriverResolution(
                "new.exe" if force_acquire else "old.exe",
                "acquired" if force_acquire else "packaged",
                "150.0.0.0",
                "150.0.0.0" if force_acquire else "149.0.0.0",
                force_acquire,
            )

    resolver = Resolver()
    created = []

    def chrome(*, service, options):
        del options
        created.append(service.path)
        if service.path == "old.exe":
            raise RuntimeError("session not created: This version of ChromeDriver only supports Chrome version 149")
        return "driver"

    monkeypatch.setattr(driver_module.webdriver, "Chrome", chrome)
    assert create_chrome_driver(object(), resolver=resolver) == "driver"
    assert resolver.calls == [False, True]
    assert created == ["old.exe", "new.exe"]


def test_non_mismatch_startup_failure_does_not_trigger_acquisition(monkeypatch):
    class Resolver:
        calls = []

        def resolve(self, *, force_acquire=False):
            self.calls.append(force_acquire)
            return DriverResolution("locked.exe", "shared-cache", "150", "150")

    resolver = Resolver()
    raw = PermissionError("[WinError 5] Access is denied: locked.exe")
    monkeypatch.setattr(driver_module.webdriver, "Chrome", lambda **_kwargs: (_ for _ in ()).throw(raw))

    with pytest.raises(BrowserComponentError) as captured:
        create_chrome_driver(object(), resolver=resolver)

    assert resolver.calls == [False]
    assert captured.value.__cause__ is raw
    assert str(captured.value) == "Architect Pro couldn't start its browser automation component."


def test_owned_cleanup_quits_only_the_current_driver_and_never_uses_global_process_kills():
    class OwnedDriver:
        session_id = "owned"

        def __init__(self):
            self.quit_calls = 0

        def quit(self):
            self.quit_calls += 1

    owned = OwnedDriver()
    managed = ManagedChrome(BrowserMode.HEADLESS)
    managed.driver = owned
    managed.close()

    source = inspect.getsource(driver_module).lower()
    assert owned.quit_calls == 1
    assert "taskkill" not in source
    assert "chromedriver.exe /f" not in source


def test_runner_keeps_raw_winerror_in_technical_details_but_returns_clean_message():
    class FailedManagedDriver:
        def start(self):
            raw = PermissionError("[WinError 5] Access is denied: chromedriver.exe")
            raise BrowserComponentError() from raw

        def close(self, **_kwargs):
            pass

    job = {
        "job_id": "job_driver_failure",
        "application_type": "BUILDING_WARRANT",
        "site_label": "Test",
        "user_inputs": {"Email": "test@example.com", "PDF Folder Path": "C:/test"},
        "document_mapping": {"pdf_folder_path": "C:/test", "buckets": {}, "bucket_labels": {}},
    }
    result = run_automation(
        job,
        password="secret",
        driver_factory=lambda _mode: FailedManagedDriver(),
        workflow_registry={"BUILDING_WARRANT": lambda **_kwargs: None},
    )

    assert result.message == "Architect Pro couldn't start its browser automation component."
    assert result.error_code == "BROWSER_COMPONENT_STARTUP_FAILED"
    assert "WinError 5" in result.technical_details
    assert "WinError 5" not in result.message

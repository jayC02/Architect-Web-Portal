import http.client
import threading
import urllib.parse
from unittest.mock import patch

import pytest

from gui.services import agent_enrollment, background_agent, portal_handoff


INSTALLATION_ID = "9c65df19-5a77-4e2c-a82f-30362b36773e"
GRANT = "ape_" + ("g" * 48)


def send_callback(port, path):
    connection = http.client.HTTPConnection("127.0.0.1", port, timeout=2)
    connection.request("GET", path)
    response = connection.getresponse()
    response.read()
    connection.close()
    return response.status, response.getheader("Location")


def test_pkce_state_and_connection_url_are_random_and_strict():
    verifier_one, challenge_one = agent_enrollment.generate_pkce()
    verifier_two, challenge_two = agent_enrollment.generate_pkce()
    state_one = agent_enrollment.generate_state()
    state_two = agent_enrollment.generate_state()

    assert verifier_one != verifier_two
    assert challenge_one != challenge_two
    assert state_one != state_two
    assert 43 <= len(verifier_one) <= 128
    assert len(challenge_one) == 43
    assert len(state_one) >= 32
    url = agent_enrollment.build_connection_url(
        "https://architectpro.co.uk", INSTALLATION_ID, challenge_one, state_one, 49152
    )
    parsed = urllib.parse.urlparse(url)
    assert parsed.scheme == "https"
    assert parsed.netloc == "www.architectpro.co.uk"
    assert parsed.path == "/desktop-agent/connect"
    assert urllib.parse.parse_qs(parsed.query) == {
        "installationId": [INSTALLATION_ID],
        "codeChallenge": [challenge_one],
        "state": [state_one],
        "port": ["49152"],
    }


@pytest.mark.parametrize("port", [0, -1, 65536, True, "not-a-port"])
def test_invalid_callback_ports_are_rejected(port):
    with pytest.raises(agent_enrollment.AgentEnrollmentError):
        agent_enrollment.validate_port(port)


def test_loopback_server_binds_random_127_address_and_accepts_exact_callback():
    state = agent_enrollment.generate_state()
    callback = agent_enrollment._CallbackState(state, "https://www.architectpro.co.uk")
    server = agent_enrollment._LoopbackServer(callback)
    try:
        assert server.server_address[0] == "127.0.0.1"
        assert 1 <= server.server_address[1] <= 65535
        worker = threading.Thread(target=server.handle_request)
        worker.start()
        status, location = send_callback(
            server.server_address[1],
            f"/callback?grant={GRANT}&state={urllib.parse.quote(state)}",
        )
        worker.join(timeout=2)
        assert status == 302
        assert location == "https://www.architectpro.co.uk/settings/integrations?agent=connecting"
        assert callback.grant == GRANT
    finally:
        server.server_close()


def test_wrong_path_and_state_never_yield_a_grant():
    expected = agent_enrollment.generate_state()
    callback = agent_enrollment._CallbackState(expected, "https://www.architectpro.co.uk")
    server = agent_enrollment._LoopbackServer(callback)
    try:
        worker = threading.Thread(target=server.handle_request)
        worker.start()
        status, _ = send_callback(server.server_address[1], f"/callback?grant={GRANT}&state=wrong")
        worker.join(timeout=2)
        assert status == 400
        assert callback.grant is None
        assert callback.error
    finally:
        server.server_close()


def test_complete_browser_enrollment_exchanges_only_after_verified_callback():
    captured = {}

    def open_browser(url):
        parsed = urllib.parse.urlparse(url)
        values = urllib.parse.parse_qs(parsed.query)
        captured.update(values)

        def callback():
            send_callback(
                int(values["port"][0]),
                f"/callback?grant={GRANT}&state={urllib.parse.quote(values['state'][0])}",
            )

        threading.Thread(target=callback).start()
        return True

    sentinel = object()
    with patch.object(background_agent, "installation_id", return_value=INSTALLATION_ID), patch.object(
        background_agent.AgentApi, "enroll_pkce", return_value=sentinel
    ) as exchange:
        result = agent_enrollment.enroll_via_browser(
            "https://architectpro.co.uk", timeout_seconds=2, browser_open=open_browser
        )

    assert result is sentinel
    assert captured["installationId"] == [INSTALLATION_ID]
    assert captured["port"][0].isdigit()
    exchange.assert_called_once()
    portal_url, grant, verifier, installation_id = exchange.call_args.args
    assert portal_url == "https://www.architectpro.co.uk"
    assert grant == GRANT
    assert installation_id == INSTALLATION_ID
    assert len(verifier) >= 43


def test_pkce_exchange_uses_stable_installation_and_saves_only_returned_credential():
    request_payload = {}

    def request(_client, path, method="GET", payload=None):
        request_payload.update({"path": path, "method": method, "payload": payload})
        return {"credential": "apa_returned-credential-value"}

    with patch.object(background_agent, "installation_id", return_value=INSTALLATION_ID), patch.object(
        portal_handoff.PortalClient, "_request", request
    ), patch.object(background_agent.secure_credentials, "save_agent_credential", return_value=(True, "")) as save, patch.object(
        portal_handoff, "save_portal_url"
    ):
        api = background_agent.AgentApi.enroll_pkce(
            "https://architectpro.co.uk", GRANT, "v" * 64, INSTALLATION_ID
        )

    assert isinstance(api, background_agent.AgentApi)
    assert request_payload["path"] == "/api/desktop/enrollment/exchange"
    assert request_payload["method"] == "POST"
    assert request_payload["payload"]["installationId"] == INSTALLATION_ID
    assert request_payload["payload"]["grant"] == GRANT
    assert request_payload["payload"]["codeVerifier"] == "v" * 64
    save.assert_called_once_with("apa_returned-credential-value")


def test_pkce_exchange_rejects_a_different_installation_before_network_access():
    with patch.object(background_agent, "installation_id", return_value=INSTALLATION_ID), patch.object(
        portal_handoff.PortalClient, "_request"
    ) as request:
        with pytest.raises(portal_handoff.PortalHandoffError):
            background_agent.AgentApi.enroll_pkce(
                "https://architectpro.co.uk", GRANT, "v" * 64, "3d2e6a6d-1b71-4e91-96ea-cdf9069d65af"
            )
    request.assert_not_called()

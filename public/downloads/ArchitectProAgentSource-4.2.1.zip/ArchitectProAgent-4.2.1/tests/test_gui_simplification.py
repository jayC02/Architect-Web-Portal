import os
import sys
import tempfile
import unittest
from unittest.mock import patch


os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from PySide6.QtWidgets import QApplication, QLabel, QPushButton

import Building_Warrant
import Householder
from gui.app import BuildingWarrantApp, automation_entrypoint_for_application_type
from gui.services import portal_answers


class GuiSimplificationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt_app = QApplication.instance() or QApplication([])

    def test_ai_intake_and_sidebar_shortcuts_are_not_in_the_workflow(self):
        with tempfile.TemporaryDirectory() as temp, patch.dict(
            os.environ,
            {"APPDATA": temp},
        ):
            window = BuildingWarrantApp(portal_answers.BUILDING_WARRANT_TYPE)
            try:
                self.assertNotIn("AI Intake", window.WORKFLOW_STEPS)
                self.assertNotIn("AI Intake", [
                    window.tabs.tabText(index)
                    for index in range(window.tabs.count())
                ])
                sidebar_text = {
                    label.text()
                    for label in window.sidebar.findChildren(QLabel)
                }
                self.assertNotIn("Shortcuts", sidebar_text)
                all_page_text = {
                    label.text()
                    for label in window.findChildren(QLabel)
                }
                self.assertNotIn("AI Intake", all_page_text)

                window.navigate_to_step(window.start_tab_index)
                self.qt_app.processEvents()
                self.assertFalse(window.start_button.isEnabled())
                data_entry_action = next(
                    action
                    for action in window.findChildren(QPushButton)
                    if action.objectName() == "PreflightActionButton"
                    and action.text() == "Open Data Entry"
                )
                data_entry_action.click()
                self.qt_app.processEvents()
                self.assertEqual(
                    window.tabs.currentIndex(),
                    window.step_index("Data Entry"),
                )
            finally:
                window.close()
                window.deleteLater()

    def test_validated_application_type_selects_only_the_matching_automation(self):
        householder, householder_name = automation_entrypoint_for_application_type(
            portal_answers.HOUSEHOLDER_TYPE,
        )
        warrant, warrant_name = automation_entrypoint_for_application_type(
            portal_answers.BUILDING_WARRANT_TYPE,
        )

        self.assertIs(householder, Householder.main)
        self.assertEqual(householder_name, "Householder.main()")
        self.assertIs(warrant, Building_Warrant.main)
        self.assertEqual(warrant_name, "Building_Warrant.main()")

        with self.assertRaisesRegex(RuntimeError, "missing or unsupported"):
            automation_entrypoint_for_application_type("")

if __name__ == "__main__":
    unittest.main()

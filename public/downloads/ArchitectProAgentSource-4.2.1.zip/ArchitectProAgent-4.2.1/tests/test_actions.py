import pytest
from selenium.common.exceptions import StaleElementReferenceException, WebDriverException
from selenium.webdriver.common.by import By

from automation.common.actions import click_when_clickable, get_when_clickable


def test_click_when_clickable_requeries_element_stale_during_wait():
    class StaleElement:
        def is_displayed(self):
            raise StaleElementReferenceException("login button replaced")

    class LiveElement:
        def __init__(self):
            self.clicked = False

        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

        def click(self):
            self.clicked = True

    live_element = LiveElement()

    class Driver:
        def __init__(self):
            self.elements = iter((StaleElement(), live_element))
            self.lookups = 0

        def find_element(self, _by, _locator):
            self.lookups += 1
            return next(self.elements)

    driver = Driver()

    result = click_when_clickable(driver, By.ID, "login", timeout=1)

    assert result is live_element
    assert live_element.clicked is True
    assert driver.lookups == 2


def test_get_when_clickable_requeries_title_select_stale_during_visibility_check():
    class StaleSelect:
        def is_displayed(self):
            raise StaleElementReferenceException("title select replaced by postback")

    class LiveSelect:
        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

    live_select = LiveSelect()

    class Driver:
        def __init__(self):
            self.elements = iter((StaleSelect(), live_select))
            self.lookups = 0

        def find_element(self, _by, _locator):
            self.lookups += 1
            return next(self.elements)

    driver = Driver()

    assert get_when_clickable(driver, By.ID, "applicant-title", timeout=1) is live_select
    assert driver.lookups == 2


def test_type_into_does_not_touch_field_after_native_typing(monkeypatch):
    class Element:
        def __init__(self):
            self.value = ""

        def send_keys(self, value):
            self.value = value

    element = Element()

    class Driver:
        def __init__(self):
            self.scripts = []

        def execute_script(self, script, *_args):
            self.scripts.append(script)

    class Wait:
        def __init__(self, _driver, _timeout, **_kwargs):
            pass

        def until(self, _condition):
            return element

    monkeypatch.setattr("automation.common.actions.WebDriverWait", Wait)
    driver = Driver()

    result = __import__("automation.common.actions", fromlist=["type_into"]).type_into(
        driver, By.ID, "password", "secret", clear_first=False
    )

    assert result is element
    assert element.value == "secret"
    assert len(driver.scripts) == 1
    assert "scrollIntoView" in driver.scripts[0]


def test_click_when_clickable_requeries_chrome_detached_node():
    class DetachedElement:
        def is_displayed(self):
            raise WebDriverException("Node with given id does not belong to the document")

    class LiveElement:
        def __init__(self):
            self.clicked = False

        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

        def click(self):
            self.clicked = True

    live = LiveElement()

    class Driver:
        def __init__(self):
            self.elements = iter((DetachedElement(), live))

        def find_element(self, _by, _locator):
            return next(self.elements)

    assert click_when_clickable(Driver(), By.ID, "postback-control", timeout=1) is live
    assert live.clicked is True


def test_click_when_clickable_does_not_swallow_unrelated_webdriver_error():
    class BrokenElement:
        def is_displayed(self):
            raise WebDriverException("disconnected: renderer process crashed")

    class Driver:
        def find_element(self, _by, _locator):
            return BrokenElement()

    with pytest.raises(WebDriverException, match="renderer process crashed"):
        click_when_clickable(Driver(), By.ID, "portal-control", timeout=1)

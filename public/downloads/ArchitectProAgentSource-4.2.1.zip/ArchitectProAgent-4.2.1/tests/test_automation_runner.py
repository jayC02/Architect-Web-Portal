from copy import deepcopy

from automation.common.driver import BrowserMode
from automation.common.handoff import FEE_HANDOFF
from automation.common.proposal_creation import (
    ManualAddressResolutionRequired,
    ProposalCreationError,
    ProposalCreationUncertain,
)
from automation.runner import CancellationToken, ProgressStatus, describe_failure, domain_error, run_automation


def job(application_type="BUILDING_WARRANT"):
    return {
        "job_id": "job_test_123456",
        "application_type": application_type,
        "site_label": "5 Tulloch Street",
        "user_inputs": {"Email": "test@example.com", "PDF Folder Path": "C:/test"},
        "document_mapping": {"pdf_folder_path": "C:/test", "buckets": {}, "bucket_labels": {}},
    }


class FakeManagedDriver:
    def __init__(self):
        self.driver = object()
        self.started = 0
        self.closed = []
        self.handoffs = 0

    def start(self):
        self.started += 1
        return self.driver

    def close(self, *, preserve_visible=False):
        self.closed.append(preserve_visible)

    def handoff_to_user(self):
        self.handoffs += 1


def test_runner_dispatches_both_workflows_without_gui_and_emits_ordered_progress():
    for application_type in ("BUILDING_WARRANT", "HOUSEHOLDER_PLANNING"):
        managed = FakeManagedDriver()
        calls = []
        events = []

        def workflow(**kwargs):
            calls.append(kwargs)
            kwargs["progress"]("login", "running", "Logging in")
            kwargs["progress"]("login", "completed", "Logged in")

        result = run_automation(
            job(application_type),
            browser_mode=BrowserMode.AUTO,
            password="secret",
            progress_callback=events.append,
            driver_factory=lambda _mode: managed,
            workflow_registry={application_type: workflow},
        )

        assert result.outcome == "success"
        assert result.last_stage == "final_review"
        assert result.message == "Application prepared"
        assert len(calls) == 1
        assert calls[0]["driver"] is managed.driver
        assert [(event.stage, event.status) for event in events] == [
            ("validation", ProgressStatus.RUNNING),
            ("validation", ProgressStatus.COMPLETED),
            ("browser", ProgressStatus.RUNNING),
            ("browser", ProgressStatus.COMPLETED),
            ("workflow", ProgressStatus.RUNNING),
            ("login", ProgressStatus.RUNNING),
            ("login", ProgressStatus.COMPLETED),
            ("workflow", ProgressStatus.COMPLETED),
        ]
        assert managed.handoffs == 1
        assert managed.closed == [True]
        assert "stage_login" in result.timings


def test_runner_cancellation_is_cooperative_and_does_not_start_browser():
    token = CancellationToken()
    token.cancel()
    managed = FakeManagedDriver()
    result = run_automation(
        job(), password="secret", cancellation_token=token,
        driver_factory=lambda _mode: managed,
    )
    assert result.outcome == "cancelled"
    assert managed.started == 0


def test_runner_returns_domain_failure_and_preserves_snapshot_immutability():
    source = job()
    original = deepcopy(source)
    managed = FakeManagedDriver()

    def workflow(**kwargs):
        kwargs["user_inputs"]["Email"] = "changed@example.com"
        raise RuntimeError("Supporting Documents page did not confirm the upload.")

    result = run_automation(
        source, password="secret", driver_factory=lambda _mode: managed,
        workflow_registry={"BUILDING_WARRANT": workflow},
    )
    assert result.outcome == "failure"
    assert "did not confirm" in result.message
    assert source == original


def test_runner_source_has_no_gui_imports():
    import inspect
    import automation.runner as runner
    import automation.common.runtime as runtime

    assert "from gui" not in inspect.getsource(runner)
    assert "from gui" not in inspect.getsource(runtime)


def test_headless_uses_modern_chrome_mode():
    from automation.common.driver import chrome_options_for_mode

    auto_arguments = chrome_options_for_mode(BrowserMode.AUTO).arguments
    assert "--headless=new" not in auto_arguments
    assert "--start-minimized" in auto_arguments

    headless_arguments = chrome_options_for_mode(BrowserMode.HEADLESS).arguments
    assert "--headless=new" in headless_arguments
    assert "--headless" not in headless_arguments

    visible_arguments = chrome_options_for_mode(BrowserMode.VISIBLE).arguments
    assert "--headless=new" not in visible_arguments


def test_browser_disconnect_and_authentication_failures_are_sanitised():
    from automation.runner import domain_error

    browser_message, browser_code = domain_error(RuntimeError("invalid session id: disconnected from DevTools"))
    auth_message, auth_code = domain_error(RuntimeError("Login did not reach the authenticated home page"))
    assert browser_code == "BROWSER_CONNECTION_INTERRUPTED"
    assert "DevTools" not in browser_message
    assert auth_code == "AUTHENTICATION_FAILED"
    assert "Update the saved login" in auth_message


def test_verified_fee_handoff_reveals_and_preserves_managed_browser():
    for application_type in ("HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"):
        managed = FakeManagedDriver()
        events = []

        def workflow(**_kwargs):
            return FEE_HANDOFF

        result = run_automation(
            job(application_type),
            browser_mode=BrowserMode.AUTO,
            password="secret",
            progress_callback=events.append,
            driver_factory=lambda _mode: managed,
            workflow_registry={application_type: workflow},
        )
        assert result.outcome == "user_action_required"
        assert result.last_stage == "fee"
        assert result.message == "Complete the fee in the browser."
        assert managed.handoffs == 1
        assert managed.closed == [True]
        assert events[-1].stage == "fee"
        assert events[-1].status is ProgressStatus.USER_ACTION_REQUIRED


def test_closing_revealed_browser_after_preparation_does_not_change_success_result():
    managed = FakeManagedDriver()

    result = run_automation(
        job("HOUSEHOLDER_PLANNING"),
        browser_mode=BrowserMode.AUTO,
        password="secret",
        driver_factory=lambda _mode: managed,
        workflow_registry={"HOUSEHOLDER_PLANNING": lambda **_kwargs: None},
    )

    assert result.outcome == "success"
    assert managed.handoffs == 1
    managed.close(preserve_visible=False)  # The architect closes Chrome later.
    assert result.outcome == "success"
    assert result.message == "Application prepared"


def test_failure_before_fee_never_reveals_browser():
    managed = FakeManagedDriver()

    def workflow(**_kwargs):
        raise RuntimeError("Portal stopped before Declaration")

    result = run_automation(
        job(), password="secret", driver_factory=lambda _mode: managed,
        workflow_registry={"BUILDING_WARRANT": workflow},
    )
    assert result.outcome == "failure"
    assert managed.handoffs == 0
    assert managed.closed == [False]


def test_real_headless_workflow_is_rejected_before_browser_start():
    managed = FakeManagedDriver()
    result = run_automation(
        job(), browser_mode=BrowserMode.HEADLESS, password="secret",
        driver_factory=lambda _mode: managed,
    )
    assert result.outcome == "failure"
    assert "cannot reveal" in result.message
    assert managed.started == 0


def test_address_selection_pauses_and_resumes_inside_same_owned_session():
    managed = FakeManagedDriver()
    events = []
    callback_requests = []
    seen_drivers = []

    def workflow(**kwargs):
        seen_drivers.append(kwargs["driver"])
        response = kwargs["address_resolution_callback"]({
            "stage": "address_selection",
            "project_address": "73 Blackhill Drive, Glasgow, G12 8AB",
            "candidates": [{
                "candidate_id": "portal-address-1",
                "display_text": "73 Blackhill Drive, Glasgow, G12 8AA",
            }],
        })
        assert response == {"action": "select", "candidate_id": "portal-address-1"}
        seen_drivers.append(kwargs["driver"])

    result = run_automation(
        job(), password="secret", driver_factory=lambda _mode: managed,
        workflow_registry={"BUILDING_WARRANT": workflow},
        progress_callback=events.append,
        address_resolution_callback=lambda request: callback_requests.append(request) or {
            "action": "select", "candidate_id": "portal-address-1",
        },
    )

    assert result.outcome == "success"
    assert managed.started == 1
    assert seen_drivers == [managed.driver, managed.driver]
    assert managed.handoffs == 1
    assert managed.closed == [True]
    address_events = [event for event in events if event.stage == "address_selection"]
    assert [event.status for event in address_events] == [
        ProgressStatus.USER_ACTION_REQUIRED,
        ProgressStatus.RUNNING,
    ]


def test_manual_address_fallback_reveals_and_preserves_same_owned_browser():
    managed = FakeManagedDriver()

    def workflow(**kwargs):
        response = kwargs["address_resolution_callback"]({
            "stage": "address_selection",
            "project_address": "73 Blackhill Drive, Glasgow, G12 8AB",
            "candidates": [],
        })
        assert response["action"] == "manual"
        raise ManualAddressResolutionRequired()

    result = run_automation(
        job(), password="secret", driver_factory=lambda _mode: managed,
        workflow_registry={"BUILDING_WARRANT": workflow},
        address_resolution_callback=lambda _request: {"action": "manual"},
    )

    assert result.outcome == "user_action_required"
    assert result.last_stage == "address_selection"
    assert managed.started == 1
    assert managed.handoffs == 1
    assert managed.closed == [True]


def test_address_modal_cancellation_is_clean_and_never_reports_success():
    managed = FakeManagedDriver()

    def workflow(**kwargs):
        kwargs["address_resolution_callback"]({
            "stage": "address_selection", "candidates": []
        })
        raise AssertionError("workflow must not continue after cancellation")

    result = run_automation(
        job(), password="secret", driver_factory=lambda _mode: managed,
        workflow_registry={"BUILDING_WARRANT": workflow},
        address_resolution_callback=lambda _request: {"action": "cancel"},
    )

    assert result.outcome == "cancelled"
    assert managed.handoffs == 0


def test_controlled_failure_categories_are_human_readable():
    cases = [
        (RuntimeError("login failed for saved credentials"), "AUTHENTICATION_FAILED"),
        (ProposalCreationError("Address results", "portal address missing"), "ADDRESS_RESOLUTION_FAILED"),
        (RuntimeError("portal timed out"), "PORTAL_TIMEOUT"),
        (RuntimeError("supporting document upload rejected"), "DOCUMENT_UPLOAD_FAILED"),
        (RuntimeError("portal structure may have changed"), "UNEXPECTED_PORTAL_PAGE"),
        (RuntimeError("net::ERR_CONNECTION_RESET"), "NETWORK_INTERRUPTED"),
        (RuntimeError("unclassified failure"), "AUTOMATION_FAILED"),
    ]
    for error, expected_code in cases:
        message, code = domain_error(error)
        details = describe_failure(error, "proposal")
        assert code == expected_code
        assert details.category == expected_code
        assert message
        assert details.headline
        assert details.next_action


def test_retry_is_only_offered_before_a_confirmed_business_action():
    startup = describe_failure(ValueError("Portal login email is not configured"), "validation")
    uncertain = describe_failure(
        ProposalCreationUncertain("Create Proposal", "result uncertain"),
        "proposal",
    )
    assert startup.retry_safe is True
    assert startup.recovery_action == "update_login"
    assert uncertain.retry_safe is False
    assert uncertain.recovery_action == "close"


def test_address_failure_stage_and_recovery_action_are_coherent_and_safe():
    failure = describe_failure(
        ProposalCreationError("Address results", "No address safely matched the saved site."),
        "login",
    )
    assert failure.category == "ADDRESS_RESOLUTION_FAILED"
    assert failure.stage == "address_selection"
    assert failure.stage_description == "Selecting the property address"
    assert failure.recovery_action == "review_address"
    assert failure.retry_safe is True
    assert failure.recovery_fields == ("buildingNumber", "addressLine1", "townCity", "postcode")


def test_login_failure_maps_to_secure_login_recovery_and_safe_retry():
    failure = describe_failure(ValueError("Portal login password is not configured on this machine."), "validation")
    assert failure.category == "AUTHENTICATION_FAILED"
    assert failure.stage == "login"
    assert failure.recovery_action == "update_login"
    assert failure.retry_safe is True

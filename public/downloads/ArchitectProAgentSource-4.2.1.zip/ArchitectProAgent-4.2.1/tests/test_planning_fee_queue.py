import ast
from pathlib import Path
from types import SimpleNamespace
import pytest
from selenium.common.exceptions import TimeoutException
from automation.building_warrant import fee
from gui.services.portal_handoff import portal_job_to_values, CALCULATED_FEE_MINOR_UNITS_KEY
from tests.test_building_warrant_fee_entry import snapshot_job, FeeDriver

@pytest.mark.parametrize('amount', [0, 32550, 123456])
def test_planning_fee_snapshot_mapping(amount):
    job = snapshot_job(0)
    job['type'] = 'HOUSEHOLDER_PLANNING'
    job['dataSnapshot']['metadata']['applicationType'] = 'HOUSEHOLDER_PLANNING'
    job['dataSnapshot']['buildingWarrant'] = None
    job['dataSnapshot']['planning'] = {'recordId': 'planning-test', 'feeMinorUnits': amount, 'answers': {}}
    assert portal_job_to_values(job)[CALCULATED_FEE_MINOR_UNITS_KEY] == amount

@pytest.mark.parametrize('amount', [None, True, -1, '325.50'])
def test_invalid_planning_fee_never_defaults_to_zero(amount):
    job = snapshot_job(0)
    job['type'] = 'HOUSEHOLDER_PLANNING'
    job['dataSnapshot']['metadata']['applicationType'] = 'HOUSEHOLDER_PLANNING'
    job['dataSnapshot']['buildingWarrant'] = None
    job['dataSnapshot']['planning'] = {'recordId': 'planning-test', 'feeMinorUnits': amount, 'answers': {}}
    assert CALCULATED_FEE_MINOR_UNITS_KEY not in portal_job_to_values(job)

def test_unconfirmed_fee_cannot_complete(monkeypatch):
    monkeypatch.setattr(fee, 'type_into', lambda *args, **kwargs: None)
    with pytest.raises(fee.BuildingWarrantFeeError, match='did not confirm'):
        fee.enter_calculated_fee(FeeDriver(), 32550, timeout=0.01)

def test_fee_review_releases_queue_but_other_input_keeps_claim():
    source = (Path(__file__).parents[1] / 'gui/agent_app.py').read_text(encoding='utf-8')
    tree = ast.parse(source)
    method = next(n for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name == 'on_completed')
    branch = next(n for n in method.body if isinstance(n, ast.If) and any(isinstance(c, ast.Call) and isinstance(c.func, ast.Attribute) and c.func.attr == 'set_background_run_state' for c in ast.walk(n)))
    code = compile(ast.fix_missing_locations(ast.Module(body=[branch], type_ignores=[])), '<release>', 'exec')
    for stage, expected in [('fee', ('READY', False)), ('address_selection', ('USER_ACTION_REQUIRED', True))]:
        calls = []
        window = SimpleNamespace(set_background_run_state=lambda state, keep_job: calls.append((state, keep_job)))
        exec(code, {'self': window, 'result': SimpleNamespace(outcome='user_action_required', last_stage=stage)})
        assert calls == [expected]

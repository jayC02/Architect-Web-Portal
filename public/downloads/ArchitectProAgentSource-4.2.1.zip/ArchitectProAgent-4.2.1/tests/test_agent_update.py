import hashlib
import io
from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from gui.services import agent_update, background_agent, portal_handoff

BASE = 'https://www.architectpro.co.uk'
PAYLOAD = b'fixture installer bytes'

def release(**values):
    return dict(version='4.2.2', status='AVAILABLE', downloadUrl='/downloads/ArchitectProAgentSetup-4.2.2.exe',
                sha256=hashlib.sha256(PAYLOAD).hexdigest(), sizeBytes=len(PAYLOAD), **values)

class Response(io.BytesIO):
    def geturl(self): return BASE + '/downloads/ArchitectProAgentSetup-4.2.2.exe'

def prepare(monkeypatch, tmp_path, data):
    monkeypatch.setattr(agent_update, 'release_metadata', lambda _url: (BASE, data))
    monkeypatch.setattr(agent_update.storage_paths, 'runtime_path', lambda _name: str(tmp_path / 'updates'))
    monkeypatch.setattr(agent_update.urllib.request, 'urlopen', lambda *_args, **_kwargs: Response(PAYLOAD))

def test_download_verified_before_install(monkeypatch, tmp_path):
    prepare(monkeypatch, tmp_path, release())
    messages = []
    path = agent_update.download_update(progress=messages.append)
    from pathlib import Path
    assert Path(path).read_bytes() == PAYLOAD
    assert messages[-1].endswith('100%')
    assert not list(tmp_path.rglob('*.download'))

@pytest.mark.parametrize('changes', [{'sha256':'0'*64}, {'sizeBytes':len(PAYLOAD)+1}, {'sizeBytes':len(PAYLOAD)-1}])
def test_corrupted_or_incomplete_download_cannot_install(monkeypatch, tmp_path, changes):
    data = release(); data.update(changes)
    prepare(monkeypatch, tmp_path, data)
    with pytest.raises(portal_handoff.PortalHandoffError): agent_update.download_update()
    assert not list(tmp_path.rglob('*.exe'))
    assert not list(tmp_path.rglob('*.download'))

@pytest.mark.parametrize('changes', [
    {'downloadUrl':'https://untrusted.test/downloads/ArchitectProAgentSetup-4.2.2.exe'},
    {'downloadUrl':'/downloads/other.exe'}, {'version':'../evil'}, {'sha256':'invalid'},
    {'sizeBytes':True}, {'sizeBytes':200*1024*1024}, {'status':'BUILDING'}])
def test_untrusted_release_rejected(changes):
    data=release(); data.update(changes)
    with pytest.raises(portal_handoff.PortalHandoffError): agent_update.validate_release(BASE, data)

def test_up_to_date_does_not_download(monkeypatch):
    data=release(); data.update(version=background_agent.AGENT_VERSION,
        downloadUrl=f'/downloads/ArchitectProAgentSetup-{background_agent.AGENT_VERSION}.exe')
    monkeypatch.setattr(agent_update, 'release_metadata', lambda _url: (BASE, data))
    request=Mock(); monkeypatch.setattr(agent_update.urllib.request, 'urlopen', request)
    assert agent_update.download_update() is None
    request.assert_not_called()

def test_installer_invocation_preserves_existing_installation(monkeypatch):
    popen=Mock(); monkeypatch.setattr(agent_update.subprocess, 'Popen', popen)
    agent_update.launch_installer('C:/verified/setup.exe')
    args=popen.call_args.args[0]
    assert args[0]=='C:/verified/setup.exe'
    assert '/RESTARTAGENT=1' in args
    assert '/CLOSEAPPLICATIONS' in args
    assert not popen.call_args.kwargs.get('shell')
    assert not any('uninstall' in str(arg).lower() for arg in args)

def test_update_protocol_cannot_carry_secrets_or_arguments():
    assert portal_handoff.is_agent_update_launch('architectpro://update')
    for value in ['architectpro://update?url=evil', 'architectpro://update/other', 'architectpro://update#token', 'https://update']:
        assert not portal_handoff.is_agent_update_launch(value)

def test_active_execution_blocks_update(monkeypatch):
    from tests.test_agent_gui import make_window
    from gui import agent_app
    window=make_window()
    try:
        window.automation_thread=SimpleNamespace(isRunning=lambda:True)
        download=Mock(); monkeypatch.setattr(agent_app.agent_update, 'download_update', download)
        window.update_agent()
        assert not window._updating
        assert 'Finish or stop' in window.message.text()
        download.assert_not_called()
    finally:
        window.automation_thread=None; window.close()

import os
import sys
import unittest
import base64
import json
from datetime import datetime, timedelta, timezone
from unittest.mock import patch


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from gui.services import portal_answers, portal_handoff


class PortalHandoffTests(unittest.TestCase):
    def test_shared_v2_fixture_is_supported(self):
        path = os.path.join(ROOT, "tests", "fixtures", "automation-job-v2-building-warrant.json")
        with open(path, encoding="utf-8") as handle:
            snapshot = json.load(handle)
        job = {
            "id": snapshot["metadata"]["jobId"],
            "projectId": snapshot["metadata"]["projectId"],
            "type": snapshot["metadata"]["applicationType"],
            "dataSnapshot": snapshot,
        }
        portal_handoff.validate_portal_job(job)
        values = portal_handoff.portal_job_to_values(job)
        self.assertEqual(values["Description of Work"], "Snapshot Integration Description")
        self.assertEqual(values["Estimated Work Value"], 23456)
        self.assertEqual(values["Current Use"], "Existing residential dwelling")
        self.assertEqual(values["Proposed Use"], "Extended residential dwelling")
        self.assertEqual(values["Applicant Title"], "Ms")
        self.assertEqual(values["Applicant First Name"], "Integration")
        self.assertEqual(values["Applicant Last Name"], "Test")
        self.assertEqual(values["Applicant Company"], "Integration Client Ltd")
        self.assertEqual(values["Agent First Name"], "Avery")
        self.assertEqual(values["Scheme Type"], "SER")
        self.assertEqual(values["Registration Number (A) Part 1"], "SER1")
        self.assertEqual(values["Registration Number (A) Part 2"], "1234")
        self.assertEqual(values["Name of Certifier"], "Casey Certifier")
        self.assertEqual(values["Registration Number (B) Part 1"], "SER1")
        self.assertEqual(values["Registration Number (B) Part 2"], "5678")
        self.assertEqual(values["Name of Approved Body"], "Integration Engineers")

    def test_v2_project_type_overrides_stale_warrant_preset(self):
        path = os.path.join(ROOT, "tests", "fixtures", "automation-job-v2-building-warrant.json")
        with open(path, encoding="utf-8") as handle:
            snapshot = json.load(handle)
        snapshot["project"]["typeOfWorkKey"] = "new_build"
        snapshot["project"]["typeOfWorkLabel"] = "New build"
        snapshot["buildingWarrant"]["presetKey"] = "demolition"
        snapshot["buildingWarrant"]["presetLabel"] = "Demolition"
        values = portal_handoff.portal_job_to_values({
            "id": snapshot["metadata"]["jobId"],
            "projectId": snapshot["metadata"]["projectId"],
            "type": snapshot["metadata"]["applicationType"],
            "dataSnapshot": snapshot,
        })

        self.assertEqual(
            values[portal_answers.PROFILE_KEY],
            portal_answers.NEW_BUILD_PROFILE,
        )
        self.assertEqual(values["Proposed Work"], "Construct")

    def test_v2_multiple_work_types_map_to_combined_desktop_answers(self):
        path = os.path.join(ROOT, "tests", "fixtures", "automation-job-v2-building-warrant.json")
        with open(path, encoding="utf-8") as handle:
            snapshot = json.load(handle)
        snapshot["buildingWarrant"]["typeOfWorkKeys"] = ["new_build", "demolition"]
        snapshot["buildingWarrant"]["typeOfWorkLabels"] = ["New build", "Demolition"]

        values = portal_handoff.portal_job_to_values({
            "id": snapshot["metadata"]["jobId"],
            "projectId": snapshot["metadata"]["projectId"],
            "type": snapshot["metadata"]["applicationType"],
            "dataSnapshot": snapshot,
        })

        self.assertEqual(values[portal_answers.TYPE_OF_WORKS_KEY], "New build | Demolition")
        self.assertEqual(values["Proposed Work"], "Construct")
        merged = portal_answers.defaults_for_profiles(values[portal_answers.TYPE_OF_WORKS_KEY])
        self.assertEqual(merged["New Building Construction"], "Yes")
        self.assertEqual(merged["Includes New Building Or Extension"], "Yes")
        self.assertEqual(merged["Includes Demolition"], "Yes")

    def test_job_cache_cleanup_removes_only_old_terminal_jobs(self):
        import tempfile

        with tempfile.TemporaryDirectory() as temp:
            now = datetime(2026, 7, 26, tzinfo=timezone.utc)
            with patch.dict(os.environ, {"APPDATA": temp}):
                jobs_root = os.path.join(temp, "NinetyOneArchitects", "Building Portal", "jobs")

                def cache(job_id, status, age_days):
                    folder = os.path.join(jobs_root, job_id)
                    os.makedirs(folder, exist_ok=True)
                    with open(os.path.join(folder, "document.pdf"), "wb") as handle:
                        handle.write(b"%PDF-1.4")
                    with open(os.path.join(folder, "cache.json"), "w", encoding="utf-8") as handle:
                        json.dump(
                            {
                                "jobId": job_id,
                                "status": status,
                                "updatedAt": (now - timedelta(days=age_days)).isoformat(),
                            },
                            handle,
                        )

                cache("completed-job-123", "COMPLETED", 30)
                cache("final-failure-123", "FAILED_FINAL", 30)
                cache("active-job-12345", "IN_PROGRESS", 30)
                cache("retry-job-123456", "FAILED_RETRYABLE", 30)
                unrelated = os.path.join(temp, "NinetyOneArchitects", "Building Portal", "presets.json")
                with open(unrelated, "w", encoding="utf-8") as handle:
                    handle.write("{}")

                removed = portal_handoff.cleanup_old_job_caches(now=now, retention_days=14)

                self.assertEqual(removed, ["completed-job-123", "final-failure-123"])
                self.assertFalse(os.path.exists(os.path.join(jobs_root, "completed-job-123")))
                self.assertFalse(os.path.exists(os.path.join(jobs_root, "final-failure-123")))
                self.assertTrue(os.path.exists(os.path.join(jobs_root, "active-job-12345")))
                self.assertTrue(os.path.exists(os.path.join(jobs_root, "retry-job-123456")))
                self.assertTrue(os.path.exists(unrelated))

    def test_protocol_parser_accepts_only_expected_shape(self):
        code = "aph_" + ("a" * 43)
        portal = base64.urlsafe_b64encode(b"https://architectpro.co.uk").decode("ascii").rstrip("=")
        value = f"architectpro://automation/job_123456/{code}/{portal}"
        self.assertEqual(portal_handoff.parse_automation_url(value), "job_123456")
        launch = portal_handoff.parse_automation_launch(value)
        self.assertEqual(launch["code"], code)
        self.assertEqual(launch["portal_url"], "https://www.architectpro.co.uk")
        with self.assertRaises(portal_handoff.PortalHandoffError):
            portal_handoff.parse_automation_url("https://example.com/automation/job_123456")
        with self.assertRaises(portal_handoff.PortalHandoffError):
            portal_handoff.parse_automation_url(f"architectpro://automation/../secret/{code}/{portal}")
        with self.assertRaises(portal_handoff.PortalHandoffError):
            portal_handoff.parse_automation_url("architectpro://automation/job_123456")

    def test_query_format_remains_supported_for_existing_links(self):
        code = "aph_" + ("b" * 43)
        value = f"architectpro://automation/job_123456?code={code}&portal=https%3A%2F%2Farchitectpro.co.uk"
        launch = portal_handoff.parse_automation_launch(value)
        self.assertEqual(launch["job_id"], "job_123456")
        self.assertEqual(launch["portal_url"], "https://www.architectpro.co.uk")

    def test_secure_login_settings_protocol_is_narrow_and_has_no_payload(self):
        self.assertTrue(portal_handoff.is_login_settings_launch("architectpro://settings/login"))
        self.assertFalse(portal_handoff.is_login_settings_launch("architectpro://settings/login?password=secret"))
        self.assertFalse(portal_handoff.is_login_settings_launch("architectpro://settings/other"))

    def test_agent_convenience_protocols_are_narrow_and_have_no_payload(self):
        self.assertTrue(portal_handoff.is_agent_open_launch("architectpro://agent"))
        self.assertTrue(portal_handoff.is_agent_reconnect_launch("architectpro://reconnect"))
        self.assertFalse(portal_handoff.is_agent_open_launch("architectpro://agent?grant=secret"))
        self.assertFalse(portal_handoff.is_agent_reconnect_launch("architectpro://reconnect/extra"))

    def test_portal_host_is_canonicalised_before_api_requests(self):
        self.assertEqual(
            portal_handoff._normalise_portal_url("https://architectpro.co.uk"),
            "https://www.architectpro.co.uk",
        )

    def test_portal_payload_maps_into_existing_widget_keys(self):
        job = {
            "id": "job_legacy_warrant",
            "projectId": "project_legacy_warrant",
            "type": "BUILDING_WARRANT",
            "dataSnapshot": {
                "buildingWarrantApplication": {"id": "warrant_legacy"},
                "project": {"name": "4 Willow Court", "projectType": "New build", "notes": "Build a new dwelling"},
                "client": {"name": "Alex Example", "email": "alex@example.com", "phone": "07000000000", "address": "4 Willow Court"},
                "site": {"addressLine1": "4 Willow Court", "townCity": "Glasgow", "postcode": "G1 1AA"},
                "applicationQuestions": {"Application Staged": "Yes"},
            },
        }
        values = portal_handoff.portal_job_to_values(job)
        self.assertEqual(values["Applicant First Name"], "Alex")
        self.assertEqual(values["Applicant Last Name"], "Example")
        self.assertEqual(values["Description of Work"], "Build a new dwelling")
        self.assertEqual(values[portal_answers.PROFILE_KEY], portal_answers.NEW_BUILD_PROFILE)
        self.assertEqual(values["Application Staged"], "Yes")
        self.assertNotIn("Name of Certifier", values)

    def test_v2_portal_payload_maps_authoritative_structured_values(self):
        job = {
            "id": "job_123456",
            "projectId": "project_123456",
            "type": "BUILDING_WARRANT",
            "dataSnapshot": {
                "contractVersion": "architectpro.automation-job",
                "snapshotVersion": 2,
                "metadata": {
                    "jobId": "job_123456",
                    "projectId": "project_123456",
                    "applicationType": "BUILDING_WARRANT",
                },
                "organisation": {
                    "agent": {
                        "firstName": "Jay",
                        "lastName": "Architect",
                        "email": "agent@example.com",
                        "phone": "07000000001",
                        "address": {
                            "addressLine1": "1 Practice Street",
                            "townCity": "Glasgow",
                            "postcode": "G1 1AA",
                            "country": "United Kingdom",
                        },
                    },
                },
                "project": {
                    "name": "4 Willow Court",
                    "typeOfWorkKey": "new_build",
                    "typeOfWorkLabel": "New build",
                },
                "site": {
                    "address": {
                        "addressLine1": "4 Willow Court",
                        "addressLine2": "4",
                        "townCity": "Glasgow",
                        "postcode": "G2 2BB",
                        "country": "United Kingdom",
                    },
                },
                "applicant": {
                    "displayName": "Ms Alex Example",
                    "title": "Ms",
                    "firstName": "Alex",
                    "lastName": "Example",
                    "email": "alex@example.com",
                    "phone": "07000000002",
                    "companyName": "Example Client Ltd",
                    "address": {
                        "addressLine1": "4 Willow Court",
                        "townCity": "Glasgow",
                        "postcode": "G2 2BB",
                        "country": "United Kingdom",
                    },
                },
                "buildingWarrant": {
                    "recordId": "warrant_123456",
                    "presetLabel": "New build",
                    "description": "Construct a new dwelling",
                    "estimatedValue": 250000,
                    "currentUse": "Vacant land",
                    "proposedUse": "Residential dwelling",
                    "unusualAnswers": {
                        "applicantIsOwner": True,
                        "applicationIsStaged": False,
                        "intendedLifeFiveYearsOrLess": False,
                        "fireAndRescueServiceEnforcingAuthority": True,
                        "listedBuildingOrConservationArea": False,
                        "otherHistoricalImportance": False,
                        "scottishMinistersRelaxationDirection": False,
                        "dangerousBuildingNotice": False,
                        "approvedCertifierOfConstruction": False,
                        "coveredBySTAS": False,
                        "restrictPublicInspection": False,
                    },
                    "certifier": {
                        "schemeType": "SER",
                        "registrationAPart1": "SER1",
                        "registrationAPart2": "1234",
                        "registrationBPart1": "SER1",
                        "registrationBPart2": "5678",
                        "certifierName": "Chris Certifier",
                        "approvedBody": "Example Engineers",
                    },
                },
                "planning": None,
                "documents": [],
                "preflight": {"status": "READY", "missing": [], "warnings": []},
            },
        }

        values = portal_handoff.portal_job_to_values(job)

        self.assertEqual(values["Agent First Name"], "Jay")
        self.assertEqual(values["Site Address"], "4 Willow Court, Glasgow, G2 2BB")
        self.assertEqual(values["Applicant Title"], "Ms")
        self.assertEqual(values["Applicant First Name"], "Alex")
        self.assertEqual(values["Description of Work"], "Construct a new dwelling")
        self.assertEqual(values["Estimated Work Value"], 250000)
        self.assertEqual(values[portal_answers.PROFILE_KEY], portal_answers.NEW_BUILD_PROFILE)
        self.assertEqual(values["Application Staged"], "No")
        self.assertEqual(values["Name of Certifier"], "Chris Certifier")

    def test_v2_householder_payload_maps_legal_answers_without_guessing_names(self):
        job = {
            "id": "job_123456",
            "projectId": "project_123456",
            "type": "HOUSEHOLDER_PLANNING",
            "dataSnapshot": {
                "contractVersion": "architectpro.automation-job",
                "snapshotVersion": 2,
                "metadata": {
                    "jobId": "job_123456",
                    "projectId": "project_123456",
                    "applicationType": "HOUSEHOLDER_PLANNING",
                },
                "organisation": {"agent": {"address": {}}},
                "project": {
                    "name": "Householder test",
                    "typeOfWorkKey": "domestic_alteration_extension",
                    "typeOfWorkLabel": "Domestic alteration / extension",
                },
                "site": {"address": {}},
                "applicant": {
                    "displayName": "A company name that must not be split",
                    "firstName": "Jane",
                    "lastName": "Smith",
                    "address": {},
                },
                "planning": {
                    "recordId": "planning_123456",
                    "description": "Rear extension",
                    "answers": {
                        "discussedWithPlanningAuthority": False,
                        "treesOnOrAdjacentToSite": True,
                        "newOrAlteredVehicleAccess": True,
                        "currentParkingSpaces": 1,
                        "proposedParkingSpaces": 2,
                        "soleOwner": True,
                        "agriculturalHolding": False,
                    },
                },
                "buildingWarrant": None,
                "documents": [],
                "preflight": {"status": "READY", "missing": [], "warnings": []},
            },
        }

        values = portal_handoff.portal_job_to_values(job)

        self.assertEqual(values["Applicant First Name"], "Jane")
        self.assertEqual(values["Applicant Last Name"], "Smith")
        self.assertEqual(values["Householder Trees On Site"], "Yes")
        self.assertEqual(values["Householder Current Parking Spaces"], 1)
        self.assertEqual(values["Householder Sole Owner"], "Yes")
        self.assertEqual(values["Description of Work"], "Rear extension")
        self.assertNotIn(portal_answers.PROFILE_KEY, values)
        self.assertNotIn("Proposed Work", values)
        self.assertNotIn("Current Use", values)
        self.assertNotIn("Proposed Use", values)
        self.assertNotIn("Estimated Work Value", values)

    def test_v2_snapshot_rejects_unsupported_versions(self):
        with self.assertRaises(portal_handoff.PortalHandoffError):
            portal_handoff.portal_job_to_values({
                "id": "job_123456",
                "dataSnapshot": {
                    "contractVersion": "architectpro.automation-job",
                    "snapshotVersion": 3,
                },
            })

    def test_planning_application_type_selects_planning_automation(self):
        job = {
            "id": "job_planning_123",
            "projectId": "project_planning_123",
            "type": "PLANNING_APPLICATION",
            "dataSnapshot": {
                "contractVersion": "architectpro.automation-job",
                "snapshotVersion": 2,
                "metadata": {
                    "jobId": "job_planning_123",
                    "projectId": "project_planning_123",
                    "applicationType": "PLANNING_APPLICATION",
                },
                "organisation": {},
                "project": {},
                "site": {},
                "applicant": {},
                "planning": {"recordId": "planning_123", "answers": {}},
                "buildingWarrant": None,
                "documents": [],
                "preflight": {},
            },
        }
        self.assertEqual(
            portal_handoff.application_type_from_job(job),
            portal_answers.HOUSEHOLDER_TYPE,
        )
        self.assertEqual(
            portal_handoff.application_identity_from_job(job)["selected_automation"],
            "PLANNING",
        )

    def test_conflicting_job_and_snapshot_types_are_blocked(self):
        job = {
            "id": "job_conflict_123",
            "projectId": "project_conflict_123",
            "type": "BUILDING_WARRANT",
            "dataSnapshot": {
                "contractVersion": "architectpro.automation-job",
                "snapshotVersion": 2,
                "metadata": {
                    "jobId": "job_conflict_123",
                    "projectId": "project_conflict_123",
                    "applicationType": "PLANNING_APPLICATION",
                },
                "planning": {"recordId": "planning_123"},
                "buildingWarrant": None,
            },
        }
        with self.assertRaisesRegex(portal_handoff.PortalHandoffError, "do not match"):
            portal_handoff.application_type_from_job(job)

    def test_missing_application_type_is_blocked(self):
        with self.assertRaisesRegex(portal_handoff.PortalHandoffError, "missing its application type"):
            portal_handoff.application_type_from_job({
                "id": "job_missing_type",
                "projectId": "project_missing_type",
                "dataSnapshot": {
                    "schemaVersion": 1,
                    "planningApplication": {"id": "planning_123"},
                },
            })

    def test_building_warrant_type_of_work_selects_matching_profile(self):
        cases = [
            ("Domestic alteration / extension", portal_answers.DOMESTIC_PROFILE, "Construct"),
            ("New build", portal_answers.NEW_BUILD_PROFILE, "Construct"),
            ("Conversion / change of use", portal_answers.CONVERSION_PROFILE, "Convert"),
            ("Demolition", portal_answers.DEMOLITION_PROFILE, "Demolish"),
        ]
        for project_type, expected_profile, expected_work in cases:
            with self.subTest(project_type=project_type):
                values = portal_handoff.portal_job_to_values({
                    "id": "job_legacy_warrant",
                    "projectId": "project_legacy_warrant",
                    "type": "BUILDING_WARRANT",
                    "dataSnapshot": {
                        "buildingWarrantApplication": {"id": "warrant_legacy"},
                        "project": {"name": "Test project", "projectType": project_type},
                        "applicationQuestions": {"Application Profile": expected_profile},
                    },
                })
                self.assertEqual(values[portal_answers.PROFILE_KEY], expected_profile)
                self.assertEqual(values["Proposed Work"], expected_work)

    def test_legacy_householder_ignores_building_warrant_only_fields(self):
        values = portal_handoff.portal_job_to_values({
            "id": "job_legacy_planning",
            "projectId": "project_legacy_planning",
            "type": "HOUSEHOLDER_PLANNING",
            "dataSnapshot": {
                "planningApplication": {"id": "planning_legacy"},
                "project": {
                    "name": "Householder test",
                    "projectType": "Demolition",
                    "notes": "Rear extension",
                },
                "applicationQuestions": {
                    portal_answers.PROFILE_KEY: portal_answers.DEMOLITION_PROFILE,
                    "Proposed Work": "Demolish",
                    "Householder Trees On Site": "No",
                },
            },
        })

        self.assertEqual(values["Description of Work"], "Rear extension")
        self.assertEqual(values["Householder Trees On Site"], "No")
        self.assertNotIn(portal_answers.PROFILE_KEY, values)
        self.assertNotIn("Proposed Work", values)

    def test_explicit_portal_profile_controls_proposed_work(self):
        values = portal_handoff.portal_job_to_values({
            "id": "job_legacy_warrant",
            "projectId": "project_legacy_warrant",
            "type": "BUILDING_WARRANT",
            "dataSnapshot": {
                "buildingWarrantApplication": {"id": "warrant_legacy"},
                "project": {"name": "Legacy project", "projectType": "Domestic"},
                "applicationQuestions": {
                    portal_answers.PROFILE_KEY: portal_answers.CONVERSION_PROFILE,
                },
            },
        })
        self.assertEqual(values[portal_answers.PROFILE_KEY], portal_answers.CONVERSION_PROFILE)
        self.assertEqual(values["Proposed Work"], "Convert")

    def test_portal_import_clears_all_project_specific_sections(self):
        with open(os.path.join(ROOT, "gui", "app.py"), encoding="utf-8") as handle:
            app_source = handle.read()
        method = app_source.split("def clear_portal_import_state", 1)[1].split("def clear_portal_widget", 1)[0]
        self.assertIn("input_fields", method)
        self.assertIn("agent_line_edits", method)
        self.assertIn("applicant_line_edits", method)
        self.assertIn("cert_line_edits", method)
        self.assertIn("cert_dropdowns", method)
        self.assertIn("clear_pdf_mapping_lists_for_new_selection", method)

    def test_true_location_plan_has_priority_over_site_plan(self):
        documents = [
            {"id": "site", "type": "SITE_PLAN", "localPath": "C:/job/site.pdf", "localName": "site.pdf"},
            {"id": "location", "type": "LOCATION_PLAN", "localPath": "C:/job/location.pdf", "localName": "location.pdf"},
        ]
        buckets = portal_handoff.document_bucket_map(documents)
        self.assertEqual(buckets["location_plan"], ["location.pdf"])
        self.assertIn("site.pdf", buckets["other"])

    def test_site_plan_is_location_fallback(self):
        documents = [{"id": "site", "type": "SITE_PLAN", "localPath": "C:/job/site.pdf", "localName": "site.pdf"}]
        self.assertEqual(portal_handoff.document_bucket_map(documents)["location_plan"], ["site.pdf"])

    def test_reviewed_category_variants_map_to_exact_desktop_buckets(self):
        documents = [
            {"id": "location", "categoryKey": "location_plan", "localPath": "C:/job/location.pdf", "localName": "location.pdf"},
            {"id": "existing", "categoryKey": "Existing Plans", "localPath": "C:/job/existing.pdf", "localName": "existing.pdf"},
            {"id": "proposed", "categoryKey": "proposed_plans", "localPath": "C:/job/proposed.pdf", "localName": "proposed.pdf"},
            {"id": "section", "categoryKey": "section", "localPath": "C:/job/section.pdf", "localName": "section.pdf"},
            {"id": "spec", "categoryKey": "specifications", "localPath": "C:/job/spec.pdf", "localName": "spec.pdf"},
            {"id": "support", "categoryKey": "supporting_document", "localPath": "C:/job/support.pdf", "localName": "support.pdf"},
        ]
        buckets = portal_handoff.document_bucket_map(documents)
        self.assertEqual(buckets["location_plan"], ["location.pdf"])
        self.assertEqual(buckets["existing"], ["existing.pdf"])
        self.assertEqual(buckets["proposed"], ["proposed.pdf"])
        self.assertEqual(buckets["sections"], ["section.pdf"])
        self.assertEqual(buckets["specs"], ["spec.pdf"])
        self.assertEqual(buckets["other"], ["support.pdf"])

    def test_safe_local_filename_blocks_traversal_and_duplicate_names_are_stable(self):
        self.assertEqual(
            portal_handoff.safe_local_filename("../../client/location plan.pdf"),
            "location plan.pdf",
        )
        self.assertEqual(
            portal_handoff.safe_local_filename(r"..\client\location plan.pdf"),
            "location plan.pdf",
        )
        used = set()
        self.assertEqual(portal_handoff.unique_filename("Plan.pdf", used), "Plan.pdf")
        self.assertEqual(portal_handoff.unique_filename("plan.pdf", used), "plan (2).pdf")

    def test_content_disposition_filename_fallback(self):
        self.assertEqual(
            portal_handoff.filename_from_content_disposition(
                "attachment; filename=\"Reviewed Location Plan.pdf\""
            ),
            "Reviewed Location Plan.pdf",
        )
        self.assertEqual(
            portal_handoff.filename_from_content_disposition(
                "attachment; filename*=UTF-8''Reviewed%20Plan.pdf"
            ),
            "Reviewed Plan.pdf",
        )

    def test_normalised_state_does_not_merge_stale_local_values(self):
        with open(
            os.path.join(ROOT, "tests", "fixtures", "automation-job-v2-building-warrant.json"),
            encoding="utf-8",
        ) as handle:
            snapshot = json.load(handle)
        job = {
            "id": snapshot["metadata"]["jobId"],
            "projectId": snapshot["metadata"]["projectId"],
            "type": snapshot["metadata"]["applicationType"],
            "dataSnapshot": snapshot,
        }
        documents = [
            {
                **document,
                "type": document["categoryKey"],
                "localName": document["filename"],
                "localPath": f"C:/job/{document['filename']}",
            }
            for document in snapshot["documents"]
        ]
        state = portal_handoff.normalise_portal_job(job, documents, [])
        stale = {
            "Description of Work": "STALE LOCAL DESCRIPTION",
            "Estimated Work Value": 99999,
            "Applicant First Name": "STALE APPLICANT",
        }
        final_values = {**stale, **state.form_values}
        self.assertEqual(final_values["Description of Work"], "Snapshot Integration Description")
        self.assertEqual(final_values["Estimated Work Value"], 23456)
        self.assertEqual(final_values["Applicant First Name"], "Integration")
        self.assertEqual(state.document_buckets["location_plan"], ["INT-001 Location Plan.pdf"])
        self.assertEqual(state.document_buckets["existing"], ["INT-101 Existing Plans.pdf"])
        self.assertEqual(state.document_buckets["proposed"], ["INT-201 Proposed Plans.pdf"])
        self.assertEqual(state.document_buckets["sections"], ["INT-301 Section A-A.pdf"])
        self.assertEqual(state.document_buckets["specs"], ["INT-401 Outline Specification.pdf"])


if __name__ == "__main__":
    unittest.main()

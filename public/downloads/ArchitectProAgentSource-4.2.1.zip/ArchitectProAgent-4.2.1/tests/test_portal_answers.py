from gui.services import portal_answers


def test_domestic_profile_defaults_and_design_certificate_inference():
    answers = portal_answers.collect_answers(
        portal_answers.DOMESTIC_PROFILE,
        {},
        {"Name of Certifier": ""},
    )

    assert answers["Includes Existing Building Work"] == "Yes"
    assert answers["Includes New Building Or Extension"] == "Yes"
    assert answers["New Building Construction"] == "No"
    assert answers["Conversion Regulations"] == "No"
    assert answers["Approved Certifier Design"] == "No"


def test_exception_values_override_profile_defaults():
    answers = portal_answers.collect_answers(
        portal_answers.NEW_BUILD_PROFILE,
        {"Application Staged": "Yes", "Public Inspection Restricted": "Yes"},
        {"Name of Certifier": "Chris Pattison"},
    )

    assert answers["Includes Existing Building Work"] == "No"
    assert answers["New Building Construction"] == "Yes"
    assert answers["Application Staged"] == "Yes"
    assert answers["Public Inspection Restricted"] == "Yes"
    assert answers["Approved Certifier Design"] == "Yes"


def test_multiple_work_types_merge_profile_answers_without_losing_demolition():
    answers = portal_answers.collect_answers(
        [portal_answers.NEW_BUILD_PROFILE, portal_answers.DEMOLITION_PROFILE],
        {},
        {},
    )

    assert answers[portal_answers.TYPE_OF_WORKS_KEY] == "New build | Demolition"
    assert answers["New Building Construction"] == "Yes"
    assert answers["Includes New Building Or Extension"] == "Yes"
    assert answers["Includes Demolition"] == "Yes"
    assert portal_answers.proposed_work_for_profiles(
        [portal_answers.NEW_BUILD_PROFILE, portal_answers.DEMOLITION_PROFILE]
    ) == "Construct"


def test_householder_vehicle_access_sets_parking_defaults():
    answers = portal_answers.collect_householder_answers(
        {"Householder New Or Altered Vehicle Access": "Yes"},
        {},
    )

    assert answers["Householder New Or Altered Vehicle Access"] == "Yes"
    assert answers["Householder Current Parking Spaces"] == "0"
    assert answers["Householder Proposed Parking Spaces"] == "0"

from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from gui.services import callback_outbox, portal_handoff


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    monkeypatch.setenv("APPDATA", str(tmp_path))


def correction_event():
    event = callback_outbox.build_event(job_id="job_address_123", status="FAILED_RETRYABLE", event_type="result")
    event["addressCorrection"] = {"postcode": "G41 5AA"}
    return event


def test_result_failure_retains_dependent_correction_across_restart(monkeypatch):
    client = SimpleNamespace(
        send_callback=Mock(side_effect=portal_handoff.PortalHandoffError("offline")),
        correct_address_and_restart=Mock(return_value={"job": {"id": "fresh_job"}}),
    )
    event = correction_event()
    assert not callback_outbox.deliver_event(event, client)
    client.correct_address_and_restart.assert_not_called()
    restored = callback_outbox.pending_events()[0]
    assert restored["addressCorrection"]["postcode"] == "G41 5AA"
    assert restored["payload"]["callbackId"] == event["id"]
    client.send_callback.side_effect = None
    client.send_callback.return_value = {"ok": True, "status": "FAILED_RETRYABLE"}
    monkeypatch.setattr(portal_handoff, "get_job_access_token", lambda _job: "test")
    monkeypatch.setattr(portal_handoff, "PortalClient", lambda *_args: client)
    outcome = callback_outbox.retry_pending(now=datetime.now(timezone.utc) + timedelta(hours=2))
    assert outcome == {"delivered": 1, "retained": 0}
    client.correct_address_and_restart.assert_called_once_with("job_address_123", "G41 5AA")


def test_lost_correction_response_retains_intent_without_resending_result():
    client = SimpleNamespace(
        send_callback=Mock(return_value={"ok": True}),
        correct_address_and_restart=Mock(side_effect=[portal_handoff.PortalHandoffError("response lost"), {"job": {"id": "same_fresh_job"}}]),
    )
    event = correction_event()
    assert not callback_outbox.deliver_event(event, client)
    restored = callback_outbox.pending_events()[0]
    assert restored["callbackAcknowledged"] is True
    assert callback_outbox.deliver_event(restored, client)
    client.send_callback.assert_called_once()
    assert client.correct_address_and_restart.call_args_list[0] == client.correct_address_and_restart.call_args_list[1]
    assert restored["addressCorrection"]["newJobId"] == "same_fresh_job"
    assert callback_outbox.pending_events() == []


@pytest.mark.parametrize("code", [401, 403, 404, 409])
def test_permanent_rejection_is_visible_and_not_replayed(code):
    client = SimpleNamespace(send_callback=Mock(return_value={"ok": True}), correct_address_and_restart=Mock(side_effect=portal_handoff.PortalHandoffError("conflict", code)))
    assert not callback_outbox.deliver_event(correction_event(), client)
    restored = callback_outbox.pending_events()[0]
    assert restored["recoveryBlocked"] is True
    assert callback_outbox.retry_pending()["blocked"] == 1
    assert not callback_outbox.deliver_event(restored, client)
    client.correct_address_and_restart.assert_called_once()

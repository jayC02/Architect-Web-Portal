from types import SimpleNamespace

import Gui


def test_browser_startup_smoke_requires_matching_browser_and_driver_major(monkeypatch):
    driver = SimpleNamespace(
        capabilities={
            "browserVersion": "150.0.7871.182",
            "chrome": {"chromedriverVersion": "150.0.7871.124"},
        },
        quit_calls=0,
    )
    driver.quit = lambda: setattr(driver, "quit_calls", driver.quit_calls + 1)
    monkeypatch.setattr("automation.common.driver.create_chrome_driver", lambda _options: driver)

    assert Gui.browser_startup_smoke_test() == 0
    assert driver.quit_calls == 1

from pathlib import Path

from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.by import By

from automation.building_warrant.login import submit_login_and_wait_for_home


def test_portal_handoffs_use_known_sidebar_control_names():
    building_login = Path("automation/building_warrant/login.py").read_text(encoding="utf-8")
    householder_run = Path("automation/householder/run.py").read_text(encoding="utf-8")

    assert 'click_when_clickable(driver, By.NAME, "ctl00$sideBar$ctl11")' in building_login
    assert 'click_when_clickable(driver, By.NAME, "ctl00$sideBar$ctl13")' in householder_run


def test_login_navigation_stale_is_success_when_authenticated_home_appears():
    class ServiceControl:
        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

    service_control = ServiceControl()

    class LoginControl(ServiceControl):
        def __init__(self, driver):
            self.driver = driver

        def click(self):
            self.driver.authenticated = True
            raise StaleElementReferenceException("login page navigated")

    class Driver:
        def __init__(self):
            self.authenticated = False
            self.login_control = LoginControl(self)

        def find_elements(self, by, locator):
            if by == By.NAME and locator == "ctl00$sideBar$ctl11":
                return [service_control] if self.authenticated else []
            if by == By.ID and locator == "MainContent_UclLogin_LoginWizard_BtnLogin":
                return [] if self.authenticated else [self.login_control]
            return []

    assert submit_login_and_wait_for_home(Driver(), timeout=1) is service_control


def test_planning_login_uses_same_stale_safe_handoff_for_eplanning():
    planning_name = "ctl00$sideBar$ctl13"

    class ServiceControl:
        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

    service_control = ServiceControl()

    class LoginControl(ServiceControl):
        def __init__(self, driver):
            self.driver = driver

        def click(self):
            self.driver.authenticated = True
            raise StaleElementReferenceException("login page navigated")

    class Driver:
        def __init__(self):
            self.authenticated = False
            self.login_control = LoginControl(self)

        def find_elements(self, by, locator):
            if by == By.NAME and locator == planning_name:
                return [service_control] if self.authenticated else []
            if by == By.ID and locator == "MainContent_UclLogin_LoginWizard_BtnLogin":
                return [] if self.authenticated else [self.login_control]
            return []

    assert submit_login_and_wait_for_home(
        Driver(),
        timeout=1,
        authenticated_control_name=planning_name,
    ) is service_control

    householder_run = Path("automation/householder/run.py").read_text(encoding="utf-8")
    assert "submit_login_and_wait_for_home(" in householder_run
    assert 'authenticated_control_name="ctl00$sideBar$ctl13"' in householder_run

import json
from pathlib import Path

import pytest
from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    WebDriverException,
)

from automation.common.proposal_creation import (
    BUILDING_WARRANT,
    BUILDING_WARRANT_FORM,
    HOUSEHOLDER,
    HOUSEHOLDER_FORM,
    HOUSEHOLDER_INITIAL_OPTION,
    POSTCODE_INPUT_ID,
    AddressPostcodeCorrectionRequired,
    AddressOption,
    ManualAddressResolutionRequired,
    ProposalCreationError,
    ProposalNameInUse,
    ProposalCreationUncertain,
    SavedProposalNotFoundError,
    SeleniumProposalPortal,
    build_context,
    confirmed_postal_address,
    create_proposal_and_resume,
    exact_address_fields,
    match_address,
    normalise_postcode,
    page_size_value,
    proposal_name_after_deleted_collision,
)
from gui.services import portal_handoff


def inputs(application_type=BUILDING_WARRANT, **overrides):
    values = {
        "Application Type": application_type,
        "Site Address": "12 Rowan Road, Glasgow, G1 1AA",
        "Site Postcode": " g1   1aa ",
        "Description of Work": "Demolish the existing extension and construct a replacement.",
        "Automation Job ID": "job-123",
        "Project ID": "project-456",
        "Application Record ID": "application-789",
    }
    values.update(overrides)
    return values


class MemoryStore:
    def __init__(self, existing=None):
        self.existing = existing
        self.saved = []
        self.resolved = []
        self.cleared = []

    def get(self, _context):
        return self.existing

    def save(self, context, reference, proposal_name, portal_address=""):
        self.saved.append((context.job_key, reference, proposal_name))
        self.resolved.append(portal_address)

    def clear(self, context, reference):
        self.cleared.append((context.job_key, reference))
        self.existing = None
        return True


class FakePortal:
    def __init__(self, application_type, options=None, *, uncertain=False, recovered_reference=""):
        self.application_type = application_type
        self.options = list(options or [AddressOption("12 Rowan Road, Glasgow, G1 1AA", "address-1")])
        self.uncertain = uncertain
        self.recovered_reference = recovered_reference
        self.reference = ""
        self.events = []

    def open_new_proposal(self):
        self.events.append("open-new")
        if self.application_type == HOUSEHOLDER:
            self.events.append(("initial-option", HOUSEHOLDER_INITIAL_OPTION))

    def search_postcode(self, postcode):
        self.events.append(("postcode-search", postcode))

    def read_addresses(self):
        self.events.append(("read-addresses", tuple(option.display for option in self.options)))
        return self.options

    def select_address(self, option, expected_address=None):
        assert expected_address
        self.events.append(("select-address", option.display))
        return option.display

    def enter_proposal_details(self, name, description):
        self.events.append(("proposal-details", name, description))

    def select_form(self):
        label = BUILDING_WARRANT_FORM if self.application_type == BUILDING_WARRANT else HOUSEHOLDER_FORM
        self.events.extend([("selection-mode", "Select forms from a list"), ("form", label), "add-forms"])

    def create_proposal(self):
        self.events.append("create-proposal")
        if self.uncertain:
            raise ProposalCreationUncertain("Create Proposal", "result uncertain")
        self.reference = "500000001"
        return self.reference

    def find_matching_draft(self, name):
        self.events.append(("find-matching-draft", name))
        self.reference = self.recovered_reference
        return self.recovered_reference

    def current_proposal_reference(self):
        return self.reference

    def open_existing_proposal(self, reference, proposal_name=""):
        self.events.append(("open-existing", reference))
        self.reference = reference

    def open_added_form(self):
        self.events.append("open-form")


def run(portal, values=None, store=None, address_selector=None):
    resumed = []
    result = create_proposal_and_resume(
        object(),
        values or inputs(portal.application_type),
        lambda: resumed.append(portal.application_type) or "resumed",
        portal=portal,
        state_store=store or MemoryStore(),
        address_selector=address_selector,
    )
    return result, resumed


def test_building_warrant_creates_exact_form_and_resumes_existing_automation():
    portal = FakePortal(BUILDING_WARRANT, [
        AddressOption("10 Rowan Road, Glasgow, G1 1AA", "wrong-first"),
        AddressOption("12 Rowan Road, Glasgow, G1 1AA", "correct-second"),
    ])
    store = MemoryStore()
    result, resumed = run(portal, store=store)

    assert result == "resumed"
    assert ("postcode-search", "G1 1AA") in portal.events
    assert ("select-address", "12 Rowan Road, Glasgow, G1 1AA") in portal.events
    assert ("select-address", "10 Rowan Road, Glasgow, G1 1AA") not in portal.events
    assert ("proposal-details", "12 Rowan Road, Glasgow, G1 1AA", inputs()["Description of Work"]) in portal.events
    assert ("form", BUILDING_WARRANT_FORM) in portal.events
    assert portal.events[-2:] == ["create-proposal", "open-form"]
    assert resumed == [BUILDING_WARRANT]
    assert store.saved[0][1] == "500000001"


def test_householder_selects_initial_category_exact_form_and_resumes():
    portal = FakePortal(HOUSEHOLDER)
    result, resumed = run(portal)
    assert result == "resumed"
    assert ("initial-option", HOUSEHOLDER_INITIAL_OPTION) in portal.events
    assert ("form", HOUSEHOLDER_FORM) in portal.events
    assert resumed == [HOUSEHOLDER]


def test_householder_category_direct_navigation_to_postcode_is_success():
    class Driver:
        def __init__(self):
            self.on_postcode_page = False
            self.continuation_queries = 0

        def find_elements(self, _by, locator):
            if locator == POSTCODE_INPUT_ID:
                return [object()] if self.on_postcode_page else []
            if "input[type='submit']" in locator:
                self.continuation_queries += 1
            return []

        def find_element(self, _by, _locator):
            raise AssertionError("The category control should not be queried after direct navigation.")

    class Label:
        def __init__(self, driver):
            self.driver = driver

        def get_attribute(self, name):
            return "householder-category" if name == "for" else None

        def click(self):
            self.driver.on_postcode_page = True

    driver = Driver()
    portal = SeleniumProposalPortal(driver, HOUSEHOLDER, timeout=1)
    portal._find_exact_label = lambda _text, _step: Label(driver)

    portal._select_householder_initial_category()

    assert driver.on_postcode_page is True
    assert driver.continuation_queries == 0


def test_householder_category_reacquires_after_stale_postback_control():
    class Driver:
        def __init__(self):
            self.on_postcode_page = False
            self.detached_checks = 0

        def find_elements(self, _by, locator):
            if locator == POSTCODE_INPUT_ID:
                return [object()] if self.on_postcode_page else []
            if locator == "householder-category":
                return [Control(self)]
            return []

    class Control:
        def __init__(self, driver):
            self.driver = driver

        def is_selected(self):
            self.driver.detached_checks += 1
            self.driver.on_postcode_page = True
            raise StaleElementReferenceException()

    class Label:
        def get_attribute(self, name):
            return "householder-category" if name == "for" else None

        def click(self):
            return None

    driver = Driver()
    portal = SeleniumProposalPortal(driver, HOUSEHOLDER, timeout=1)
    portal._find_exact_label = lambda _text, _step: Label()

    portal._select_householder_initial_category()

    assert driver.on_postcode_page is True
    assert driver.detached_checks == 1


def test_ambiguous_address_requests_selection_and_pauses_without_creation():
    portal = FakePortal(BUILDING_WARRANT, [
        AddressOption("12 Rowan Road, Central Glasgow, G1 1AA", "one"),
        AddressOption("12 Rowan Road, Glasgow City, G1 1AA", "two"),
    ])
    requests = []
    with pytest.raises(ProposalCreationError, match="no property was selected"):
        run(portal, address_selector=lambda options: requests.append(options) or None)
    assert len(requests[0]) == 2
    assert "create-proposal" not in portal.events


@pytest.mark.parametrize("application_type", [BUILDING_WARRANT, HOUSEHOLDER])
def test_different_portal_postcode_is_user_selected_and_execution_address_is_saved(application_type):
    canonical = "73 Blackhill Drive, Glasgow, G12 8AB"
    portal_value = "73 Blackhill Drive, Glasgow, G12 8AA"
    values = inputs(application_type, **{
        "Site Address": canonical,
        "Site Postcode": "G12 8AB",
    })
    portal = FakePortal(application_type, [
        AddressOption(portal_value, "portal-control", selection_value="73 Blackhill Drive")
    ])
    store = MemoryStore()
    requests = []

    result = create_proposal_and_resume(
        object(),
        values,
        lambda: "resumed",
        portal=portal,
        state_store=store,
        address_resolver=lambda request: requests.append(request) or {
            "action": "select",
            "candidate_id": request["candidates"][0]["candidate_id"],
        },
    )

    assert result == "resumed"
    assert requests[0]["project_postcode"] == "G12 8AB"
    assert requests[0]["candidates"][0]["postcode"] == "G12 8AA"
    assert "element_id" not in requests[0]["candidates"][0]
    assert portal.events.count(("select-address", portal_value)) == 1
    assert store.resolved == [portal_value]
    assert values["Site Address"] == canonical
    assert values["Site Postcode"] == "G12 8AB"


def test_multiple_candidates_require_one_identity_and_only_select_that_candidate_once():
    options = [
        AddressOption("73 Blackhill Drive, Glasgow, G12 8AA", "stale-one", 1, "73 Blackhill Drive"),
        AddressOption("73A Blackhill Drive, Glasgow, G12 8AB", "stale-two", 2, "73A Blackhill Drive"),
    ]
    portal = FakePortal(BUILDING_WARRANT, options)
    requests = []
    result = create_proposal_and_resume(
        object(),
        inputs(**{
            "Site Address": "73 Blackhill Drive, Glasgow, G12 8AB",
            "Site Postcode": "G12 8AB",
        }),
        lambda: "resumed",
        portal=portal,
        state_store=MemoryStore(),
        address_resolver=lambda request: requests.append(request) or {
            "action": "select",
            "candidate_id": request["candidates"][1]["candidate_id"],
        },
    )

    assert result == "resumed"
    assert [candidate["display_text"] for candidate in requests[0]["candidates"]] == [
        option.display for option in options
    ]
    selections = [event for event in portal.events if isinstance(event, tuple) and event[0] == "select-address"]
    assert selections == [("select-address", options[1].display)]


@pytest.mark.parametrize("application_type", [BUILDING_WARRANT, HOUSEHOLDER])
def test_alternative_postcode_stops_for_canonical_correction_without_mutating_snapshot_inputs(application_type):
    values = inputs(application_type, **{
        "Site Address": "73 Blackhill Drive, Glasgow, G12 8AB",
        "Site Postcode": "G12 8AB",
    })

    class AlternatePostcodePortal(FakePortal):
        def search_postcode(self, postcode):
            super().search_postcode(postcode)
            self.options = [] if postcode == "G12 8AB" else [
                AddressOption("73 Blackhill Drive, Glasgow, G12 8AA", "alternate")
            ]

    portal = AlternatePostcodePortal(application_type, [])
    with pytest.raises(AddressPostcodeCorrectionRequired) as captured:
        create_proposal_and_resume(
            object(), values, lambda: "resumed", portal=portal, state_store=MemoryStore(),
            address_resolver=lambda _request: {"action": "change_postcode", "postcode": "G12 8AA"},
        )

    assert captured.value.corrected_postcode == "G12 8AA"
    assert ("postcode-search", "G12 8AB") in portal.events
    assert ("postcode-search", "G12 8AA") not in portal.events
    assert values["Site Postcode"] == "G12 8AB"
    assert "create-proposal" not in portal.events


def test_no_candidates_can_request_manual_resolution_without_creating_proposal():
    portal = FakePortal(BUILDING_WARRANT, [])
    portal.options = []
    with pytest.raises(ManualAddressResolutionRequired):
        create_proposal_and_resume(
            object(), inputs(), lambda: "resumed", portal=portal, state_store=MemoryStore(),
            address_resolver=lambda request: (
                {"action": "manual"} if not request["candidates"] else {"action": "cancel"}
            ),
        )
    assert "create-proposal" not in portal.events


def test_missing_address_match_is_recoverable_and_does_not_create():
    portal = FakePortal(BUILDING_WARRANT, [AddressOption("99 Other Street, Glasgow, G1 1AA", "wrong")])
    with pytest.raises(ProposalCreationError, match="No returned address safely matched"):
        run(portal)
    assert "create-proposal" not in portal.events


@pytest.mark.parametrize("missing_key", ["Site Postcode", "Site Address", "Description of Work", "Automation Job ID"])
def test_missing_required_project_data_stops_before_portal_interaction(missing_key):
    portal = FakePortal(BUILDING_WARRANT)
    values = inputs()
    values[missing_key] = ""
    if missing_key == "Automation Job ID":
        values["Project ID"] = ""
        values["Application Record ID"] = ""
    with pytest.raises(ProposalCreationError, match="Preflight"):
        run(portal, values=values)
    assert portal.events == []


def test_existing_proposal_reference_reopens_without_creating():
    portal = FakePortal(BUILDING_WARRANT)
    store = MemoryStore({"proposalReference": "500000009"})
    result, resumed = run(portal, store=store)
    assert result == "resumed"
    assert portal.events == [("open-existing", "500000009"), "open-form"]
    assert resumed == [BUILDING_WARRANT]


@pytest.mark.parametrize("application_type", [BUILDING_WARRANT, HOUSEHOLDER])
def test_deleted_saved_proposal_is_cleared_and_recreated_safely(application_type):
    class DeletedProposalPortal(FakePortal):
        def open_existing_proposal(self, reference, proposal_name=""):
            self.events.append(("open-existing", reference))
            raise SavedProposalNotFoundError("Resume", "The exact saved draft no longer exists.")

    portal = DeletedProposalPortal(application_type)
    store = MemoryStore({"proposalReference": "500000009"})

    result, resumed = run(portal, values=inputs(application_type), store=store)

    assert result == "resumed"
    assert portal.events[0] == ("open-existing", "500000009")
    assert "open-new" in portal.events
    assert portal.events.count("create-proposal") == 1
    assert store.cleared == [("job-123", "500000009")]
    assert store.saved[0][1] == "500000001"
    assert resumed == [application_type]


def test_temporary_proposal_list_failure_does_not_clear_state_or_create_duplicate():
    class UnavailableProposalListPortal(FakePortal):
        def open_existing_proposal(self, reference, proposal_name=""):
            self.events.append(("open-existing", reference))
            raise ProposalCreationError("Proposal list", "The proposal list could not be opened.")

    portal = UnavailableProposalListPortal(BUILDING_WARRANT)
    store = MemoryStore({"proposalReference": "500000009"})

    with pytest.raises(ProposalCreationError, match="proposal list could not be opened"):
        run(portal, store=store)

    assert portal.events == [("open-existing", "500000009")]
    assert store.cleared == []
    assert store.saved == []


def test_uncertain_creation_checks_list_and_reuses_found_draft_once():
    portal = FakePortal(BUILDING_WARRANT, uncertain=True, recovered_reference="500000010")
    store = MemoryStore()
    result, resumed = run(portal, store=store)
    assert result == "resumed"
    assert portal.events.count("create-proposal") == 1
    assert len([event for event in portal.events if isinstance(event, tuple) and event[0] == "find-matching-draft"]) == 1
    assert ("open-existing", "500000010") in portal.events
    assert store.saved[0][1] == "500000010"
    assert resumed == [BUILDING_WARRANT]


def test_existing_exact_draft_is_recovered_when_portal_rejects_duplicate_name():
    class ExistingNamePortal(FakePortal):
        def enter_proposal_details(self, name, description):
            self.events.append(("proposal-details", name, description))
            raise ProposalNameInUse("Proposal details", "name already in use")

    portal = ExistingNamePortal(
        HOUSEHOLDER,
        recovered_reference="500000777",
    )
    store = MemoryStore()

    result, resumed = run(portal, values=inputs(HOUSEHOLDER), store=store)

    assert result == "resumed"
    assert portal.events.count("create-proposal") == 0
    assert ("find-matching-draft", "12 Rowan Road, Glasgow, G1 1AA") in portal.events
    assert ("open-existing", "500000777") in portal.events
    assert store.saved == [("job-123", "500000777", "12 Rowan Road, Glasgow, G1 1AA")]
    assert resumed == [HOUSEHOLDER]


def test_deleted_name_reservation_retries_once_with_address_and_application_type():
    class DeletedNamePortal(FakePortal):
        def enter_proposal_details(self, name, description):
            self.events.append(("proposal-details", name, description))
            if name == "12 Rowan Road, Glasgow, G1 1AA":
                raise ProposalNameInUse("Proposal details", "name already in use")

    portal = DeletedNamePortal(HOUSEHOLDER)
    store = MemoryStore()

    result, resumed = run(portal, values=inputs(HOUSEHOLDER), store=store)

    alternative = proposal_name_after_deleted_collision(
        "12 Rowan Road, Glasgow, G1 1AA",
        HOUSEHOLDER,
    )
    assert alternative == "12 Rowan Road, Glasgow, G1 1AA - Householder"
    assert portal.events.count("open-new") == 2
    assert portal.events.count("create-proposal") == 1
    assert ("proposal-details", alternative, inputs(HOUSEHOLDER)["Description of Work"]) in portal.events
    assert store.saved == [("job-123", "500000001", alternative)]
    assert resumed == [HOUSEHOLDER]


def test_repeated_deleted_name_reservations_use_bounded_numbered_fallback():
    base = "12 Rowan Road, Glasgow, G1 1AA"
    first_fallback = proposal_name_after_deleted_collision(base, HOUSEHOLDER)

    class RepeatedDeletedNamePortal(FakePortal):
        def enter_proposal_details(self, name, description):
            self.events.append(("proposal-details", name, description))
            if name in {base, first_fallback}:
                raise ProposalNameInUse("Proposal details", "name already in use")

    portal = RepeatedDeletedNamePortal(HOUSEHOLDER)
    store = MemoryStore()

    result, resumed = run(portal, values=inputs(HOUSEHOLDER), store=store)

    second_fallback = proposal_name_after_deleted_collision(
        base,
        HOUSEHOLDER,
        collision_number=2,
    )
    assert second_fallback == "12 Rowan Road, Glasgow, G1 1AA - Householder 2"
    assert portal.events.count("open-new") == 3
    assert portal.events.count("create-proposal") == 1
    assert store.saved == [("job-123", "500000001", second_fallback)]
    assert resumed == [HOUSEHOLDER]


def test_incorrect_similarly_named_forms_are_not_targeted():
    assert BUILDING_WARRANT_FORM == "Application for Building Warrant"
    assert BUILDING_WARRANT_FORM != "Application for Amendment of Building Warrant"
    assert HOUSEHOLDER_FORM == "Householder Application"
    assert HOUSEHOLDER_FORM != "Householder Planning Application"


def test_open_added_form_requeries_after_stale_candidate_text():
    class StaleCandidate:
        @property
        def text(self):
            raise StaleElementReferenceException("form link replaced by postback")

    class LiveCandidate:
        text = HOUSEHOLDER_FORM

        def __init__(self, driver):
            self.driver = driver

        def click(self):
            self.driver.current_url = (
                "https://www.eplanning.scot/ePlanningClient/CustomPages/Applications/FormSummary.aspx"
            )

    class Driver:
        def __init__(self):
            self.current_url = "https://www.eplanning.scot/ePlanningClient/CustomPages/Applications/Proposal.aspx"
            self.calls = 0

        def find_elements(self, _by, _locator):
            self.calls += 1
            return [StaleCandidate()] if self.calls == 1 else [LiveCandidate(self)]

    driver = Driver()
    SeleniumProposalPortal(driver, HOUSEHOLDER, timeout=1).open_added_form()

    assert driver.calls == 2
    assert "/Applications/FormSummary.aspx" in driver.current_url


def test_session_expiry_stops_all_proposal_actions():
    portal = FakePortal(BUILDING_WARRANT)

    def expired():
        raise ProposalCreationError("Session", "The portal session expired")

    portal.open_new_proposal = expired
    with pytest.raises(ProposalCreationError, match="session expired"):
        run(portal)
    assert "create-proposal" not in portal.events


def test_postcode_and_flat_unit_matching_are_deterministic():
    assert normalise_postcode(" g1   1aa ") == "G1 1AA"
    flat_options = [
        AddressOption("Flat 1/2, 12 Rowan Rd, Glasgow, G1 1AA"),
        AddressOption("Flat 1/1, 12 Rowan Road, Glasgow, G1 1AA"),
    ]
    match = match_address("Flat 1/1, 12 Rowan Road, Glasgow, G1 1AA", flat_options)
    assert match.option == flat_options[1]
    assert build_context(inputs()).postcode == "G1 1AA"


def test_confirmed_address_ignores_harmless_portal_formatting():
    context = build_context(inputs(**{
        "Site Address": "147 Blackhill Drive, 147, Glasgow, G23 5NN",
        "Site Postcode": "G23 5NN",
    }))
    confirmed_text = confirmed_postal_address(
        "Postal Address:\n147 BLACKHILL DRIVE,\nGLASGOW,\u00a0G23\u202f5NN.\n"
        "UPRN: 000147999\nEasting: 123456"
    )
    confirmed = AddressOption(confirmed_text)

    match = match_address(context.site_address, [confirmed])

    assert context.site_address == "147 Blackhill Drive, Glasgow, G23 5NN"
    assert confirmed_text == "147 BLACKHILL DRIVE,\nGLASGOW,\u00a0G23\u202f5NN"
    assert match.status == "exact"
    assert match.option is confirmed


def test_address_result_uses_its_own_submit_value_instead_of_first_row():
    options = [
        AddressOption(
            "108 BLACKHILL DRIVE, GLASGOW, G23 5NN",
            "address-9",
            selection_value="108 BLACKHILL DRIVE",
        ),
        AddressOption(
            "110 BLACKHILL DRIVE, GLASGOW, G23 5NN",
            "address-10",
            selection_value="110 BLACKHILL DRIVE",
        ),
    ]

    match = match_address("110 Blackhill Drive, Glasgow, G23 5NN", options)

    assert match.status == "exact"
    assert match.option.element_id == "address-10"

    noisy_snapshot_match = match_address(
        "105 Ralston Avenue, 147,, Glasgow, G23 5nn",
        [
            AddressOption(
                "105 RALSTON AVENUE, GLASGOW, G23 5NN",
                "address-ralston",
                selection_value="105 RALSTON AVENUE",
            )
        ],
    )
    assert noisy_snapshot_match.status == "missing"
    assert noisy_snapshot_match.option is None


@pytest.mark.parametrize("expected,candidate", [
    ("10 Alpha Street, Glasgow, G41 5AA", "10 Beta Road, Glasgow, G41 5AA"),
    ("10 Alpha Street, Glasgow, G41 5AA", "10 Alpha Road, Glasgow, G41 5AA"),
    ("10 Alpha Street, Glasgow, G41 5AA", "10 Alpha Street, Paisley, G41 5AA"),
    ("10A Alpha Street, Glasgow, G41 5AA", "10 Alpha Street, Glasgow, G41 5AA"),
    ("Flat 1/2, 10 Alpha Street, Glasgow, G41 5AA", "Flat 1-2, 10 Alpha Street, Glasgow, G41 5AA"),
    ("Flat 1/2, 10 Alpha Street, Glasgow, G41 5AA", "Flat 1 2, 10 Alpha Street, Glasgow, G41 5AA"),
    ("Flat 1/2, 10 Alpha Street, Glasgow, G41 5AA", "Flat 1/1, 10 Alpha Street, Glasgow, G41 5AA"),
    ("10 St John Road, Glasgow, G41 5AA", "10 Street John Road, Glasgow, G41 5AA"),
    ("10 King's Road, Glasgow, G41 5AA", "10 Kings Road, Glasgow, G41 5AA"),
    ("10 Alpha Street, Glasgow, G41 5AA", "10 Alpha Street, Glasgow, G41 5AB"),
    ("", ""),
])
def test_meaningful_address_differences_never_auto_match(expected, candidate):
    # Even a matching submit-value substring cannot override conflicting text.
    result = match_address(expected, [AddressOption(candidate, "row", selection_value=expected.split(",")[0])])
    assert result.status not in {"exact", "equivalent"}
    assert result.option is None


@pytest.mark.parametrize("candidate", [
    "10 ALPHA STREET, GLASGOW, G415AA",
    "10 Alpha St., Glasgow, G41 5AA",
    "10 Alpha St\nGlasgow\nG41\u202f5AA.",
    "  10  Alpha Street,\u00a0Glasgow, G41 5AA  ",
    "10 Alpha Street Glasgow G41 5AA",
])
def test_complete_address_allows_only_harmless_formatting(candidate):
    option = AddressOption(candidate)
    result = match_address("10 Alpha Street, Glasgow, G41 5AA", [option])
    assert result.status == "exact"
    assert result.option is option


@pytest.mark.parametrize("application_type", [BUILDING_WARRANT, HOUSEHOLDER])
def test_wrong_street_requires_native_chooser_before_any_selection(application_type):
    candidate = AddressOption("12 Beta Road, Glasgow, G1 1AA", "row")
    portal = FakePortal(application_type, [candidate])
    requests = []

    def choose(request):
        assert not any(event[0] == "select-address" for event in portal.events if isinstance(event, tuple))
        assert "create-proposal" not in portal.events
        requests.append(request)
        return {"action": "select", "candidate_id": request["candidates"][0]["candidate_id"]}

    assert create_proposal_and_resume(
        object(), inputs(application_type), lambda: "resumed",
        portal=portal, state_store=MemoryStore(), address_resolver=choose,
    ) == "resumed"
    assert len(requests) == 1
    assert ("select-address", candidate.display) in portal.events


def test_exact_address_fallback_only_uses_safely_structured_site_details():
    assert exact_address_fields(
        "Flat 1/1, 12 Rowan Road, Glasgow, G1 1AA",
        "G1 1AA",
    ) == {
        "building_name": "Flat 1/1",
        "building_number": "12",
        "street": "Rowan Road",
        "town": "Glasgow",
        "postcode": "G1 1AA",
    }
    assert exact_address_fields("Open land near Glasgow, G1 1AA", "G1 1AA") is None


def test_snapshot_v2_supplies_authoritative_proposal_context_without_reentry():
    fixture = Path(__file__).parent / "fixtures" / "automation-job-v2-building-warrant.json"
    snapshot = json.loads(fixture.read_text(encoding="utf-8"))
    job = {
        "id": snapshot["metadata"]["jobId"],
        "projectId": snapshot["metadata"]["projectId"],
        "type": snapshot["metadata"]["applicationType"],
        "dataSnapshot": snapshot,
    }
    values = portal_handoff.portal_job_to_values(job)

    assert values["Site Address"] == "24 Integration Avenue, Flat 2, Glasgow, G2 2BB"
    assert values["Site Postcode"] == "G2 2BB"
    assert values["Automation Job ID"] == "job_fixture_building_warrant"
    assert values["Project ID"] == "project_fixture"
    assert values["Application Record ID"] == "warrant_fixture"


class FakePageSizeControl:
    def __init__(self, size, enabled=True, on_click=None):
        self.size = size
        self.enabled = enabled
        self.on_click = on_click
        self.clicks = 0

    def is_enabled(self):
        return self.enabled

    def get_attribute(self, name):
        if name == "value":
            return str(self.size)
        if name == "id":
            return f"MainContent_CreateProposalWizard_btnPageSize{self.size}"
        if name == "name":
            return f"ctl00$MainContent$CreateProposalWizard$btnPageSize{self.size}"
        if name == "disabled":
            return None if self.enabled else "disabled"
        return None

    def click(self):
        self.clicks += 1
        if self.on_click:
            self.on_click()


class ScriptedResultsPortal(SeleniumProposalPortal):
    def __init__(self, pages, page_sizes, active_max=False):
        super().__init__(driver=None, application_type=BUILDING_WARRANT)
        self.pages = pages
        self.current_page = 0
        self.expanded = False
        self.refreshes = []
        self.read_generations = []
        maximum = max(page_sizes)
        self.controls = [
            FakePageSizeControl(
                size,
                enabled=not (active_max and size == maximum),
                on_click=(lambda: setattr(self, "expanded", True)) if size == maximum else None,
            )
            for size in page_sizes
        ]

    def _page_size_controls(self):
        return [(control.size, control) for control in self.controls]

    def _click_results_refresh(self, control, step):
        control.click()
        self.refreshes.append(step)

    def _results_table_signature(self):
        return f"{self.expanded}:{self.current_page}"

    def read_addresses(self):
        self.read_generations.append((self.expanded, self.current_page))
        return self.pages[self.current_page]

    def _next_result_page_control(self, _visited_numeric_pages):
        if self.current_page + 1 >= len(self.pages):
            return None, None
        next_page = self.current_page + 1
        control = FakePageSizeControl(
            next_page + 1,
            on_click=lambda: setattr(self, "current_page", next_page),
        )
        return control, next_page + 1


def test_largest_enabled_page_size_is_clicked_and_refreshed_table_is_read():
    portal = ScriptedResultsPortal(
        [[AddressOption("12 Rowan Road, Glasgow, G1 1AA", "correct")]],
        [10, 25, 50, 75],
    )
    options, outcome = portal.collect_address_options(inputs()["Site Address"])
    assert [control.clicks for control in portal.controls] == [0, 0, 0, 1]
    assert portal.refreshes == ["Address results page size"]
    assert portal.read_generations == [(True, 0)]
    assert outcome.option.display == options[0].display


def test_disabled_largest_page_size_is_treated_as_active_without_clicking():
    portal = ScriptedResultsPortal(
        [[AddressOption("12 Rowan Road, Glasgow, G1 1AA", "correct")]],
        [10, 25, 75],
        active_max=True,
    )
    _options, outcome = portal.collect_address_options(inputs()["Site Address"])
    assert [control.clicks for control in portal.controls] == [0, 0, 0]
    assert portal.refreshes == []
    assert outcome.status == "exact"


def test_page_size_is_dynamic_and_not_hardcoded_to_75():
    portal = ScriptedResultsPortal(
        [[AddressOption("12 Rowan Road, Glasgow, G1 1AA", "correct")]],
        [10, 20, 100],
    )
    portal.collect_address_options(inputs()["Site Address"])
    assert [control.clicks for control in portal.controls] == [0, 0, 1]
    assert page_size_value("", "MainContent_CreateProposalWizard_btnPageSize125", "") == 125


def test_correct_address_on_second_page_is_found_after_every_first_page_row():
    first_page = [
        AddressOption("10 Rowan Road, Glasgow, G1 1AA", "wrong-1"),
        AddressOption("11 Rowan Road, Glasgow, G1 1AA", "wrong-2"),
    ]
    second_page = [AddressOption("12 Rowan Road, Glasgow, G1 1AA", "correct")]
    portal = ScriptedResultsPortal([first_page, second_page], [10, 20, 100])
    options, outcome = portal.collect_address_options(inputs()["Site Address"])
    assert [option.display for option in options] == [
        "10 Rowan Road, Glasgow, G1 1AA",
        "11 Rowan Road, Glasgow, G1 1AA",
        "12 Rowan Road, Glasgow, G1 1AA",
    ]
    assert portal.read_generations == [(True, 0), (True, 1)]
    assert outcome.option.display == second_page[0].display
    assert "Address results pagination" in portal.refreshes


def test_first_page_match_is_not_unique_until_later_pages_are_checked():
    address = inputs()["Site Address"]
    portal = ScriptedResultsPortal([
        [AddressOption(address, "row-1")],
        [AddressOption(address, "row-1")],
    ], [10])
    options, outcome = portal.collect_address_options(address)
    assert portal.read_generations == [(True, 0), (True, 1)]
    assert len(options) == 2
    assert [option.page_number for option in options] == [1, 2]
    assert outcome.status == "ambiguous"
    assert outcome.option is None


def test_repeated_results_cannot_silently_return_an_unverified_match():
    portal = ScriptedResultsPortal([
        [AddressOption(inputs()["Site Address"], "row-1")],
        [AddressOption("99 Other Road, Glasgow, G1 1AA", "row-1")],
    ], [10])
    portal._results_table_signature = lambda: "unchanged"
    with pytest.raises(ProposalCreationError, match="pages repeated"):
        portal.collect_address_options(inputs()["Site Address"])


class SelectionReadbackPortal(SeleniumProposalPortal):
    def __init__(self, selected, readback, current_page=1):
        from types import SimpleNamespace

        driver = SimpleNamespace(
            find_elements=lambda *_args: [],
            find_element=lambda *_args: SimpleNamespace(text=f"Postal Address: {readback} Easting: 123"),
        )
        super().__init__(driver, BUILDING_WARRANT)
        self.selected = selected
        self._address_results_page = current_page
        self.events = []

    def _open_result_page(self, page):
        self.events.append(("page", page))

    def read_addresses(self):
        self.events.append(("read", self._address_results_page))
        return [self.selected]

    def _click_id(self, element_id, step):
        self.events.append(("click", step))
        return object()

    def _wait_postback(self, *_args):
        pass


def test_wrong_street_readback_stops_before_confirmation():
    selected = AddressOption("10 Alpha Street, Glasgow, G41 5AA", "reused-row")
    portal = SelectionReadbackPortal(selected, "10 Beta Road, Glasgow, G41 5AA")
    with pytest.raises(ProposalCreationError, match="no longer matches"):
        portal.select_address(selected, selected.display)
    assert ("click", "Address selection") in portal.events
    assert ("click", "Confirm address") not in portal.events
    assert ("click", "Confirm local authority") not in portal.events


def test_selection_returns_to_first_page_and_reacquires_row_after_full_collection():
    selected = AddressOption("10 Alpha Street, Glasgow, G41 5AA", "reused-row", page_number=1)
    portal = SelectionReadbackPortal(selected, "10 ALPHA ST., GLASGOW, G415AA", current_page=2)
    assert portal.select_address(selected, selected.display) == selected.display
    assert portal.events[:3] == [("page", 1), ("read", 1), ("click", "Address selection")]
    assert ("click", "Confirm address") in portal.events


def test_changed_live_row_stops_before_selection():
    selected = AddressOption("10 Alpha Street, Glasgow, G41 5AA", "reused-row")
    replacement = AddressOption("10 Beta Road, Glasgow, G41 5AA", "reused-row")
    portal = SelectionReadbackPortal(replacement, replacement.display)
    with pytest.raises(ProposalCreationError, match="could not be found uniquely"):
        portal.select_address(selected, selected.display)
    assert not any(event[0] == "click" for event in portal.events)


def test_live_pager_submit_pattern_is_scoped_to_address_results():
    source = Path(
        "automation/common/proposal_creation.py"
    ).read_text(encoding="utf-8")
    assert "input[type='submit'][id*='_dgAddressResults_'][id*='_BtnPage_']" in source
    assert "input[type='submit'][name*='$dgAddressResults$'][name*='$BtnPage']" in source


def test_results_signature_requeries_table_replaced_during_postback():
    class StaleTable:
        @property
        def text(self):
            raise StaleElementReferenceException("address table replaced")

    class FreshTable:
        text = "105 RALSTON AVENUE GLASGOW G23 5NN"

    class Driver:
        def __init__(self):
            self.tables = iter(([StaleTable()], [FreshTable()]))

        def find_elements(self, _by, _locator):
            return next(self.tables)

    portal = SeleniumProposalPortal(Driver(), BUILDING_WARRANT)

    assert portal._results_table_signature() == "105 RALSTON AVENUE GLASGOW G23 5NN"


@pytest.mark.parametrize(
    "dynamic_error",
    [
        StaleElementReferenceException("postback replaced control"),
        WebDriverException("Node with given id does not belong to the document"),
    ],
)
def test_postback_wait_retries_dynamic_node_until_target_state(dynamic_error):
    class Driver:
        current_url = "https://www.eplanning.scot/proposal"

    driver = Driver()
    portal = SeleniumProposalPortal(driver, HOUSEHOLDER)
    states = iter((dynamic_error, True))

    def condition(_driver):
        state = next(states)
        if isinstance(state, Exception):
            raise state
        return state

    def wait(predicate, timeout=None):
        assert predicate(driver) is False
        assert predicate(driver) is True
        return True

    portal._wait = wait
    portal._wait_postback(object(), condition, "Ownership 25%")


def test_open_existing_proposal_skips_invalid_text_candidate_then_opens_exact_card():
    class OpenControl:
        text = "12 Rowan Road, Glasgow, G1 1AA"

        def __init__(self):
            self.clicked = False

        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

        def get_attribute(self, name):
            return self.text if name == "value" else ""

        def click(self):
            self.clicked = True

    control = OpenControl()

    class Container:
        text = "Proposal Reference: 500000123\n12 Rowan Road, Glasgow, G1 1AA"

        def find_elements(self, _by, _locator):
            return [control]

    container = Container()

    class ReferenceNode:
        text = "Proposal Reference: 500000123"

        def __init__(self, valid):
            self.valid = valid

        def find_element(self, _by, _locator):
            if not self.valid:
                raise NoSuchElementException("unrelated duplicate text")
            return container

    class Driver:
        current_url = "https://www.eplanning.scot/proposals"

        def find_elements(self, _by, _locator):
            return [ReferenceNode(False), ReferenceNode(True)]

    portal = SeleniumProposalPortal(Driver(), HOUSEHOLDER)
    portal._open_proposal_list = lambda: None

    portal.open_existing_proposal("500000123", "12 Rowan Road, Glasgow, G1 1AA")

    assert control.clicked is True

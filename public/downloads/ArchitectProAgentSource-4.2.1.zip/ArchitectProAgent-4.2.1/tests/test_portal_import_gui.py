import json
import os
import sys
import tempfile
import unittest
from unittest.mock import patch


os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from PySide6.QtWidgets import QApplication

from gui.app import BuildingWarrantApp
from gui.controllers import preflight_controller
from gui.services import portal_answers, storage_paths


class PortalImportGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt_app = QApplication.instance() or QApplication([])

    def test_complete_v2_job_replaces_stale_widgets_and_saves_reviewed_mapping(self):
        fixture_path = os.path.join(
            ROOT,
            "tests",
            "fixtures",
            "automation-job-v2-building-warrant.json",
        )
        with open(fixture_path, encoding="utf-8") as handle:
            snapshot = json.load(handle)
        job = {
            "id": snapshot["metadata"]["jobId"],
            "projectId": snapshot["metadata"]["projectId"],
            "title": snapshot["project"]["name"],
            "type": snapshot["metadata"]["applicationType"],
            "status": "READY",
            "dataSnapshot": snapshot,
        }

        with tempfile.TemporaryDirectory() as temp, patch.dict(
            os.environ,
            {"APPDATA": temp},
        ):
            document_folder = os.path.join(temp, "downloaded")
            os.makedirs(document_folder)
            documents = []
            for document in snapshot["documents"]:
                path = os.path.join(document_folder, document["filename"])
                with open(path, "wb") as handle:
                    handle.write(b"%PDF-1.4\n%%EOF")
                documents.append({
                    **document,
                    "type": document["categoryKey"],
                    "localPath": path,
                    "localName": document["filename"],
                })

            window = BuildingWarrantApp(portal_answers.BUILDING_WARRANT_TYPE)
            try:
                window.input_fields["Email"].setText("local@example.com")
                window.input_fields["Password"].setText("local-password")
                window.input_fields["Description of Work"].setPlainText(
                    "STALE LOCAL DESCRIPTION"
                )
                window.input_fields["Estimated Work Value"].setText("99999")
                window.applicant_line_edits["Applicant First Name"].setText(
                    "STALE APPLICANT"
                )
                window.agent_line_edits["Agent First Name"].setText("STALE AGENT")
                window.cert_line_edits["Name of Certifier"].setText("STALE CERTIFIER")

                window.portal_job = job
                window.downloaded_documents = documents
                window.download_failures = []
                window.load_from_portal_job()

                values = window.collect_user_inputs()
                self.assertEqual(
                    values["Description of Work"],
                    "Snapshot Integration Description",
                )
                self.assertEqual(values["Estimated Work Value"], "23456")
                self.assertEqual(values["Applicant First Name"], "Integration")
                self.assertEqual(values["Applicant Last Name"], "Test")
                self.assertEqual(values["Agent First Name"], "Avery")
                self.assertEqual(values["Name of Certifier"], "Casey Certifier")
                self.assertEqual(values["Email"], "local@example.com")
                self.assertEqual(values["Password"], "local-password")
                self.assertTrue(
                    preflight_controller.build_preflight_report(window)["ready"]
                )
                self.assertTrue(window.start_button.isEnabled())
                self.assertEqual(
                    window.bucket_lists["location_plan"].count(),
                    1,
                )
                self.assertEqual(window.bucket_lists["existing"].count(), 1)
                self.assertEqual(window.bucket_lists["proposed"].count(), 1)
                self.assertEqual(window.bucket_lists["sections"].count(), 1)
                self.assertEqual(window.bucket_lists["specs"].count(), 1)
                self.assertTrue(window.is_mapping_currently_saved())
                self.assertEqual(window.portal_import_blocking_issues, [])

                with open(
                    storage_paths.runtime_path("supporting_docs.json"),
                    encoding="utf-8",
                ) as handle:
                    mapping = json.load(handle)["buckets"]
                self.assertEqual(
                    mapping["location_plan"],
                    ["INT-001 Location Plan.pdf"],
                )
                self.assertEqual(
                    mapping["existing"],
                    ["INT-101 Existing Plans.pdf"],
                )
                self.assertEqual(
                    mapping["proposed"],
                    ["INT-201 Proposed Plans.pdf"],
                )
                self.assertEqual(
                    mapping["sections"],
                    ["INT-301 Section A-A.pdf"],
                )
                self.assertEqual(
                    mapping["specs"],
                    ["INT-401 Outline Specification.pdf"],
                )
            finally:
                window.close()
                window.deleteLater()


if __name__ == "__main__":
    unittest.main()

from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from gui import agent_app
from gui.services import callback_outbox, portal_handoff
from automation.runner import AutomationResult


@pytest.fixture(autouse=True)
def isolated_outbox(tmp_path, monkeypatch):
    monkeypatch.setenv("APPDATA", str(tmp_path))


@pytest.mark.parametrize("response", [{}, {"ok": True}, {"ok": True, "status": "FAILED_RETRYABLE"}, None, "invalid"])
def test_unacknowledged_start_never_enters_runner(response, monkeypatch):
    runner = Mock()
    monkeypatch.setattr("automation.runner.run_automation", runner)
    client = SimpleNamespace(send_callback=Mock(return_value=response))
    thread = agent_app.AutomationThread(SimpleNamespace(job_id="job_start_123"), "secret", "AUTO", client)
    rejected = []
    thread.start_rejected.connect(rejected.append)
    thread.run()
    runner.assert_not_called()
    assert rejected and thread.password == ""
    assert len({call.args[1]["callbackId"] for call in client.send_callback.call_args_list}) == 1
    client.send_callback.reset_mock()
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(portal_handoff, "get_job_access_token", lambda _job: "test")
        patch.setattr(portal_handoff, "PortalClient", lambda *_args: client)
        callback_outbox.retry_pending()
    client.send_callback.assert_not_called()


def test_lost_ack_retries_same_start_and_enters_runner_once(monkeypatch):
    result = AutomationResult("success", "job_start_123", "HOUSEHOLDER_PLANNING", "Prepared", "final_review")
    runner = Mock(return_value=result)
    monkeypatch.setattr("automation.runner.run_automation", runner)
    client = SimpleNamespace(send_callback=Mock(side_effect=[
        portal_handoff.PortalHandoffError("response lost"),
        {"ok": True, "duplicate": True, "status": "IN_PROGRESS"},
        {"ok": True, "status": "COMPLETED"},
    ]))
    thread = agent_app.AutomationThread(SimpleNamespace(job_id="job_start_123"), "secret", "AUTO", client)
    thread.run()
    thread.run()
    runner.assert_called_once()
    calls = client.send_callback.call_args_list
    assert calls[0].args[1] == calls[1].args[1]
    assert callback_outbox.pending_events() == []


def test_terminal_job_cannot_start_or_replay_from_result_action():
    from tests.test_agent_gui import make_window, runtime_job, result
    window = make_window()
    try:
        window.runtime_job = runtime_job()
        window.on_completed(result("failure"))
        window.start_automation()
        assert window.automation_thread is None
        window.open_project_for_retry = Mock()
        window._result_action = "retry"
        window.handle_result_action()
        window.open_project_for_retry.assert_called_once()
        window.return_to_ready()
        assert not window._can_start_job()
        window._retired_job_ids.clear()
        window.portal_job["status"] = "FAILED_RETRYABLE"
        assert not window._can_start_job()
    finally:
        window.close()


def test_outbox_write_failure_cannot_start_selenium(monkeypatch):
    runner = Mock()
    monkeypatch.setattr("automation.runner.run_automation", runner)
    monkeypatch.setattr(callback_outbox, "save_event", Mock(side_effect=OSError("disk unavailable")))
    client = SimpleNamespace(send_callback=Mock())
    thread = agent_app.AutomationThread(SimpleNamespace(job_id="job_start_123"), "secret", "AUTO", client)
    rejected = []
    thread.start_rejected.connect(rejected.append)
    thread.run()
    runner.assert_not_called()
    client.send_callback.assert_not_called()
    assert rejected and thread.password == ""

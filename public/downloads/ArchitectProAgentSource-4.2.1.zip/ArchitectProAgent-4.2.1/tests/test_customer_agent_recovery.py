from types import SimpleNamespace
from unittest.mock import Mock
import pytest
from gui.services import agent_connection, background_agent, portal_handoff, secure_credentials


@pytest.fixture
def storage(monkeypatch, tmp_path):
    monkeypatch.setenv("APPDATA", str(tmp_path))
    values = {"agent": "apa_old", "portal": "portal-password", "job": "job-token"}
    monkeypatch.setattr(secure_credentials, "get_agent_credential", lambda: (values["agent"], True, ""))
    monkeypatch.setattr(secure_credentials, "delete_agent_credential", lambda: (values.update(agent=None) or True, ""))
    monkeypatch.setattr(secure_credentials, "save_agent_credential", lambda value: (values.update(agent=value) or True, ""))
    return values


@pytest.mark.parametrize("status", [None, 401, 403])
def test_reset_preserves_installation_and_unrelated_credentials(storage, status):
    identity = background_agent.installation_id()
    revoke = Mock(return_value={"ok": True}, side_effect=portal_handoff.PortalHandoffError("expired", status) if status else None)
    assert agent_connection.reset_connection(api_factory=lambda **_kwargs: SimpleNamespace(revoke_self=revoke)) == {"ok": True}
    revoke.assert_called_once()
    assert storage == {"agent": None, "portal": "portal-password", "job": "job-token"}
    assert background_agent.installation_id() == identity


@pytest.mark.parametrize("error", [portal_handoff.PortalHandoffError("offline"), portal_handoff.PortalHandoffError("busy", 409), portal_handoff.PortalHandoffError("unavailable", 500)])
def test_ambiguous_or_active_server_response_never_clears_credentials(storage, error):
    with pytest.raises(portal_handoff.PortalHandoffError, match="kept"):
        agent_connection.reset_connection(api_factory=lambda **_kwargs: SimpleNamespace(revoke_self=Mock(side_effect=error)))
    assert storage["agent"] == "apa_old"


def test_active_local_run_blocks_before_network(storage):
    api = Mock()
    with pytest.raises(portal_handoff.PortalHandoffError, match="Finish or release"):
        agent_connection.reset_connection(active_execution=True, api_factory=api)
    api.assert_not_called()
    assert storage["agent"] == "apa_old"


def test_credential_rotated_during_reset_is_not_deleted(storage):
    def revoke():
        storage["agent"] = "apa_another-enrollment"
        return {"ok": True}
    with pytest.raises(portal_handoff.PortalHandoffError, match="changed during reset"):
        agent_connection.reset_connection(api_factory=lambda **_kwargs: SimpleNamespace(revoke_self=revoke))
    assert storage["agent"] == "apa_another-enrollment"


def test_reset_reenroll_heartbeat_then_claim_existing_ready_job(storage, monkeypatch):
    identity = background_agent.installation_id()
    agent_connection.reset_connection(api_factory=lambda **_kwargs: SimpleNamespace(revoke_self=lambda: {"ok": True}))
    calls = []
    def request(_client, path, method="GET", payload=None):
        calls.append((path, payload))
        if path.endswith('/exchange'):
            assert payload["installationId"] == identity
            return {"credential": "apa_new"}
        if path.endswith('/heartbeat'):
            return {"ok": True}
        if path.endswith('/queue'):
            return {"jobs": [{"id": "existing_ready_job"}]}
        if path.endswith('/claim'):
            return {"jobAccessToken": "apd_existing_job"}
        raise AssertionError(path)
    monkeypatch.setattr(portal_handoff.PortalClient, "_request", request)
    monkeypatch.setattr(portal_handoff, "save_portal_url", lambda *_: None)
    monkeypatch.setattr(portal_handoff, "save_job_access_token", lambda *_: None)
    api = background_agent.AgentApi.enroll_pkce("https://architectpro.co.uk", "ape_test", "v" * 64, identity)
    assert storage["agent"] == "apa_new"
    engine = background_agent.PollingEngine(api_factory=lambda: api)
    claimed, _ = engine.tick()
    assert claimed["job_id"] == "existing_ready_job"
    assert background_agent.installation_id() == identity
    assert calls[-3][0].endswith('/heartbeat')
    assert not any('restart' in path for path, _ in calls)


def test_connection_status_is_authenticated_and_survives_job_ui_refresh():
    from tests.test_agent_gui import make_window, runtime_job
    window = make_window()
    try:
        window.runtime_job = runtime_job()
        window.on_background_connection_state('READY', 'Connected')
        assert window.connection.text() == '● Connected'
        window.on_background_connection_state('AUTH_REQUIRED', 'revoked')
        window.show_ready()
        assert 'Connection needs attention' in window.connection.text()
        assert window.reset_button.isVisible()
        window.on_background_connection_state('OFFLINE', 'unavailable')
        assert 'Offline' in window.connection.text()
        window.on_background_connection_state('READY', 'Connected')
        assert window.connection.text() == '● Connected'
        window.automation_thread = SimpleNamespace(isRunning=lambda: True)
        assert window._has_active_execution()
        window.automation_thread = None
        window.portal_job = {"id": "queued", "status": "READY"}
        assert not window._has_active_execution()
    finally:
        window.close()


def test_reset_protocol_is_command_only():
    assert portal_handoff.is_agent_reset_launch('architectpro://reset-connection')
    for value in ['architectpro://reset-connection?token=secret', 'architectpro://reset-connection#secret', 'https://reset-connection', 'architectpro://reset-connection/another']:
        assert not portal_handoff.is_agent_reset_launch(value)
    assert agent_connection.connection_failure_state(portal_handoff.PortalHandoffError('revoked', 401)) == 'AUTH_REQUIRED'
    assert agent_connection.connection_failure_state(portal_handoff.PortalHandoffError('offline')) == 'OFFLINE'


def test_native_confirmed_reset_finishes_before_secure_reenrollment(storage, monkeypatch):
    from PySide6.QtCore import QCoreApplication, QEvent, QEventLoop, QTimer
    from PySide6.QtWidgets import QMessageBox
    from gui import agent_app
    from tests.test_agent_gui import make_window
    window = make_window()
    loop = QEventLoop()
    timeout = QTimer()
    timeout.setSingleShot(True)
    timeout.timeout.connect(loop.quit)
    enroll = Mock(side_effect=lambda **_kwargs: loop.quit())
    monkeypatch.setattr(window, 'begin_agent_enrollment', enroll)
    monkeypatch.setattr(QMessageBox, 'question', lambda *_args: QMessageBox.StandardButton.Yes)
    real_reset = agent_connection.reset_connection
    monkeypatch.setattr(agent_connection, 'reset_connection', lambda: real_reset(api_factory=lambda **_kwargs: SimpleNamespace(revoke_self=lambda: {'ok': True})))
    identity = background_agent.installation_id()
    try:
        window.portal_job = {'id': 'existing_ready_job', 'status': 'READY'}
        window.reset_agent_connection()
        timeout.start(2000)
        loop.exec()
        enroll.assert_called_once_with(force=True)
        assert not window.reset_thread.isRunning()
        assert window.reset_button.isEnabled()
        assert storage['agent'] is None
        assert storage['portal'] == 'portal-password'
        assert background_agent.installation_id() == identity
    finally:
        timeout.stop()
        if window.reset_thread:
            window.reset_thread.wait(2000)
        window.close()
        window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)


def test_reset_worker_rechecks_inflight_claim_before_touching_credential(storage, monkeypatch):
    from PySide6.QtCore import QCoreApplication, QEvent
    from gui import agent_app
    background = SimpleNamespace(isRunning=lambda: False, engine=SimpleNamespace(current_job_id='claimed_during_stop', pending_release=None))
    worker = agent_app.AgentResetThread(background)
    failures = []
    worker.failed.connect(lambda message, state: failures.append((message, state)))
    reset = Mock()
    monkeypatch.setattr(agent_connection, 'reset_connection', reset)
    worker.run()
    assert 'Finish or release' in failures[0][0]
    reset.assert_not_called()
    assert storage['agent'] == 'apa_old'
    worker.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)

from collections import Counter

import pytest
from selenium.common.exceptions import (
    ElementNotInteractableException,
    NoSuchElementException,
    StaleElementReferenceException,
)
from selenium.webdriver.common.by import By

from automation.common import declaration
from automation.common.handoff import FEE_HANDOFF
from automation.building_warrant import run as building_warrant_run
from automation.householder import run as householder_run


class PortalElement:
    def __init__(self, driver, element_id, generation):
        self.driver = driver
        self.element_id = element_id
        self.generation = generation

    def _check_stale(self):
        if self.generation != self.driver.generation:
            raise StaleElementReferenceException("ASP.NET postback replaced this element")

    def is_displayed(self):
        self._check_stale(); return True

    def is_enabled(self):
        self._check_stale(); return True

    def is_selected(self):
        self._check_stale(); return self.driver.checked[self.element_id]

    def click(self):
        self._check_stale()
        self.driver.clicks[self.element_id] += 1
        self.driver.actions.append(("click", self.element_id))
        if self.element_id in {
            declaration.RD1_CHECKBOX_ID,
            declaration.RD2_CHECKBOX_ID,
            declaration.BW_ACCEPT_CHECKBOX_ID,
        }:
            self.driver.checked[self.element_id] = not self.driver.checked[self.element_id]
            return
        transitions = {
            declaration.DECLARATION_BUTTON_ID: getattr(
                self.driver, "declaration_destination", "rd1"
            ),
            declaration.RD1_NEXT_ID: "rd2",
            declaration.BW_FIRST_NEXT_ID: "rd2",
            declaration.RD2_NEXT_ID: "rd3",
            declaration.RD3_NEXT_ID: "summary_fee",
            declaration.FEE_BUTTON_ID: self.driver.fee_destination,
        }
        destination = transitions.get(self.element_id)
        if destination and self.element_id not in self.driver.uncertain_buttons:
            self.driver.phase = destination
            self.driver.generation += 1
            if destination == "fee":
                self.driver.current_url = "https://portal.example/CustomPages/Applications/Fee.aspx"


class PortalDriver:
    def __init__(self, *, rd1_checked=False, rd2_checked=False, fee_destination="fee"):
        self.phase = "summary"
        self.generation = 0
        self.current_url = "https://portal.example/FormSummary.aspx"
        self.fee_destination = fee_destination
        self.checked = {
            declaration.RD1_CHECKBOX_ID: rd1_checked,
            declaration.RD2_CHECKBOX_ID: rd2_checked,
        }
        self.clicks = Counter()
        self.finds = Counter()
        self.actions = []
        self.uncertain_buttons = set()

    def execute_script(self, script, *arguments):
        if "document.readyState" in script:
            return "complete"
        if "return Boolean" in script:
            return arguments[0].is_selected()
        if "checked = true" in script:
            self.checked[arguments[0].element_id] = True
            return None
        if "arguments[0].click()" in script:
            arguments[0].click()
            return None
        return None

    def _available(self):
        return {
            "summary": {declaration.DECLARATION_BUTTON_ID},
            "rd1": {declaration.RD1_CHECKBOX_ID, declaration.RD1_NEXT_ID},
            "rd2": {declaration.RD2_CHECKBOX_ID, declaration.RD2_NEXT_ID},
            "rd3": {declaration.RD3_NEXT_ID},
            "summary_fee": {
                declaration.DECLARATION_BUTTON_ID,
                declaration.FEE_BUTTON_ID,
            },
            "fee": set(),
            "unknown": set(),
        }[self.phase]

    def find_element(self, by, value):
        assert by == By.ID
        self.finds[value] += 1
        if value not in self._available():
            raise NoSuchElementException(value)
        return PortalElement(self, value, self.generation)

    def find_elements(self, by, value):
        if by == By.ID:
            try:
                return [self.find_element(by, value)]
            except NoSuchElementException:
                return []
        if self.phase == "fee" and by in {By.CSS_SELECTOR, By.XPATH}:
            return [object()]
        return []


@pytest.mark.parametrize("already_checked", [False, True])
def test_householder_completes_declaration_idempotently_and_reacquires_controls(already_checked):
    driver = PortalDriver(rd1_checked=already_checked, rd2_checked=already_checked)
    events = []
    selectors = declaration.complete_declaration(
        driver,
        householder_run.HOUSEHOLDER,
        progress=lambda *event: events.append(event),
        timeout=0.2,
    )
    assert selectors.enter == "MainContent_FormSections_btnDeclaration"
    assert driver.phase == "summary_fee"
    assert driver.clicks[declaration.RD1_CHECKBOX_ID] == (0 if already_checked else 1)
    assert driver.clicks[declaration.RD2_CHECKBOX_ID] == (0 if already_checked else 1)
    assert driver.clicks[declaration.RD1_NEXT_ID] == 1
    assert driver.clicks[declaration.RD2_NEXT_ID] == 1
    assert driver.clicks[declaration.RD3_NEXT_ID] == 1
    assert driver.clicks[declaration.FEE_BUTTON_ID] == 0
    assert driver.finds[declaration.RD2_CHECKBOX_ID] >= 2
    assert any(event[0] == "declaration.complete" for event in events)


def test_declaration_mapping_accepts_canonical_and_actual_workflow_types():
    planning = declaration.declaration_selectors_for("HOUSEHOLDER_PLANNING")
    warrant = declaration.declaration_selectors_for("BUILDING_WARRANT")

    assert declaration.declaration_selectors_for(householder_run.HOUSEHOLDER) is planning
    assert declaration.declaration_selectors_for(building_warrant_run.BUILDING_WARRANT) is warrant
    assert declaration.declaration_selectors_for("  householder_planning  ") is planning
    assert declaration.declaration_selectors_for("building warrant") is warrant
    assert planning == declaration.DeclarationSelectors(
        enter="MainContent_FormSections_btnDeclaration",
        rd1_checkbox="MainContent_DeclarationWizard_cbAcceptRD1",
        rd1_next="MainContent_DeclarationWizard_btnNextRD1",
        rd2_checkbox="MainContent_DeclarationWizard_cbComplete",
        rd2_next="MainContent_DeclarationWizard_btnNextRD2",
        rd3_next="MainContent_DeclarationWizard_btnNextRD3",
        fee="MainContent_FormSections_btnFee",
    )
    assert warrant == declaration.DeclarationSelectors(
        enter="MainContent_FormSections_btnDeclaration",
        rd1_checkbox="MainContent_DeclarationWizard_cbAcceptBW",
        rd1_next="MainContent_DeclarationWizard_btnNextBW",
        rd2_checkbox="MainContent_DeclarationWizard_cbComplete",
        rd2_next="MainContent_DeclarationWizard_btnNextRD2",
        rd3_next="MainContent_DeclarationWizard_btnNextRD3",
        fee="MainContent_FormSections_btnFee",
        person_dropdown="MainContent_DeclarationWizard_ddlBuildingWarrant1",
        ownership_dropdown="MainContent_DeclarationWizard_ddlBuildingWarrant2",
    )


def test_declaration_mapping_rejects_unsupported_application_type():
    with pytest.raises(ValueError, match="not configured.*COMMERCIAL_PLANNING"):
        declaration.declaration_selectors_for("COMMERCIAL_PLANNING")


@pytest.mark.parametrize("element_id", [declaration.RD1_CHECKBOX_ID, declaration.RD2_CHECKBOX_ID])
def test_declaration_checkbox_reuses_safe_existing_input_setter_and_never_toggles_checked(
    monkeypatch, element_id
):
    driver = PortalDriver()
    driver.phase = "rd1" if element_id == declaration.RD1_CHECKBOX_ID else "rd2"
    calls = []

    def safe_setter(current, current_id, label, timeout):
        calls.append((current, current_id, label, timeout))
        current.checked[current_id] = True

    monkeypatch.setattr(declaration, "select_option_by_id", safe_setter)
    declaration.ensure_checkbox_checked(driver, element_id, timeout=0.2)
    assert [call[1] for call in calls] == [element_id]
    assert driver.checked[element_id] is True

    declaration.ensure_checkbox_checked(driver, element_id, timeout=0.2)
    assert [call[1] for call in calls] == [element_id]


def test_existing_input_setter_handles_natively_non_interactable_declaration_checkbox():
    class HiddenCheckbox:
        checked = False

        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

        def is_selected(self):
            return self.checked

        def click(self):
            raise ElementNotInteractableException("portal input is covered")

    class Driver:
        def __init__(self):
            self.checkbox = HiddenCheckbox()

        def find_element(self, _by, _value):
            return self.checkbox

        def find_elements(self, _by, _value):
            return [self.checkbox]

        def execute_script(self, script, *arguments):
            if "document.readyState" in script:
                return "complete"
            if "arguments[0].click()" in script:
                arguments[0].checked = True
            if "checked = true" in script:
                arguments[0].checked = True
            if "return Boolean" in script:
                return arguments[0].checked
            return None

    driver = Driver()
    declaration.ensure_checkbox_checked(driver, declaration.RD1_CHECKBOX_ID, timeout=0.2)
    assert driver.checkbox.checked is True


def test_uncertain_declaration_next_is_not_clicked_twice():
    driver = PortalDriver()
    driver.phase = "rd1"
    driver.uncertain_buttons.add(declaration.RD1_NEXT_ID)
    with pytest.raises(declaration.DeclarationHandoffError, match="did not confirm advancement"):
        declaration._advance_once(driver, declaration.RD1_NEXT_ID, declaration.RD2_CHECKBOX_ID, timeout=0.01)
    assert driver.clicks[declaration.RD1_NEXT_ID] == 1


class SelectedOption:
    def __init__(self, value):
        self.value = value
        self.text = value

    def get_attribute(self, name):
        return self.value if name == "value" else None


class PortalSelect:
    def __init__(self, element):
        self.element = element

    @property
    def first_selected_option(self):
        self.element._check_stale()
        return SelectedOption(self.element.driver.selected[self.element.element_id])

    def select_by_value(self, value):
        self.element._check_stale()
        driver = self.element.driver
        element_id = self.element.element_id
        driver.selects[element_id] += 1
        driver.actions.append(("select", element_id, value))
        driver.selected[element_id] = value
        # Model the ASP.NET replacement seen after changing a wizard dropdown.
        driver.generation += 1


class BuildingWarrantPortalDriver(PortalDriver):
    def __init__(self, *, accept_checked=False, complete_checked=False):
        super().__init__(rd2_checked=complete_checked)
        self.declaration_destination = "bw1"
        self.checked[declaration.BW_ACCEPT_CHECKBOX_ID] = accept_checked
        self.selected = {
            declaration.BW_PERSON_ID: "",
            declaration.BW_OWNERSHIP_ID: "",
        }
        self.selects = Counter()

    def _available(self):
        return {
            "summary": {declaration.DECLARATION_BUTTON_ID},
            "bw1": {
                declaration.BW_PERSON_ID,
                declaration.BW_OWNERSHIP_ID,
                declaration.BW_ACCEPT_CHECKBOX_ID,
                declaration.BW_FIRST_NEXT_ID,
            },
            "rd2": {declaration.RD2_CHECKBOX_ID, declaration.RD2_NEXT_ID},
            "rd3": {declaration.RD3_NEXT_ID},
            "summary_fee": {
                declaration.DECLARATION_BUTTON_ID,
                declaration.FEE_BUTTON_ID,
            },
            "fee": set(),
            "unknown": set(),
        }[self.phase]


@pytest.mark.parametrize(
    ("user_inputs", "person", "ownership"),
    [
        ({"Applicant Is Owner": True}, "I", declaration.BW_SINGLE_OWNER),
        ({"Applicant Is Owner": False}, "I", declaration.BW_NON_OWNER),
        (
            {"Applicant Is Owner": True, "Applicant Company": "Joint Owner Ltd"},
            "We",
            declaration.BW_PLURAL_OWNER,
        ),
    ],
)
def test_building_warrant_uses_exact_dropdowns_then_returns_to_main_page(
    monkeypatch, user_inputs, person, ownership
):
    monkeypatch.setattr(declaration, "Select", PortalSelect)
    driver = BuildingWarrantPortalDriver()
    events = []

    selectors = declaration.complete_declaration(
        driver,
        building_warrant_run.BUILDING_WARRANT,
        user_inputs=user_inputs,
        progress=lambda *event: events.append(event),
        timeout=0.2,
    )

    assert selectors.person_dropdown == declaration.BW_PERSON_ID
    assert driver.selected == {
        declaration.BW_PERSON_ID: person,
        declaration.BW_OWNERSHIP_ID: ownership,
    }
    assert driver.phase == "summary_fee"
    assert driver.clicks[declaration.BW_ACCEPT_CHECKBOX_ID] == 1
    assert driver.clicks[declaration.BW_FIRST_NEXT_ID] == 1
    assert driver.clicks[declaration.RD2_CHECKBOX_ID] == 1
    assert driver.clicks[declaration.RD2_NEXT_ID] == 1
    assert driver.clicks[declaration.RD3_NEXT_ID] == 1
    assert driver.clicks[declaration.FEE_BUTTON_ID] == 0
    assert driver.finds[declaration.BW_OWNERSHIP_ID] >= 2
    assert driver.finds[declaration.RD2_CHECKBOX_ID] >= 2
    assert [event[0] for event in events if event[1] == "running"] == [
        "declaration.open",
        "declaration.person",
        "declaration.ownership",
        "declaration.accept",
        "declaration.next_1",
        "declaration.complete",
        "declaration.next_2",
        "declaration.next_3",
    ]

    result = declaration.open_fee_and_handoff(
        driver,
        building_warrant_run.BUILDING_WARRANT,
        declaration_complete=True,
        timeout=0.2,
    )
    assert result is FEE_HANDOFF
    assert result.stage == "fee"
    assert driver.phase == "fee"
    assert driver.clicks[declaration.FEE_BUTTON_ID] == 1


def test_building_warrant_checked_boxes_are_not_clicked_again(monkeypatch):
    monkeypatch.setattr(declaration, "Select", PortalSelect)
    driver = BuildingWarrantPortalDriver(accept_checked=True, complete_checked=True)

    declaration.complete_declaration(
        driver,
        building_warrant_run.BUILDING_WARRANT,
        user_inputs={"Applicant Is Owner": True},
        timeout=0.2,
    )

    assert driver.clicks[declaration.BW_ACCEPT_CHECKBOX_ID] == 0
    assert driver.clicks[declaration.RD2_CHECKBOX_ID] == 0


def test_uncertain_building_warrant_next_is_not_clicked_twice():
    driver = BuildingWarrantPortalDriver()
    driver.phase = "bw1"
    driver.uncertain_buttons.add(declaration.BW_FIRST_NEXT_ID)

    with pytest.raises(declaration.DeclarationHandoffError, match="did not confirm advancement"):
        declaration._advance_once(
            driver,
            declaration.BW_FIRST_NEXT_ID,
            declaration.RD2_CHECKBOX_ID,
            timeout=0.01,
        )

    assert driver.clicks[declaration.BW_FIRST_NEXT_ID] == 1


def test_fee_requires_declaration_and_positive_page_confirmation():
    driver = PortalDriver()
    driver.phase = "summary_fee"
    with pytest.raises(declaration.DeclarationHandoffError, match="before Declaration"):
        declaration.open_fee_and_handoff(driver, "HOUSEHOLDER_PLANNING", declaration_complete=False)
    assert driver.clicks[declaration.FEE_BUTTON_ID] == 0

    driver.fee_destination = "unknown"
    with pytest.raises(declaration.DeclarationHandoffError, match="did not confirm"):
        declaration.open_fee_and_handoff(
            driver, "HOUSEHOLDER_PLANNING", declaration_complete=True, timeout=0.01
        )
    assert driver.clicks[declaration.FEE_BUTTON_ID] == 1


@pytest.mark.parametrize("application_type", ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"])
def test_verified_fee_returns_common_user_action_without_populating_fee(application_type):
    driver = PortalDriver()
    driver.phase = "summary_fee"
    result = declaration.open_fee_and_handoff(
        driver, application_type, declaration_complete=True, timeout=0.2
    )
    assert result is FEE_HANDOFF
    assert result.stage == "fee"
    assert driver.phase == "fee"
    assert driver.clicks == Counter({declaration.FEE_BUTTON_ID: 1})

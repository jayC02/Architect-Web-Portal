import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from PySide6.QtWidgets import QApplication
from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException

from automation.common import forms
from automation.runner import ProgressStatus, run_automation
from gui import agent_app
from gui.services import portal_handoff


TITLE_ID = "ApplicantTitle"
FIRST_NAME_ID = "ApplicantFirstName"
OTHER_TITLE_ID = "ApplicantOtherTitle"


class Element:
    def __init__(self, driver, kind, generation=None):
        self.driver = driver
        self.kind = kind
        self.generation = driver.generation if generation is None else generation

    def _assert_live(self):
        if self.generation != self.driver.generation:
            raise StaleElementReferenceException("the portal rerendered")

    def is_enabled(self):
        self._assert_live()
        return True

    def is_displayed(self):
        self._assert_live()
        return self.kind != "other" or self.driver.title == "Other"

    def clear(self):
        self._assert_live()
        self.driver.other_title = ""

    def send_keys(self, value):
        self._assert_live()
        self.driver.other_title = value

    def get_attribute(self, name):
        self._assert_live()
        return self.driver.other_title if self.kind == "other" and name == "value" else None


class Driver:
    def __init__(self):
        self.generation = 0
        self.title = "Please Select One"
        self.other_title = ""
        self.title_elements = []
        self.other_elements = []

    def find_element(self, _by, locator):
        if locator == TITLE_ID:
            element = Element(self, "title")
            self.title_elements.append(element)
            return element
        if locator == FIRST_NAME_ID:
            return Element(self, "first")
        if locator == OTHER_TITLE_ID or "other title" in str(locator).lower():
            if self.title != "Other":
                raise NoSuchElementException()
            element = Element(self, "other")
            self.other_elements.append(element)
            return element
        raise NoSuchElementException(locator)

    def execute_script(self, script, *_args):
        return "complete" if "document.readyState" in script else None


class Select:
    def __init__(self, element):
        self.element = element

    @property
    def first_selected_option(self):
        self.element._assert_live()
        return SimpleNamespace(text=self.element.driver.title)

    def select_by_visible_text(self, title):
        self.element._assert_live()
        self.element.driver.title = title
        self.element.driver.generation += 1


class Wait:
    def __init__(self, driver, _timeout, **_kwargs):
        self.driver = driver

    def until(self, condition):
        value = condition(self.driver)
        if not value:
            raise AssertionError("simulated portal condition was not satisfied")
        return value


@pytest.fixture(autouse=True)
def selenium_fakes(monkeypatch):
    monkeypatch.setattr(forms, "Select", Select)
    monkeypatch.setattr(forms, "WebDriverWait", Wait)
    monkeypatch.setattr(
        forms,
        "get_when_clickable",
        lambda driver, _by, locator, **_kwargs: driver.find_element(None, locator),
    )
    monkeypatch.setattr(forms, "wait_dom_ready", lambda *_args, **_kwargs: None)


def select(driver, title, *, other_title="", resolver=None, applicant_name="Alex Smith"):
    return forms.select_applicant_title(
        driver,
        TITLE_ID,
        title,
        FIRST_NAME_ID,
        other_title=other_title,
        other_title_element_ids=(OTHER_TITLE_ID,),
        resolver=resolver,
        applicant_name=applicant_name,
    )


def test_supported_and_formatting_only_titles_do_not_prompt():
    for supplied, expected in (("Ms", "Ms"), ("mr.", "Mr")):
        driver = Driver()
        prompts = []
        assert select(driver, supplied, resolver=lambda request: prompts.append(request)) == expected
        assert driver.title == expected
        assert prompts == []


def test_explicit_unsupported_title_populates_other_after_reacquiring_live_dom():
    driver = Driver()
    assert select(driver, "Professor") == "Other"
    assert driver.title == "Other"
    assert driver.other_title == "Professor"
    assert driver.title_elements[0].generation == 0
    assert driver.other_elements
    assert all(element.generation == 1 for element in driver.other_elements)


def test_literal_other_requires_explicit_non_placeholder_other_title():
    driver = Driver()
    requests = []

    def resolve(request):
        requests.append(request)
        return {"action": "select", "title": "Other", "other_title": "Professor"}

    assert select(driver, "Other", resolver=resolve) == "Other"
    assert requests == [{
        "stage": "applicant_details",
        "applicant_name": "Alex Smith",
        "options": ["Mr", "Mrs", "Miss", "Ms", "Other"],
        "selected_title": "Other",
    }]
    assert driver.other_title == "Professor"

    with pytest.raises(forms.ApplicantTitleResolutionRequired):
        select(Driver(), "Other", resolver=lambda _request: {
            "action": "select", "title": "Other", "other_title": "Other",
        })


def test_missing_title_never_infers_from_applicant_name():
    requests = []
    driver = Driver()
    assert select(
        driver,
        "",
        applicant_name="Mr Smith",
        resolver=lambda request: requests.append(request) or {
            "action": "select", "title": "Ms", "other_title": "",
        },
    ) == "Ms"
    assert driver.title == "Ms"
    assert driver.other_title == ""
    assert requests[0]["applicant_name"] == "Mr Smith"


def test_blank_other_title_cannot_continue_without_a_resolver():
    with pytest.raises(forms.ApplicantTitleResolutionRequired):
        select(Driver(), "Other", other_title="   ")


def test_explicit_snapshot_other_title_is_forwarded_without_prompting():
    fixture = Path(__file__).parent / "fixtures" / "automation-job-v2-building-warrant.json"
    snapshot = json.loads(fixture.read_text(encoding="utf-8"))
    snapshot["applicant"]["title"] = "Other"
    snapshot["applicant"]["otherTitle"] = "Professor"
    values = portal_handoff.portal_job_to_values({
        "id": snapshot["metadata"]["jobId"],
        "projectId": snapshot["metadata"]["projectId"],
        "type": snapshot["metadata"]["applicationType"],
        "dataSnapshot": snapshot,
    })
    assert values["Applicant Title"] == "Other"
    assert values["Applicant Other Title"] == "Professor"


def test_agent_dialog_blocks_blank_or_placeholder_other_title():
    QApplication.instance() or QApplication([])
    dialog = agent_app.ApplicantTitleDialog({
        "applicant_name": "Alex Smith",
        "options": ["Mr", "Mrs", "Miss", "Ms", "Other"],
        "selected_title": "Other",
    })
    try:
        assert dialog.other_title.isHidden() is False
        assert dialog.continue_button.isEnabled() is False
        dialog.other_title.setText("Other")
        assert dialog.continue_button.isEnabled() is False
        dialog.other_title.setText("Professor")
        assert dialog.continue_button.isEnabled() is True
        dialog.accept_selection()
        assert dialog.response == {
            "action": "select",
            "title": "Other",
            "other_title": "Professor",
        }
    finally:
        dialog.close()


class ManagedDriver:
    def __init__(self):
        self.driver = object()
        self.started = 0
        self.handoffs = 0
        self.closed = []

    def start(self):
        self.started += 1
        return self.driver

    def handoff_to_user(self):
        self.handoffs += 1

    def close(self, *, preserve_visible=False):
        self.closed.append(preserve_visible)


def test_runner_pauses_and_resumes_title_recovery_in_same_browser_session():
    managed = ManagedDriver()
    seen_drivers = []
    events = []

    def workflow(**kwargs):
        seen_drivers.append(kwargs["driver"])
        response = kwargs["applicant_title_resolution_callback"]({
            "stage": "applicant_details",
            "applicant_name": "Alex Smith",
            "options": ["Mr", "Mrs", "Miss", "Ms", "Other"],
            "selected_title": "Other",
        })
        assert response == {
            "action": "select",
            "title": "Other",
            "other_title": "Professor",
        }
        seen_drivers.append(kwargs["driver"])

    result = run_automation(
        {
            "job_id": "job_title_123456",
            "application_type": "HOUSEHOLDER_PLANNING",
            "site_label": "10 High Street",
            "user_inputs": {"Email": "test@example.com", "PDF Folder Path": "C:/test"},
            "document_mapping": {"pdf_folder_path": "C:/test", "buckets": {}, "bucket_labels": {}},
        },
        password="secret",
        driver_factory=lambda _mode: managed,
        workflow_registry={"HOUSEHOLDER_PLANNING": workflow},
        progress_callback=events.append,
        applicant_title_resolution_callback=lambda _request: {
            "action": "select",
            "title": "Other",
            "other_title": "Professor",
        },
    )

    assert result.outcome == "success"
    assert managed.started == 1
    assert seen_drivers == [managed.driver, managed.driver]
    assert managed.handoffs == 1
    title_events = [event for event in events if event.stage == "applicant_details"]
    assert [event.status for event in title_events] == [
        ProgressStatus.USER_ACTION_REQUIRED,
        ProgressStatus.RUNNING,
    ]

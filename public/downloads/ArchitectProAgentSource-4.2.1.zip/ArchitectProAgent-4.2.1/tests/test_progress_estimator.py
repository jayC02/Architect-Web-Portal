import inspect
import json
from types import SimpleNamespace

from automation.progress import (
    DEFAULT_STAGE_SECONDS,
    ProgressEstimator,
    TimingHistoryStore,
    workflow_stages,
)


class Clock:
    def __init__(self):
        self.value = 0.0

    def __call__(self):
        return self.value

    def advance(self, seconds):
        self.value += seconds


def event(stage, status, message=""):
    return SimpleNamespace(stage=stage, status=SimpleNamespace(value=status), message=message)


def timings(application_type, seconds=10.0):
    values = {"overall": seconds * len(workflow_stages(application_type))}
    values.update({f"stage_{stage}": seconds for stage in workflow_stages(application_type)})
    return values


def test_stage_progress_is_monotonic_and_never_completes_before_success(tmp_path):
    clock = Clock()
    estimator = ProgressEstimator("HOUSEHOLDER_PLANNING", history=TimingHistoryStore(str(tmp_path / "history.json")), clock=clock)
    percents = []
    for stage in workflow_stages("HOUSEHOLDER_PLANNING"):
        estimator.consume(event(stage, "running"))
        clock.advance(2)
        percents.append(estimator.snapshot().progress_percent)
        percents.append(estimator.consume(event(stage, "completed")).progress_percent)
    assert percents == sorted(percents)
    assert max(percents) < 100
    assert estimator.complete(timings("HOUSEHOLDER_PLANNING")).progress_percent == 100


def test_snapshot_is_transportable_and_identifies_workflow_stage_state(tmp_path):
    estimator = ProgressEstimator("HOUSEHOLDER_PLANNING", history=TimingHistoryStore(str(tmp_path / "history.json")))
    snapshot = estimator.snapshot()
    payload = snapshot.as_payload()
    assert snapshot.progress_percent == 1
    assert payload["workflow"] == "planning"
    assert payload["stage"] == "validation"
    assert payload["stageLabel"] == "Starting automation…"
    assert payload["stageState"] == "running"
    assert payload["progressPercent"] == 1


def test_fee_handoff_reaches_100_percent_and_removes_eta(tmp_path):
    store = TimingHistoryStore(str(tmp_path / "history.json"))
    estimator = ProgressEstimator("HOUSEHOLDER_PLANNING", history=store)
    snapshot = estimator.handoff(timings("HOUSEHOLDER_PLANNING", 10.0))
    assert snapshot.status == "user_action_required"
    assert snapshot.stage == "fee"
    assert snapshot.progress_percent == 100
    assert snapshot.estimated_seconds_remaining is None
    assert store.has_successful_history("HOUSEHOLDER_PLANNING")


def test_building_warrant_declaration_checkpoints_render_as_user_progress(tmp_path):
    estimator = ProgressEstimator(
        "BUILDING_WARRANT",
        history=TimingHistoryStore(str(tmp_path / "history.json")),
    )
    estimator.consume(event("declaration", "running", "Completing declaration"))

    opening = estimator.consume(
        event("declaration.open", "running", "Opening declaration")
    )
    completing = estimator.consume(
        event("declaration.ownership", "running", "Setting declaration ownership")
    )
    legacy_fee = estimator.consume(event("fee.open", "running", "Opening fee"))

    assert opening.stage == "declaration"
    assert opening.message == "Opening declaration"
    assert completing.stage == "declaration"
    assert completing.message == "Setting declaration ownership"
    assert legacy_fee.stage == "final_review"
    assert legacy_fee.message == "Opening fee"


def test_address_selection_pauses_eta_without_completing_workflow_and_then_resumes(tmp_path):
    clock = Clock()
    estimator = ProgressEstimator(
        "HOUSEHOLDER_PLANNING",
        history=TimingHistoryStore(str(tmp_path / "history.json")),
        clock=clock,
    )
    estimator.consume(event("proposal", "running", "Opening proposal"))
    before = estimator.snapshot().progress_percent

    paused = estimator.consume(event(
        "address_selection",
        "user_action_required",
        "Select the correct property address to continue.",
    ))
    assert paused.status == "user_action_required"
    assert paused.progress_percent == before
    assert paused.estimated_seconds_remaining is None
    assert "fee" not in estimator.completed

    resumed = estimator.consume(event(
        "address_selection",
        "running",
        "Address confirmed. Continuing automation.",
    ))
    assert resumed.status == "running"
    assert resumed.stage == "proposal"


def test_planning_and_building_warrant_keep_independent_history(tmp_path):
    store = TimingHistoryStore(str(tmp_path / "history.json"))
    store.record_success("HOUSEHOLDER_PLANNING", timings("HOUSEHOLDER_PLANNING", 12.0))
    store.record_success("BUILDING_WARRANT", timings("BUILDING_WARRANT", 35.0))
    planning = store.expected_stage_seconds("HOUSEHOLDER_PLANNING")
    warrant = store.expected_stage_seconds("BUILDING_WARRANT")
    assert planning["documents"] == 12.0
    assert warrant["documents"] == 35.0
    assert "ownership" in planning
    assert "ownership" not in warrant
    assert workflow_stages("HOUSEHOLDER_PLANNING")[-2:] == ("declaration", "final_review")
    assert workflow_stages("BUILDING_WARRANT")[-2:] == ("declaration", "final_review")


def test_successful_history_replaces_first_run_defaults_and_is_rolling(tmp_path):
    store = TimingHistoryStore(str(tmp_path / "history.json"))
    initial = store.expected_stage_seconds("BUILDING_WARRANT")
    for seconds in range(1, 13):
        assert store.record_success("BUILDING_WARRANT", timings("BUILDING_WARRANT", float(seconds)))
    learned = store.expected_stage_seconds("BUILDING_WARRANT")
    persisted = store.load()["profiles"]["building_warrant"]
    assert initial == DEFAULT_STAGE_SECONDS["building_warrant"]
    assert learned["documents"] != initial["documents"]
    assert len(persisted) == 10


def test_slow_stage_holds_below_completion_and_can_increase_eta(tmp_path):
    clock = Clock()
    store = TimingHistoryStore(str(tmp_path / "history.json"))
    store.record_success("BUILDING_WARRANT", timings("BUILDING_WARRANT", 20.0))
    estimator = ProgressEstimator("BUILDING_WARRANT", history=store, clock=clock)
    for stage in ("validation", "browser", "login", "proposal", "main_details"):
        estimator.consume(event(stage, "running"))
        estimator.consume(event(stage, "completed"))
    estimator.consume(event("documents", "running"))
    expected = estimator.expected["documents"]
    clock.advance(expected)
    first = estimator.snapshot()
    clock.advance(expected)
    slower = estimator.snapshot()
    assert slower.estimated_seconds_remaining > first.estimated_seconds_remaining
    assert slower.progress_percent < 100


def test_failed_and_cancelled_runs_stop_without_polluting_history(tmp_path):
    path = tmp_path / "history.json"
    for status in ("failed", "cancelled"):
        clock = Clock()
        estimator = ProgressEstimator("BUILDING_WARRANT", history=TimingHistoryStore(str(path)), clock=clock)
        stopped = estimator.stop(status, "Stopped safely")
        clock.advance(300)
        assert stopped.status == status
        assert estimator.snapshot().progress_percent == stopped.progress_percent
    assert not path.exists()


def test_timing_persistence_is_anonymous_and_progress_layer_is_gui_independent(tmp_path):
    path = tmp_path / "history.json"
    store = TimingHistoryStore(str(path))
    unsafe_input = timings("HOUSEHOLDER_PLANNING") | {
        "client": "Jane Citizen",
        "project": "73 Blackhill Drive",
        "password": "secret",
    }
    store.record_success("HOUSEHOLDER_PLANNING", unsafe_input)
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)
    assert "Jane Citizen" not in text
    assert "Blackhill" not in text
    assert "secret" not in text
    assert set(data["profiles"]["planning"][0]) == {"overall", "stages"}

    import automation.progress as progress
    source = inspect.getsource(progress)
    assert "from gui" not in source
    assert "PySide" not in source


def test_empty_or_invalid_history_falls_back_safely(tmp_path):
    path = tmp_path / "history.json"
    path.write_text("not json", encoding="utf-8")
    assert TimingHistoryStore(str(path)).expected_stage_seconds("HOUSEHOLDER_PLANNING") == DEFAULT_STAGE_SECONDS["planning"]


def test_no_history_shows_estimating_but_recent_planning_run_predicts_about_two_minutes(tmp_path):
    empty = ProgressEstimator(
        "HOUSEHOLDER_PLANNING",
        history=TimingHistoryStore(str(tmp_path / "empty.json")),
    )
    assert empty.snapshot().estimated_seconds_remaining is None

    store = TimingHistoryStore(str(tmp_path / "planning.json"))
    observed = {
        "overall": 84.571,
        "stage_browser": 3.839,
        "stage_documents": 45.694,
        "stage_login": 5.168,
        "stage_main_details": 8.215,
        "stage_ownership": 4.22,
        "stage_proposal": 14.781,
    }
    assert store.record_success("HOUSEHOLDER_PLANNING", observed)
    learned = ProgressEstimator("HOUSEHOLDER_PLANNING", history=store)
    remaining = learned.snapshot().estimated_seconds_remaining
    assert 90 <= remaining <= 130

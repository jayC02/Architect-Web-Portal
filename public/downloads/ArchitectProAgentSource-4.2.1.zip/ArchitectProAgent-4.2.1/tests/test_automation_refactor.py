﻿import json
from types import SimpleNamespace

import pytest

import Building_Warrant
import Householder
from automation.building_warrant import run as building_warrant_run
from automation.common import actions, documents, runtime
from automation.common.uploads import wait_for_supporting_doc_upload_result
from automation.householder import documents as householder_documents
from automation.householder.documents import (
    HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS,
    complete_later_householder_sections,
    complete_email_notification,
    householder_electronic_document_ids,
    normalise_supporting_document_description,
    normalise_supporting_document_title,
    LOCATION_PLAN_ANNOTATED_ID,
    LOCATION_PLAN_CONTINUE_ID,
    LOCATION_PLAN_OPTIONS_CONTINUE_ID,
    LOCATION_PLAN_SECTION_ID,
    LOCATION_PLAN_UPLOADED_ID,
    load_prepared_householder_documents,
    prepare_supporting_document_upload,
    prepare_location_plan_upload,
    upload_location_plan,
)
from automation.householder.main_details import complete_householder_main_details

from gui.controllers import preflight_controller
from gui.services import portal_answers


def test_compatibility_entrypoints_still_export_main_and_helpers():
    assert Building_Warrant.main is building_warrant_run.main
    assert Building_Warrant.load_required_json is runtime.load_required_json
    assert Building_Warrant.create_chrome_driver is not None
    assert Householder.main is not None
    assert Householder.complete_householder_main_details is complete_householder_main_details




@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (True, "Yes"),
        (False, "No"),
        (" yes ", "Yes"),
        ("off", "No"),
        ("unknown", "No"),
    ],
)
def test_yes_no_answer_normalises_values(value, expected):
    assert actions.yes_no_answer({"Question": value}, "Question", default="No") == expected


def test_load_required_json_validates_object_and_required_keys(tmp_path):
    missing = tmp_path / "missing.json"
    with pytest.raises(RuntimeError, match="missing"):
        runtime.load_required_json(str(missing))

    invalid = tmp_path / "invalid.json"
    invalid.write_text("{not json", encoding="utf-8")
    with pytest.raises(RuntimeError, match="Invalid JSON"):
        runtime.load_required_json(str(invalid))

    data_file = tmp_path / "data.json"
    data_file.write_text(json.dumps({"Email": "user@example.com"}), encoding="utf-8")
    with pytest.raises(RuntimeError, match="missing key"):
        runtime.load_required_json(str(data_file), required_keys=["PDF Folder Path"])

    assert runtime.load_required_json(str(data_file), required_keys=["Email"]) == {"Email": "user@example.com"}


def test_supporting_docs_upload_list_uses_mapping_order(monkeypatch, tmp_path):
    pdf_folder = tmp_path / "pdfs"
    pdf_folder.mkdir()
    for filename in ["location.pdf", "proposed.pdf", "existing.pdf", "photo.pdf"]:
        (pdf_folder / filename).write_text("not a real pdf, only path validation is needed", encoding="utf-8")

    mapping = {
        "pdf_folder_path": str(pdf_folder),
        "bucket_labels": {
            "proposed": "Proposed Plans",
            "existing": "Existing Plans",
            "photos": "Photos",
        },
        "buckets": {
            "location_plan": ["location.pdf"],
            "proposed": ["proposed.pdf"],
            "existing": ["existing.pdf"],
            "photos": ["photo.pdf"],
        },
    }
    mapping_path = tmp_path / "supporting_docs.json"
    mapping_path.write_text(json.dumps(mapping), encoding="utf-8")

    monkeypatch.setattr(documents, "SUPPORTING_DOCS_JSON", str(mapping_path))
    monkeypatch.setattr(documents.storage_paths, "migrate_json_if_missing", lambda *args, **kwargs: None)

    entries, location_plan, effective_folder, bucket_labels = documents.load_supporting_docs_upload_list("")

    assert entries == [
        ("proposed.pdf", "proposed"),
        ("existing.pdf", "existing"),
        ("photo.pdf", "photos"),
    ]
    assert location_plan == "location.pdf"
    assert effective_folder == str(pdf_folder)
    assert bucket_labels["proposed"] == "Proposed Plans"


def _write_householder_document_mapping(monkeypatch, tmp_path, location_files):
    pdf_folder = tmp_path / "prepared-documents"
    pdf_folder.mkdir()
    for filename in [*location_files, "proposed.pdf"]:
        (pdf_folder / filename).write_bytes(b"%PDF-1.4\n%%EOF")
    mapping = {
        "pdf_folder_path": str(pdf_folder),
        "bucket_labels": {
            "location_plan": "Location Plan",
            "proposed": "Proposed Plans",
        },
        "buckets": {
            "location_plan": location_files,
            "proposed": ["proposed.pdf"],
        },
    }
    mapping_path = tmp_path / "supporting_docs.json"
    mapping_path.write_text(json.dumps(mapping), encoding="utf-8")
    monkeypatch.setattr(documents, "SUPPORTING_DOCS_JSON", str(mapping_path))
    monkeypatch.setattr(
        documents.storage_paths,
        "migrate_json_if_missing",
        lambda *args, **kwargs: None,
    )
    return pdf_folder


def test_householder_location_plan_startup_preflight_accepts_canonical_mapping(monkeypatch, tmp_path):
    pdf_folder = _write_householder_document_mapping(
        monkeypatch,
        tmp_path,
        ["canonical-location-plan.pdf"],
    )

    prepared = load_prepared_householder_documents(str(pdf_folder))

    assert prepared[1] == "canonical-location-plan.pdf"
    assert prepared[2] == str(pdf_folder / "canonical-location-plan.pdf")


def test_householder_location_plan_startup_preflight_rejects_missing_plan(monkeypatch, tmp_path):
    pdf_folder = _write_householder_document_mapping(monkeypatch, tmp_path, [])

    with pytest.raises(
        FileNotFoundError,
        match="A Location Plan is required before Householder automation can continue",
    ):
        load_prepared_householder_documents(str(pdf_folder))


def test_householder_location_plan_upload_uses_canonical_prepared_file(monkeypatch, tmp_path):
    pdf_folder = _write_householder_document_mapping(
        monkeypatch,
        tmp_path,
        ["canonical-location-plan.pdf"],
    )
    prepared = load_prepared_householder_documents(str(pdf_folder))
    selected_paths = []

    for name in (
        "complete_email_notification",
        "complete_checklist",
        "upload_supporting_documents",
        "open_declaration",
        "record_checkpoint",
    ):
        monkeypatch.setattr(householder_documents, name, lambda *args, **kwargs: None)
    monkeypatch.setattr(
        householder_documents,
        "upload_location_plan",
        lambda _driver, path: selected_paths.append(path),
    )

    complete_later_householder_sections(
        object(),
        str(pdf_folder),
        {},
        prepared_documents=prepared,
    )

    assert selected_paths == [str(pdf_folder / "canonical-location-plan.pdf")]


def test_location_plan_upload_accepts_canonical_file_without_handoff_boolean(monkeypatch, tmp_path):
    location_plan_path = tmp_path / "canonical-location-plan.pdf"
    location_plan_path.write_bytes(b"%PDF-1.4\n%%EOF")
    selected_paths = []

    class FileInput:
        def send_keys(self, path):
            selected_paths.append(path)

    class Wait:
        calls = 0

        def __init__(self, _driver, _timeout):
            pass

        def until(self, _condition):
            Wait.calls += 1
            return FileInput() if Wait.calls == 1 else True

    monkeypatch.setattr(householder_documents, "WebDriverWait", Wait)
    monkeypatch.setattr(householder_documents, "dismiss_gdpr_modal_if_present", lambda _driver: None)
    monkeypatch.setattr(householder_documents, "wait_dom_ready", lambda _driver: None)
    monkeypatch.setattr(householder_documents, "prepare_location_plan_upload", lambda _driver: None)
    monkeypatch.setattr(householder_documents, "select_by_text", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "select_option_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "click_by_id", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(householder_documents, "get_paper_size_from_pdf", lambda _path: "A4")
    monkeypatch.setattr(householder_documents, "get_visible_portal_error", lambda _driver: None)

    upload_location_plan(object(), str(location_plan_path))

    assert selected_paths == [str(location_plan_path)]


class FakeWidget:
    def __init__(self, value="", required=False):
        self._value = value
        self._required = required

    def property(self, name):
        if name == "required":
            return self._required
        return None

    def text(self):
        return self._value

    def currentText(self):
        return self._value


class FakeList:
    def __init__(self, count):
        self._count = count

    def count(self):
        return self._count


def test_preflight_checks_report_missing_required_and_location_plan(tmp_path):
    app = SimpleNamespace(
        application_type=portal_answers.BUILDING_WARRANT_TYPE,
        input_fields={
            "Email": FakeWidget("", required=True),
            "Password": FakeWidget("secret", required=True),
        },
        agent_line_edits={"Agent First Name": FakeWidget("Jay", required=True)},
        applicant_line_edits={"Applicant First Name": FakeWidget("", required=True)},
        cert_line_edits={},
        cert_dropdowns={},
        pdf_folder_path=str(tmp_path),
        selected_pdf_paths=[],
        bucket_lists={"location_plan": FakeList(0)},
        state=SimpleNamespace(
            set_login_state=lambda *args: None,
            set_pdf_selection=lambda *args: None,
            set_mapping_saved=lambda *args: None,
        ),
        is_mapping_currently_saved=lambda: False,
    )

    checks = preflight_controller.build_preflight_checks(app)

    assert "Data Entry: Email" in preflight_controller.missing_required_field_names(app)
    assert "Applicant Details: Applicant First Name" in preflight_controller.missing_required_field_names(app)
    assert checks["required_fields"][0] == "Missing"
    assert checks["password"][0] == "Ready"
    assert checks["mapping"][0] == "Missing"
    assert checks["location_plan"][0] == "Missing"


def test_preflight_report_shows_exact_missing_fields_and_next_pdf_action(tmp_path):
    app = SimpleNamespace(
        application_type=portal_answers.BUILDING_WARRANT_TYPE,
        input_fields={
            "Email": FakeWidget("", required=True),
            "Password": FakeWidget("secret", required=True),
        },
        agent_line_edits={"Agent First Name": FakeWidget("Jay", required=True)},
        applicant_line_edits={
            "Applicant First Name": FakeWidget("", required=True),
        },
        cert_line_edits={},
        cert_dropdowns={},
        pdf_folder_path="",
        selected_pdf_paths=[],
        bucket_lists={"location_plan": FakeList(0)},
        portal_import_blocking_issues=[],
        WORKFLOW_STEPS=[
            "Welcome",
            "Application Questions",
            "Organise PDFs",
            "Data Entry",
            "Agent Details",
            "Applicant Details",
            "Certificates",
            "Start Automation",
        ],
        is_mapping_currently_saved=lambda: False,
    )

    report = preflight_controller.build_preflight_report(app)
    titles = [item["title"] for item in report["items"]]

    assert report["ready"] is False
    assert "Email" in titles
    assert "Applicant First Name" in titles
    assert "No PDF files selected" in titles
    assert "Document sorting has not been saved" not in titles
    assert "Exactly one Location Plan is required" not in titles
    assert next(item for item in report["items"] if item["title"] == "Email")[
        "step"
    ] == "Data Entry"


def test_preflight_report_lists_each_ready_workflow_section(tmp_path):
    pdf_path = tmp_path / "Location Plan.pdf"
    pdf_path.write_bytes(b"%PDF-1.4")
    steps = [
        "Welcome",
        "Application Questions",
        "Organise PDFs",
        "Data Entry",
        "Agent Details",
        "Applicant Details",
        "Certificates",
        "Start Automation",
    ]
    app = SimpleNamespace(
        application_type=portal_answers.BUILDING_WARRANT_TYPE,
        input_fields={
            "Email": FakeWidget("portal@example.com", required=True),
            "Password": FakeWidget("secret", required=True),
        },
        agent_line_edits={"Agent First Name": FakeWidget("Jay", required=True)},
        applicant_line_edits={
            "Applicant First Name": FakeWidget("Alex", required=True),
        },
        cert_line_edits={},
        cert_dropdowns={},
        pdf_folder_path=str(tmp_path),
        selected_pdf_paths=[str(pdf_path)],
        bucket_lists={"location_plan": FakeList(1)},
        portal_import_blocking_issues=[],
        WORKFLOW_STEPS=steps,
        is_mapping_currently_saved=lambda: True,
    )

    report = preflight_controller.build_preflight_report(app)

    assert report["ready"] is True
    assert [item["title"] for item in report["items"]] == steps[1:-1]


def test_householder_checklist_maps_pdf_buckets_to_electronic_documents():
    ids = householder_electronic_document_ids(
        [
            ("Existing Plans.pdf", "existing"),
            ("Proposed Plans.pdf", "proposed"),
            ("Rear Elevation.pdf", "elevations"),
            ("Section AA.pdf", "sections"),
            ("Site Layout.pdf", "other"),
            ("Roof Plan.pdf", "other"),
            ("Photo Sheet.pdf", "photos"),
        ],
        location_plan_file="Location Plan.pdf",
    )

    assert ids == [
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["elevations"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["floor_plans"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["sections"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["site_or_block_plan"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["roof_plan"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["photos"],
    ]


def test_householder_checklist_does_not_treat_true_location_plan_as_site_plan():
    ids = householder_electronic_document_ids(
        [("Proposed Floor Plan.pdf", "proposed")],
        location_plan_file="Location Plan.pdf",
    )

    assert HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["floor_plans"] in ids
    assert HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["site_or_block_plan"] not in ids


def test_householder_checklist_uses_drawing_title_for_elevations(monkeypatch, tmp_path):
    monkeypatch.setattr(
        "automation.householder.documents._extract_pdf_first_page_text",
        lambda _path: "EXISTING PLANS & ELEVATIONS // 1:100",
    )

    ids = householder_electronic_document_ids(
        [("23-050_L(1-)01.pdf", "existing")],
        location_plan_file="Location Plan.pdf",
        pdf_folder_path=str(tmp_path),
    )

    assert ids == [
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["elevations"],
        HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["floor_plans"],
    ]
    assert HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS["site_or_block_plan"] not in ids


def test_email_notification_does_not_enable_optional_extra_email_copies(monkeypatch):
    class Checkbox:
        def is_selected(self):
            return False

    class Driver:
        def find_elements(self, by, locator):
            assert (by, locator) == (actions.By.ID, "MainContent_cbUseEmail")
            return [Checkbox()]

    clicks = []
    monkeypatch.setattr(
        "automation.householder.documents.click_by_id",
        lambda _driver, element_id, label, timeout=15: clicks.append((element_id, label)),
    )
    monkeypatch.setattr(
        "automation.householder.documents.click_label_for_any",
        lambda *_args, **_kwargs: pytest.fail("Optional extra email copies must remain disabled"),
    )

    complete_email_notification(Driver())

    assert [element_id for element_id, _label in clicks] == [
        "MainContent_FormSections_btnEmailNotification",
        "MainContent_btnConfirm",
    ]


def test_householder_supporting_document_entry_uses_eplanning_ids(monkeypatch):
    clicks = []
    labels = []
    monkeypatch.setattr(
        "automation.householder.documents.click_by_id",
        lambda _driver, element_id, label, timeout=15: clicks.append(element_id),
    )
    monkeypatch.setattr(
        "automation.householder.documents.click_label_for_any",
        lambda _driver, element_ids, label, timeout=15: labels.append(element_ids[0]),
    )

    prepare_supporting_document_upload(object())

    assert clicks == [
        "MainContent_FormSections_btnSupportingDocumentation",
        "MainContent_btnContinue",
        "MainContent_btnAddDocumentation",
        "MainContent_btnAttachmentContinue",
    ]
    assert labels == ["MainContent_rbYes", "MainContent_rbUploaded"]


def test_supporting_upload_result_accepts_householder_add_document_id():
    class AddButton:
        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

    button = AddButton()

    class Driver:
        def find_elements(self, by, locator):
            if by == actions.By.ID and locator == "MainContent_btnAddDocumentation":
                return [button]
            return []

    assert wait_for_supporting_doc_upload_result(Driver(), "drawing.pdf", timeout=0.1) is button


def test_supporting_upload_waits_for_old_postback_form_to_detach():
    class ReplacedButton:
        def is_displayed(self):
            from selenium.common.exceptions import StaleElementReferenceException
            raise StaleElementReferenceException("replaced by ASP.NET postback")

    class AddButton:
        def is_displayed(self):
            return True

        def is_enabled(self):
            return True

    button = AddButton()

    class Driver:
        polls = 0

        def find_elements(self, by, locator):
            if by == actions.By.ID and locator == "MainContent_btnAddDocumentation":
                self.polls += 1
                if self.polls == 1:
                    return [ReplacedButton()]
                return [button]
            return []

    assert wait_for_supporting_doc_upload_result(
        Driver(),
        "drawing.pdf",
        timeout=1,
    ) is button


def test_householder_supporting_document_title_uses_portal_safe_characters():
    assert normalise_supporting_document_title("23-050_L(20)01.pdf") == "D_23_050_L_20_01"
    assert normalise_supporting_document_title("Sheet-Garage.pdf") == "Sheet_Garage"


def test_householder_supporting_document_description_removes_forbidden_punctuation():
    assert normalise_supporting_document_description("Specifications / Reports") == "Specifications Reports"


def test_householder_location_plan_entry_uses_eplanning_ids(monkeypatch):
    clicks = []
    labels = []
    monkeypatch.setattr(
        "automation.householder.documents.click_by_id",
        lambda _driver, element_id, label, timeout=15: clicks.append(element_id),
    )
    monkeypatch.setattr(
        "automation.householder.documents.click_label_for_any",
        lambda _driver, element_ids, label, timeout=15: labels.append(element_ids[0]),
    )

    prepare_location_plan_upload(object())

    assert clicks == [
        LOCATION_PLAN_SECTION_ID,
        LOCATION_PLAN_CONTINUE_ID,
        LOCATION_PLAN_OPTIONS_CONTINUE_ID,
    ]
    assert labels == [LOCATION_PLAN_UPLOADED_ID]
    assert LOCATION_PLAN_ANNOTATED_ID.endswith("cbFileAnnotated")


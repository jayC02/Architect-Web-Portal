import os
import sys
import unittest
from unittest.mock import ANY, MagicMock, patch

from selenium.webdriver.common.by import By


ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from automation.building_warrant.agent import fill_agent_details
from gui.services import portal_handoff


class AgentBuildingNumberTests(unittest.TestCase):
    def test_handoff_maps_building_number_and_automation_enters_it(self):
        job = {
            "id": "job_agent_building_number",
            "projectId": "project_agent_building_number",
            "type": "BUILDING_WARRANT",
            "dataSnapshot": {
                "contractVersion": "architectpro.automation-job",
                "snapshotVersion": 2,
                "metadata": {"jobId": "job_agent_building_number", "projectId": "project_agent_building_number", "applicationType": "BUILDING_WARRANT"},
                "organisation": {
                    "agent": {
                        "firstName": "Alex",
                        "lastName": "Agent",
                        "email": "agent@example.com",
                        "phone": None,
                        "buildingNumber": "20",
                        "address": {"addressLine1": "Practice Road", "townCity": "Glasgow", "postcode": "G2 2BB", "country": "United Kingdom"},
                    }
                },
                "project": {"name": "14 Test Street", "typeOfWorkKey": "new_build", "typeOfWorkLabel": "New build"},
                "site": {"address": {"addressLine1": "14 Test Street", "townCity": "Glasgow", "postcode": "G1 1AA", "country": "United Kingdom"}},
                "applicant": {"displayName": "Test Client", "firstName": "Test", "lastName": "Client", "email": "client@example.com", "buildingNumber": "14", "address": {}},
                "buildingWarrant": {"recordId": "warrant_agent_building_number", "description": "Construct a new residential dwelling", "estimatedValue": 200000, "currentUse": "Vacant", "proposedUse": "Dwelling", "unusualAnswers": {}, "certifier": None},
                "planning": None,
                "documents": [],
                "preflight": {"status": "READY", "missing": [], "warnings": []},
            },
        }
        values = portal_handoff.portal_job_to_values(job)
        self.assertEqual(values["Agent Building Number"], "20")
        self.assertEqual(values["Applicant Building Number"], "14")

        owner_label = MagicMock()
        waiter = MagicMock()
        waiter.until.side_effect = [MagicMock(), owner_label]
        with patch("automation.building_warrant.agent.WebDriverWait", return_value=waiter), \
             patch("automation.building_warrant.agent.click_when_clickable"), \
             patch("automation.building_warrant.agent.get_when_present"), \
             patch("automation.building_warrant.agent.type_into") as type_into:
            fill_agent_details(MagicMock(), values)

        type_into.assert_any_call(
            ANY,
            By.ID,
            "MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentBuildingNo",
            "20",
        )

    def test_desktop_agent_form_marks_building_number_required(self):
        path = os.path.join(ROOT, "gui", "pages", "agent_details_page.py")
        with open(path, encoding="utf-8") as handle:
            source = handle.read()
        required_block = source[source.index("required = {"):source.index("app.agent_line_edits")]
        self.assertIn('"Agent Building Number"', required_block)

        applicant_path = os.path.join(ROOT, "gui", "pages", "applicant_details_page.py")
        with open(applicant_path, encoding="utf-8") as handle:
            applicant_source = handle.read()
        self.assertIn(
            '("Applicant Building Number", "Enter building number", True)',
            applicant_source,
        )


if __name__ == "__main__":
    unittest.main()

from gui.services import pdf_mapping
from gui.services.pdf_mapping import CONFIDENCE_ROLE, FILENAME_ROLE


class FakeItem:
    def __init__(self, filename):
        self._text = filename
        self._data = {FILENAME_ROLE: filename}

    def data(self, role):
        return self._data.get(role)

    def setData(self, role, value):
        self._data[role] = value

    def text(self):
        return self._text

    def setText(self, value):
        self._text = value


class FakeList:
    def __init__(self, names=None):
        self.items = [FakeItem(name) for name in (names or [])]

    def count(self):
        return len(self.items)

    def item(self, index):
        return self.items[index]

    def addItem(self, item):
        self.items.append(item)

    def takeItem(self, index):
        return self.items.pop(index)

    def row(self, item):
        return self.items.index(item)


def names(fake_list):
    return [fake_list.item(index).data(FILENAME_ROLE) for index in range(fake_list.count())]


def bucket_lists():
    return {
        "location_plan": FakeList(),
        "proposed": FakeList(),
        "existing": FakeList(),
        "elevations": FakeList(),
        "sections": FakeList(),
        "details": FakeList(),
        "calcs": FakeList(),
        "specs": FakeList(),
        "photos": FakeList(),
        "other": FakeList(),
    }


def test_true_location_plan_wins_over_site_plan_fallback(monkeypatch):
    inbox = FakeList(["Location Plan.pdf", "Site Plan.pdf"])
    buckets = bucket_lists()

    def fake_score(base_folder, filename, log):
        if filename == "Location Plan.pdf":
            return "location_plan", "High", "true location"
        return "location_plan_fallback", "Medium", "fallback"

    monkeypatch.setattr(pdf_mapping, "score_pdf", fake_score)

    result = pdf_mapping.autosort_pdfs(".", inbox, buckets, lambda message: None)

    assert result["sorted"] == 1
    assert names(buckets["location_plan"]) == ["Location Plan.pdf"]
    assert names(inbox) == ["Site Plan.pdf"]


def test_site_plan_fallback_used_when_no_true_location_plan(monkeypatch):
    inbox = FakeList(["Site Plan.pdf"])
    buckets = bucket_lists()

    monkeypatch.setattr(
        pdf_mapping,
        "score_pdf",
        lambda base_folder, filename, log: ("location_plan_fallback", "Medium", "fallback"),
    )

    result = pdf_mapping.autosort_pdfs(".", inbox, buckets, lambda message: None)

    assert result["sorted"] == 1
    assert names(buckets["location_plan"]) == ["Site Plan.pdf"]
    assert buckets["location_plan"].item(0).data(CONFIDENCE_ROLE) == "Medium"
    assert names(inbox) == []

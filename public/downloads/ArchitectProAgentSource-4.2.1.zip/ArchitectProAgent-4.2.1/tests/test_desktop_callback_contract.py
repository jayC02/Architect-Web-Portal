import json
from datetime import datetime
from pathlib import Path

import pytest

from automation.runner import AutomationResult
from gui.services.desktop_callback_contract import map_runner_result_callback


FIXTURES = json.loads(
    (Path(__file__).parent / "fixtures" / "desktop-callback-contract-v1.json").read_text(
        encoding="utf-8"
    )
)


def _runner_result(value):
    return AutomationResult(
        value["outcome"],
        value["jobId"],
        value["applicationType"],
        value["message"],
        value["lastStage"],
        value.get("timings") or {},
        "",
        value.get("errorCode"),
        recovery_action=("retry" if value.get("retrySafe") else "review_portal"),
        retry_safe=bool(value.get("retrySafe", False)),
    )


@pytest.mark.parametrize("fixture", FIXTURES, ids=lambda value: value["name"])
def test_runner_results_map_to_shared_web_contract_fixture(fixture):
    expected = fixture["callback"]
    actual = map_runner_result_callback(
        _runner_result(fixture["runnerResult"]),
        callback_id=expected["callbackId"],
        occurred_at=datetime.fromisoformat(expected["occurredAt"]),
    )
    assert actual == expected


def test_unknown_runner_outcome_never_maps_to_success():
    unknown = AutomationResult(
        "unexpected",
        "job_contract_123456",
        "BUILDING_WARRANT",
        "Unexpected result",
        "workflow",
        {},
    )
    with pytest.raises(ValueError, match="Unsupported automation runner outcome"):
        map_runner_result_callback(unknown)


def test_fee_stage_survives_the_mapping_boundary():
    fee = next(value for value in FIXTURES if value["name"] == "fee_handoff")
    callback = map_runner_result_callback(
        _runner_result(fee["runnerResult"]),
        callback_id=fee["callback"]["callbackId"],
        occurred_at=fee["callback"]["occurredAt"],
    )
    assert callback["status"] == "AWAITING_PORTAL_REVIEW"
    assert callback["result"]["outcome"] == "awaiting_user_portal_review"
    assert callback["result"]["currentSection"] == "fee"


def test_structured_failure_recovery_metadata_survives_callback_mapping():
    result = AutomationResult(
        "failure",
        "job_contract_123456",
        "HOUSEHOLDER_PLANNING",
        "Architect Pro could not safely resolve the property address returned by the portal.",
        "address_selection",
        {},
        "",
        "ADDRESS_RESOLUTION_FAILED",
        "Property address could not be resolved",
        "Selecting the property address",
        "Architect Pro stopped rather than selecting the wrong property.",
        "Review the saved project address and start a new safe attempt.",
        "review_address",
        True,
        "ADDRESS_RESOLUTION_FAILED",
        ("buildingNumber", "addressLine1", "townCity", "postcode"),
    )
    callback = map_runner_result_callback(result)
    assert callback["status"] == "FAILED_RETRYABLE"
    assert callback["lastCheckpoint"] == "address_selection"
    assert callback["result"]["failureCategory"] == "ADDRESS_RESOLUTION_FAILED"
    assert callback["result"]["recoveryAction"] == "review_address"
    assert callback["result"]["retrySafe"] is True
    assert callback["result"]["recoveryFields"] == ["buildingNumber", "addressLine1", "townCity", "postcode"]


def test_packaged_agent_wires_startup_reconnect_and_periodic_outbox_retry():
    source = (Path(__file__).parents[1] / "gui" / "agent_app.py").read_text(encoding="utf-8")
    assert "QTimer.singleShot(0, self.retry_callback_outbox)" in source
    assert "self.callback_retry_timer.setInterval(30_000)" in source
    assert "self.callback_retry_timer.start()" in source
    assert "self.show_ready()\n        self.retry_callback_outbox()" in source
    assert "CallbackRetryThread" in source
    assert "self.settings.update(load_settings())" in source

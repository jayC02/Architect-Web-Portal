import copy
import json
from pathlib import Path

import pytest
from selenium.webdriver.common.by import By

from automation.building_warrant import fee
from gui.services import portal_handoff


FIXTURE = Path(__file__).parent / "fixtures" / "automation-job-v2-building-warrant.json"


def snapshot_job(total_fee_minor_units, *, job_id="job_fee_snapshot"):
    snapshot = json.loads(FIXTURE.read_text(encoding="utf-8"))
    snapshot["metadata"]["jobId"] = job_id
    snapshot["buildingWarrant"]["feeCalculation"] = {
        "calculationStatus": "CALCULATED",
        "scheduleVersion": "BUILDING_STANDARDS_2026",
        "effectiveFrom": "2026-04-01",
        "submissionType": "BUILDING_WARRANT",
        "valueOfWorksMinorUnits": 4_000_000,
        "calculationBasisMinorUnits": 4_000_000,
        "baseFeeMinorUnits": 86_500,
        "multiplierPercent": 100,
        "subtotalMinorUnits": 86_500,
        "adjustments": [],
        "totalFeeMinorUnits": total_fee_minor_units,
        "specialRule": None,
        "explanation": ["Calculated by Architect Pro."],
    }
    return {
        "id": job_id,
        "projectId": snapshot["metadata"]["projectId"],
        "type": "BUILDING_WARRANT",
        "dataSnapshot": snapshot,
    }


class FeeField:
    def __init__(self, driver):
        self.driver = driver

    def get_attribute(self, name):
        return self.driver.value if name == "value" else None


class FeeDriver:
    def __init__(self):
        self.value = "0.00"
        self.finds = 0

    def find_element(self, by, locator):
        assert (by, locator) == (By.ID, fee.FEE_FIELD_ID)
        self.finds += 1
        return FeeField(self)


@pytest.mark.parametrize(
    ("minor_units", "expected"),
    [(76_000, "760.00"), (139_000, "1390.00")],
)
def test_snapshot_fee_is_entered_with_exact_two_decimal_value(monkeypatch, minor_units, expected):
    driver = FeeDriver()
    calls = []

    def safe_type_into(current, by, locator, value, *, timeout, clear_first):
        calls.append((by, locator, value, timeout, clear_first))
        current.value = value
        return FeeField(current)

    monkeypatch.setattr(fee, "type_into", safe_type_into)

    assert fee.enter_calculated_fee(driver, minor_units, timeout=0.1) == expected
    assert driver.value == expected
    assert calls == [(By.ID, "MainContent_txtEnterFee", expected, 0.1, True)]
    assert driver.finds >= 1  # verification reacquires the field after entry/rerender


def test_missing_or_needs_information_fee_never_falls_back_to_zero():
    missing_job = snapshot_job(76_000, job_id="job_fee_missing")
    del missing_job["dataSnapshot"]["buildingWarrant"]["feeCalculation"]
    missing_state = portal_handoff.normalise_portal_job(missing_job)
    assert portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY not in missing_state.form_values
    assert missing_state.blocking_issues == [portal_handoff.MISSING_BUILDING_WARRANT_FEE_MESSAGE]

    needs_job = snapshot_job(76_000, job_id="job_fee_needs_information")
    needs_job["dataSnapshot"]["buildingWarrant"]["feeCalculation"] = {
        "calculationStatus": "NEEDS_INFORMATION",
        "scheduleVersion": "BUILDING_STANDARDS_2026",
        "effectiveFrom": "2026-04-01",
        "submissionType": "BUILDING_WARRANT",
        "missingInputs": ["valueOfWorksMinorUnits"],
        "explanation": ["Enter the estimated value of works."],
    }
    needs_state = portal_handoff.normalise_portal_job(needs_job)
    assert portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY not in needs_state.form_values
    assert needs_state.blocking_issues == [portal_handoff.MISSING_BUILDING_WARRANT_FEE_MESSAGE]

    with pytest.raises(fee.BuildingWarrantFeeError, match="fee could not be calculated"):
        fee.require_calculated_fee_minor_units({})
    with pytest.raises(fee.BuildingWarrantFeeError, match="fee could not be calculated"):
        fee.require_calculated_fee_minor_units({fee.CALCULATED_FEE_MINOR_UNITS_KEY: "0"})


def test_fresh_retry_uses_new_snapshot_fee_and_never_reuses_job_a():
    job_a = snapshot_job(76_000, job_id="job_fee_a")
    job_b = copy.deepcopy(job_a)
    job_b["id"] = "job_fee_b"
    job_b["dataSnapshot"]["metadata"]["jobId"] = "job_fee_b"
    job_b["dataSnapshot"]["buildingWarrant"]["feeCalculation"]["totalFeeMinorUnits"] = 139_000

    values_a = portal_handoff.portal_job_to_values(job_a)
    values_b = portal_handoff.portal_job_to_values(job_b)

    assert values_a[portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY] == 76_000
    assert values_b[portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY] == 139_000
    assert values_b[portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY] != values_a[portal_handoff.CALCULATED_FEE_MINOR_UNITS_KEY]


def test_building_warrant_workflow_enters_fee_after_verified_fee_navigation_only():
    source = (Path(__file__).parents[1] / "automation" / "building_warrant" / "run.py").read_text(encoding="utf-8")
    declaration = source.index("complete_declaration(")
    fee_page = source.index("fee_handoff = open_fee_and_handoff(")
    fee_entry = source.index("enter_calculated_fee(driver, calculated_fee_minor_units)")
    handoff = source.index("return fee_handoff")
    assert declaration < fee_page < fee_entry < handoff

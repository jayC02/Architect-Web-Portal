import time

from gui.services.background_agent import CAPABILITIES, PollingEngine, ProgressPublisher


class FixedRandom:
    def uniform(self, start, _end):
        return start


class FakeClient:
    def __init__(self):
        self.progress = []

    def send_progress(self, job_id, payload):
        self.progress.append((job_id, payload))


class FakeApi:
    def __init__(self, jobs=None, heartbeat_response=None):
        self.jobs = list(jobs or [])
        self.heartbeats = []
        self.claims = []
        self.client = FakeClient()
        self.heartbeat_response = heartbeat_response

    def heartbeat(self, state, current_job_id, agent_run_id):
        self.heartbeats.append((state, current_job_id, agent_run_id))
        return self.heartbeat_response

    def queue(self):
        return list(self.jobs)

    def claim(self, job_id, agent_run_id):
        self.claims.append((job_id, agent_run_id))
        return self.client


def test_capabilities_advertise_only_supported_contracts():
    assert CAPABILITIES["workflows"] == ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"]
    assert CAPABILITIES["snapshotVersions"] == [2]
    assert CAPABILITIES["callbackContractVersions"] == [1]
    assert CAPABILITIES["progressContractVersions"] == [1]


def test_poll_claims_one_job_and_stops_reading_queue_during_run():
    api = FakeApi([{"id": "job-1"}, {"id": "job-2"}])
    engine = PollingEngine(api_factory=lambda: api, random_source=FixedRandom())

    claimed, delay = engine.tick()

    assert claimed["job_id"] == "job-1"
    assert delay == 0.0
    assert engine.current_job_id == "job-1"
    assert engine.state == "RUNNING"
    assert len(api.claims) == 1

    assert engine.tick() == (None, 30.0)
    assert len(api.claims) == 1
    assert api.heartbeats[-1][1:] == ("job-1", engine.agent_run_id)


def test_backoff_is_bounded_and_resets_after_success():
    engine = PollingEngine(api_factory=lambda: FakeApi(), random_source=FixedRandom())
    assert engine.failed_delay() == 5.0
    for _ in range(10):
        delay = engine.failed_delay()
    assert delay == 120.0
    engine.tick()
    assert engine.failure_count == 0


def test_release_must_be_acknowledged_before_polling_another_job():
    api = FakeApi([{"id": "job-next"}])
    engine = PollingEngine(api_factory=lambda: api)
    engine.set_run("job-old", "run-old", "USER_ACTION_REQUIRED")
    engine.set_run(None, None, "READY")
    assert engine.tick() == (None, 5.0)
    assert api.claims == []
    assert api.heartbeats[-1] == ("READY", "job-old", "run-old")
    api.heartbeat_response = {"releaseAcknowledged": True}
    claimed, _delay = engine.tick()
    assert claimed["job_id"] == "job-next"
    assert engine.pending_release is None


def test_paused_run_receives_scoped_reveal_command_without_reclaiming_job():
    command = {"type": "REVEAL_BROWSER", "jobId": "job-1", "agentRunId": "run-1", "requestedAt": "2026-08-19T16:00:00.000Z"}
    api = FakeApi(heartbeat_response={"commands": [command]})
    engine = PollingEngine(api_factory=lambda: api, random_source=FixedRandom())
    engine.set_run("job-1", "run-1", "USER_ACTION_REQUIRED")
    assert engine.tick() == (None, 5.0)
    assert engine.pending_commands == [command]
    assert api.claims == []


def test_idle_agent_receives_completed_application_open_command_before_claiming_queue():
    command = {
        "type": "OPEN_APPLICATION",
        "jobId": "job-complete",
        "applicationType": "HOUSEHOLDER_PLANNING",
        "agentRunId": "run-original",
        "requestedAt": "2026-08-20T09:00:00.000Z",
    }
    api = FakeApi(
        jobs=[{"id": "job-new"}],
        heartbeat_response={"commands": [command]},
    )
    engine = PollingEngine(api_factory=lambda: api, random_source=FixedRandom())

    assert engine.tick() == (None, 5.0)
    assert engine.pending_commands == [command]
    assert api.claims == []


def test_progress_is_monotonic_coalesced_and_job_scoped():
    now = [100.0]
    client = FakeClient()
    publisher = ProgressPublisher(client, "job-1", "run-1", now=lambda: now[0])
    try:
        assert publisher.publish(stage="browser", stage_state="RUNNING", percent=10, eta_seconds=90, message="Starting")
        assert not publisher.publish(stage="browser", stage_state="RUNNING", percent=11, eta_seconds=85, message="Noise")
        now[0] += 10
        assert publisher.publish(stage="browser", stage_state="RUNNING", percent=11, eta_seconds=85, message="Still working")

        deadline = time.monotonic() + 1
        while len(client.progress) < 2 and time.monotonic() < deadline:
            time.sleep(0.01)

        payloads = [entry[1] for entry in client.progress]
        assert [payload["sequence"] for payload in payloads] == [1, 2]
        assert all(payload["jobId"] == "job-1" for payload in payloads)
        assert all(payload["agentRunId"] == "run-1" for payload in payloads)
    finally:
        publisher.close()

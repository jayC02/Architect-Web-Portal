"""Customer recovery of enrollment only; never reset installation or portal data."""
from . import background_agent, portal_handoff, secure_credentials


def connection_failure_state(error):
    return "AUTH_REQUIRED" if getattr(error, "status_code", None) in {401, 403} else "OFFLINE"


def reset_connection(*, active_execution=False, api_factory=background_agent.AgentApi):
    if active_execution:
        raise portal_handoff.PortalHandoffError("Finish or release the current application before resetting the Agent connection.")
    credential, available, message = secure_credentials.get_agent_credential()
    if not available:
        raise portal_handoff.PortalHandoffError(message or "Secure connection storage is unavailable. Try reset again.")
    if credential:
        try:
            response = api_factory(credential=credential).revoke_self()
            if not isinstance(response, dict) or response.get("ok") is not True:
                raise portal_handoff.PortalHandoffError("Reset was not confirmed. Your connection has been kept; try again.")
        except portal_handoff.PortalHandoffError as error:
            if getattr(error, "status_code", None) not in {401, 403}:
                raise portal_handoff.PortalHandoffError(
                    "Reset could not be confirmed. Your connection has been kept. "
                    + (str(error) if getattr(error, "status_code", None) == 409 else "Check your connection and try Reset & reconnect again.")
                ) from error
    current, available, message = secure_credentials.get_agent_credential()
    if not available or current != credential:
        raise portal_handoff.PortalHandoffError(message or "The connection changed during reset. Check the Agent and try again.")
    if credential:
        ok, message = secure_credentials.delete_agent_credential()
        if not ok:
            raise portal_handoff.PortalHandoffError(message or "The old connection could not be cleared. Try reset again.")
    # installation_id(), portal settings, portal passwords and job history are
    # intentionally untouched. Browser enrollment reuses the stable identity.
    return {"ok": True}

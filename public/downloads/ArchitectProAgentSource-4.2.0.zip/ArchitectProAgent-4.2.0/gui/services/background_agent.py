"""Narrow registered-Agent client and background queue orchestration."""

from __future__ import annotations

import json
import os
import queue
import random
import socket
import sys
import threading
import time
import uuid
from datetime import datetime, timezone

from . import portal_handoff, secure_credentials, storage_paths


AGENT_VERSION = "4.2.0"
AGENT_CONTRACT_VERSION = 1
PROGRESS_CONTRACT_VERSION = 1
CAPABILITIES = {
    "workflows": ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"],
    "snapshotVersions": [2],
    "callbackContractVersions": [1],
    "progressContractVersions": [PROGRESS_CONTRACT_VERSION],
}
INSTALLATION_FILE = "agent_installation.json"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_VALUE = "ArchitectProAgent"


def installation_id():
    path = storage_paths.runtime_path(INSTALLATION_FILE)
    data, _ = storage_paths.load_json_file(path)
    value = str((data or {}).get("installation_id") or "") if isinstance(data, dict) else ""
    try:
        return str(uuid.UUID(value))
    except ValueError:
        value = str(uuid.uuid4())
        with open(path, "w", encoding="utf-8") as handle:
            json.dump({"installation_id": value}, handle, indent=2)
        return value


def start_with_windows_enabled():
    if os.name != "nt":
        return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            winreg.QueryValueEx(key, RUN_VALUE)
        return True
    except OSError:
        return False


def set_start_with_windows(enabled):
    if os.name != "nt":
        return False
    import winreg
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
        if enabled:
            executable = os.path.abspath(sys.executable)
            if getattr(sys, "frozen", False):
                command = f'"{executable}" --background'
            else:
                launcher = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "Gui.py"))
                command = f'"{executable}" "{launcher}" --background'
            winreg.SetValueEx(key, RUN_VALUE, 0, winreg.REG_SZ, command)
        else:
            try:
                winreg.DeleteValue(key, RUN_VALUE)
            except FileNotFoundError:
                pass
    return True


class AgentApi:
    def __init__(self, portal_url=None, credential=None):
        self.portal_url = portal_handoff._normalise_portal_url(portal_url or portal_handoff.load_portal_url())
        if credential is None:
            credential, _, _ = secure_credentials.get_agent_credential()
        if not credential:
            raise portal_handoff.PortalHandoffError("Connect this Agent from Architect Pro Settings.")
        self.client = portal_handoff.PortalClient(self.portal_url, credential)

    @classmethod
    def enroll(cls, portal_url, enrollment_code):
        value = str(enrollment_code or "").strip()
        organisation_id, separator, token = value.partition(":")
        if not separator or not organisation_id or not token.startswith("ape_"):
            raise portal_handoff.PortalHandoffError("Paste the complete enrollment code from Architect Pro Settings.")
        temporary = portal_handoff.PortalClient(portal_url, "enrollment")
        result = temporary._request("/api/desktop/enrollment/exchange", "POST", {
            "token": token,
            "organisationId": organisation_id,
            "installationId": installation_id(),
            "machineName": socket.gethostname(),
            "agentVersion": AGENT_VERSION,
            "capabilities": CAPABILITIES,
        })
        ok, message = secure_credentials.save_agent_credential(result.get("credential"))
        if not ok:
            raise portal_handoff.PortalHandoffError(message)
        portal_handoff.save_portal_url(portal_url)
        return cls(portal_url, result.get("credential"))

    @classmethod
    def enroll_pkce(cls, portal_url, grant, code_verifier, expected_installation_id=None):
        current_installation_id = installation_id()
        if expected_installation_id and expected_installation_id != current_installation_id:
            raise portal_handoff.PortalHandoffError("This connection belongs to another Agent installation.")
        temporary = portal_handoff.PortalClient(portal_url, "enrollment")
        result = temporary._request("/api/desktop/enrollment/exchange", "POST", {
            "grant": grant,
            "codeVerifier": code_verifier,
            "installationId": current_installation_id,
            "machineName": socket.gethostname(),
            "agentVersion": AGENT_VERSION,
            "capabilities": CAPABILITIES,
        })
        ok, message = secure_credentials.save_agent_credential(result.get("credential"))
        if not ok:
            raise portal_handoff.PortalHandoffError(message)
        portal_handoff.save_portal_url(portal_url)
        return cls(portal_url, result.get("credential"))

    def revoke_self(self):
        return self.client._request("/api/desktop/registration", "DELETE")

    def heartbeat(self, state="READY", current_job_id=None, agent_run_id=None):
        return self.client._request("/api/desktop/heartbeat", "POST", {
            "version": AGENT_CONTRACT_VERSION,
            "agentVersion": AGENT_VERSION,
            "capabilities": CAPABILITIES,
            "state": state,
            "currentJobId": current_job_id,
            "agentRunId": agent_run_id,
        })

    def acknowledge_browser_reveal(self, job_id, agent_run_id, requested_at):
        return self.client._request(
            f"/api/desktop/automation-jobs/{job_id}/reveal-browser",
            "POST",
            {"agentRunId": agent_run_id, "requestedAt": requested_at},
        )

    def get_view_job(self, job_id):
        return self.client._request(
            f"/api/desktop/automation-jobs/{job_id}/view"
        ).get("job")

    def queue(self):
        return self.client._request("/api/desktop/queue").get("jobs") or []

    def claim(self, job_id, agent_run_id):
        result = self.client._request(
            f"/api/desktop/queue/{job_id}/claim",
            "POST",
            {"agentRunId": agent_run_id},
        )
        token = result.get("jobAccessToken")
        portal_handoff.save_job_access_token(job_id, token)
        return portal_handoff.PortalClient(self.portal_url, token)


class PollingEngine:
    """Testable poll/heartbeat engine; a Qt thread owns its loop in the UI."""

    def __init__(self, api_factory=AgentApi, random_source=None):
        self.api_factory = api_factory
        self.random = random_source or random.Random()
        self.current_job_id = None
        self.agent_run_id = None
        self.state = "READY"
        self.failure_count = 0
        self.pending_commands = []
        self.pending_release = None

    def set_run(self, job_id=None, agent_run_id=None, state="READY"):
        if not job_id and self.current_job_id and self.agent_run_id:
            self.pending_release = (self.current_job_id, self.agent_run_id)
        self.current_job_id = job_id
        self.agent_run_id = agent_run_id
        self.state = state

    def tick(self):
        api = self.api_factory()
        if self.pending_release:
            releasing = self.pending_release
            acknowledgement = api.heartbeat("READY", *releasing) or {}
            if not acknowledgement.get("releaseAcknowledged"):
                return None, 5.0
            if self.pending_release == releasing:
                self.pending_release = None
        heartbeat = api.heartbeat(self.state, self.current_job_id, self.agent_run_id) or {}
        self.pending_commands = list(heartbeat.get("commands") or [])
        if self.pending_commands and not self.current_job_id:
            self.failure_count = 0
            return None, 5.0
        if self.current_job_id:
            self.failure_count = 0
            return None, 5.0 if self.pending_commands or self.state == "USER_ACTION_REQUIRED" else 30.0
        jobs = api.queue()
        if not jobs:
            self.failure_count = 0
            return None, self.random.uniform(20.0, 30.0)
        run_id = str(uuid.uuid4())
        job_id = jobs[0]["id"]
        client = api.claim(job_id, run_id)
        self.set_run(job_id, run_id, "RUNNING")
        self.failure_count = 0
        return {"job_id": job_id, "agent_run_id": run_id, "client": client}, 0.0

    def failed_delay(self):
        self.failure_count += 1
        return min(5.0 * (2 ** (self.failure_count - 1)), 120.0) * self.random.uniform(1.0, 1.2)


class ProgressPublisher:
    """Ordered, coalesced progress delivery using the claimed job token."""

    def __init__(self, client, job_id, agent_run_id, now=time.monotonic):
        self.client = client
        self.job_id = job_id
        self.agent_run_id = agent_run_id
        self.now = now
        self.sequence = 0
        self.last_stage = None
        self.last_percent = -1
        self.last_eta = None
        self.last_sent = 0.0
        self.events = queue.Queue()
        self.worker = threading.Thread(target=self._deliver, daemon=True)
        self.worker.start()

    def publish(self, *, stage, stage_state, percent, eta_seconds, message, status="RUNNING", force=False):
        current = self.now()
        meaningful = force or stage != self.last_stage or abs(int(percent) - self.last_percent) >= 3
        if self.last_eta is None or eta_seconds is None:
            meaningful = meaningful or self.last_eta != eta_seconds
        else:
            meaningful = meaningful or abs(int(eta_seconds) - int(self.last_eta)) >= 10
        if not meaningful and current - self.last_sent < 10.0:
            return False
        self.sequence += 1
        self.last_stage, self.last_percent, self.last_eta, self.last_sent = stage, int(percent), eta_seconds, current
        self.events.put({
            "version": PROGRESS_CONTRACT_VERSION,
            "jobId": self.job_id,
            "agentRunId": self.agent_run_id,
            "sequence": self.sequence,
            "occurredAt": datetime.now(timezone.utc).isoformat(),
            "status": status,
            "progress": {
                "stage": str(stage),
                "stageState": str(stage_state),
                "percent": max(0, min(100, int(percent))),
                "etaSeconds": None if eta_seconds is None else max(0, int(eta_seconds)),
                "message": str(message or "Preparing application")[:500],
            },
        })
        return True

    def _deliver(self):
        while True:
            payload = self.events.get()
            if payload is None:
                return
            try:
                self.client.send_progress(self.job_id, payload)
            except Exception:
                # The authoritative callback outbox still delivers result state. A future
                # progress event supersedes this projection and heartbeats retain the lease.
                pass

    def close(self):
        self.events.put(None)

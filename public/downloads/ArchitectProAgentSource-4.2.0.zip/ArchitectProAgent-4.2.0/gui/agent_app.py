"""Polished Architect Pro Automation Agent UI."""

from __future__ import annotations

import json
import re
import sys
import threading
from dataclasses import replace
from datetime import datetime, timezone

from PySide6.QtCore import QEventLoop, QThread, QTimer, Qt, Signal
from PySide6.QtGui import QAction, QGuiApplication, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QProgressBar, QScrollArea,
    QMenu, QPushButton, QRadioButton, QSystemTrayIcon, QTextEdit, QVBoxLayout, QWidget,
)

from automation.common.browser_mode import BrowserMode
from automation.common.driver import create_managed_chrome, reveal_handed_off_browser
from automation.common.existing_application import open_existing_application
from automation.progress import ProgressEstimator, USER_STAGE_LABELS, format_remaining, workflow_stages
from automation.portal_adapter import runtime_job_from_portal
from gui.services import agent_connection, agent_enrollment, background_agent, callback_outbox, portal_handoff, secure_credentials, storage_paths
from gui.services.desktop_callback_contract import build_started_callback, map_runner_result_callback
from gui.startup_splash import packaged_asset_path, show_window_after_splash, update_startup_splash


SETTINGS_FILE = "automation_agent_settings.json"
BROWSER_MODE_POLICY_VERSION = 2

APP_QSS = """
QWidget { background: #F4F3EF; color: #20231F; font-family: "Segoe UI Variable Text", "Segoe UI"; font-size: 13px; }
QFrame#AgentCard { background: #FBFAF7; border: 1px solid #DCD9D1; border-radius: 12px; }
QFrame#AgentCard[state="error"] { background: #FFF8F7; border: 2px solid #B83A3A; }
QLabel#Brand { font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 19px; font-weight: 650; }
QLabel#Connection { color: #326148; font-size: 12px; font-weight: 600; }
QLabel#Eyebrow { color: #76736C; font-size: 11px; font-weight: 650; letter-spacing: 1px; }
QLabel#Heading { font-family: "Segoe UI Variable Display", "Segoe UI"; font-size: 24px; font-weight: 650; }
QLabel#Site { font-size: 16px; font-weight: 600; }
QLabel#Muted { color: #69665F; line-height: 1.35; }
QLabel#Percent { font-size: 15px; font-weight: 650; }
QLabel#Task { color: #3D5748; font-weight: 600; }
QLabel#ErrorEyebrow { color: #A12D2D; font-size: 11px; font-weight: 700; letter-spacing: 1px; }
QPushButton { min-height: 34px; padding: 0 15px; border: 1px solid #CAC7BF; border-radius: 5px; background: #FBFAF7; }
QPushButton:hover { background: #EFEEE9; }
QPushButton:focus { border: 2px solid #4B7F62; }
QPushButton#Primary { min-height: 42px; border: 0; background: #315E46; color: white; font-weight: 650; }
QPushButton#Primary:hover { background: #274D39; }
QPushButton#Danger { color: #8B2F2F; border-color: #D8BABA; background: #FFF8F7; }
QPushButton#Link { border: 0; background: transparent; color: #516B5A; padding: 2px 4px; text-align: left; }
QProgressBar { height: 10px; border: 0; border-radius: 5px; background: #E2E0D9; }
QProgressBar::chunk { border-radius: 5px; background: #4B7F62; }
QListWidget { background: transparent; border: 0; outline: 0; }
QListWidget::item { padding: 4px 0; color: #626059; }
QTextEdit { background: #F0EFEA; border: 1px solid #D8D5CD; border-radius: 5px; font-family: Consolas; font-size: 11px; }
QLineEdit, QComboBox { min-height: 34px; padding: 0 9px; background: white; border: 1px solid #C9C6BE; border-radius: 5px; }
QLineEdit:focus, QComboBox:focus { border: 2px solid #4B7F62; }
"""


def load_settings():
    data, _ = storage_paths.load_json_file(storage_paths.runtime_path(SETTINGS_FILE))
    data = data if isinstance(data, dict) else {}
    browser_mode = str(data.get("browser_mode") or BrowserMode.AUTO.value).upper()
    if data.get("browser_mode_policy_version") != BROWSER_MODE_POLICY_VERSION and browser_mode == BrowserMode.HEADLESS.value:
        browser_mode = BrowserMode.AUTO.value
    return {
        "email": str(data.get("email") or "").strip(),
        "browser_mode": browser_mode,
        "start_with_windows": bool(data.get("start_with_windows", background_agent.start_with_windows_enabled())),
    }


def save_settings(settings):
    safe = {
        "email": str(settings.get("email") or "").strip(),
        "browser_mode": BrowserMode.parse(settings.get("browser_mode")).value,
        "browser_mode_policy_version": BROWSER_MODE_POLICY_VERSION,
    }
    with open(storage_paths.runtime_path(SETTINGS_FILE), "w", encoding="utf-8") as handle:
        json.dump(safe, handle, indent=2)


def find_stored_login(settings):
    candidates = [str(settings.get("email") or "").strip()]
    for filename in ("last_used_presets.json", "login_presets.json"):
        value, _ = storage_paths.load_json_file(storage_paths.runtime_path(filename))
        if not isinstance(value, dict):
            continue
        if filename == "last_used_presets.json":
            candidates.append(str(value.get("login_presets.json") or "").strip())
        else:
            candidates.extend(str(email).strip() for email in value)
    for email in dict.fromkeys(filter(None, candidates)):
        password, available, _ = secure_credentials.get_login_password(email)
        if available and password:
            return email
    return ""


def sanitise_technical_details(value):
    text = str(value or "")
    patterns = (
        (r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+", r"\1[REDACTED]"),
        (r"(?i)(password|passwd|token|cookie|authorization)(\s*[:=]\s*)[^\s,;]+", r"\1\2[REDACTED]"),
    )
    for pattern, replacement in patterns:
        text = re.sub(pattern, replacement, text)
    return text


class AddressResolutionDialog(QDialog):
    def __init__(self, request, parent=None):
        super().__init__(parent)
        self.request = dict(request or {})
        self.response = {"action": "cancel"}
        candidates = list(self.request.get("candidates") or [])
        self.setWindowTitle("Select the property address")
        self.setModal(True)
        self.setMinimumWidth(560)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 26, 28, 24)
        layout.setSpacing(12)

        title = QLabel("Choose property address" if candidates else "No addresses found")
        title.setObjectName("Heading")
        explanation = QLabel(
            f"Architect Pro found addresses for {self.request.get('searched_postcode') or 'this postcode'} but couldn't safely determine which one belongs to this project."
            if candidates
            else f"Architect Pro couldn't find any addresses for {self.request.get('searched_postcode') or 'this postcode'}. Check the postcode and try again."
        )
        explanation.setObjectName("Muted")
        explanation.setWordWrap(True)
        project_label = QLabel("ARCHITECT PRO ADDRESS")
        project_label.setObjectName("Eyebrow")
        project = QLabel(str(self.request.get("project_address") or "Address not provided"))
        project.setObjectName("Site")
        project.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(explanation)
        layout.addSpacing(4)
        layout.addWidget(project_label)
        layout.addWidget(project)

        self.candidate_group = QButtonGroup(self)
        if candidates:
            returned = QLabel("THE PORTAL RETURNED")
            returned.setObjectName("Eyebrow")
            layout.addSpacing(5)
            layout.addWidget(returned)
            candidate_widget = QWidget()
            candidate_layout = QVBoxLayout(candidate_widget)
            candidate_layout.setContentsMargins(0, 0, 0, 0)
            candidate_layout.setSpacing(4)
            for candidate in candidates:
                radio = QRadioButton(str(candidate.get("display_text") or "Portal address"))
                radio.setProperty("candidate_id", candidate.get("candidate_id"))
                radio.setMinimumHeight(32)
                radio.setStyleSheet("QRadioButton { padding: 6px 4px; }")
                self.candidate_group.addButton(radio)
                radio.toggled.connect(self.update_continue_state)
                candidate_layout.addWidget(radio)
            candidate_layout.addStretch()
            scroller = QScrollArea()
            scroller.setWidgetResizable(True)
            scroller.setMaximumHeight(340)
            scroller.setWidget(candidate_widget)
            layout.addWidget(scroller)

        self.error = QLabel()
        self.error.setStyleSheet("color: #A12D2D;")
        self.error.setWordWrap(True)
        layout.addWidget(self.error)

        postcode_row = QHBoxLayout()
        self.alternate_postcode = QLineEdit()
        self.alternate_postcode.setPlaceholderText("Enter corrected postcode")
        postcode_button = QPushButton("Change postcode")
        postcode_button.clicked.connect(self.use_alternate_postcode)
        postcode_row.addWidget(self.alternate_postcode)
        postcode_row.addWidget(postcode_button)
        layout.addLayout(postcode_row)

        buttons = QHBoxLayout()
        manual = QPushButton("Open browser to resolve manually")
        manual.clicked.connect(self.use_manual_browser)
        cancel = QPushButton("Cancel automation")
        cancel.setObjectName("Danger")
        cancel.clicked.connect(self.reject)
        self.continue_button = QPushButton("Continue")
        self.continue_button.setObjectName("Primary")
        self.continue_button.setEnabled(False)
        self.continue_button.clicked.connect(self.use_selected_candidate)
        buttons.addWidget(manual)
        buttons.addStretch()
        buttons.addWidget(cancel)
        if candidates:
            buttons.addWidget(self.continue_button)
        layout.addLayout(buttons)
        self.setStyleSheet(APP_QSS)

    def update_continue_state(self):
        self.continue_button.setEnabled(self.candidate_group.checkedButton() is not None)

    def use_selected_candidate(self):
        selected = self.candidate_group.checkedButton()
        if selected is None:
            self.error.setText("Select one portal address to continue.")
            return
        self.response = {
            "action": "select",
            "candidate_id": str(selected.property("candidate_id") or ""),
        }
        self.accept()

    def use_alternate_postcode(self):
        postcode = self.alternate_postcode.text().strip().upper()
        if not re.fullmatch(r"[A-Z]{1,2}\d[A-Z\d]?\s*\d[A-Z]{2}", postcode):
            self.error.setText("Enter a valid UK postcode.")
            return
        self.response = {"action": "change_postcode", "postcode": postcode}
        self.accept()

    def use_manual_browser(self):
        self.response = {"action": "manual"}
        self.accept()


class ApplicantTitleDialog(QDialog):
    def __init__(self, request, parent=None):
        super().__init__(parent)
        self.request = dict(request or {})
        self.response = {"action": "cancel"}
        self.setWindowTitle("Applicant title required")
        self.setModal(True)
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(28, 26, 28, 24)
        layout.setSpacing(12)

        title = QLabel("Applicant title required")
        title.setObjectName("Heading")
        explanation = QLabel("Architect Pro needs the applicant's title to continue.")
        explanation.setObjectName("Muted")
        applicant = QLabel(str(self.request.get("applicant_name") or "Applicant"))
        applicant.setObjectName("Site")
        layout.addWidget(title)
        layout.addWidget(explanation)
        layout.addWidget(applicant)

        form = QFormLayout()
        self.title = QComboBox()
        self.title.addItem("Select title", "")
        for option in self.request.get("options") or []:
            self.title.addItem(str(option), str(option))
        selected = str(self.request.get("selected_title") or "")
        selected_index = self.title.findData(selected)
        if selected_index >= 0:
            self.title.setCurrentIndex(selected_index)
        self.other_title = QLineEdit()
        self.other_title.setPlaceholderText("Enter the actual title")
        form.addRow("Title", self.title)
        form.addRow("Other title", self.other_title)
        layout.addLayout(form)

        self.error = QLabel()
        self.error.setStyleSheet("color: #A12D2D;")
        layout.addWidget(self.error)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.continue_button = buttons.addButton("Continue", QDialogButtonBox.ButtonRole.AcceptRole)
        buttons.rejected.connect(self.reject)
        self.continue_button.clicked.connect(self.accept_selection)
        layout.addWidget(buttons)
        self.title.currentIndexChanged.connect(self.update_state)
        self.other_title.textChanged.connect(self.update_state)
        self.update_state()
        self.setStyleSheet(APP_QSS)

    def update_state(self):
        selected = str(self.title.currentData() or "")
        needs_other = selected == "Other"
        self.other_title.setVisible(needs_other)
        valid_other = bool(self.other_title.text().strip()) and self.other_title.text().strip().casefold() != "other"
        self.continue_button.setEnabled(bool(selected) and (not needs_other or valid_other))

    def accept_selection(self):
        selected = str(self.title.currentData() or "")
        other_title = self.other_title.text().strip()
        if not selected:
            self.error.setText("Select the applicant's title to continue.")
            return
        if selected == "Other" and (not other_title or other_title.casefold() == "other"):
            self.error.setText("Enter the applicant's actual other title to continue.")
            return
        self.response = {
            "action": "select",
            "title": selected,
            "other_title": other_title if selected == "Other" else "",
        }
        self.accept()


class CredentialDialog(QDialog):
    def __init__(self, email="", parent=None):
        super().__init__(parent)
        self.setWindowTitle("Connect eDevelopment")
        self.setModal(True)
        self.setMinimumWidth(430)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 22)
        title = QLabel("Connect eDevelopment")
        title.setObjectName("Heading")
        explanation = QLabel("Architect Pro needs your eDevelopment login to prepare applications automatically. Your password is stored in Windows Credential Manager.")
        explanation.setObjectName("Muted")
        explanation.setWordWrap(True)
        form = QFormLayout()
        self.email = QLineEdit(email)
        self.email.setPlaceholderText("name@example.com")
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        self.password.setPlaceholderText("Password")
        form.addRow("Username / Email", self.email)
        form.addRow("Password", self.password)
        self.error = QLabel()
        self.error.setStyleSheet("color: #A12D2D;")
        self.error.setWordWrap(True)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        self.save_button = buttons.addButton("Save & Continue", QDialogButtonBox.ButtonRole.AcceptRole)
        self.save_button.setObjectName("Primary")
        buttons.accepted.connect(self.save)
        buttons.rejected.connect(self.reject)
        layout.addWidget(title)
        layout.addWidget(explanation)
        layout.addSpacing(8)
        layout.addLayout(form)
        layout.addWidget(self.error)
        layout.addWidget(buttons)
        self.setStyleSheet(APP_QSS)

    def save(self):
        email = self.email.text().strip()
        password = self.password.text()
        if not email or not password:
            self.error.setText("Enter both your username/email and password.")
            return
        ok, message = secure_credentials.save_login_password(email, password)
        if not ok:
            self.error.setText(message)
            return
        self.password.clear()
        self.accept()


class SettingsDialog(QDialog):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = dict(settings)
        self.setWindowTitle("Agent settings")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 24, 26, 22)
        title = QLabel("Agent settings")
        title.setObjectName("Heading")
        account = QFrame()
        account.setObjectName("AgentCard")
        account_layout = QVBoxLayout(account)
        account_layout.addWidget(QLabel("EDEVELOPMENT ACCOUNT"))
        self.account_label = QLabel(settings.get("email") or "Not connected")
        self.account_label.setObjectName("Site")
        self.account_status = QLabel("Connected" if find_stored_login(settings) else "Login required")
        self.account_status.setObjectName("Connection")
        account_layout.addWidget(self.account_label)
        account_layout.addWidget(self.account_status)
        actions = QHBoxLayout()
        change = QPushButton("Change login")
        change.clicked.connect(self.change_login)
        remove = QPushButton("Remove saved login")
        remove.clicked.connect(self.remove_login)
        actions.addWidget(change); actions.addWidget(remove); actions.addStretch()
        account_layout.addLayout(actions)
        mode_label = QLabel("Browser mode")
        self.mode = QComboBox()
        self.mode.addItems([mode.value for mode in BrowserMode])
        self.mode.setCurrentText(settings["browser_mode"])
        mode_help = QLabel("AUTO hides the owned Chrome window and reveals it at Fee. VISIBLE is for troubleshooting. HEADLESS cannot provide the Fee handoff.")
        mode_help.setObjectName("Muted")
        mode_help.setWordWrap(True)
        agent_box = QFrame(); agent_box.setObjectName("AgentCard")
        agent_layout = QVBoxLayout(agent_box)
        credential, _, _ = secure_credentials.get_agent_credential()
        accepted = getattr(parent, "_enrollment_state", "DISCONNECTED") in {"READY", "RUNNING", "USER_ACTION_REQUIRED"}
        self.agent_status = QLabel("Connected to Architect Pro" if accepted else "Connection needs attention" if credential else "Not connected")
        self.agent_status.setObjectName("Connection")
        connect_agent = QPushButton("Reconnect Agent" if credential else "Connect Agent")
        connect_agent.clicked.connect(self.connect_agent)
        reset_agent = QPushButton("Reset & reconnect")
        reset_agent.setObjectName("Danger")
        reset_agent.clicked.connect(self.reset_agent_connection)
        self.start_with_windows = QCheckBox("Start Architect Pro Agent with Windows")
        self.start_with_windows.setChecked(bool(settings.get("start_with_windows")))
        agent_layout.addWidget(QLabel("BACKGROUND AGENT")); agent_layout.addWidget(self.agent_status); agent_layout.addWidget(connect_agent); agent_layout.addWidget(self.start_with_windows)
        agent_layout.addWidget(reset_agent)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept); buttons.rejected.connect(self.reject)
        layout.addWidget(title); layout.addWidget(agent_box); layout.addWidget(account); layout.addWidget(mode_label); layout.addWidget(self.mode); layout.addWidget(mode_help); layout.addWidget(buttons)
        self.setStyleSheet(APP_QSS)

    def change_login(self):
        dialog = CredentialDialog(self.settings.get("email", ""), self)
        if dialog.exec():
            self.settings["email"] = dialog.email.text().strip()
            self.account_label.setText(self.settings["email"])
            self.account_status.setText("Connected")

    def remove_login(self):
        email = self.settings.get("email", "")
        if email:
            secure_credentials.delete_login_password(email)
        self.settings["email"] = ""
        self.account_label.setText("Not connected")
        self.account_status.setText("Login required")

    def connect_agent(self):
        self.accept()
        parent = self.parent()
        if parent and hasattr(parent, "begin_agent_enrollment"):
            QTimer.singleShot(0, lambda: parent.begin_agent_enrollment(force=True))

    def reset_agent_connection(self):
        self.accept()
        parent = self.parent()
        if parent:
            QTimer.singleShot(0, parent.reset_agent_connection)

    def values(self):
        return {
            "email": self.settings.get("email", ""),
            "browser_mode": self.mode.currentText(),
            "start_with_windows": self.start_with_windows.isChecked(),
        }


class AgentEnrollmentThread(QThread):
    connected = Signal(object)
    failed = Signal(str)

    def __init__(self, portal_url=None, parent=None):
        super().__init__(parent)
        self.portal_url = portal_url

    def run(self):
        try:
            client = agent_enrollment.enroll_via_browser(self.portal_url)
        except Exception as exc:
            self.failed.emit(str(exc))
            return
        self.connected.emit(client)


class AgentResetThread(QThread):
    completed = Signal()
    failed = Signal(str, str)

    def __init__(self, background_thread=None, parent=None):
        super().__init__(parent)
        self.background_thread = background_thread

    def run(self):
        try:
            if self.background_thread:
                if self.background_thread.isRunning() and not self.background_thread.wait(50_000):
                    raise portal_handoff.PortalHandoffError("The Agent is still finishing a connection request. Wait a moment and try reset again.")
                engine = self.background_thread.engine
                if engine.current_job_id or engine.pending_release:
                    raise portal_handoff.PortalHandoffError("Finish or release the current application before resetting the Agent connection.")
            agent_connection.reset_connection()
        except Exception as error:
            self.failed.emit(str(error), agent_connection.connection_failure_state(error))
            return
        self.completed.emit()


class JobLoadThread(QThread):
    loaded = Signal(object, object, object, object)
    failed = Signal(str)
    phase = Signal(str)

    def __init__(self, launch_url, client=None, job_id=""):
        super().__init__(); self.launch_url = launch_url; self.client = client; self.job_id = job_id

    def run(self):
        try:
            self.phase.emit("connecting")
            client, job_id = self.client, self.job_id
            if client is None:
                if not self.launch_url:
                    self.phase.emit("looking")
                    self.failed.emit("No automation job ready"); return
                launch = portal_handoff.parse_automation_launch(self.launch_url)
                client = portal_handoff.PortalClient.from_handoff(launch["portal_url"], launch["job_id"], launch["code"])
                job_id = launch["job_id"]
            self.phase.emit("looking")
            job = client.get_job(job_id)
            if not job:
                raise portal_handoff.PortalHandoffError("The automation job could not be loaded.")
            self.phase.emit("loading")
            documents, failures = client.download_documents(job)
            self.loaded.emit(job, client, documents, failures)
        except Exception as exc:
            self.failed.emit(str(exc))


class AutomationThread(QThread):
    progress = Signal(object)
    completed = Signal(object)
    start_rejected = Signal(str)
    address_resolution_required = Signal(object)
    applicant_title_resolution_required = Signal(object)

    def __init__(self, runtime_job, password, browser_mode, portal_client=None):
        super().__init__()
        from automation.runner import CancellationToken
        self.runtime_job = runtime_job; self.password = password; self.browser_mode = browser_mode
        self.portal_client = portal_client; self.cancellation = CancellationToken()
        self._execution_entered = False
        self._address_response = None
        self._address_wait = threading.Event()
        self._applicant_title_response = None
        self._applicant_title_wait = threading.Event()

    def cancel(self):
        self.cancellation.cancel()
        self.provide_address_resolution({"action": "cancel"})
        self.provide_applicant_title_resolution({"action": "cancel"})

    def provide_address_resolution(self, response):
        self._address_response = dict(response or {"action": "cancel"})
        self._address_wait.set()

    def resolve_address(self, request):
        self._address_response = None
        self._address_wait.clear()
        self.address_resolution_required.emit(dict(request))
        while not self._address_wait.wait(0.1):
            if self.cancellation.cancelled:
                return {"action": "cancel"}
        return dict(self._address_response or {"action": "cancel"})

    def provide_applicant_title_resolution(self, response):
        self._applicant_title_response = dict(response or {"action": "cancel"})
        self._applicant_title_wait.set()

    def resolve_applicant_title(self, request):
        self._applicant_title_response = None
        self._applicant_title_wait.clear()
        self.applicant_title_resolution_required.emit(dict(request))
        while not self._applicant_title_wait.wait(0.1):
            if self.cancellation.cancelled:
                return {"action": "cancel"}
        return dict(self._applicant_title_response or {"action": "cancel"})

    def _callback(self, payload):
        if self.portal_client:
            try:
                return callback_outbox.queue_and_deliver(
                    self.portal_client,
                    payload=payload,
                    allow_start=payload.get("eventType") == "started",
                )
            except OSError:
                return False
        return False

    def run(self):
        from automation.runner import run_automation
        if self._execution_entered:
            return
        started = build_started_callback(self.runtime_job.job_id)
        # Lost acknowledgement retries use the same idempotency key, within this
        # live invocation only. No browser is created before an affirmative ack.
        acknowledged = False
        for _ in range(3):
            if self.cancellation.cancelled:
                break
            if self._callback(started):
                acknowledged = True
                break
        if not acknowledged or self.cancellation.cancelled:
            self.password = ""
            self.start_rejected.emit("Start was not acknowledged by Architect Pro. No automation was started. Review the application in Architect Pro before retrying.")
            return
        self._execution_entered = True
        result = run_automation(
            self.runtime_job, browser_mode=self.browser_mode, password=self.password,
            cancellation_token=self.cancellation, progress_callback=self.progress.emit,
            address_resolution_callback=self.resolve_address,
            applicant_title_resolution_callback=self.resolve_applicant_title,
        )
        if result.address_correction_postcode:
            event = callback_outbox.build_outbox_event(
                map_runner_result_callback(result, include_browser_metadata=bool(getattr(self.runtime_job, "metadata", {}).get("state_model", {}).get("retainedBrowserMetadata"))),
                address_correction_postcode=result.address_correction_postcode,
            )
            persistence_failed = False
            try:
                delivered = callback_outbox.deliver_event(event, client=self.portal_client)
            except OSError:
                delivered = False
                persistence_failed = True
            if delivered:
                result = replace(result, fresh_retry_job_id=event["addressCorrection"]["newJobId"])
            else:
                detail = ("Postcode recovery could not be saved on this device. Review and correct the application in Architect Pro before retrying."
                          if persistence_failed else
                          "Review the current application in Architect Pro; postcode recovery needs attention."
                          if event.get("recoveryBlocked") else
                          "Postcode recovery is saved on this device and will retry when connected. The corrected attempt has not yet been confirmed.")
                result = replace(result, message=f"{result.message} {detail}")
        else:
            self._callback(map_runner_result_callback(result, include_browser_metadata=bool(getattr(self.runtime_job, "metadata", {}).get("state_model", {}).get("retainedBrowserMetadata"))))
        self.password = ""; self.completed.emit(result)


class CallbackRetryThread(QThread):
    completed = Signal(object)

    def run(self):
        self.completed.emit(callback_outbox.retry_pending())


class ExistingApplicationThread(QThread):
    opened = Signal(str)
    failed = Signal(str)

    def __init__(self, job_id, application_type, user_inputs, password, parent=None):
        super().__init__(parent)
        self.job_id = job_id
        self.application_type = application_type
        self.user_inputs = dict(user_inputs)
        self.password = password

    def run(self):
        managed = create_managed_chrome(BrowserMode.AUTO)
        managed.bind_to_job(self.job_id)
        try:
            driver = managed.start()
            open_existing_application(
                driver,
                self.application_type,
                self.user_inputs,
                password=self.password,
            )
            managed.handoff_to_user()
            self.opened.emit(str(driver.session_id))
        except Exception as exc:
            managed.close()
            self.failed.emit(str(exc))
        finally:
            self.password = ""


class BackgroundPollThread(QThread):
    claimed = Signal(object, str, str)
    connection_state = Signal(str, str)
    command_received = Signal(object)

    def __init__(self, parent=None, engine=None):
        super().__init__(parent)
        self.engine = engine or background_agent.PollingEngine()
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()

    def set_run(self, job_id=None, agent_run_id=None, state="READY"):
        self.engine.set_run(job_id, agent_run_id, state)
        self._stop_event.set()

    def run(self):
        while not self.isInterruptionRequested():
            self._stop_event.clear()
            credential, _, _ = secure_credentials.get_agent_credential()
            if not credential:
                self.connection_state.emit("DISCONNECTED", "Connect this Agent in Settings")
                self._stop_event.wait(10.0)
                continue
            try:
                claimed, delay = self.engine.tick()
                self.connection_state.emit(self.engine.state, "Ready for applications" if not self.engine.current_job_id else "Application running")
                if claimed:
                    self.claimed.emit(claimed["client"], claimed["job_id"], claimed["agent_run_id"])
                    delay = 30.0
                for command in self.engine.pending_commands:
                    self.command_received.emit(command)
            except Exception as exc:
                self.connection_state.emit(agent_connection.connection_failure_state(exc), str(exc))
                delay = self.engine.failed_delay()
            self._stop_event.wait(max(1.0, min(delay, 30.0)))


class AutomationAgent(QWidget):
    def __init__(self, launch_url=None, *, auto_refresh=True, auto_onboard=True):
        super().__init__()
        self.launch_url = launch_url; self.settings = load_settings()
        stored_email = find_stored_login(self.settings)
        if stored_email and stored_email != self.settings["email"]:
            self.settings["email"] = stored_email; save_settings(self.settings)
        self.portal_client = None; self.portal_job = None; self.runtime_job = None
        self._retired_job_ids = set()
        self.load_thread = None; self.automation_thread = None; self.estimator = None
        self.callback_retry_thread = None
        self.enrollment_thread = None
        self.reset_thread = None
        self._reset_succeeded = False
        self._enrollment_state = "DISCONNECTED"
        self.view_application_thread = None
        self._view_command = None
        self.background_thread = None; self.progress_publisher = None
        self._auto_start_claimed = False; self._quitting = False
        self._result_action = "ready"
        self.setWindowTitle("Architect Pro")
        self.setMinimumSize(540, 500); self.resize(600, 540); self.setStyleSheet(APP_QSS)
        self.eta_timer = QTimer(self); self.eta_timer.setInterval(1000); self.eta_timer.timeout.connect(self.update_progress_clock)
        self.callback_retry_timer = QTimer(self); self.callback_retry_timer.setInterval(30_000); self.callback_retry_timer.timeout.connect(self.retry_callback_outbox)
        self._build()
        self._setup_tray()
        if auto_refresh:
            self.show_loading("connecting")
        else:
            self.show_no_job()
        credential, _, _ = secure_credentials.get_agent_credential()
        if auto_onboard:
            QTimer.singleShot(0, self.ensure_agent_enrollment)
        if auto_refresh:
            if self.launch_url or credential:
                QTimer.singleShot(0, self.refresh_job)
            QTimer.singleShot(0, self.retry_callback_outbox)
            self.callback_retry_timer.start()
            if credential:
                self.start_background_agent()

    def _setup_tray(self):
        self.tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        icon_path = packaged_asset_path("architect-pro-mark.png")
        self.tray = QSystemTrayIcon(QIcon(icon_path), self)
        self.tray.setToolTip("Architect Pro Agent — checking connection")
        menu = QMenu(self)
        open_action = QAction("Open Architect Pro Agent", self); open_action.triggered.connect(self.show_from_tray)
        settings_action = QAction("Settings", self); settings_action.triggered.connect(self.open_settings)
        self.startup_action = QAction("Start with Windows", self); self.startup_action.setCheckable(True)
        self.startup_action.setChecked(background_agent.start_with_windows_enabled())
        self.startup_action.toggled.connect(self.toggle_start_with_windows)
        quit_action = QAction("Quit", self); quit_action.triggered.connect(self.quit_agent)
        menu.addAction(open_action); menu.addAction(settings_action); menu.addAction(self.startup_action); menu.addSeparator(); menu.addAction(quit_action)
        self.tray.setContextMenu(menu); self.tray.activated.connect(lambda reason: self.show_from_tray() if reason == QSystemTrayIcon.ActivationReason.Trigger else None)
        self.tray.show()

    def show_from_tray(self):
        self.showNormal(); self.raise_(); self.activateWindow()

    def toggle_start_with_windows(self, enabled):
        try:
            background_agent.set_start_with_windows(enabled)
            self.settings["start_with_windows"] = bool(enabled); save_settings(self.settings)
        except OSError as exc:
            self.technical_log.append(sanitise_technical_details(exc))

    def quit_agent(self):
        self._quitting = True
        self._stop_background_agent()
        if self.progress_publisher:
            self.progress_publisher.close()
        QApplication.quit()

    def closeEvent(self, event):
        if self.tray and not self._quitting:
            event.ignore(); self.hide(); self.tray.showMessage("Architect Pro Agent", "Still running in the background and ready for applications.", QSystemTrayIcon.MessageIcon.Information, 2500)
            return
        self._stop_background_agent()
        super().closeEvent(event)

    def _stop_background_agent(self):
        if self.background_thread and self.background_thread.isRunning():
            self.background_thread.requestInterruption()
            self.background_thread.stop()
            self.background_thread.wait(3000)

    def start_background_agent(self):
        if self.background_thread and self.background_thread.isRunning():
            self.background_thread.stop(); return
        self.background_thread = BackgroundPollThread(self)
        self.background_thread.claimed.connect(self.on_background_job_claimed)
        self.background_thread.connection_state.connect(self.on_background_connection_state)
        self.background_thread.command_received.connect(self.on_background_command)
        self.background_thread.start()

    def ensure_agent_enrollment(self):
        credential, _, _ = secure_credentials.get_agent_credential()
        if credential:
            if not self.background_thread or not self.background_thread.isRunning():
                self.start_background_agent()
            QTimer.singleShot(0, self.ensure_credentials)
            return True
        self.begin_agent_enrollment()
        return False

    def begin_agent_enrollment(self, force=False):
        if self.reset_thread and self.reset_thread.isRunning():
            return
        if self._has_active_execution():
            self.message.setText("Finish or release the current application before reconnecting this Agent.")
            return
        if self.enrollment_thread and self.enrollment_thread.isRunning():
            self.showNormal(); self.raise_(); self.activateWindow()
            return
        if force:
            self._stop_background_agent()
            if self.background_thread and self.background_thread.isRunning():
                self.message.setText("The Agent is finishing a connection request. Wait a moment and try again.")
                return
            if self._has_active_execution():
                self.message.setText("Finish or release the current application before reconnecting this Agent.")
                return
            self.background_thread = None
        self.showNormal(); self.raise_(); self.activateWindow()
        self.show_agent_connecting()
        self.enrollment_thread = AgentEnrollmentThread(parent=self)
        self.enrollment_thread.connected.connect(self.on_agent_enrolled)
        self.enrollment_thread.failed.connect(self.on_agent_enrollment_failed)
        self.enrollment_thread.start()

    def on_agent_enrolled(self, _client):
        self._enrollment_state = "CONNECTING"
        self.show_no_job("Connection saved. Checking authenticated Agent connection…")
        self._render_enrollment_connection()
        self.start_background_agent()
        QTimer.singleShot(0, self.ensure_credentials)

    def on_agent_enrollment_failed(self, message):
        self._enrollment_state = "AUTH_REQUIRED"
        self.estimator = None
        self.eta_timer.stop()
        self._render_enrollment_connection()
        self._set_card_state("error")
        self.eyebrow.setText("NEEDS ATTENTION")
        self.heading.setText("Couldn't connect this computer")
        self.site.clear(); self.application_type.clear()
        self.message.setText(str(message or "Return to Architect Pro and try connecting the Agent again."))
        self.loading_area.hide(); self.progress_area.hide()
        self._set_controls(connect=True)
        self.technical_log.clear(); self.technical_log.hide(); self.technical_toggle.hide(); self.copy_technical_button.hide()
        credential, _, _ = secure_credentials.get_agent_credential()
        if credential and (not self.background_thread or not self.background_thread.isRunning()):
            self.start_background_agent()

    def show_agent_connecting(self):
        self.estimator = None
        self.eta_timer.stop()
        self._enrollment_state = "CONNECTING"
        self._render_enrollment_connection()
        self._set_card_state()
        self.eyebrow.setText("DESKTOP AUTOMATION")
        self.heading.setText("Connecting this computer…")
        self.site.clear(); self.application_type.clear()
        self.message.setText("Finish signing in through the browser if prompted. No connection code is required.")
        self.loading_detail.setText("Waiting for secure browser authorisation")
        self.progress_area.hide(); self.loading_area.show(); self._set_controls()
        self.technical_log.clear(); self.technical_log.hide(); self.technical_toggle.hide(); self.copy_technical_button.hide()

    def on_background_connection_state(self, state, detail):
        self._enrollment_state = state
        self._render_enrollment_connection()
        if state == "AUTH_REQUIRED":
            self.message.setText("This Agent is no longer connected to Architect Pro. Choose Reset & reconnect to connect this computer again.")
            self.reset_button.show()
        elif state == "OFFLINE":
            self.message.setText("Offline — reconnecting. Your saved connection has been kept.")
        elif state == "READY" and not self._has_active_execution() and not self.runtime_job:
            self.message.setText("Connected and ready. Prepare an application in Architect Pro and it will appear here.")
        if self.tray:
            self.tray.setToolTip(f"Architect Pro Agent — {detail}")

    def _render_enrollment_connection(self):
        labels = {"DISCONNECTED": "● Agent disconnected", "AUTH_REQUIRED": "● Connection needs attention", "OFFLINE": "● Offline — reconnecting", "READY": "● Connected", "RUNNING": "● Agent running", "USER_ACTION_REQUIRED": "● Action required"}
        self.connection.setText(labels.get(self._enrollment_state, "● Checking connection…"))
        self.connection.setStyleSheet("color: #166534;" if self._enrollment_state in {"READY", "RUNNING", "USER_ACTION_REQUIRED"} else "color: #92400e;")

    def _has_active_execution(self):
        engine = self.background_thread.engine if self.background_thread else None
        return bool((self.automation_thread and self.automation_thread.isRunning())
                    or (self.load_thread and self.load_thread.isRunning())
                    or (self.view_application_thread and self.view_application_thread.isRunning())
                    or (engine and (engine.current_job_id or engine.pending_release))
                    or self._result_action == "fee")

    def reset_agent_connection(self):
        from PySide6.QtWidgets import QMessageBox
        if (self.reset_thread and self.reset_thread.isRunning()) or (self.enrollment_thread and self.enrollment_thread.isRunning()):
            return
        if self._has_active_execution():
            self.message.setText("Finish or release the current application before resetting the Agent connection.")
            return
        choice = QMessageBox.question(self, "Reset this Agent connection?",
            "This disconnects this computer from Architect Pro and starts a fresh connection.\n\nIt does not delete projects, applications or portal data. Your portal login and this computer's installation identity are kept.",
            QMessageBox.StandardButton.Cancel | QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.Cancel)
        if choice != QMessageBox.StandardButton.Yes:
            return
        if self.background_thread:
            self.background_thread.requestInterruption(); self.background_thread.stop()
        self.message.setText("Resetting the Agent connection…")
        self.reset_button.setEnabled(False)
        self.reset_thread = AgentResetThread(self.background_thread, self)
        self._reset_succeeded = False
        self.reset_thread.completed.connect(self.on_agent_reset)
        self.reset_thread.failed.connect(self.on_agent_reset_failed)
        self.reset_thread.finished.connect(self._finish_connection_reset)
        self.reset_thread.start()

    def on_agent_reset(self):
        self._reset_succeeded = True
        self.background_thread = None
        self.portal_client = None; self.portal_job = None; self.runtime_job = None
        self._enrollment_state = "DISCONNECTED"
        self._render_enrollment_connection()
        self.reset_button.setEnabled(True)
        self.message.setText("Connection reset. Reconnecting securely…")
        # finished is emitted after completed; enrollment starts only once the
        # reset worker has actually stopped.

    def _finish_connection_reset(self):
        if self._reset_succeeded:
            self.begin_agent_enrollment(force=True)

    def on_agent_reset_failed(self, message, connection_state="OFFLINE"):
        self.reset_button.setEnabled(True)
        self.message.setText(message)
        self._enrollment_state = connection_state
        self._render_enrollment_connection()
        if not self._has_active_execution():
            self.start_background_agent()

    def on_background_job_claimed(self, client, job_id, agent_run_id):
        if self.automation_thread and self.automation_thread.isRunning():
            return
        self.portal_client = client
        self.portal_job = {"id": job_id}
        self._auto_start_claimed = True
        self.show_loading("loading")
        self.refresh_job()

    def on_background_command(self, command):
        if command.get("type") not in {"REVEAL_BROWSER", "OPEN_APPLICATION"} or not self.background_thread:
            return
        engine = self.background_thread.engine
        legacy_reveal = command.get("type") == "REVEAL_BROWSER"
        if legacy_reveal and (
            command.get("jobId") != engine.current_job_id
            or command.get("agentRunId") != engine.agent_run_id
        ):
            return
        try:
            reveal_handed_off_browser(command["jobId"])
        except Exception as exc:
            if legacy_reveal:
                self.technical_log.append(sanitise_technical_details(exc))
                self.showNormal(); self.raise_(); self.activateWindow()
                self.message.setText("The existing fee browser could not be brought to the front. Try Open fee in browser again.")
                return
            self._open_completed_application(command)
            return
        if self.tray:
            title = "Fee browser opened" if legacy_reveal else "Application opened"
            detail = "Continue the fee in the existing portal session." if legacy_reveal else "Review the prepared application in the existing portal session."
            self.tray.showMessage(title, detail, QSystemTrayIcon.MessageIcon.Information, 4000)
        self._acknowledge_view_command(command)

    def _acknowledge_view_command(self, command):
        try:
            background_agent.AgentApi().acknowledge_browser_reveal(
                command["jobId"], command["agentRunId"], command["requestedAt"]
            )
        except Exception as exc:
            # The next heartbeat safely retries the same idempotent command.
            self.technical_log.append(sanitise_technical_details(exc))

    def _open_completed_application(self, command):
        if self.view_application_thread and self.view_application_thread.isRunning():
            return
        try:
            job = background_agent.AgentApi().get_view_job(command["jobId"])
            if not job:
                raise RuntimeError("The prepared application could not be loaded from Architect Pro.")
            email = find_stored_login(self.settings)
            password, _, _ = secure_credentials.get_login_password(email)
            if not password:
                if not self.change_login(first_run=True):
                    raise RuntimeError("Saved portal credentials are required to open this application.")
                email = find_stored_login(self.settings)
                password, _, _ = secure_credentials.get_login_password(email)
            if not email or not password:
                raise RuntimeError("Saved portal credentials are required to open this application.")
            values = portal_handoff.portal_job_to_values(job)
            values["Email"] = email
        except Exception as exc:
            self._show_view_application_error(command, exc)
            return

        self._view_command = dict(command)
        self.showNormal(); self.raise_(); self.activateWindow()
        self._set_card_state()
        self.eyebrow.setText("OPENING APPLICATION")
        self.heading.setText("Opening prepared application")
        self.message.setText("Architect Pro is finding the exact saved government application.")
        self._set_controls()
        self.view_application_thread = ExistingApplicationThread(
            command["jobId"],
            str(job.get("type") or ""),
            values,
            password,
            self,
        )
        self.view_application_thread.opened.connect(self._on_view_application_opened)
        self.view_application_thread.failed.connect(
            lambda message: self._show_view_application_error(command, message)
        )
        self.view_application_thread.start()

    def _on_view_application_opened(self, _session_id):
        command = self._view_command or {}
        self.eyebrow.setText("APPLICATION OPEN")
        self.heading.setText("Application ready to review")
        self.message.setText("The prepared application is open in your browser. Architect Pro will not make any further changes.")
        self._set_controls(result=True)
        if self.tray:
            self.tray.showMessage("Application opened", "The prepared government application is ready to review.", QSystemTrayIcon.MessageIcon.Information, 4000)
        if command:
            self._acknowledge_view_command(command)

    def _show_view_application_error(self, command, error):
        message = sanitise_technical_details(error)
        self.technical_log.append(message)
        self.showNormal(); self.raise_(); self.activateWindow()
        self._set_card_state("error")
        application = (
            "Building Warrant"
            if "WARRANT" in str(command.get("applicationType") or "")
            else "Householder application"
        )
        self.eyebrow.setText("COULDN'T OPEN APPLICATION")
        self.heading.setText(f"Couldn't open the {application}")
        self.message.setText(
            "Architect Pro couldn't find or open the exact existing application. "
            "No new proposal was created. Review the technical details and try again."
        )
        self._set_controls(result=True)
        self._acknowledge_view_command(command)

    def set_background_run_state(self, state="READY", keep_job=False):
        if not self.background_thread:
            return
        job_id = self.background_thread.engine.current_job_id if keep_job else None
        run_id = self.background_thread.engine.agent_run_id if keep_job else None
        self.background_thread.set_run(job_id, run_id, state)

    def retry_callback_outbox(self):
        if not callback_outbox.pending_events():
            return
        if self.callback_retry_thread and self.callback_retry_thread.isRunning():
            return
        self.callback_retry_thread = CallbackRetryThread(self)
        self.callback_retry_thread.completed.connect(self.on_callback_retry_completed)
        self.callback_retry_thread.start()

    def on_callback_retry_completed(self, result):
        if result.get("blocked"):
            self.technical_log.append("Postcode recovery needs attention. Review the current application in Architect Pro.")
            if not (self.automation_thread and self.automation_thread.isRunning()):
                self.message.setText("A saved postcode recovery could not be applied. Review the current application in Architect Pro; the old attempt will not be replayed.")
        if result.get("delivered"):
            self.technical_log.append(
                f"Portal result sync: {result['delivered']} delivered."
            )

    def _build(self):
        outer = QVBoxLayout(self); outer.setContentsMargins(28, 24, 28, 24); outer.setSpacing(14)
        header = QHBoxLayout()
        logo = QLabel(); logo.setFixedSize(36, 36)
        pixmap = QPixmap(packaged_asset_path("architect-pro-mark.png"))
        if not pixmap.isNull(): logo.setPixmap(pixmap.scaled(36, 36, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        else: logo.setText("AP")
        brand = QLabel("Architect Pro"); brand.setObjectName("Brand")
        self.connection = QLabel("● Checking connection"); self.connection.setObjectName("Connection")
        header.addWidget(logo); header.addWidget(brand); header.addStretch(); header.addWidget(self.connection)
        self.card = QFrame(); self.card.setObjectName("AgentCard")
        card = QVBoxLayout(self.card); card.setContentsMargins(28, 26, 28, 24); card.setSpacing(11)
        self.eyebrow = QLabel("AUTOMATION AGENT"); self.eyebrow.setObjectName("Eyebrow")
        self.heading = QLabel(); self.heading.setObjectName("Heading"); self.heading.setWordWrap(True)
        self.site = QLabel(); self.site.setObjectName("Site"); self.site.setWordWrap(True)
        self.application_type = QLabel(); self.application_type.setObjectName("Muted")
        self.message = QLabel(); self.message.setObjectName("Muted"); self.message.setWordWrap(True)
        self.progress_area = QWidget(); progress_layout = QVBoxLayout(self.progress_area); progress_layout.setContentsMargins(0, 8, 0, 0); progress_layout.setSpacing(8)
        progress_header = QHBoxLayout(); self.percent = QLabel("0%"); self.percent.setObjectName("Percent"); self.eta = QLabel("Estimating time remaining…"); self.eta.setObjectName("Muted")
        progress_header.addWidget(self.percent); progress_header.addStretch(); progress_header.addWidget(self.eta)
        self.progress_bar = QProgressBar(); self.progress_bar.setRange(0, 100); self.progress_bar.setTextVisible(False)
        self.current_task = QLabel(); self.current_task.setObjectName("Task")
        self.progress_list = QListWidget(); self.progress_list.setFixedHeight(190); self.progress_list.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        progress_layout.addLayout(progress_header); progress_layout.addWidget(self.progress_bar); progress_layout.addWidget(self.current_task); progress_layout.addWidget(self.progress_list)
        self.loading_area = QWidget(); loading_layout = QVBoxLayout(self.loading_area); loading_layout.setContentsMargins(0, 8, 0, 4); loading_layout.setSpacing(8)
        self.loading_bar = QProgressBar(); self.loading_bar.setRange(0, 0); self.loading_bar.setTextVisible(False)
        self.loading_detail = QLabel("Checking for prepared applications"); self.loading_detail.setObjectName("Muted")
        loading_layout.addWidget(self.loading_bar); loading_layout.addWidget(self.loading_detail)
        self.start_button = QPushButton("Start Automation"); self.start_button.setObjectName("Primary"); self.start_button.clicked.connect(self.start_automation)
        self.stop_button = QPushButton("Stop Automation"); self.stop_button.setObjectName("Danger"); self.stop_button.clicked.connect(self.stop_automation)
        self.result_button = QPushButton("Done"); self.result_button.clicked.connect(self.handle_result_action)
        self.browser_button = QPushButton("Open fee in browser"); self.browser_button.setObjectName("Primary"); self.browser_button.clicked.connect(self.reveal_fee_browser)
        self.update_login_button = QPushButton("Update login"); self.update_login_button.clicked.connect(self.change_login)
        self.connect_button = QPushButton("Try again"); self.connect_button.setObjectName("Primary"); self.connect_button.clicked.connect(self.begin_agent_enrollment)
        self.reset_button = QPushButton("Reset & reconnect"); self.reset_button.setObjectName("Danger"); self.reset_button.clicked.connect(self.reset_agent_connection)
        actions = QHBoxLayout(); actions.addWidget(self.start_button); actions.addWidget(self.stop_button); actions.addWidget(self.browser_button); actions.addWidget(self.result_button); actions.addWidget(self.update_login_button); actions.addWidget(self.connect_button)
        actions.addWidget(self.reset_button)
        technical_actions = QHBoxLayout()
        self.technical_toggle = QPushButton("View technical details"); self.technical_toggle.setObjectName("Link"); self.technical_toggle.clicked.connect(self.toggle_technical)
        self.copy_technical_button = QPushButton("Copy technical details"); self.copy_technical_button.setObjectName("Link"); self.copy_technical_button.clicked.connect(self.copy_technical_details)
        technical_actions.addWidget(self.technical_toggle); technical_actions.addWidget(self.copy_technical_button); technical_actions.addStretch()
        self.technical_log = QTextEdit(); self.technical_log.setReadOnly(True); self.technical_log.setFixedHeight(120)
        for widget in (self.eyebrow, self.heading, self.site, self.application_type, self.message, self.loading_area, self.progress_area): card.addWidget(widget)
        card.addLayout(actions); card.addLayout(technical_actions); card.addWidget(self.technical_log)
        footer = QHBoxLayout(); self.refresh_button = QPushButton("Refresh"); self.refresh_button.clicked.connect(self.refresh_job); self.settings_button = QPushButton("Settings"); self.settings_button.clicked.connect(self.open_settings); footer.addWidget(self.refresh_button); footer.addWidget(self.settings_button); footer.addStretch()
        outer.addLayout(header); outer.addWidget(self.card); outer.addLayout(footer); outer.addStretch()
        self.technical_log.hide()
        self.copy_technical_button.hide()

    def _set_card_state(self, state="normal"):
        self.card.setProperty("state", state)
        self.card.style().unpolish(self.card)
        self.card.style().polish(self.card)
        self.eyebrow.setObjectName("ErrorEyebrow" if state == "error" else "Eyebrow")
        self.eyebrow.style().unpolish(self.eyebrow)
        self.eyebrow.style().polish(self.eyebrow)

    def showEvent(self, event):
        if not getattr(self, "_centred", False):
            screen = QGuiApplication.primaryScreen()
            if screen:
                frame = self.frameGeometry(); frame.moveCenter(screen.availableGeometry().center()); self.move(frame.topLeft())
            self._centred = True
        super().showEvent(event)

    def _application_label(self):
        if not self.runtime_job: return "Application"
        value = self.runtime_job.application_type
        return "Householder Planning" if value in {"HOUSEHOLDER_PLANNING", "PLANNING_APPLICATION"} else "Building Warrant"

    def _set_controls(self, *, start=False, stop=False, result=False, update_login=False, reveal=False, connect=False):
        self.start_button.setVisible(start); self.stop_button.setVisible(stop)
        self.browser_button.setVisible(reveal); self.result_button.setVisible(result); self.update_login_button.setVisible(update_login)
        self.connect_button.setVisible(connect)

    def _resize_for_state(self, running=False):
        self.resize(self.width(), 660 if running else 540)

    def _reset_progress_display(self):
        self.progress_bar.setValue(0); self.percent.setText("0%")
        self.eta.setText("Estimating time remaining…"); self.eta.show(); self.current_task.clear(); self.progress_list.clear()

    def show_loading(self, phase="connecting"):
        states = {
            "connecting": ("● Connecting…", "Connecting to Architect Pro…", "Establishing a secure connection"),
            "looking": ("● Connecting…", "Looking for prepared application…", "Checking for prepared applications"),
            "loading": ("● Connected", "Loading prepared application…", "Retrieving job details and documents"),
        }
        connection, heading, detail = states.get(phase, states["connecting"])
        self.estimator = None; self.eta_timer.stop(); self._render_enrollment_connection(); self._set_card_state()
        self.eyebrow.setText("AUTOMATION AGENT"); self.heading.setText(heading)
        self.site.clear(); self.application_type.clear(); self.message.clear(); self.loading_detail.setText(detail)
        self._reset_progress_display(); self.progress_area.hide(); self.loading_area.show(); self._set_controls()
        self.technical_log.clear(); self.technical_log.hide(); self.technical_toggle.hide(); self.copy_technical_button.hide(); self._resize_for_state()

    def ensure_credentials(self):
        if find_stored_login(self.settings): return True
        return self.change_login(first_run=True)

    def change_login(self, first_run=False):
        dialog = CredentialDialog(self.settings.get("email", ""), self)
        if not dialog.exec(): return False
        self.settings["email"] = dialog.email.text().strip(); save_settings(self.settings)
        if self.portal_job: self.refresh_job()
        return True

    def show_no_job(self, detail="Prepare an application in Architect Pro and it will appear here."):
        self.estimator = None; self.eta_timer.stop(); self._render_enrollment_connection(); self._set_card_state()
        self.eyebrow.setText("AUTOMATION AGENT"); self.heading.setText("No application ready")
        self.site.clear(); self.application_type.clear(); self.message.setText(detail)
        self._reset_progress_display(); self.loading_area.hide(); self.progress_area.hide(); self._set_controls(); self.technical_log.clear(); self.technical_log.hide(); self.technical_toggle.hide(); self.copy_technical_button.hide()
        self._resize_for_state()

    def show_load_error(self, technical_message):
        self.estimator = None; self.eta_timer.stop(); self._render_enrollment_connection(); self._set_card_state("error")
        self.eyebrow.setText("NEEDS ATTENTION"); self.heading.setText("Could not load application")
        self.site.clear(); self.application_type.clear(); self.message.setText("Architect Pro could not load the prepared application. Try Refresh.")
        self._reset_progress_display(); self.loading_area.hide(); self.progress_area.hide(); self._set_controls()
        self.technical_log.setPlainText(sanitise_technical_details(technical_message)); self.technical_log.hide(); self.technical_toggle.show(); self.copy_technical_button.hide(); self._resize_for_state()

    def show_ready(self):
        if not self._can_start_job():
            self.show_no_job("This attempt is no longer runnable. Review the application in Architect Pro to prepare a fresh attempt.")
            return
        self.estimator = None; self.eta_timer.stop(); self._render_enrollment_connection(); self._set_card_state()
        self.eyebrow.setText("READY TO PREPARE"); self.heading.setText(self.runtime_job.site_label)
        self.site.clear(); self.application_type.setText(self._application_label())
        self.message.setText("The prepared application is ready. Start when you are ready to continue.")
        self._result_action = "ready"; self.result_button.setText("Done")
        self._reset_progress_display(); self.loading_area.hide(); self.progress_area.hide(); self._set_controls(start=True); self.start_button.setEnabled(True)
        self.technical_log.clear(); self.technical_log.append(f"Job ID: {self.runtime_job.job_id}"); self.technical_log.hide(); self.technical_toggle.show(); self.copy_technical_button.hide()
        self._resize_for_state()

    def refresh_job(self):
        if self.load_thread and self.load_thread.isRunning(): return
        job_id = str((self.portal_job or {}).get("id") or "")
        self.runtime_job = None; self.refresh_button.setEnabled(False); self.show_loading("connecting")
        self.load_thread = JobLoadThread(self.launch_url, self.portal_client, job_id)
        self.load_thread.phase.connect(self.show_loading); self.load_thread.loaded.connect(self.on_job_loaded); self.load_thread.failed.connect(self.on_job_failed)
        self.load_thread.finished.connect(lambda: self.refresh_button.setEnabled(True)); self.load_thread.start()

    def on_job_loaded(self, job, client, documents, failures):
        try:
            self.portal_job = job; self.portal_client = client
            self.runtime_job = runtime_job_from_portal(job, documents, failures, login_email=self.settings["email"])
        except Exception as exc:
            self.on_job_failed(str(exc)); return
        self.show_ready()
        self.retry_callback_outbox()
        if self._auto_start_claimed:
            self._auto_start_claimed = False
            QTimer.singleShot(0, self.start_automation)

    def on_job_failed(self, message):
        if message == "No automation job ready":
            self.portal_job = None; self.show_no_job()
        else:
            self.show_load_error(message)

    def open_settings(self):
        dialog = SettingsDialog(self.settings, self)
        if not dialog.exec(): return
        self.settings = dialog.values(); save_settings(self.settings)
        background_agent.set_start_with_windows(self.settings.get("start_with_windows", False))
        if hasattr(self, "startup_action"):
            self.startup_action.blockSignals(True); self.startup_action.setChecked(self.settings["start_with_windows"]); self.startup_action.blockSignals(False)
        self.start_background_agent()
        if self.portal_job: self.refresh_job()

    def start_automation(self):
        if not self._can_start_job() or (self.automation_thread and self.automation_thread.isRunning()): return
        # A one-shot architectpro://settings/login helper may have updated the
        # shared secure-login settings while this background Agent stayed open.
        self.settings.update(load_settings())
        email = find_stored_login(self.settings)
        password, _, _ = secure_credentials.get_login_password(email)
        if not password:
            if self.change_login(first_run=True): QTimer.singleShot(0, self.start_automation)
            return
        self.settings["email"] = email; save_settings(self.settings)
        self._set_card_state(); self._render_enrollment_connection(); self._result_action = "ready"
        self.eyebrow.setText("AUTOMATION RUNNING"); self.heading.setText(f"Preparing {self._application_label()}")
        self.site.setText(self.runtime_job.site_label); self.application_type.clear(); self.message.setText("Chrome is running securely in the background.")
        self.estimator = ProgressEstimator(self.runtime_job.application_type)
        self.progress_list.clear()
        for stage in workflow_stages(self.runtime_job.application_type): self.progress_list.addItem(f"○ {USER_STAGE_LABELS[stage]}")
        self.eta.show(); self.loading_area.hide(); self.progress_area.show(); self._set_controls(stop=True); self.refresh_button.setEnabled(False); self.settings_button.setEnabled(False)
        self.technical_toggle.show(); self._resize_for_state(running=True)
        self.eta_timer.start(); self.update_progress_clock()
        QApplication.processEvents(QEventLoop.ProcessEventsFlag.ExcludeUserInputEvents)
        self.automation_thread = AutomationThread(self.runtime_job, password, self.settings["browser_mode"], self.portal_client)
        self.automation_thread.progress.connect(self.on_progress); self.automation_thread.completed.connect(self.on_completed)
        if hasattr(self.automation_thread, "start_rejected"):
            self.automation_thread.start_rejected.connect(self.on_start_rejected)
        if hasattr(self.automation_thread, "address_resolution_required"):
            self.automation_thread.address_resolution_required.connect(self.on_address_resolution_required)
        if hasattr(self.automation_thread, "applicant_title_resolution_required"):
            self.automation_thread.applicant_title_resolution_required.connect(self.on_applicant_title_resolution_required)
        if self.background_thread and self.background_thread.engine.agent_run_id:
            self.progress_publisher = background_agent.ProgressPublisher(
                self.portal_client,
                self.runtime_job.job_id,
                self.background_thread.engine.agent_run_id,
            )
            self.set_background_run_state("RUNNING", keep_job=True)
        self.automation_thread.start()

    def render_progress(self, snapshot):
        self.progress_bar.setValue(snapshot.progress_percent); self.percent.setText(f"{snapshot.progress_percent}%")
        self.eta.setText(format_remaining(snapshot.estimated_seconds_remaining)); self.current_task.setText(snapshot.message)
        stages = workflow_stages(self.runtime_job.application_type)
        for index, stage in enumerate(stages):
            if stage in self.estimator.completed: marker = "✓"
            elif stage == snapshot.stage and snapshot.status == "running": marker = "●"
            else: marker = "○"
            item = self.progress_list.item(index)
            if item is not None:
                item.setText(f"{marker} {USER_STAGE_LABELS[stage]}")

    def on_progress(self, event):
        self.technical_log.append(f"{event.status.value}: {event.stage}: {event.message}")
        snapshot = self.estimator.consume(event) if self.estimator else None
        if snapshot: self.render_progress(snapshot)
        if self.progress_publisher and snapshot:
            action_required = event.status.value == "user_action_required"
            self.progress_publisher.publish(
                stage=event.stage,
                stage_state=event.status.value,
                percent=snapshot.progress_percent,
                eta_seconds=None if action_required else snapshot.estimated_seconds_remaining,
                message=event.message,
                status="USER_ACTION_REQUIRED" if action_required else "RUNNING",
                force=action_required or event.status.value in {"completed", "failed"},
            )
            self.set_background_run_state("USER_ACTION_REQUIRED" if action_required else "RUNNING", keep_job=True)
        if event.stage == "address_selection":
            if event.status.value == "user_action_required":
                self.eta_timer.stop(); self.eta.hide()
                self.current_task.setText("Address confirmation required")
                self.message.setText("Select the correct property address to continue.")
            elif event.status.value == "running":
                self.eta.show(); self.eta_timer.start()
                self.heading.setText(f"Preparing {self._application_label()}")
                self.message.setText("Chrome is running securely in the background.")

    def on_address_resolution_required(self, request):
        self.eta_timer.stop(); self.eta.hide()
        self.eyebrow.setText("ACTION REQUIRED")
        self.heading.setText("Address confirmation required")
        self.site.setText(str(request.get("project_address") or self.runtime_job.site_label))
        candidates = list(request.get("candidates") or [])
        self.message.setText(
            "Select the matching portal address. Chrome will remain hidden."
            if candidates
            else "Try another postcode, open the same browser for manual resolution, or cancel safely."
        )
        self.showNormal(); self.activateWindow(); self.raise_()
        if self.tray:
            self.tray.showMessage("Address confirmation required", "Choose the correct property address to continue the application.", QSystemTrayIcon.MessageIcon.Information, 5000)
        dialog = AddressResolutionDialog(request, self)
        dialog.exec()
        response = dict(dialog.response or {"action": "cancel"})
        if self.automation_thread:
            self.automation_thread.provide_address_resolution(response)
        if response.get("action") in {"select", "change_postcode"}:
            self.eyebrow.setText("AUTOMATION RUNNING")
            self.heading.setText(f"Preparing {self._application_label()}")
            self.message.setText("Chrome is running securely in the background.")

    def on_applicant_title_resolution_required(self, request):
        self.eta_timer.stop(); self.eta.hide()
        self.eyebrow.setText("ACTION REQUIRED")
        self.heading.setText("Applicant title required")
        self.message.setText("Choose the applicant's title to continue. Chrome will remain open.")
        self.showNormal(); self.activateWindow(); self.raise_()
        if self.tray:
            self.tray.showMessage(
                "Applicant title required",
                "Choose the applicant's title to continue the application.",
                QSystemTrayIcon.MessageIcon.Information,
                5000,
            )
        dialog = ApplicantTitleDialog(request, self)
        dialog.exec()
        response = dict(dialog.response or {"action": "cancel"})
        if self.automation_thread:
            self.automation_thread.provide_applicant_title_resolution(response)
        if response.get("action") == "select":
            self.eyebrow.setText("AUTOMATION RUNNING")
            self.heading.setText(f"Preparing {self._application_label()}")
            self.message.setText("Chrome is running securely in the background.")

    def update_progress_clock(self):
        if self.estimator and self.estimator.status == "running": self.render_progress(self.estimator.snapshot())

    def stop_automation(self):
        if self.automation_thread and self.automation_thread.isRunning():
            self.eta_timer.stop(); self.stop_button.setEnabled(False); self.eta.setText("Stopping safely…")
            self.current_task.setText("Stopping at the next safe boundary…"); self.automation_thread.cancel()

    def on_completed(self, result):
        self._retired_job_ids.add(self.runtime_job.job_id)
        self.eta_timer.stop(); self.refresh_button.setEnabled(True); self.settings_button.setEnabled(True); self.stop_button.setEnabled(True)
        if result.timings:
            self.technical_log.append(f"Timings: {json.dumps(dict(result.timings), sort_keys=True)}")
        if self.progress_publisher and result.outcome == "failure" and not result.fresh_retry_job_id:
            percent = self.estimator.snapshot().progress_percent if self.estimator else 0
            self.progress_publisher.publish(stage=result.last_stage or "unknown", stage_state="failed", percent=percent, eta_seconds=None, message=result.message, status="ERROR", force=True)
        if result.fresh_retry_job_id:
            self._set_card_state(); self._render_enrollment_connection()
            self.eyebrow.setText("FRESH ATTEMPT QUEUED")
            self.heading.setText("Postcode updated")
            self.message.setText("Architect Pro saved the corrected postcode and queued a fresh automation attempt.")
            self.progress_area.hide(); self._result_action = "ready"
            self.result_button.setText("Done"); self._set_controls(result=True); self._resize_for_state()
        elif result.outcome == "user_action_required":
            if result.last_stage == "fee" or "fee" in result.message.lower():
                snapshot = self.estimator.handoff(result.timings) if self.estimator else None
                if snapshot:
                    self.render_progress(snapshot)
                    fee_index = len(workflow_stages(self.runtime_job.application_type)) - 1
                    fee_item = self.progress_list.item(fee_index)
                    if fee_item is not None:
                        fee_item.setText("● Fee — Complete in browser")
                self.current_task.setText("Your input is required to finish the application.")
                self.eyebrow.setText("ACTION REQUIRED"); self.heading.setText("Application ready for review")
                self.message.setText("The application fee has been entered. Review and submit when ready; queued applications will continue automatically.")
                self._result_action = "fee"
                self.result_button.setText("I've finished")
            else:
                self.current_task.setText("Resolve the property address in the browser.")
                self.eyebrow.setText("ACTION REQUIRED"); self.heading.setText("Browser opened for address review")
                self.message.setText(result.message)
            self.eta.hide()
            self.progress_area.show(); self._set_controls(result=True, reveal=result.last_stage == "fee" or "fee" in result.message.lower())
        elif result.outcome == "success":
            snapshot = self.estimator.complete(result.timings) if self.estimator else None
            if snapshot: self.render_progress(snapshot)
            self.eyebrow.setText("AUTOMATION COMPLETE"); self.heading.setText("Application prepared")
            self.message.setText(
                "Architect Pro has completed the automated application.\n"
                "The application is open in your browser for review."
            )
            self.progress_area.hide(); self._set_controls(result=True); self._resize_for_state()
        elif result.outcome == "cancelled":
            if self.estimator: self.estimator.stop("cancelled", "Automation cancelled")
            self.eyebrow.setText("STOPPED"); self.heading.setText("Automation cancelled")
            self.message.setText("The run stopped at a safe workflow boundary."); self.progress_area.hide(); self._set_controls(result=True); self._resize_for_state()
        else:
            if self.estimator: self.estimator.stop("failed", result.message)
            self._set_card_state("error"); self.connection.setText("● Automation stopped")
            self.eyebrow.setText("APPLICATION AUTOMATION STOPPED")
            self.heading.setText(result.error_headline or "Automation stopped")
            self.site.setText(f"{self._application_label()} — {self.runtime_job.site_label}")
            self.application_type.setText(
                f"Stage: {result.stage_description or result.last_stage.replace('_', ' ').title()}"
            )
            self.message.setText(
                f"{result.message}\n\n"
                f"{result.progression_message or 'The application has not been marked as complete.'}\n\n"
                f"Next: {result.next_action or 'Review the technical details before trying again.'}"
            )
            technical = "\n".join(filter(None, [
                f"Stage: {result.last_stage}",
                f"Category: {result.failure_category or result.error_code or 'AUTOMATION_FAILED'}",
                f"Checkpoint: {result.last_stage}",
                f"Outcome: {'known safe to retry' if result.retry_safe else 'uncertain or not safely retryable'}",
                f"Occurred: {datetime.now(timezone.utc).isoformat()}",
                result.technical_details,
            ]))
            self.technical_log.append(sanitise_technical_details(technical))
            self.progress_area.hide(); self.technical_log.hide(); self._resize_for_state()
            self.copy_technical_button.hide(); self.technical_toggle.setText("View technical details")
            self._result_action = "retry" if result.retry_safe else "ready"
            self.result_button.setText("Review and retry in Architect Pro" if result.retry_safe else "Done")
            self._set_controls(result=True, update_login=result.error_code == "AUTHENTICATION_FAILED")
        # A fee handoff has finished all automation and preserves its own browser.
        # Release only that terminal review state; unresolved input still pauses.
        if result.outcome == "user_action_required" and result.last_stage != "fee":
            self.set_background_run_state("USER_ACTION_REQUIRED", keep_job=True)
        else:
            self.set_background_run_state("READY", keep_job=False)
        if self.progress_publisher:
            self.progress_publisher.close(); self.progress_publisher = None

    def return_to_ready(self):
        if self.runtime_job: self.show_ready()
        else: self.show_no_job()

    def handle_result_action(self):
        if self._result_action == "retry":
            self.open_project_for_retry()
        else:
            if self._result_action == "fee":
                self._result_action = "ready"
            self.return_to_ready()

    def _can_start_job(self):
        return bool(self.runtime_job and self.runtime_job.job_id not in self._retired_job_ids
                    and (self.portal_job or {}).get("status") in {"READY", "CLAIMED"})

    def on_start_rejected(self, message):
        self._retired_job_ids.add(self.runtime_job.job_id)
        self.eta_timer.stop(); self.estimator = None
        self.refresh_button.setEnabled(True); self.settings_button.setEnabled(True)
        self.heading.setText("Automation not started"); self.message.setText(message)
        self.progress_area.hide(); self._result_action = "retry"
        self.result_button.setText("Review in Architect Pro"); self._set_controls(result=True)
        self.set_background_run_state("READY", keep_job=False)

    def open_project_for_retry(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from urllib.parse import quote
        project_id = str((self.portal_job or {}).get("projectId") or "")
        if not project_id:
            self.message.setText("Open this project's application in Architect Pro to prepare a fresh attempt.")
            return
        portal_url = self.portal_client.portal_url if self.portal_client else portal_handoff.load_portal_url()
        QDesktopServices.openUrl(QUrl(f"{portal_url.rstrip('/')}/projects/{quote(project_id, safe='')}"))

    def reveal_fee_browser(self):
        if not self.runtime_job:
            return
        try:
            reveal_handed_off_browser(self.runtime_job.job_id)
        except Exception as exc:
            self.technical_log.append(sanitise_technical_details(exc))
            self.message.setText("The existing fee browser could not be brought to the front. Keep the Agent open and try again.")

    def toggle_technical(self):
        visible = not self.technical_log.isVisible()
        self.technical_log.setVisible(visible)
        self.copy_technical_button.setVisible(visible)
        self.technical_toggle.setText("Hide technical details" if visible else "View technical details")

    def copy_technical_details(self):
        QApplication.clipboard().setText(sanitise_technical_details(self.technical_log.toPlainText()))


def main(app=None, splash=None):
    app = app or QApplication(sys.argv); smoke_test = "--smoke-test" in sys.argv
    app.setQuitOnLastWindowClosed(False)
    update_startup_splash(splash, "loading_agent", app)
    portal_handoff.cleanup_old_job_caches(log=print)
    if not smoke_test: portal_handoff.register_protocol_handler()
    launch_url = None if smoke_test else portal_handoff.automation_url_from_args()
    login_settings_launch = portal_handoff.is_login_settings_launch(launch_url)
    agent_open_launch = portal_handoff.is_agent_open_launch(launch_url)
    agent_reconnect_launch = portal_handoff.is_agent_reconnect_launch(launch_url)
    agent_reset_launch = portal_handoff.is_agent_reset_launch(launch_url)
    window = AutomationAgent(
        None if login_settings_launch or agent_open_launch or agent_reconnect_launch or agent_reset_launch else launch_url,
        auto_refresh=not smoke_test and not login_settings_launch and not agent_reset_launch,
        auto_onboard=not smoke_test and not login_settings_launch and not agent_reconnect_launch and not agent_reset_launch,
    )
    update_startup_splash(splash, "opening_agent", app)
    show_window_after_splash(window, splash, app)
    if login_settings_launch:
        def update_login_and_close():
            window.change_login(first_run=True)
            window.quit_agent()
        QTimer.singleShot(0, update_login_and_close)
    elif agent_reset_launch:
        QTimer.singleShot(0, window.reset_agent_connection)
    elif agent_reconnect_launch:
        QTimer.singleShot(0, lambda: window.begin_agent_enrollment(force=True))
    if "--background" in sys.argv:
        QTimer.singleShot(0, window.hide)
    if smoke_test: QTimer.singleShot(300, app.quit)
    return app.exec()

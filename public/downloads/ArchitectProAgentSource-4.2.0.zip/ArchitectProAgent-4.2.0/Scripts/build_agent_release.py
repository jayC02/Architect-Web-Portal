"""Build a versioned installer and source ZIP without replacing older release folders."""
from pathlib import Path
import re
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
version = re.search(r'AGENT_VERSION = "([^" ]+)"', (ROOT / 'gui/services/background_agent.py').read_text(encoding='utf-8')).group(1)
release = ROOT / 'Releases' / version
release.mkdir(parents=True, exist_ok=True)
imports = [
    'automation.runner', 'automation.progress', 'automation.common.declaration',
    'automation.common.existing_application', 'automation.common.handoff', 'automation.common.window_control',
    'automation.householder.run', 'automation.building_warrant.run', 'automation.portal_adapter',
    'gui.agent_app', 'gui.services.portal_answers', 'gui.services.portal_handoff', 'gui.services.callback_outbox',
    'gui.services.secure_credentials', 'gui.services.storage_paths', 'keyring', 'keyring.backends.Windows',
    'keyring.errors', 'PySide6.QtCore', 'PySide6.QtGui', 'PySide6.QtWidgets', 'PyPDF2',
    'selenium', 'selenium.webdriver.chrome.service', 'webdriver_manager.chrome',
]
command = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--windowed', '--onedir', '--noupx',
    '--workpath', str(release / 'build'), '--distpath', str(release / 'dist'), '--specpath', str(release / 'build'),
    '--name', 'ArchitectPortalAutomation', '--version-file', str(ROOT / 'version_info.txt'),
    '--add-data', f'{ROOT / "assets"};assets']
for module in imports:
    command += ['--hidden-import', module]
for module in ['gui.app', 'gui.pages', 'gui.controllers', 'gui.application_selector', 'gui.sidebar', 'gui.stepper']:
    command += ['--exclude-module', module]
icon = next(ROOT.glob('*.ico'), None)
if icon: command += ['--icon', str(icon)]
subprocess.run(command + ['Gui.py'], cwd=ROOT, check=True)
# Only assets and the Python package were included; no runtime settings are copied.
app = release / 'dist' / 'ArchitectPortalAutomation'
import os
compiler = Path(os.environ['LOCALAPPDATA']) / 'Programs/Inno Setup 6/ISCC.exe'
if not compiler.is_file():
    compiler = Path(os.environ.get('ProgramFiles(x86)', 'C:/Program Files (x86)')) / 'Inno Setup 6/ISCC.exe'
subprocess.run([str(compiler), f'/DMyAppSourceDir={app}', f'/O{release}', str(ROOT / 'installer/ArchitectProAgent.iss')], cwd=ROOT, check=True)
source = release / f'ArchitectProAgentSource-{version}.zip'
allowed = {'.py', '.txt', '.md', '.json', '.png', '.ico', '.iss', '.bat', '.ps1'}
paths = []
for folder in ['automation', 'gui', 'assets', 'installer', 'tests']:
    paths += [p for p in (ROOT / folder).rglob('*') if p.is_file() and p.suffix.lower() in allowed
              and '__pycache__' not in p.parts and not p.name.endswith('_presets.json')]
paths += [ROOT / name for name in ['Gui.py', 'AGENT_README.md', 'requirements.txt', 'requirements-dev.txt', 'version_info.txt', 'build_exe.bat', 'build_installer.bat']]
paths += [Path(__file__).resolve(), *ROOT.glob('*.ico')]
with zipfile.ZipFile(source, 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted(set(paths)):
        if path.is_file(): archive.write(path, f'ArchitectProAgent-{version}/{path.relative_to(ROOT).as_posix()}')
print(f'Installer: {release / ("ArchitectProAgentSetup-" + version + ".exe")}')
print(f'Source: {source}')

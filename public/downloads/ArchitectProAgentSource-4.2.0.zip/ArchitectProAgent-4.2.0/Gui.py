# -*- coding: utf-8 -*-
import os
import sys

from PySide6.QtWidgets import QApplication

from gui.startup_splash import StartupSplash, close_startup_splash


def browser_startup_smoke_test():
    """Internal packaged-build check; never used by a normal Agent launch."""
    from automation.common.browser_mode import BrowserMode
    from automation.common.driver import chrome_options_for_mode, create_chrome_driver

    driver = None
    try:
        driver = create_chrome_driver(chrome_options_for_mode(BrowserMode.HEADLESS))
        browser_major = str(driver.capabilities.get("browserVersion", "")).split(".", 1)[0]
        driver_version = driver.capabilities.get("chrome", {}).get("chromedriverVersion", "")
        driver_major = str(driver_version).split(".", 1)[0]
        return 0 if browser_major and browser_major == driver_major else 2
    except Exception:
        return 2
    finally:
        if driver is not None:
            driver.quit()


def uninstall_cleanup():
    """Best-effort local cleanup; uninstall must succeed without portal access."""
    from gui.services import background_agent, portal_handoff, secure_credentials, storage_paths

    try:
        background_agent.AgentApi().revoke_self()
    except Exception:
        pass
    secure_credentials.delete_agent_credential()
    try:
        background_agent.set_start_with_windows(False)
    except OSError:
        pass
    portal_handoff.unregister_protocol_handler()
    for filename in (background_agent.INSTALLATION_FILE, "portal_settings.json"):
        try:
            os.remove(storage_paths.runtime_path(filename))
        except FileNotFoundError:
            pass
        except OSError:
            pass
    return 0


def main():
    if "--browser-startup-smoke-test" in sys.argv:
        return browser_startup_smoke_test()
    if "--uninstall-cleanup" in sys.argv:
        return uninstall_cleanup()
    app = QApplication(sys.argv)
    splash = StartupSplash()
    splash.show()
    app.processEvents()
    try:
        from gui.agent_app import main as run_application
        return run_application(app=app, splash=splash)
    except Exception:
        close_startup_splash(splash, app)
        raise


if __name__ == "__main__":
    sys.exit(main())

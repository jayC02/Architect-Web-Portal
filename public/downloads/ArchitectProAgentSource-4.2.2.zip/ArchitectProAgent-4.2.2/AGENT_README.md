# Architect Pro Agent 4.2.2

For future updates, click **Update Agent** in the Agent window or Architect Pro Settings. The Agent downloads and verifies the update, installs it over the existing version and restarts. No uninstall or reconnect is required. Finish or stop an active application before updating.

Run `ArchitectProAgentSetup-4.2.2.exe` to update the existing installation. It uses the same Windows installer identity and keeps your connection and saved settings in the existing application-data folder. If an older Agent has a stuck application and refuses to update, choose Quit from its notification-area icon and run this installer.

Version 4.2.2 fixes loading the next queued application after a previous one finishes. A failed preparation download is reported and releases the claim instead of indefinitely holding the queue. The portal update also restores opening prepared applications for review after the Agent releases them.

1. In Architect Pro Settings, choose Download & connect Agent (or Reinstall / update), install it, and complete the browser connection if prompted.
2. Open Agent Settings and save your eDevelopment login.
3. Prepare and queue Planning or Building Warrant applications in the website. Keep the Agent running in the Windows notification area: it processes one job at a time.
4. When the application is ready for review, check it in the council portal and submit it yourself. Closing the Agent window keeps the app running in the notification area; Quit stops it.

The website queue shows only running applications and authorised jobs waiting for the Agent. The remove button withdraws a waiting job without deleting its prepared application. Run it again from its application page when needed. Stop active automation from the Agent.

The release includes the current Planning and Building Warrant fee entry, queue processing, immutable application snapshots and browser-review handoff code. Architect-entered Planning fees and calculated Building Warrant fees are checked in the council fee field before review.

Source: `ArchitectProAgentSource-4.2.2.zip`. Install dependencies from `requirements.txt` and run `python Gui.py`; Windows and Google Chrome are required. `python Scripts/build_agent_release.py` builds a versioned installer and source archive; Inno Setup 6 is required for the installer. Runtime passwords, enrollment credentials and project caches are not part of the source archive.

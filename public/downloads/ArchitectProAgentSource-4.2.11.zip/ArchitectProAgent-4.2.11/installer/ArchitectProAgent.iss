#define MyAppName "Architect Pro Agent"
#define MyAppVersion "4.2.11"
#define MyAppPublisher "Ninety One Architects"
#define MyAppExeName "ArchitectPortalAutomation.exe"
#ifndef MyAppSourceDir
  #define MyAppSourceDir "..\Releases\_dist\ArchitectPortalAutomation"
#endif

[Setup]
AppId={{7D61568B-AB50-4E36-9397-8A8323A195E5}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\Architect Pro Agent
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\Releases\_installer
OutputBaseFilename=ArchitectProAgentSetup-{#MyAppVersion}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=yes
DisableDirPage=auto
DisableProgramGroupPage=yes
DisableReadyPage=yes
DisableFinishedPage=yes
UninstallDisplayIcon={app}\versions\{#MyAppVersion}\{#MyAppExeName}
CloseApplications=yes
SetupLogging=yes
RestartApplications=no
CloseApplicationsFilter=*

[Files]
; Keep each release's executable and dependencies together. A certificate or
; DLL still held open from an older release cannot block this new version.
Source: "{#MyAppSourceDir}\*"; DestDir: "{app}\versions\{#MyAppVersion}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Registry]
Root: HKCU; Subkey: "Software\Classes\architectpro"; ValueType: string; ValueName: ""; ValueData: "URL:Architect Pro Agent Protocol"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\architectpro"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""
Root: HKCU; Subkey: "Software\Classes\architectpro\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\versions\{#MyAppVersion}\{#MyAppExeName},0"
Root: HKCU; Subkey: "Software\Classes\architectpro\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\versions\{#MyAppVersion}\{#MyAppExeName}"" ""%1"""
Root: HKCU; Subkey: "Software\Microsoft\Windows\CurrentVersion\Run"; ValueType: string; ValueName: "ArchitectProAgent"; ValueData: """{app}\versions\{#MyAppVersion}\{#MyAppExeName}"""; Flags: uninsdeletevalue; Check: RegisterAgentStartup

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\versions\{#MyAppVersion}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\versions\{#MyAppVersion}\{#MyAppExeName}"; Check: CreateAgentDesktopShortcut

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional shortcuts:"

[Run]
Filename: "{app}\versions\{#MyAppVersion}\{#MyAppExeName}"; Flags: nowait; Check: StartAgentAfterInstall

[UninstallRun]
Filename: "{app}\versions\{#MyAppVersion}\{#MyAppExeName}"; Parameters: "--uninstall-cleanup"; Flags: runhidden waituntilterminated skipifdoesntexist; RunOnceId: "ArchitectProAgentCleanup"

[Code]
#include "agent-upgrade.iss"

"""Real Qt/login selection boundaries, with isolated settings and a fake keyring."""
import json
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from PySide6.QtWidgets import QApplication, QLineEdit

from gui import agent_app
from tests.test_agent_gui import JobThreadStub, ThreadStub, make_window, runtime_job
from tests.test_secure_credentials import FakeKeyring


@pytest.fixture(autouse=True)
def isolated_login(monkeypatch, tmp_path):
    QApplication.instance() or QApplication([])
    monkeypatch.setenv("APPDATA", str(tmp_path))
    keyring = FakeKeyring()
    monkeypatch.setattr(agent_app.secure_credentials, "_load_keyring", lambda: (keyring, None))
    monkeypatch.setattr(agent_app.background_agent, "start_with_windows_enabled", lambda: False)
    monkeypatch.setattr(agent_app.background_agent, "set_start_with_windows", Mock())
    return keyring


def remember(email, password="fixture-password"):
    assert agent_app.secure_credentials.save_login_password(email, password)[0]


def legacy_login():
    remember("legacy@example.test")
    path = agent_app.storage_paths.runtime_path("login_presets.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump({"legacy@example.test": {}}, handle)


def test_missing_selected_password_never_switches_to_another_account():
    legacy_login()
    assert agent_app.find_stored_login({"email": "selected@example.test"}) == ""


def test_first_upgrade_still_imports_a_legacy_login_without_an_explicit_choice():
    legacy_login()
    assert agent_app.find_stored_login({"email": ""}) == "legacy@example.test"


def test_removed_login_stays_removed_after_save_and_restart():
    legacy_login()
    remember("selected@example.test")
    dialog = agent_app.SettingsDialog({"email": "selected@example.test", "browser_mode": "AUTO"})
    try:
        dialog.remove_login()
        agent_app.save_settings(dialog.values())
        assert agent_app.find_stored_login(agent_app.load_settings()) == ""
        assert agent_app.secure_credentials.get_login_password("selected@example.test")[0] is None
        assert agent_app.secure_credentials.get_login_password("legacy@example.test")[0]
    finally:
        dialog.close()


def test_failed_password_removal_keeps_selection_and_reports_failure(monkeypatch):
    remember("selected@example.test")
    monkeypatch.setattr(agent_app.secure_credentials, "delete_login_password", lambda _email: (False, "Unavailable"))
    dialog = agent_app.SettingsDialog({"email": "selected@example.test", "browser_mode": "AUTO"})
    try:
        dialog.remove_login()
        assert dialog.values()["email"] == "selected@example.test"
        assert dialog.account_label.text() == "selected@example.test"
        assert "could not" in dialog.account_status.text().lower()
        assert agent_app.secure_credentials.get_login_password("selected@example.test")[0]
    finally:
        dialog.close()


@pytest.mark.parametrize("application_type", ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"])
def test_account_changed_after_download_uses_matching_email_and_password(monkeypatch, application_type):
    window = make_window()
    original = runtime_job(application_type)
    window.runtime_job = original
    remember("new@example.test", "new-fixture-password")
    agent_app.save_settings({"email": "new@example.test", "browser_mode": "AUTO"})
    captured = []

    class CapturingThread(ThreadStub):
        def __init__(self, job, password, *_args):
            super().__init__()
            captured.append((job, password))

    monkeypatch.setattr(agent_app, "AutomationThread", CapturingThread)
    try:
        window.start_automation()
        assert len(captured) == 1
        job, password = captured[0]
        assert (job.user_inputs["Email"], password) == ("new@example.test", "new-fixture-password")
        assert original.user_inputs["Email"] == "test@example.com"
        assert job.job_id == original.job_id
        assert job.document_mapping == original.document_mapping
        assert job.metadata == original.metadata
    finally:
        window.eta_timer.stop()
        window.close()


@pytest.mark.parametrize("worker", ["automation_thread", "load_thread", "view_application_thread", "cancel_thread"])
def test_tray_settings_cannot_disturb_an_active_worker(monkeypatch, worker):
    window = make_window()
    original = runtime_job()
    window.runtime_job = original
    setattr(window, worker, SimpleNamespace(isRunning=lambda: True))
    dialog = Mock()
    dialog.return_value.exec.return_value = True
    dialog.return_value.values.return_value = dict(window.settings)
    monkeypatch.setattr(agent_app, "SettingsDialog", dialog)
    monkeypatch.setattr(window, "refresh_job", Mock())
    monkeypatch.setattr(window, "start_background_agent", Mock())
    try:
        window.open_settings()
        dialog.assert_not_called()
        window.refresh_job.assert_not_called()
        assert window.runtime_job is original
    finally:
        setattr(window, worker, None)
        window.close()


def test_claim_arriving_while_settings_open_does_not_reload_active_worker(monkeypatch):
    window = make_window()
    original = runtime_job()

    class SettingsStub:
        def __init__(self, *_args):
            pass

        def exec(self):
            window.runtime_job = original
            window.automation_thread = SimpleNamespace(isRunning=lambda: True)
            return True

        def values(self):
            return dict(window.settings)

    monkeypatch.setattr(agent_app, "SettingsDialog", SettingsStub)
    monkeypatch.setattr(window, "refresh_job", Mock())
    monkeypatch.setattr(window, "start_background_agent", Mock())
    try:
        window.open_settings()
        window.refresh_job.assert_not_called()
        assert window.runtime_job is original
    finally:
        window.automation_thread = None
        window.close()


@pytest.mark.parametrize("loaded", [True, False])
def test_settings_save_preserves_failed_login_restart_controls(monkeypatch, loaded):
    window = make_window()
    window.runtime_job = runtime_job() if loaded else None
    window._retired_job_ids.add("job_test_123456")
    dialog = Mock()
    dialog.return_value.exec.return_value = True
    dialog.return_value.values.return_value = dict(window.settings, email="corrected@example.test")
    monkeypatch.setattr(agent_app, "SettingsDialog", dialog)
    monkeypatch.setattr(window, "refresh_job", Mock())
    monkeypatch.setattr(window, "start_background_agent", Mock())
    try:
        window.open_settings()
        window.refresh_job.assert_not_called()
        assert window._result_action == "retry"
        assert window.result_button.isVisible()
        assert "Architect Pro" in window.result_button.text()
    finally:
        window.close()


def test_login_helper_cannot_reload_an_already_running_job(monkeypatch):
    window = make_window()
    window.runtime_job = runtime_job()
    window.automation_thread = SimpleNamespace(isRunning=lambda: True)

    class CredentialStub:
        def __init__(self, *_args):
            self.email = QLineEdit("corrected@example.test")

        def exec(self):
            return True

    monkeypatch.setattr(agent_app, "CredentialDialog", CredentialStub)
    monkeypatch.setattr(window, "refresh_job", Mock())
    try:
        assert window.change_login()
        window.refresh_job.assert_not_called()
    finally:
        window.automation_thread = None
        window.close()


def test_claim_received_during_update_starts_loading_after_update_is_abandoned(monkeypatch):
    window = make_window()
    engine = agent_app.background_agent.PollingEngine()
    engine.set_run("claimed-during-update", "fixture-run", "RUNNING")
    window.background_thread = SimpleNamespace(engine=engine)
    window._updating = True
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    monkeypatch.setattr(window, "start_background_agent", Mock())
    try:
        window.on_background_job_claimed(object(), "claimed-during-update", "fixture-run")
        assert window.load_thread is None
        window.on_update_failed("A queued application was claimed before polling stopped.")
        assert window.load_thread is not None
        assert window.load_thread.isRunning()
        assert window.portal_job["id"] == engine.current_job_id
        assert window._auto_start_claimed
    finally:
        window.background_thread = None
        window.load_thread = None
        window.close()


@pytest.mark.parametrize("maintenance", ["update", "reset", "enrollment", "quit", "settings", "login"])
def test_review_commands_wait_during_update_or_connection_changes(monkeypatch, maintenance):
    window = make_window()
    window.background_thread = SimpleNamespace(engine=agent_app.background_agent.PollingEngine())
    if maintenance == "update":
        window._updating = True
    elif maintenance == "quit":
        window._quitting = True
    elif maintenance in {"settings", "login"}:
        setattr(window, f"_{maintenance}_dialog_open", True)
    else:
        setattr(window, f"{maintenance}_thread", SimpleNamespace(isRunning=lambda: True))
    reveal = Mock()
    monkeypatch.setattr(agent_app, "reveal_handed_off_browser", reveal)
    monkeypatch.setattr(window, "_acknowledge_view_command", Mock())
    monkeypatch.setattr(window, "_open_completed_application", Mock())
    try:
        window.on_background_command({"type": "OPEN_APPLICATION", "jobId": "prepared-job", "agentRunId": "old-run", "requestedAt": "fixture-time"})
        reveal.assert_not_called()
        window._acknowledge_view_command.assert_not_called()
        window._open_completed_application.assert_not_called()
    finally:
        window.background_thread = None
        window.reset_thread = None
        window.enrollment_thread = None
        window.close()


@pytest.mark.parametrize("maintenance", ["update", "reset", "enrollment"])
def test_manual_start_waits_for_update_and_connection_changes(monkeypatch, maintenance):
    window = make_window()
    window.runtime_job = runtime_job()
    remember("selected@example.test")
    agent_app.save_settings({"email": "selected@example.test", "browser_mode": "AUTO"})
    if maintenance == "update":
        window._updating = True
    else:
        setattr(window, f"{maintenance}_thread", SimpleNamespace(isRunning=lambda: True))
    worker = Mock()
    monkeypatch.setattr(agent_app, "AutomationThread", worker)
    try:
        window.start_automation()
        worker.assert_not_called()
    finally:
        window.eta_timer.stop()
        window.automation_thread = None
        window.reset_thread = None
        window.enrollment_thread = None
        window.close()


def test_installer_is_not_launched_if_execution_begins_before_download_completion(monkeypatch):
    window = make_window()
    window._updating = True
    window.view_application_thread = SimpleNamespace(isRunning=lambda: True)
    launch = Mock()
    monkeypatch.setattr(agent_app.agent_update, "launch_installer", launch)
    monkeypatch.setattr(window, "on_update_failed", Mock())
    monkeypatch.setattr(window, "quit_agent", Mock())
    try:
        window.on_update_downloaded("C:/verified/fixture-installer.exe")
        launch.assert_not_called()
        window.quit_agent.assert_not_called()
        window.on_update_failed.assert_called_once()
    finally:
        window.view_application_thread = None
        window.close()


def test_accepted_enrollment_can_prompt_for_login_before_worker_finished(monkeypatch):
    window = make_window()
    window.enrollment_thread = SimpleNamespace(isRunning=lambda: True)
    monkeypatch.setattr(window, "start_background_agent", Mock())
    monkeypatch.setattr(agent_app.QTimer, "singleShot", Mock())
    dialog = Mock()
    dialog.return_value.exec.return_value = False
    monkeypatch.setattr(agent_app, "CredentialDialog", dialog)
    try:
        window.on_agent_enrolled(object())
        window.ensure_credentials()
        dialog.return_value.exec.assert_called_once()
    finally:
        window.enrollment_thread = None
        window.close()


def test_accepted_enrollment_does_not_drop_a_ready_job_start(monkeypatch):
    window = make_window()
    window.runtime_job = runtime_job()
    window.enrollment_thread = SimpleNamespace(isRunning=lambda: True)
    remember("selected@example.test")
    agent_app.save_settings({"email": "selected@example.test", "browser_mode": "AUTO"})
    monkeypatch.setattr(window, "start_background_agent", Mock())
    monkeypatch.setattr(agent_app.QTimer, "singleShot", Mock())
    worker = Mock()
    monkeypatch.setattr(agent_app, "AutomationThread", worker)
    try:
        window.on_agent_enrolled(object())
        window.start_automation()
        worker.return_value.start.assert_called_once()
    finally:
        window.eta_timer.stop()
        window.enrollment_thread = None
        window.automation_thread = None
        window.close()


@pytest.mark.parametrize("dialog_type", ["settings", "login"])
def test_claim_waits_until_account_dialog_closes(monkeypatch, dialog_type):
    window = make_window()
    engine = agent_app.background_agent.PollingEngine()
    window.background_thread = SimpleNamespace(engine=engine)
    callbacks = []
    monkeypatch.setattr(agent_app.QTimer, "singleShot", lambda _delay, callback: callbacks.append(callback))
    monkeypatch.setattr(window, "refresh_job", Mock())
    monkeypatch.setattr(window, "start_background_agent", Mock())

    class DialogStub:
        def __init__(self, *_args):
            self.email = QLineEdit("selected@example.test")

        def exec(self):
            engine.set_run("arriving-during-dialog", "fixture-run", "RUNNING")
            window.on_background_job_claimed(object(), "arriving-during-dialog", "fixture-run")
            window.refresh_job.assert_not_called()
            return False

    monkeypatch.setattr(agent_app, "SettingsDialog" if dialog_type == "settings" else "CredentialDialog", DialogStub)
    try:
        if dialog_type == "settings":
            window.open_settings()
        else:
            window.change_login()
        assert callbacks
        callbacks.pop()()
        window.refresh_job.assert_called_once()
        assert window.portal_job["id"] == engine.current_job_id == "arriving-during-dialog"
        assert engine.agent_run_id == "fixture-run"
    finally:
        window.background_thread = None
        window.close()


@pytest.mark.parametrize("dialog_type", ["settings", "login"])
def test_update_waits_until_account_dialog_closes(monkeypatch, dialog_type):
    window = make_window()
    setattr(window, f"_{dialog_type}_dialog_open", True)
    monkeypatch.setattr(agent_app.sys, "frozen", True, raising=False)
    worker = Mock()
    monkeypatch.setattr(agent_app, "AgentUpdateThread", worker)
    try:
        window.update_agent()
        assert not window._updating
        worker.assert_not_called()
        assert "window" in window.update_status.text().lower()
    finally:
        setattr(window, f"_{dialog_type}_dialog_open", False)
        window.close()


def test_cancelled_dialog_claim_is_not_resurrected_when_its_timer_runs(monkeypatch):
    window = make_window()
    engine = agent_app.background_agent.PollingEngine()
    engine.set_run("old-claim", "old-run", "RUNNING")
    window.background_thread = SimpleNamespace(engine=engine)
    window._settings_dialog_open = True
    callbacks = []
    monkeypatch.setattr(agent_app.QTimer, "singleShot", lambda _delay, callback: callbacks.append(callback))
    monkeypatch.setattr(window, "refresh_job", Mock())
    try:
        window.on_background_job_claimed(object(), "old-claim", "old-run")
        assert callbacks
        engine.set_run(None, None, "READY")
        window._settings_dialog_open = False
        callbacks.pop()()
        window.refresh_job.assert_not_called()
        assert not window._auto_start_claimed
    finally:
        window.background_thread = None
        window.close()


def test_login_helper_does_not_stack_over_an_existing_settings_dialog(monkeypatch):
    window = make_window()
    window._settings_dialog_open = True
    dialog = Mock()
    monkeypatch.setattr(agent_app, "CredentialDialog", dialog)
    try:
        assert window.change_login() is False
        dialog.assert_not_called()
    finally:
        window.close()


def test_login_correction_keeps_a_downloaded_job_ready_to_start(monkeypatch):
    window = make_window()
    original = runtime_job()
    window.runtime_job = original
    remember("selected@example.test")

    class CredentialStub:
        def __init__(self, *_args):
            self.email = QLineEdit("selected@example.test")

        def exec(self):
            return True

    monkeypatch.setattr(agent_app, "CredentialDialog", CredentialStub)
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    worker = Mock()
    monkeypatch.setattr(agent_app, "AutomationThread", worker)
    try:
        assert window.change_login()
        assert window.runtime_job is original
        assert window._can_start_job()
        window.start_automation()
        worker.return_value.start.assert_called_once()
        assert worker.call_args.args[0].user_inputs["Email"] == "selected@example.test"
    finally:
        window.eta_timer.stop()
        window.automation_thread = None
        window.load_thread = None
        window.close()

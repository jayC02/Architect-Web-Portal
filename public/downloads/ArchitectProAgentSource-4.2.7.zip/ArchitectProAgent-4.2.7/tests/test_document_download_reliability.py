"""Exercise job downloads with isolated storage and the actual Windows filesystem."""
import os
import threading

import pytest

from gui.services import portal_handoff


def client_with_files(monkeypatch, tmp_path, request):
    monkeypatch.setattr(portal_handoff.storage_paths, 'app_data_dir', lambda: str(tmp_path))
    monkeypatch.setattr(portal_handoff, 'record_job_cache_status', lambda *_: None)
    client = portal_handoff.PortalClient('https://example.test', 'test-only')
    client._request = request
    return client


def test_cancelled_download_batch_never_fetches_or_saves_another_file(monkeypatch, tmp_path):
    cancelled = [False]
    requests = []
    def request(path, **_kwargs):
        requests.append(path)
        cancelled[0] = True
        return b'%PDF-test', {}
    client = client_with_files(monkeypatch, tmp_path, request)
    job = {'id': 'cancelled-job-123', 'documents': [
        {'id': str(i), 'originalFilename': f'{i}.pdf', 'downloadUrl': f'/file/{i}'} for i in range(5)
    ]}
    with pytest.raises(portal_handoff.PortalHandoffError, match='cancelled'):
        client.download_documents(job, cancelled=lambda: cancelled[0])
    assert requests == ['/file/0']
    assert not list(tmp_path.rglob('*.pdf'))


def test_long_duplicate_filenames_fit_job_path_and_keep_pdf_extension(monkeypatch, tmp_path):
    # A realistic nested AppData root: the complete job path leaves substantially
    # less than 180 characters for the filename on a standard Windows install.
    root = tmp_path / ('r' * 35)
    client = client_with_files(monkeypatch, root, lambda *_args, **_kwargs: (b'%PDF-test', {}))
    name = 'A' * 210 + '.pdf'
    job = {'id': '12345678-1234-1234-1234-123456789012', 'documents': [
        {'id': str(i), 'originalFilename': name, 'mimeType': 'application/pdf', 'downloadUrl': f'/file/{i}'} for i in range(3)
    ]}
    downloaded, failures = client.download_documents(job)
    assert failures == []
    assert len(downloaded) == 3
    assert len({item['localName'].lower() for item in downloaded}) == 3
    for item in downloaded:
        assert item['localName'].endswith('.pdf')
        assert len(os.path.abspath(item['localPath'])) <= 259
        assert open(item['localPath'], 'rb').read() == b'%PDF-test'


def test_job_load_thread_honours_cancellation_on_next_download_return(monkeypatch, tmp_path):
    from PySide6.QtWidgets import QApplication
    from gui.agent_app import JobLoadThread
    app = QApplication.instance() or QApplication([])
    entered = threading.Event()
    released = threading.Event()
    requests = []
    def request(path, **_kwargs):
        requests.append(path)
        entered.set()
        assert released.wait(3), 'test network response was not released'
        return b'%PDF-test', {}
    client = client_with_files(monkeypatch, tmp_path, request)
    client.get_job = lambda _job: {'id': 'cancelled-job-123', 'documents': [
        {'id': str(i), 'originalFilename': f'{i}.pdf', 'downloadUrl': f'/file/{i}'} for i in range(5)
    ]}
    worker = JobLoadThread(None, client, 'cancelled-job-123')
    loaded = []
    worker.loaded.connect(lambda *args: loaded.append(args))
    try:
        worker.start()
        assert entered.wait(3)
        worker.requestInterruption()
        released.set()
        assert worker.wait(3000)
        app.processEvents()
        assert requests == ['/file/0']
        assert loaded == []
        assert not list(tmp_path.rglob('*.pdf'))
    finally:
        released.set()
        worker.wait(3000)

"""The Proposed work screen: tick boxes hidden behind their labels, and Convert disabled
unless the work is a conversion (as captured from the portal)."""

import pytest

from automation.building_warrant.main_details import WORK_TYPE_IDS, fill_description_and_proposed_work

from completion_fakes import FakeDriver

DESCRIPTION_ID = "MainContent_BuildingWarrantAppWizard_txtDescWork"


def proposed_work_screen(convert_enabled=False):
    driver = FakeDriver()
    driver.add(DESCRIPTION_ID, kind="textarea")
    for element_id in WORK_TYPE_IDS.values():
        driver.add_checkbox(element_id)
        driver.fields[element_id].visible = False     # the square is drawn on the label
    driver.fields[WORK_TYPE_IDS["Convert"]].enabled = convert_enabled
    return driver


def ticked(driver):
    return {name for name, element_id in WORK_TYPE_IDS.items() if driver.selected(element_id)}


def test_ticks_construct_through_its_label_when_inputs_are_hidden():
    driver = proposed_work_screen()
    inputs = {"Description of Work": "Rear extension", "Proposed Work Types": ["Construct"]}
    assert fill_description_and_proposed_work(driver, inputs, timeout=0.5) == ["Construct"]
    assert ticked(driver) == {"Construct"}
    assert driver.value(DESCRIPTION_ID) == "Rear extension"


def test_disabled_convert_is_left_alone_when_not_wanted():
    driver = proposed_work_screen(convert_enabled=False)
    fill_description_and_proposed_work(driver, {"Description of Work": "x", "Proposed Work Types": ["Construct", "Demolish"]}, timeout=0.5)
    assert ticked(driver) == {"Construct", "Demolish"}
    assert driver.clicks(WORK_TYPE_IDS["Convert"]) == 0


def test_wanting_a_disabled_type_fails_clearly():
    driver = proposed_work_screen(convert_enabled=False)
    with pytest.raises(RuntimeError, match="Convert"):
        fill_description_and_proposed_work(driver, {"Description of Work": "x", "Proposed Work Types": ["Convert"]}, timeout=0.5)


def test_an_already_ticked_box_that_is_not_wanted_is_unticked():
    driver = proposed_work_screen()
    driver.fields[WORK_TYPE_IDS["Demolish"]].selected = True
    fill_description_and_proposed_work(driver, {"Description of Work": "x", "Proposed Work Types": ["Construct"]}, timeout=0.5)
    assert ticked(driver) == {"Construct"}


def test_conversion_descriptions_tick_hidden_boxes_through_their_labels(monkeypatch):
    from automation.building_warrant import follow_ups

    driver = FakeDriver()
    for suffix in follow_ups.CONVERSION_IDS:
        element_id = follow_ups.PREFIX + suffix
        driver.add_checkbox(element_id)
        driver.fields[element_id].visible = False
    monkeypatch.setattr(follow_ups, "ensure_follow_up_field", lambda *args, **kwargs: follow_ups.PREFIX + "C1")
    monkeypatch.setattr(follow_ups, "_observed_field_id", lambda current, expected_id, question: expected_id)
    follow_ups.fill_conversion_descriptions(driver, {"Conversion Descriptions": ["C1", "C4"]}, timeout=0.5)
    assert {suffix for suffix in follow_ups.CONVERSION_IDS if driver.selected(follow_ups.PREFIX + suffix)} == {"C1", "C4"}

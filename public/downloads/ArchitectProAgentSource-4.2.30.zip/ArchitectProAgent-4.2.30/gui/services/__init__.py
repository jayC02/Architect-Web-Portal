"""GUI service helpers."""


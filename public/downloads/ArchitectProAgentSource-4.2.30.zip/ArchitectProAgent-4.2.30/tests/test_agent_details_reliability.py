import pytest
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By

from automation.common.agent_details import (
    AgentDetailsConfirmationError, AgentDetailsValidationError,
    advance_from_agent_details, validate_agent_phone,
)
from automation.runner import describe_failure, domain_error, run_automation
from completion_fakes import FakeDriver
from tests.test_automation_runner import FakeManagedDriver, job


@pytest.mark.parametrize('value', [None, '', '   ', 'not a number', '1234', '+1 202 555 0100'])
def test_invalid_agent_phone_is_rejected_before_starting_a_browser(value):
    for application_type in ('BUILDING_WARRANT', 'HOUSEHOLDER_PLANNING', 'PLANNING_APPLICATION'):
        prepared = job(application_type)
        prepared['user_inputs']['Agent Telephone Number'] = value
        managed = FakeManagedDriver()
        calls = []
        result = run_automation(prepared, password='test-only', driver_factory=lambda _: calls.append('browser') or managed,
                                workflow_registry={application_type: lambda **_: calls.append('workflow')})
        assert result.error_code == 'AGENT_DATA_INVALID'
        assert result.last_stage == 'agent_details'
        assert result.retry_safe
        assert result.recovery_fields == ('agentPhone',)
        assert result.progression_message == 'No portal application action was performed.'
        assert calls == []
        assert managed.started == 0


@pytest.mark.parametrize('value', ['0141 000 0000', '07000000000', '+44 141 000 0000'])
def test_supported_agent_phone_formats_pass(value):
    validate_agent_phone({'Agent Telephone Number': value})


@pytest.mark.parametrize('first_name_id', [
    'MainContent_BuildingWarrantAppWizard_AgentDetails_txtAgentFirstName',
    'MainContent_HouseholderApplicationMainDetailsWizard_AgentDetails1_txtAgentFirstName',
])
def test_rejected_agent_screen_reports_its_actual_validation_message(first_name_id):
    driver = FakeDriver()
    driver.add(first_name_id, value='QA Agent')
    driver.scripts['window.Page_Validators'] = lambda: ['Telephone Number: This field is required.']
    advances = []

    def next_once():
        advances.append(True)
        raise RuntimeError('The portal did not confirm the applicant details screen.')

    with pytest.raises(AgentDetailsValidationError) as caught:
        advance_from_agent_details(driver, next_once, first_name_id)
    error = caught.value
    assert advances == [True]
    message, category = domain_error(error)
    assert category == 'AGENT_DATA_INVALID'
    assert 'Telephone Number' in message
    details = describe_failure(error, 'main_details', 'BUILDING_WARRANT')
    assert details.stage == 'agent_details'
    assert 'Telephone Number' in details.progression_message
    assert 'No portal application action' not in details.progression_message
    assert details.recovery_action == 'review_portal'
    assert not details.retry_safe


def test_unconfirmed_transition_does_not_invent_an_applicant_or_agent_data_problem():
    driver = FakeDriver()
    driver.add('agent-name')
    advances = []

    def next_once():
        advances.append(True)
        raise TimeoutException('private browser diagnostic')

    with pytest.raises(AgentDetailsConfirmationError) as caught:
        advance_from_agent_details(driver, next_once, 'agent-name')
    assert advances == [True]
    assert domain_error(caught.value)[1] == 'PORTAL_CONFIRMATION_FAILED'
    assert 'private browser diagnostic' not in str(caught.value)
    details = describe_failure(caught.value, 'main_details')
    assert details.stage == 'agent_details'
    assert not details.retry_safe


def test_a_validation_message_on_another_screen_is_not_blamed_on_the_agent():
    driver = FakeDriver()
    driver.scripts['window.Page_Validators'] = lambda: ['Applicant email is invalid.']
    with pytest.raises(AgentDetailsConfirmationError):
        advance_from_agent_details(driver, lambda: (_ for _ in ()).throw(RuntimeError('destination unconfirmed')), 'agent-name')


def test_browser_disconnection_keeps_its_original_category():
    driver = FakeDriver()
    failure = WebDriverException('invalid session id: disconnected from DevTools')
    with pytest.raises(WebDriverException) as caught:
        advance_from_agent_details(driver, lambda: (_ for _ in ()).throw(failure), 'agent-name')
    assert caught.value is failure
    assert domain_error(caught.value)[1] == 'BROWSER_CONNECTION_INTERRUPTED'


def test_successful_agent_transition_returns_without_an_extra_next():
    calls = []
    assert advance_from_agent_details(FakeDriver(), lambda: calls.append(True) or 'applicant', 'agent-name') == 'applicant'
    assert calls == [True]


@pytest.mark.parametrize('error', [ValueError('Agent first name required'), ValueError('Client first name required'),
                                  ValueError('Site address required'), ValueError('Type of work required')])
def test_data_errors_after_portal_progress_never_claim_no_action_occurred(error):
    early = describe_failure(error, 'validation')
    late = describe_failure(error, 'main_details')
    assert early.progression_message == 'No portal application action was performed.'
    assert 'may already contain changes' in late.progression_message
    assert late.recovery_action == 'review_portal'
    assert not late.retry_safe

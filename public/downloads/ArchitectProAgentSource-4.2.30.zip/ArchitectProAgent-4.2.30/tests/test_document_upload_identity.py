from types import SimpleNamespace
from unittest.mock import patch

import pytest
from selenium.common.exceptions import StaleElementReferenceException, WebDriverException

from automation.common import uploads
from automation.common.document_metadata import prepare_document_metadata, prepare_portal_titles, document_title, document_paper_size
from automation.common.documents import get_paper_size_from_pdf
from gui.services import portal_handoff


def test_reference_survives_local_filename_and_account_path_changes():
    source = {'id': 'document-one', 'fileHash': 'a' * 64, 'originalFilename': 'Long original drawing title.pdf'}
    first = prepare_document_metadata([{**source, 'localName': 'short.pdf', 'localPath': 'C:/one/short.pdf'}])
    second = prepare_document_metadata([{**source, 'localName': 'other.pdf', 'localPath': 'C:/long/account/other.pdf'}])
    assert first['short.pdf']['uploadReference'] == second['other.pdf']['uploadReference']
    assert document_title('short.pdf', first) == document_title('other.pdf', second) == 'Long original drawing title'
    changed = prepare_document_metadata([{**source, 'fileHash': 'b' * 64, 'localName': 'short.pdf', 'localPath': 'C:/one/short.pdf'}])
    assert first['short.pdf']['uploadReference'] != changed['short.pdf']['uploadReference']
    assert document_title('short.pdf', first) == document_title('short.pdf', changed)


def test_download_rejects_a_different_file_version_before_writing(monkeypatch, tmp_path):
    monkeypatch.setattr(portal_handoff.storage_paths, 'app_data_dir', lambda: str(tmp_path))
    client = portal_handoff.PortalClient('https://www.architectpro.co.uk', 'test-only')
    monkeypatch.setattr(client, '_request', lambda *_args, **_kwargs: (b'%PDF-wrong-version', {}))
    downloaded, failures = client.download_documents({'id': 'hash-mismatch', 'documents': [
        {'id': 'plan', 'downloadUrl': '/api/desktop/documents/plan', 'originalFilename': 'Plan.pdf', 'fileHash': 'a' * 64}]})
    assert downloaded == []
    assert len(failures) == 1 and 'does not match' in str(failures[0])
    assert not list(tmp_path.rglob('*.pdf'))


def test_older_job_download_gets_a_content_hash(monkeypatch, tmp_path):
    import hashlib
    content = b'%PDF-legacy-job'
    monkeypatch.setattr(portal_handoff.storage_paths, 'app_data_dir', lambda: str(tmp_path))
    client = portal_handoff.PortalClient('https://www.architectpro.co.uk', 'test-only')
    monkeypatch.setattr(client, '_request', lambda *_args, **_kwargs: (content, {}))
    downloaded, failures = client.download_documents({'id': 'hash-legacy', 'documents': [
        {'id': 'plan', 'downloadUrl': '/api/desktop/documents/plan', 'originalFilename': 'Plan.pdf'}]})
    assert failures == []
    assert downloaded[0]['fileHash'] == hashlib.sha256(content).hexdigest()


@pytest.mark.parametrize('remote_hash', ['a' * 64, 'b' * 64, None], ids=['same', 'different', 'unreadable'])
def test_legacy_reference_only_matches_when_pdf_content_matches(remote_hash):
    driver = SimpleNamespace(execute_async_script=lambda _, _view, _object: {'sha256': remote_hash})
    metadata = {'short.pdf': {'uploadReference': 'AP' + '1' * 18, 'originalFilename': 'Original Drawing.pdf',
                              'fileHash': 'a' * 64}}
    listed = uploads.AttachmentTitles(['Original Drawing'], views={
        'Original Drawing': [{'id': 'MainContent_btnView1', 'objectId': '1'}],
    })
    if remote_hash == 'a' * 64:
        assert uploads.documents_still_to_upload([('short.pdf', 'plans')], listed, metadata, driver=driver) == []
    else:
        with pytest.raises(uploads.DocumentUploadError) as caught:
            uploads.documents_still_to_upload([('short.pdf', 'plans')], listed, metadata, driver=driver)
        assert caught.value.reason_code == 'DOCUMENT_MATCH_AMBIGUOUS'
        assert caught.value.filename == 'short.pdf'


@pytest.mark.parametrize('saved_references', [['AP' + '2' * 18], ['AP' + '1' * 18] * 2])
def test_an_unmatched_revision_or_duplicate_reference_requires_review(saved_references):
    reference = 'AP' + '1' * 18
    with pytest.raises(uploads.DocumentUploadError) as caught:
        uploads.documents_still_to_upload(
            [('short.pdf', 'plans')], uploads.AttachmentTitles(saved_references),
            {'short.pdf': {'uploadReference': reference}},
        )
    assert caught.value.reason_code == 'DOCUMENT_MATCH_AMBIGUOUS'
    assert caught.value.filename == 'short.pdf'


@pytest.mark.parametrize('saved_hash', ['b' * 64, None], ids=['replaced-pdf', 'unreadable-pdf'])
def test_exact_agent_reference_cannot_prove_saved_contents(saved_hash):
    reference = 'AP' + '1' * 18
    views = {reference: [{'id': 'MainContent_btnView1', 'objectId': '1'}]}
    titles = uploads.AttachmentTitles([reference], views=views)
    driver = SimpleNamespace(execute_async_script=lambda *_: {'sha256': saved_hash})
    metadata = {'drawing.pdf': {'uploadReference': reference, 'fileHash': 'a' * 64}}
    with pytest.raises(uploads.DocumentUploadError) as caught:
        uploads.documents_still_to_upload([('drawing.pdf', 'plans')], titles, metadata, driver=driver)
    assert caught.value.reason_code == 'DOCUMENT_MATCH_AMBIGUOUS'
    assert caught.value.filename == 'drawing.pdf'


def test_legacy_filename_collision_cannot_override_an_exact_agent_reference():
    reference = 'AP' + '1' * 18
    metadata = {
        'first.pdf': {'uploadReference': reference, 'portalTitle': reference + ' drawing', 'fileHash': 'a' * 64},
        'second.pdf': {'originalFilename': reference + '.pdf', 'portalTitle': 'Second drawing', 'fileHash': 'b' * 64},
    }
    titles = uploads.AttachmentTitles([reference], views={reference: [{'id': 'View1', 'objectId': '1'}]})
    driver = SimpleNamespace(execute_async_script=lambda *_: {'sha256': 'b' * 64})
    with pytest.raises(uploads.DocumentUploadError, match='different PDF content') as caught:
        uploads.documents_still_to_upload(
            [('first.pdf', 'plans'), ('second.pdf', 'plans')], titles, metadata, driver=driver, match_renamed=True,
        )
    assert caught.value.filename == 'first.pdf'


def test_case_and_spacing_changes_still_compare_legacy_attachment_bytes():
    attached = uploads.AttachmentTitles(['SITE Floor plan'], views={
        'SITE Floor plan': [{'id': 'MainContent_btnView1', 'objectId': '1'}],
    })
    driver = SimpleNamespace(execute_async_script=lambda *_: {'sha256': 'a' * 64})
    metadata = {'Site  floor plan.pdf': {'uploadReference': 'AP' + '1' * 18, 'fileHash': 'b' * 64}}
    with pytest.raises(uploads.DocumentUploadError, match='different PDF content'):
        uploads.documents_still_to_upload([('Site  floor plan.pdf', 'plans')], attached, metadata, driver=driver)


def test_ambiguous_legacy_match_does_not_skip_two_distinct_documents():
    metadata = {name: {'uploadReference': reference, 'originalFilename': 'Plan.pdf'}
                for name, reference in [('one.pdf', 'AP1'), ('two.pdf', 'AP2')]}
    with pytest.raises(uploads.DocumentUploadError) as caught:
        uploads.documents_still_to_upload([('one.pdf', 'plans'), ('two.pdf', 'plans')], {'Plan'}, metadata)
    assert caught.value.reason_code == 'DOCUMENT_MATCH_AMBIGUOUS'


def test_a_manually_renamed_attachment_matches_once_by_pdf_content():
    metadata = {'first.pdf': {'portalTitle': 'Ground Floor Plan', 'fileHash': 'a' * 64},
                'second.pdf': {'portalTitle': 'Elevations', 'fileHash': 'b' * 64}}
    entries = [('first.pdf', 'plans'), ('second.pdf', 'plans')]
    view = {'id': 'btnView1', 'objectId': '1'}
    titles = uploads.AttachmentTitles(['Client corrected title'], views={'Client corrected title': [view]})
    reads = []
    def read(_script, _, object_id):
        reads.append(object_id)
        return {'sha256': 'a' * 64}

    pending = uploads.documents_still_to_upload(
        entries, titles, metadata, driver=SimpleNamespace(execute_async_script=read), match_renamed=True)
    assert pending == entries[1:]
    assert reads == ['1']


@pytest.mark.parametrize('saved_hash, missing_filename', [
    ('a' * 64, 'south.pdf'),
    ('b' * 64, 'north.pdf'),
    ('c' * 64, None),
])
def test_clipped_title_colliding_with_another_filename_is_resolved_by_pdf_content(saved_hash, missing_filename):
    title = 'Existing floor plan and survey'
    entries = [('north.pdf', 'plans'), ('south.pdf', 'plans')]
    metadata = {
        'north.pdf': {'drawingTitle': title + ' north', 'originalFilename': 'north.pdf', 'fileHash': 'a' * 64},
        'south.pdf': {'drawingTitle': 'Proposed south entrance', 'originalFilename': title + '.pdf', 'fileHash': 'b' * 64},
    }
    prepare_portal_titles(entries, metadata)
    clipped = uploads.reserve_document_label(metadata['north.pdf']['portalTitle'], set(), limit=len(title))
    assert clipped == title
    grid = uploads.AttachmentTitles([clipped], views={clipped: [{'id': 'View1', 'objectId': '1'}]})
    reads = []

    def read(*args):
        reads.append(args[-1])
        return {'sha256': saved_hash}

    driver = SimpleNamespace(execute_async_script=read)
    if missing_filename is None:
        with pytest.raises(uploads.DocumentUploadError, match='cannot be matched uniquely'):
            uploads.documents_still_to_upload(entries, grid, metadata, driver=driver, match_renamed=True)
    else:
        assert uploads.documents_still_to_upload(entries, grid, metadata, driver=driver, match_renamed=True) == [
            (missing_filename, 'plans'),
        ]
    assert reads == ['1']


@pytest.mark.parametrize('separator', [' ', '_'])
@pytest.mark.parametrize('saved_hash', ['b' * 64, 'd' * 64], ids=['correct-pdf', 'unrelated-pdf'])
def test_clipped_and_numbered_label_can_match_a_different_original_filename(separator, saved_hash):
    prefix = 'Existing floor plan and survey'
    entries = [(name, 'plans') for name in ('ground.pdf', 'first.pdf', 'elevation.pdf')]
    occupied = set()
    first = uploads.reserve_document_label(prefix + ' ground', occupied, limit=len(prefix), separator=separator)
    numbered = uploads.reserve_document_label(prefix + ' first', occupied, limit=len(prefix), separator=separator)
    assert numbered.endswith(separator + '2')
    metadata = {
        'ground.pdf': {'drawingTitle': prefix + ' ground', 'fileHash': 'a' * 64},
        'first.pdf': {'drawingTitle': prefix + ' first', 'fileHash': 'b' * 64},
        'elevation.pdf': {'drawingTitle': 'Proposed elevation', 'originalFilename': numbered + '.pdf', 'fileHash': 'c' * 64},
    }
    prepare_portal_titles(entries, metadata, separator=separator)
    titles = uploads.AttachmentTitles([first, numbered], views={
        first: [{'id': 'View1', 'objectId': '1'}],
        numbered: [{'id': 'View2', 'objectId': '2'}],
    })
    reads = []

    def read(_script, _view, object_id):
        reads.append(object_id)
        return {'sha256': 'a' * 64 if object_id == '1' else saved_hash}

    driver = SimpleNamespace(execute_async_script=read)
    if saved_hash == 'b' * 64:
        assert uploads.documents_still_to_upload(entries, titles, metadata, driver=driver, match_renamed=True) == entries[2:]
        assert sorted(reads) == ['1', '2']
    else:
        with pytest.raises(uploads.DocumentUploadError):
            uploads.documents_still_to_upload(entries, titles, metadata, driver=driver, match_renamed=True)


@pytest.mark.parametrize('reverse', [False, True], ids=['saved-first', 'saved-last'])
@pytest.mark.parametrize('both_attached', [False, True], ids=['one-attached', 'both-attached'])
def test_shared_original_filename_resolves_regardless_of_document_order(reverse, both_attached):
    original = 'Existing floor plan and survey'
    entries = [('north.pdf', 'plans'), ('south.pdf', 'plans')]
    if reverse:
        entries.reverse()
    metadata = {
        'north.pdf': {'drawingTitle': original + ' north', 'originalFilename': original + '.pdf', 'fileHash': 'a' * 64},
        'south.pdf': {'drawingTitle': 'Proposed south entrance', 'originalFilename': original + '.pdf', 'fileHash': 'b' * 64},
    }
    prepare_portal_titles(entries, metadata)
    clipped = uploads.reserve_document_label(metadata['north.pdf']['portalTitle'], set(), limit=len(original))
    views = {clipped: [{'id': 'View1', 'objectId': '1'}]}
    if both_attached:
        views[metadata['south.pdf']['portalTitle']] = [{'id': 'View2', 'objectId': '2'}]
    titles = uploads.AttachmentTitles(list(views), views=views)
    driver = SimpleNamespace(execute_async_script=lambda _script, _view, object_id: {
        'sha256': 'a' * 64 if object_id == '1' else 'b' * 64,
    })
    assert uploads.documents_still_to_upload(entries, titles, metadata, driver=driver, match_renamed=True) == (
        [] if both_attached else [('south.pdf', 'plans')]
    )


@pytest.mark.parametrize('saved_hash', ['a' * 64, 'b' * 64])
def test_shared_label_cannot_hide_a_duplicate_or_a_replaced_pdf(saved_hash):
    metadata = {
        'one.pdf': {'portalTitle': 'First drawing', 'originalFilename': 'Plan.pdf', 'fileHash': 'a' * 64},
        'two.pdf': {'portalTitle': 'Second drawing', 'originalFilename': 'Plan.pdf', 'fileHash': 'a' * 64},
    }
    views = {title: [{'id': f'View{index}', 'objectId': str(index)}]
             for index, title in enumerate(['First drawing', 'Second drawing', 'Plan'])}
    titles = uploads.AttachmentTitles(list(views), views=views)
    driver = SimpleNamespace(execute_async_script=lambda _script, _view, object_id: {
        'sha256': saved_hash if object_id == '2' else 'a' * 64,
    })
    with pytest.raises(uploads.DocumentUploadError, match='cannot be matched uniquely'):
        uploads.documents_still_to_upload(
            [('one.pdf', 'plans'), ('two.pdf', 'plans')], titles, metadata, driver=driver, match_renamed=True,
        )


def test_a_corrected_description_with_an_old_reference_cannot_hide_a_changed_pdf(monkeypatch):
    reference = 'AP' + '1' * 18
    view = {'id': 'btnView1', 'objectId': '1'}
    row = {'editId': 'edit', 'attached': True, 'view': view}
    listed = uploads.AttachmentTitles(['Renamed by client'], views={'Renamed by client': [view]}, legacy_rows=[row])
    driver = SimpleNamespace(execute_async_script=lambda *_: {'sha256': 'b' * 64})
    monkeypatch.setattr(uploads, '_read_hidden_document_reference', lambda *_: reference)
    metadata = {'drawing.pdf': {'uploadReference': reference, 'portalTitle': 'Ground Floor', 'fileHash': 'a' * 64}}
    with pytest.raises(uploads.DocumentUploadError, match='older or replaced PDF'):
        uploads.documents_still_to_upload([('drawing.pdf', 'plans')], listed, metadata,
                                          driver=driver, match_renamed=True)


def test_two_renamed_rows_with_identical_pdfs_need_review():
    views = [{'id': f'btnView{index}', 'objectId': str(index)} for index in range(2)]
    listed = uploads.AttachmentTitles(['Renamed', 'Renamed'], views={'Renamed': views})
    driver = SimpleNamespace(execute_async_script=lambda *_: {'sha256': 'a' * 64})
    metadata = {'drawing.pdf': {'portalTitle': 'Ground Floor', 'fileHash': 'a' * 64}}
    with pytest.raises(uploads.DocumentUploadError, match='Multiple documents have the same PDF content'):
        uploads.documents_still_to_upload([('drawing.pdf', 'plans')], listed, metadata,
                                          driver=driver, match_renamed=True)


def test_unreadable_attachment_list_is_not_an_empty_list():
    driver = SimpleNamespace(execute_script=lambda _script: None)
    with pytest.raises(uploads.DocumentUploadError) as caught:
        uploads.listed_document_titles(driver, timeout=0)
    assert caught.value.reason_code == 'DOCUMENT_LIST_UNREADABLE'


def test_attachment_list_is_reacquired_after_a_postback():
    reads = [StaleElementReferenceException(), {'recognized': True, 'titles': ['Saved'], 'paginated': False}]
    def read(_script):
        value = reads.pop(0)
        if isinstance(value, Exception):
            raise value
        return value
    assert uploads.listed_document_titles(SimpleNamespace(execute_script=read), timeout=1) == {'Saved'}


def test_disconnected_browser_is_not_treated_as_an_empty_list():
    def read(_script):
        raise WebDriverException('Chrome renderer disconnected')
    with pytest.raises(WebDriverException, match='disconnected'):
        uploads.listed_document_titles(SimpleNamespace(execute_script=read), timeout=0)


def test_a_posted_document_does_not_count_as_attached():
    listed = uploads.AttachmentTitles([], unattached=['AP123'])
    with pytest.raises(uploads.DocumentUploadError) as caught:
        uploads.documents_still_to_upload([('plan.pdf', 'plans')], listed, {'plan.pdf': {'uploadReference': 'AP123'}})
    assert caught.value.reason_code == 'DOCUMENT_MATCH_AMBIGUOUS'


def test_legacy_warrant_reference_is_read_without_saving(monkeypatch):
    events = []
    state = {'editing': False}
    def script(_script):
        return {'recognized': not state['editing'], 'titles': [], 'legacyRows': [{'editId': 'edit-one', 'attached': True}]}
    def click(_driver, _by, locator, **_kwargs):
        events.append(locator)
        state['editing'] = locator == 'edit-one'
    driver = SimpleNamespace(execute_script=script, find_element=lambda *_: SimpleNamespace(get_attribute=lambda _: 'Original Drawing'))
    monkeypatch.setattr(uploads, 'click_when_clickable', click)
    assert uploads.listed_document_titles(driver, timeout=1) == {'Original Drawing'}
    assert events == ['edit-one', 'MainContent_SupportingDocumentationWizard_btnCancelDocEdit']


def test_ai_paper_size_is_used_and_conflicts_require_review():
    metadata = {'plan.pdf': {'paperSize': {'value': 'A3', 'reviewRequired': False}}}
    assert document_paper_size('C:/files/plan.pdf', metadata) == 'A3'
    metadata['plan.pdf']['paperSize']['reviewRequired'] = True
    with pytest.raises(uploads.DocumentUploadError) as caught:
        document_paper_size('C:/files/plan.pdf', metadata)
    assert caught.value.reason_code == 'PAPER_SIZE_NEEDS_REVIEW'


def test_legacy_paper_size_uses_dimensions_not_drawing_reference(tmp_path):
    page = SimpleNamespace(mediabox=SimpleNamespace(width=297 * 72 / 25.4, height=420 * 72 / 25.4),
                           get=lambda _key, default: default, extract_text=lambda: 'Drawing GA100, paper A3')
    path = tmp_path / 'GA100.pdf'
    path.write_bytes(b'%PDF-test')
    with patch('automation.common.documents.PyPDF2.PdfReader', return_value=SimpleNamespace(is_encrypted=False, pages=[page])):
        assert get_paper_size_from_pdf(str(path)) == 'A3'

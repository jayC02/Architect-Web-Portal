import pytest

from automation.common import existing_application
from automation.common.proposal_creation import (
    HOUSEHOLDER, PLANNING_PERMISSION, ProposalStateStore, SavedProposalNotFoundError, build_context,
)


def inputs(job_id="job-householder"):
    return {
        "Email": "architect@example.com",
        "Site Address": "5 Tulloch Street, Glasgow",
        "Site Postcode": "G12 8AB",
        "Description of Work": "Single-storey rear extension",
        "Automation Job ID": job_id,
    }


class StateStore:
    def __init__(self, records):
        self.records = records

    def get(self, context):
        return self.records.get(context.job_key)


class ReadOnlyPortal:
    def __init__(self, *, missing=False):
        self.missing = missing
        self.opened = []
        self.forms_opened = 0
        self.created = 0

    def open_existing_proposal(self, reference, name):
        self.opened.append((reference, name))
        if self.missing:
            raise SavedProposalNotFoundError(
                "Open proposal", "The saved proposal was not found."
            )

    def open_added_form(self):
        self.forms_opened += 1

    def create_proposal(self, *_args, **_kwargs):
        self.created += 1
        raise AssertionError("View must never create a proposal")


@pytest.mark.parametrize(
    "application_type",
    ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"],
)
def test_view_opens_exact_saved_application_and_verifies_main_page(
    monkeypatch, application_type
):
    portal = ReadOnlyPortal()
    verified = []
    monkeypatch.setattr(
        existing_application,
        "verify_application_main_page",
        lambda driver, selectors, timeout: verified.append((driver, selectors, timeout)),
    )
    job_id = f"job-{application_type.lower()}"
    store = StateStore({
        job_id: {
            "proposalReference": f"REF-{application_type}",
            "proposalName": f"Saved {application_type}",
        }
    })
    driver = object()

    reference = existing_application.open_existing_application(
        driver,
        application_type,
        inputs(job_id),
        password="secure-password",
        state_store=store,
        portal=portal,
    )

    assert reference == f"REF-{application_type}"
    assert portal.opened == [(f"REF-{application_type}", f"Saved {application_type}")]
    assert portal.forms_opened == 1
    assert portal.created == 0
    assert verified and verified[0][0] is driver


def test_multiple_saved_applications_select_by_exact_job_identity(monkeypatch):
    monkeypatch.setattr(
        existing_application,
        "verify_application_main_page",
        lambda *_args, **_kwargs: None,
    )
    store = StateStore({
        "job-one": {"proposalReference": "REF-ONE", "proposalName": "First"},
        "job-two": {"proposalReference": "REF-TWO", "proposalName": "Second"},
    })
    portal = ReadOnlyPortal()

    reference = existing_application.open_existing_application(
        object(),
        "HOUSEHOLDER_PLANNING",
        inputs("job-two"),
        password="secure-password",
        state_store=store,
        portal=portal,
    )

    assert reference == "REF-TWO"
    assert portal.opened == [("REF-TWO", "Second")]
    assert portal.created == 0


def test_planning_permission_reopens_its_saved_form_with_real_state_identity(monkeypatch, tmp_path):
    from types import SimpleNamespace

    record = inputs("job-planning-permission")
    store = ProposalStateStore(str(tmp_path / "proposal-state.json"))
    store.save(build_context(record, PLANNING_PERMISSION), "REF-PLANNING", "Saved Planning Permission")
    assert store.get(build_context(record, HOUSEHOLDER)) is None

    portal_types = []
    portal = ReadOnlyPortal()
    monkeypatch.setattr(existing_application, "_login", lambda *_args: None)
    monkeypatch.setattr(existing_application, "verify_application_main_page", lambda *_args, **_kwargs: None)

    def build_portal(_driver, portal_type):
        portal_types.append(portal_type)
        return portal

    monkeypatch.setattr(existing_application, "SeleniumProposalPortal", build_portal)
    assert existing_application.open_existing_application(
        SimpleNamespace(), "PLANNING_APPLICATION", record, password="test-only", state_store=store,
    ) == "REF-PLANNING"
    assert portal_types == [PLANNING_PERMISSION]
    assert portal.forms_opened == 1


def test_missing_saved_application_stops_without_creating(monkeypatch):
    monkeypatch.setattr(
        existing_application,
        "verify_application_main_page",
        lambda *_args, **_kwargs: None,
    )
    portal = ReadOnlyPortal(missing=True)
    store = StateStore({
        "job-householder": {
            "proposalReference": "REF-MISSING",
            "proposalName": "Missing",
        }
    })

    with pytest.raises(existing_application.ExistingApplicationNotFound):
        existing_application.open_existing_application(
            object(),
            "HOUSEHOLDER_PLANNING",
            inputs(),
            password="secure-password",
            state_store=store,
            portal=portal,
        )

    assert portal.created == 0
    assert portal.forms_opened == 0


def test_no_saved_identity_stops_before_portal_navigation():
    portal = ReadOnlyPortal()
    with pytest.raises(existing_application.ExistingApplicationNotFound):
        existing_application.open_existing_application(
            object(),
            "HOUSEHOLDER_PLANNING",
            inputs(),
            password="secure-password",
            state_store=StateStore({}),
            portal=portal,
        )
    assert portal.opened == []
    assert portal.created == 0

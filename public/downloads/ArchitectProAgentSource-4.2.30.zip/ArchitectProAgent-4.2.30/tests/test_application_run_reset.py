import json
from pathlib import Path
import uuid

import pytest

from automation.common.proposal_creation import (
    BUILDING_WARRANT, HOUSEHOLDER, ProposalCreationError, ProposalNameInUse,
    ProposalStateStore, build_context,
)
from tests.test_proposal_creation import FakePortal, MemoryStore, inputs, run
from gui.services.portal_handoff import portal_job_to_values


@pytest.mark.parametrize('kind', [HOUSEHOLDER, BUILDING_WARRANT])
def test_reset_names_the_proposal_by_the_site_address_only(kind):
    # Proposals are real submissions: the name is exactly the site address.
    portal = FakePortal(kind)
    run(portal, values=inputs(kind, **{'Portal Draft Key': str(uuid.uuid4())}))
    names = [event[1] for event in portal.events if isinstance(event, tuple) and event[0] == 'proposal-details']
    assert names == ['12 Rowan Road, Glasgow, G1 1AA']
    assert portal.events.count('create-proposal') == 1
    assert not any(isinstance(event, tuple) and event[0] == 'open-existing' for event in portal.events)


@pytest.mark.parametrize('recovered', ['123456789', None])
def test_reset_stops_when_the_old_draft_still_holds_the_address_name(recovered):
    class OldDraftHoldsName(FakePortal):
        def enter_proposal_details(self, name, description):
            super().enter_proposal_details(name, description)
            raise ProposalNameInUse('Proposal details', 'reserved')

    portal = OldDraftHoldsName(HOUSEHOLDER, recovered_reference=recovered)
    with pytest.raises(ProposalCreationError, match='already exists in My Proposals') as error:
        run(portal, values=inputs(HOUSEHOLDER, **{'Portal Draft Key': str(uuid.uuid4())}))
    assert error.value.confirmation_required is True
    assert '12 Rowan Road, Glasgow, G1 1AA' in str(error.value)
    assert 'create-proposal' not in portal.events
    opened = [event for event in portal.events if isinstance(event, tuple) and event[0] == 'open-existing']
    assert opened == [], 'a reset never continues in the old draft'
    assert portal.events.count('open-new') == 1


def test_invalid_reset_key_stops_before_opening_the_portal():
    portal = FakePortal(HOUSEHOLDER)
    with pytest.raises(ProposalCreationError, match='valid fresh-draft identity'):
        run(portal, values=inputs(HOUSEHOLDER, **{'Portal Draft Key': 'wrong'}))
    assert portal.events == []


def test_saved_identity_from_another_reset_is_not_resumed(tmp_path):
    store = ProposalStateStore(str(tmp_path / 'state.json'))
    first = build_context(inputs(HOUSEHOLDER, **{'Portal Draft Key': str(uuid.uuid4())}))
    store.save(first, '123', 'first reset')
    second = build_context(inputs(HOUSEHOLDER, **{'Portal Draft Key': str(uuid.uuid4())}))
    assert store.get(second) is None
    assert store.get(first)['proposalReference'] == '123'


def test_trusted_web_reset_identity_reaches_the_automation_context():
    snapshot = json.loads((Path(__file__).parent / 'fixtures/automation-job-v2-building-warrant.json').read_text())
    key = str(uuid.uuid4())
    snapshot['metadata']['portalDraftKey'] = key
    job = {'id': snapshot['metadata']['jobId'], 'projectId': snapshot['metadata']['projectId'], 'type': 'BUILDING_WARRANT', 'dataSnapshot': snapshot}
    values = portal_job_to_values(job)
    assert values['Portal Draft Key'] == key
    assert build_context(values).draft_key == key

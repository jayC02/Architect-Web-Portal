import json
import os
from types import SimpleNamespace
from unittest.mock import patch

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QDialog, QLabel, QLineEdit

from automation.models import RuntimeJob
from automation.runner import AutomationResult, ProgressEvent, ProgressStatus
from gui import agent_app


@pytest.fixture(autouse=True)
def isolate_real_callback_outbox(monkeypatch):
    monkeypatch.setattr(agent_app.callback_outbox, "pending_events", lambda: [])
    monkeypatch.setattr(agent_app.secure_credentials, "get_agent_credential", lambda: (None, True, ""))
    monkeypatch.setattr(agent_app.secure_credentials, "get_login_password", lambda _email: (None, True, ""))


class SignalStub:
    def connect(self, callback):
        self.callback = callback

    def emit(self, *args):
        self.callback(*args)


class ThreadStub:
    starts = 0

    def __init__(self, *args, **kwargs):
        self.progress = SignalStub()
        self.completed = SignalStub()
        self.running = False
        self.cancelled = False

    def start(self):
        ThreadStub.starts += 1
        self.running = True

    def isRunning(self):
        return self.running

    def cancel(self):
        self.cancelled = True


class JobThreadStub:
    def __init__(self, *args, **kwargs):
        self.phase = SignalStub()
        self.loaded = SignalStub()
        self.failed = SignalStub()
        self.finished = SignalStub()
        self.running = False

    def start(self):
        self.running = True

    def isRunning(self):
        return self.running


def runtime_job(application_type="BUILDING_WARRANT"):
    return RuntimeJob.from_mapping({
        "job_id": "job_test_123456",
        "application_type": application_type,
        "site_label": "5 Tulloch Street",
        "user_inputs": {"Email": "test@example.com", "PDF Folder Path": "C:/test"},
        "document_mapping": {"pdf_folder_path": "C:/test", "buckets": {}, "bucket_labels": {}},
    })


def make_window():
    app = QApplication.instance() or QApplication([])
    with patch.object(agent_app, "find_stored_login", return_value=""), patch.object(
        agent_app, "load_settings", return_value={"email": "", "browser_mode": "AUTO"}
    ):
        window = agent_app.AutomationAgent(auto_refresh=False, auto_onboard=False)
    window.portal_job = {"id": "job_test_123456", "projectId": "project_test", "status": "CLAIMED"}
    window.show()
    app.processEvents()
    return window


def result(outcome, *, message="Done", technical_details="", error_code=None, timings=None):
    return AutomationResult(
        outcome, "job_test_123456", "BUILDING_WARRANT", message,
        "documents", timings or {},
        technical_details, error_code,
    )


def test_no_job_ready_and_running_states_show_only_relevant_controls():
    window = make_window()
    try:
        assert window.heading.text() == "No application ready"
        assert not window.start_button.isVisible()
        assert not window.progress_area.isVisible()
        assert not window.technical_log.isVisible()

        window.runtime_job = runtime_job()
        window.show_ready()
        QApplication.processEvents()
        assert window.heading.text() == "5 Tulloch Street"
        assert window.start_button.isVisible()
        assert not window.stop_button.isVisible()

        ThreadStub.starts = 0
        with patch.object(agent_app, "find_stored_login", return_value="test@example.com"), patch.object(
            agent_app.secure_credentials, "get_login_password", return_value=("secret", True, "")
        ), patch.object(agent_app, "AutomationThread", ThreadStub), patch.object(agent_app, "save_settings"):
            window.start_automation()
        QApplication.processEvents()
        assert ThreadStub.starts == 1
        assert not window.start_button.isVisible()
        assert window.stop_button.isVisible()
        assert window.progress_area.isVisible()
        assert window.current_task.text() == "Starting automation…"
        assert window.progress_bar.value() == 1
        assert window.percent.text() == "1%"
        assert not window.technical_log.isVisible()

        window.automation_thread.progress.emit(
            ProgressEvent("validation", ProgressStatus.COMPLETED, "Prepared job validated")
        )
        window.automation_thread.progress.emit(
            ProgressEvent("browser", ProgressStatus.RUNNING, "Starting browser")
        )
        assert window.current_task.text() == "Starting secure browser"
        assert window.progress_bar.value() >= 1
        assert not window.technical_log.isVisible()

        window.stop_automation()
        assert window.automation_thread.cancelled
        assert not window.eta_timer.isActive()
        assert window.eta.text() == "Stopping safely…"
    finally:
        window.close()


def test_initial_lookup_shows_responsive_indeterminate_loading_until_result(monkeypatch):
    app = QApplication.instance() or QApplication([])
    callbacks = []
    monkeypatch.setattr(agent_app, "load_settings", lambda: {"email": "saved@example.com", "browser_mode": "AUTO"})
    monkeypatch.setattr(agent_app, "find_stored_login", lambda _settings: "saved@example.com")
    monkeypatch.setattr(agent_app.QTimer, "singleShot", lambda _delay, callback: callbacks.append(callback))
    window = agent_app.AutomationAgent("architectpro://prepared", auto_refresh=True, auto_onboard=False)
    window.show(); app.processEvents()
    try:
        assert window.connection.text() == "● Agent disconnected"
        assert window.heading.text() == "Connecting to Architect Pro…"
        assert window.loading_area.isVisible()
        assert (window.loading_bar.minimum(), window.loading_bar.maximum()) == (0, 0)
        assert window.heading.text() not in {"No application ready", "5 Tulloch Street"}
        assert window.settings_button.isEnabled()
        assert window.refresh_job in callbacks

        monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
        window.refresh_job()
        app.processEvents()
        assert window.load_thread.isRunning()
        assert window.heading.text() == "Connecting to Architect Pro…"

        window.load_thread.phase.emit("looking")
        assert window.heading.text() == "Looking for prepared application…"
        assert window.connection.text() == "● Agent disconnected"

        prepared = runtime_job("HOUSEHOLDER_PLANNING")
        monkeypatch.setattr(agent_app, "runtime_job_from_portal", lambda *args, **kwargs: prepared)
        window.load_thread.phase.emit("loading")
        assert window.connection.text() == "● Agent disconnected", "loading a job is not enrollment authentication"
        window.load_thread.loaded.emit({"id": "job_test_123456", "status": "CLAIMED"}, object(), {}, [])
        assert window.heading.text() == "5 Tulloch Street"
        assert window.start_button.isVisible()
        assert not window.loading_area.isVisible()
    finally:
        window.callback_retry_timer.stop()
        window.close()


def test_no_job_and_connection_error_only_appear_after_lookup_finishes(monkeypatch):
    window = make_window()
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    try:
        window.launch_url = "architectpro://prepared"
        window.refresh_job()
        assert window.heading.text() == "Connecting to Architect Pro…"
        window.load_thread.failed.emit("No automation job ready")
        assert window.heading.text() == "No application ready"

        window.load_thread.running = False
        window.refresh_job()
        raw = "HTTPConnectionPool traceback with private diagnostics"
        window.load_thread.failed.emit(raw)
        assert window.connection.text() == "● Agent disconnected"
        assert window.heading.text() == "Could not load application"
        assert raw not in window.message.text()
        assert raw in window.technical_log.toPlainText()
        assert not window.technical_log.isVisible()
        assert window.technical_toggle.isVisible()
    finally:
        window.close()


def test_agent_enrollment_precedes_secure_portal_login_onboarding():
    QApplication.instance() or QApplication([])
    callbacks = []
    with patch.object(agent_app, "find_stored_login", return_value=""), patch.object(
        agent_app.QTimer, "singleShot", side_effect=lambda _delay, callback: callbacks.append(callback)
    ):
        window = agent_app.AutomationAgent(auto_refresh=False, auto_onboard=True)
    try:
        assert window.ensure_agent_enrollment in callbacks
        with patch.object(window, "change_login", return_value=False) as change:
            assert window.ensure_credentials() is False
            change.assert_called_once_with(first_run=True)

        with patch.object(agent_app, "find_stored_login", return_value="saved@example.com"), patch.object(
            window, "change_login"
        ) as change:
            assert window.ensure_credentials() is True
            change.assert_not_called()
    finally:
        window.close()


def test_credential_dialog_uses_masked_secure_storage_and_json_never_contains_password(tmp_path, monkeypatch):
    QApplication.instance() or QApplication([])
    saved = []
    monkeypatch.setattr(agent_app.secure_credentials, "save_login_password", lambda email, password: (saved.append((email, password)) or True, ""))
    dialog = agent_app.CredentialDialog()
    dialog.email.setText("user@example.com")
    dialog.password.setText("super-secret")
    assert dialog.password.echoMode() == QLineEdit.EchoMode.Password
    dialog.show()
    QApplication.processEvents()
    QTest.mouseClick(dialog.password_visibility_button, Qt.MouseButton.LeftButton)
    assert dialog.password.displayText() == "super-secret"
    assert dialog.password_visibility_button.text() == "Hide password"
    assert dialog.result() != QDialog.DialogCode.Accepted
    assert saved == []
    dialog.password_visibility_button.setFocus()
    QTest.keyClick(dialog.password_visibility_button, Qt.Key.Key_Space)
    assert dialog.password.echoMode() == QLineEdit.EchoMode.Password
    assert dialog.password.text() == "super-secret"
    QTest.keyClick(dialog.password_visibility_button, Qt.Key.Key_Space)
    dialog.save()
    assert dialog.result() == QDialog.DialogCode.Accepted
    assert saved == [("user@example.com", "super-secret")]
    assert dialog.password.text() == ""

    monkeypatch.setenv("APPDATA", str(tmp_path))
    agent_app.save_settings({"email": "user@example.com", "browser_mode": "AUTO", "password": "super-secret"})
    settings_text = (tmp_path / "NinetyOneArchitects" / "Building Portal" / agent_app.SETTINGS_FILE).read_text(encoding="utf-8")
    assert "super-secret" not in settings_text
    assert "password" not in settings_text.lower()
    assert json.loads(settings_text) == {
        "email": "user@example.com",
        "login_selection_set": True,
        "browser_mode": "AUTO",
        "browser_mode_policy_version": agent_app.BROWSER_MODE_POLICY_VERSION,
    }


@pytest.mark.parametrize("policy_version", [None, agent_app.BROWSER_MODE_POLICY_VERSION])
def test_saved_headless_setting_uses_auto(tmp_path, monkeypatch, policy_version):
    monkeypatch.setenv("APPDATA", str(tmp_path))
    path = tmp_path / "NinetyOneArchitects" / "Building Portal" / agent_app.SETTINGS_FILE
    path.parent.mkdir(parents=True)
    settings = {"email": "user@example.com", "browser_mode": "HEADLESS"}
    if policy_version is not None:
        settings["browser_mode_policy_version"] = policy_version
    path.write_text(json.dumps(settings), encoding="utf-8")
    assert agent_app.load_settings()["browser_mode"] == "AUTO"
    agent_app.save_settings(settings)
    assert json.loads(path.read_text(encoding="utf-8"))["browser_mode"] == "AUTO"


@pytest.mark.parametrize("saved_mode, selected_mode", [("HEADLESS", "AUTO"), ("VISIBLE", "VISIBLE")])
def test_settings_only_offer_browser_modes_that_support_review(saved_mode, selected_mode):
    QApplication.instance() or QApplication([])
    dialog = agent_app.SettingsDialog({"browser_mode": saved_mode})
    try:
        assert [dialog.mode.itemText(index) for index in range(dialog.mode.count())] == ["AUTO", "VISIBLE"]
        assert dialog.values()["browser_mode"] == selected_mode
    finally:
        dialog.close()


def test_change_login_in_settings_reuses_secure_credential_dialog(monkeypatch):
    QApplication.instance() or QApplication([])

    class DialogStub:
        calls = []

        def __init__(self, email, parent):
            self.email = QLineEdit()
            self.email.setText("changed@example.com")
            self.calls.append((email, parent))

        def exec(self):
            return True

    monkeypatch.setattr(agent_app, "find_stored_login", lambda _settings: "old@example.com")
    monkeypatch.setattr(agent_app, "CredentialDialog", DialogStub)
    dialog = agent_app.SettingsDialog({"email": "old@example.com", "browser_mode": "AUTO"})
    try:
        dialog.change_login()
        assert DialogStub.calls[0][0] == "old@example.com"
        assert dialog.values()["email"] == "changed@example.com"
    finally:
        dialog.close()


def test_result_states_hide_raw_errors_and_clear_stale_failure_on_ready():
    window = make_window()
    window.runtime_job = runtime_job()
    window.show_ready()
    window.estimator = agent_app.ProgressEstimator(window.runtime_job.application_type)
    try:
        raw = "invalid session id: disconnected from DevTools\nselenium traceback"
        clean = "The browser connection was interrupted. No further portal actions were taken."
        window.on_completed(result("failure", message=clean, technical_details=raw))
        QApplication.processEvents()
        assert window.heading.text() == "Automation stopped"
        assert clean in window.message.text()
        assert raw not in window.message.text()
        assert raw in window.technical_log.toPlainText()
        assert not window.technical_log.isVisible()

        window.return_to_ready()
        assert window.heading.text() == "No application ready"
        assert not window.start_button.isVisible()
        assert raw not in window.technical_log.toPlainText()

        window.estimator = agent_app.ProgressEstimator(window.runtime_job.application_type)
        window.on_completed(result("success"))
        assert window.heading.text() == "Application prepared"
        assert window.result_button.isVisible()
        assert not window.stop_button.isVisible()
    finally:
        window.close()


def test_authentication_failure_offers_update_login():
    window = make_window()
    window.runtime_job = runtime_job()
    window.estimator = agent_app.ProgressEstimator(window.runtime_job.application_type)
    try:
        window.on_completed(result(
            "failure",
            message="Architect Pro could not sign in to eDevelopment. Update the saved login and try again.",
            technical_details="TimeoutException at login",
            error_code="AUTHENTICATION_FAILED",
        ))
        QApplication.processEvents()
        assert window.update_login_button.isVisible()
        assert "TimeoutException" not in window.message.text()
    finally:
        window.close()


def test_update_login_after_failure_keeps_recovery_and_does_not_reload_retired_job(monkeypatch):
    class DialogStub:
        def __init__(self, *_args):
            self.email = QLineEdit()
            self.email.setText("corrected@example.test")
        def exec(self): return True
    window = make_window()
    window.runtime_job = runtime_job()
    window.portal_job = {"id": window.runtime_job.job_id, "projectId": "project", "status": "FAILED_FINAL"}
    window._retired_job_ids.add(window.runtime_job.job_id)
    monkeypatch.setattr(agent_app, "CredentialDialog", DialogStub)
    monkeypatch.setattr(agent_app, "save_settings", lambda _settings: None)
    try:
        with patch.object(window, "refresh_job") as refresh:
            assert window.change_login()
            refresh.assert_not_called()
        assert "Login updated" in window.message.text()
        assert window.result_button.isVisible()
        assert not window.start_button.isVisible()
        assert window._result_action == "retry"
    finally:
        window.close()


def test_fee_handoff_ui_removes_eta_without_stealing_browser_focus():
    window = make_window()
    window.runtime_job = runtime_job("HOUSEHOLDER_PLANNING")
    window.show_ready()
    try:
        with patch.object(agent_app, "find_stored_login", return_value="test@example.com"), patch.object(
            agent_app.secure_credentials, "get_login_password", return_value=("secret", True, "")
        ), patch.object(agent_app, "AutomationThread", ThreadStub), patch.object(agent_app, "save_settings"):
            window.start_automation()

        with patch.object(window, "activateWindow") as activate, patch.object(window, "raise_") as raise_window:
            window.on_completed(result(
                "user_action_required",
                message="Complete the fee in the browser.",
            ))
            activate.assert_not_called()
            raise_window.assert_not_called()

        QApplication.processEvents()
        assert window.heading.text() == "Application ready for review"
        assert "application fee has been entered" in window.message.text()
        assert window.progress_bar.value() == 100
        assert not window.eta.isVisible()
        assert "Complete in browser" in window.progress_list.item(window.progress_list.count() - 1).text()
        assert not window.stop_button.isVisible()
        assert window.browser_button.isVisible()
        assert window.background_thread.engine.current_job_id == "job_test_123456" if window.background_thread else True
    finally:
        window.close()


def test_web_reveal_command_focuses_same_fee_session_and_acknowledges_identity(monkeypatch):
    window = make_window()
    acknowledgements = []
    revealed = []
    window.background_thread = SimpleNamespace(
        engine=SimpleNamespace(current_job_id="job_test_123456", agent_run_id="550e8400-e29b-41d4-a716-446655440000")
    )

    class ApiStub:
        def acknowledge_browser_reveal(self, *args):
            acknowledgements.append(args)

    monkeypatch.setattr(agent_app, "reveal_handed_off_browser", lambda job_id: revealed.append(job_id))
    monkeypatch.setattr(agent_app.background_agent, "AgentApi", ApiStub)
    try:
        command = {
            "type": "REVEAL_BROWSER",
            "jobId": "job_test_123456",
            "agentRunId": "550e8400-e29b-41d4-a716-446655440000",
            "requestedAt": "2026-08-19T16:00:00.000Z",
        }
        window.on_background_command(command)
        assert revealed == ["job_test_123456"]
        assert acknowledgements == [(command["jobId"], command["agentRunId"], command["requestedAt"])]

        window.on_background_command({**command, "agentRunId": "different-run"})
        assert revealed == ["job_test_123456"]
    finally:
        window.background_thread = None
        window.close()


def test_completed_view_command_focuses_retained_session_without_loading_or_restarting(monkeypatch):
    window = make_window()
    acknowledgements = []
    revealed = []
    window.background_thread = SimpleNamespace(
        engine=SimpleNamespace(current_job_id=None, agent_run_id=None)
    )

    class ApiStub:
        def acknowledge_browser_reveal(self, *args):
            acknowledgements.append(args)

        def get_view_job(self, _job_id):
            raise AssertionError("retained session must be used before fresh-session loading")

    monkeypatch.setattr(
        agent_app,
        "reveal_handed_off_browser",
        lambda job_id: revealed.append(job_id),
    )
    monkeypatch.setattr(agent_app.background_agent, "AgentApi", ApiStub)
    command = {
        "type": "OPEN_APPLICATION",
        "jobId": "job-complete",
        "applicationType": "HOUSEHOLDER_PLANNING",
        "agentRunId": "run-original",
        "requestedAt": "2026-08-20T09:00:00.000Z",
    }
    try:
        window.on_background_command(command)
        assert revealed == ["job-complete"]
        assert acknowledgements == [
            ("job-complete", "run-original", "2026-08-20T09:00:00.000Z")
        ]
        assert window.view_application_thread is None
    finally:
        window.background_thread = None
        window.close()


@pytest.mark.parametrize("application_type", ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT"])
def test_fresh_view_thread_opens_existing_application_in_visible_owned_browser(monkeypatch, application_type):
    class ManagedBrowser:
        def __init__(self):
            self.driver = SimpleNamespace(session_id="fresh-session")
            self.bound = []
            self.handoffs = 0
            self.closed = []

        def bind_to_job(self, job_id):
            self.bound.append(job_id)

        def start(self):
            return self.driver

        def handoff_to_user(self):
            self.handoffs += 1

        def close(self, **kwargs):
            self.closed.append(kwargs)

    managed = ManagedBrowser()
    modes = []
    opened_existing = []
    opened_sessions = []
    monkeypatch.setattr(agent_app, "create_managed_chrome", lambda mode: (modes.append(mode) or managed))
    monkeypatch.setattr(
        agent_app,
        "open_existing_application",
        lambda driver, application_type, values, password: opened_existing.append(
            (driver, application_type, values, password)
        ),
    )
    thread = agent_app.ExistingApplicationThread(
        "job-complete",
        application_type,
        {"Automation Job ID": "job-complete", "Email": "architect@example.com"},
        "secure-password",
    )
    thread.opened.connect(opened_sessions.append)

    thread.run()

    assert modes == [agent_app.BrowserMode.VISIBLE]
    assert managed.bound == ["job-complete"]
    assert managed.handoffs == 1
    assert managed.closed == []
    assert opened_sessions == ["fresh-session"]
    assert opened_existing == [(
        managed.driver,
        application_type,
        {"Automation Job ID": "job-complete", "Email": "architect@example.com"},
        "secure-password",
    )]
    assert thread.password == ""


def test_address_dialog_exposes_plain_candidates_and_returns_exact_identity():
    QApplication.instance() or QApplication([])
    request = {
        "project_address": "73 Blackhill Drive, Glasgow, G12 8AB",
        "project_postcode": "G12 8AB",
        "searched_postcode": "G12 8AB",
        "candidates": [
            {"candidate_id": "portal-address-1", "display_text": "73 Blackhill Drive, Glasgow, G12 8AA"},
            {"candidate_id": "portal-address-2", "display_text": "73A Blackhill Drive, Glasgow, G12 8AB"},
        ],
    }
    dialog = agent_app.AddressResolutionDialog(request)
    try:
        assert any("G12 8AB" in label.text() for label in dialog.findChildren(QLabel))
        assert len(dialog.candidate_group.buttons()) == 2
        assert dialog.continue_button.isEnabled() is False
        dialog.candidate_group.buttons()[1].setChecked(True)
        assert dialog.continue_button.isEnabled() is True
        dialog.use_selected_candidate()
        assert dialog.response == {
            "action": "select",
            "candidate_id": "portal-address-2",
        }
    finally:
        dialog.close()


def test_no_candidate_dialog_supports_canonical_postcode_change_and_manual_fallback():
    QApplication.instance() or QApplication([])
    request = {
        "project_address": "73 Blackhill Drive, Glasgow, G12 8AB",
        "project_postcode": "G12 8AB",
        "searched_postcode": "G12 8AB",
        "candidates": [],
    }
    dialog = agent_app.AddressResolutionDialog(request)
    try:
        dialog.alternate_postcode.setText("G12 8AA")
        dialog.use_alternate_postcode()
        assert dialog.response == {"action": "change_postcode", "postcode": "G12 8AA"}
    finally:
        dialog.close()

    manual = agent_app.AddressResolutionDialog(request)
    try:
        manual.use_manual_browser()
        assert manual.response == {"action": "manual"}
    finally:
        manual.close()


def test_genuine_failure_is_prominent_structured_and_technical_details_stay_collapsed():
    window = make_window()
    window.runtime_job = runtime_job("HOUSEHOLDER_PLANNING")
    window.show_ready()
    window.estimator = agent_app.ProgressEstimator(window.runtime_job.application_type)
    failure = AutomationResult(
        "failure",
        "job_test_123456",
        "HOUSEHOLDER_PLANNING",
        "The portal did not confirm a supporting document upload, so Architect Pro stopped before continuing.",
        "documents",
        {},
        "Authorization: Bearer secret-token\nselenium.common.ElementNotInteractableException",
        "DOCUMENT_UPLOAD_FAILED",
        "A supporting document could not be uploaded",
        "Uploading supporting documents",
        "The document set may be incomplete. Architect Pro stopped before continuing.",
        "Check the prepared documents and review the portal before retrying.",
        "close",
        False,
        "DOCUMENT_UPLOAD_FAILED",
    )
    try:
        window.on_completed(failure)
        QApplication.processEvents()
        assert window.card.property("state") == "error"
        assert window.heading.text() == "A supporting document could not be uploaded"
        assert "Stage: Uploading supporting documents" == window.application_type.text()
        assert "may be incomplete" in window.message.text()
        assert "Next:" in window.message.text()
        assert not window.progress_area.isVisible()
        assert not window.eta_timer.isActive()
        assert not window.technical_log.isVisible()
        assert window.technical_toggle.text() == "View technical details"
        assert "secret-token" not in window.technical_log.toPlainText()
        assert "[REDACTED]" in window.technical_log.toPlainText()
        assert window.result_button.text() == "Done"
    finally:
        window.close()


def test_normal_startup_restores_splash_without_legacy_gui_or_backup_bundle():
    from pathlib import Path
    import Gui

    root = Path(__file__).resolve().parents[1]
    gui_source = Path(Gui.__file__).read_text(encoding="utf-8")
    assert "StartupSplash" in gui_source
    assert "gui.app" not in gui_source
    build_script = (root / "build_exe.bat").read_text(encoding="utf-8")
    assert "--exclude-module gui.app" in build_script
    assert "Backup" not in build_script
    assert "91architects.png" not in build_script


def test_successor_claim_waits_for_previous_worker_to_finish(monkeypatch):
    window = make_window()
    pending = []
    monkeypatch.setattr(agent_app.QTimer, "singleShot", lambda delay, callback: pending.append(callback))
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    old_worker = ThreadStub()
    old_worker.running = True
    window.automation_thread = old_worker
    try:
        window.on_background_job_claimed("new-client", "new-job", "new-run")
        assert len(pending) == 1
        old_worker.running = False
        pending.pop()()
        assert window.portal_job["id"] == "new-job"
        assert window.portal_client == "new-client"
        assert window._auto_start_claimed
        assert window.load_thread.running
    finally:
        window.automation_thread = None
        window.load_thread = None
        window.close()


def test_review_command_waits_without_acknowledging_during_an_active_job(monkeypatch):
    window = make_window()
    worker = ThreadStub(); worker.running = True
    window.automation_thread = worker
    window.runtime_job = runtime_job()
    window.background_thread = SimpleNamespace(engine=SimpleNamespace(
        current_job_id='job_test_123456', agent_run_id='active-run', pending_release=None))
    opened = []; acknowledgements = []
    monkeypatch.setattr(agent_app, 'reveal_handed_off_browser', lambda job: opened.append(job))
    monkeypatch.setattr(window, '_acknowledge_view_command', lambda command: acknowledgements.append(command))
    try:
        window.on_background_command({'type':'OPEN_APPLICATION', 'jobId':'old-completed-job', 'agentRunId':'old-run', 'requestedAt':'test'})
        assert opened == []
        assert acknowledgements == [], 'the next heartbeat must retry the deferred command'
        assert window.runtime_job.job_id == 'job_test_123456'
    finally:
        window.background_thread = None; window.automation_thread = None; window.close()


def test_successor_waits_for_application_view_worker_and_ignores_its_late_signal(monkeypatch):
    window = make_window(); pending = []
    monkeypatch.setattr(agent_app.QTimer, 'singleShot', lambda delay, callback: pending.append(callback))
    monkeypatch.setattr(agent_app, 'JobLoadThread', JobThreadStub)
    viewer = ThreadStub(); viewer.running = True
    window.view_application_thread = viewer
    window._view_command = {'jobId':'old-job', 'agentRunId':'old-run'}
    try:
        window.on_background_job_claimed('new-client', 'new-job', 'new-run')
        assert len(pending) == 1
        viewer.running = False; pending.pop()()
        assert window.portal_job['id'] == 'new-job'
        heading = window.heading.text()
        window._on_view_application_opened('old-session')
        assert window.heading.text() == heading
        assert window.load_thread.running
    finally:
        window.view_application_thread = None; window.load_thread = None; window.close()


def test_successor_claim_reloads_after_old_load_and_ignores_old_failure(monkeypatch):
    window = make_window()
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    monkeypatch.setattr(agent_app.QTimer, "singleShot", lambda delay, callback: callback())
    window.portal_client = "old-client"
    try:
        window.refresh_job()
        old = window.load_thread
        window.on_background_job_claimed("new-client", "new-job", "new-run")
        assert window._refresh_pending
        old.failed.emit("Old prepared application documents are unavailable")
        assert window.heading.text() != "Could not load application"
        old.running = False
        old.finished.emit()
        assert window.load_thread is not old
        assert window.load_thread.running
        assert window.portal_job["id"] == "new-job"
        assert not window._refresh_pending
    finally:
        window.load_thread = None
        window.close()


def test_claimed_load_failure_records_retryable_result_and_stops_renewal(monkeypatch):
    from gui.services.background_agent import PollingEngine
    window = make_window()
    engine = PollingEngine()
    engine.set_run("job_test_123456", "run-1", "RUNNING")
    window.background_thread = SimpleNamespace(engine=engine, set_run=engine.set_run)
    window._auto_start_claimed = True
    callbacks = []
    monkeypatch.setattr(agent_app.callback_outbox, "queue_and_deliver", lambda client, payload: callbacks.append(payload))
    try:
        window.on_job_failed("Document download failed (404)")
        assert callbacks[0]["status"] == "FAILED_RETRYABLE"
        assert callbacks[0]["result"]["safeRetryPoint"] == "before_browser"
        assert engine.current_job_id is None
        assert engine.pending_release == ("job_test_123456", "run-1")
        assert not window._auto_start_claimed
        window.on_job_failed("Repeated error")
        assert len(callbacks) == 1
    finally:
        window.background_thread = None
        window.close()


def test_refresh_uses_polling_claim_instead_of_old_prepared_job(monkeypatch):
    window = make_window()
    engine = SimpleNamespace(current_job_id="current-claim", agent_run_id="run")
    window.background_thread = SimpleNamespace(engine=engine)
    monkeypatch.setattr(agent_app, "JobLoadThread", JobThreadStub)
    monkeypatch.setattr(agent_app.portal_handoff, "get_job_access_token", lambda job: "scoped-token" if job == "current-claim" else "")
    monkeypatch.setattr(agent_app.portal_handoff, "load_portal_url", lambda: "https://example.test")
    monkeypatch.setattr(agent_app.portal_handoff, "PortalClient", lambda url, token: (url, token))
    try:
        window._retired_job_ids.add("job_test_123456")
        window.refresh_job()
        assert window.portal_job["id"] == "current-claim"
        assert window.portal_client == ("https://example.test", "scoped-token")
        assert window._auto_start_claimed
        assert window.load_thread.running
    finally:
        window.background_thread = None
        window.load_thread = None
        window.close()


def test_refresh_does_not_reload_completed_application_documents(monkeypatch):
    window = make_window()
    monkeypatch.setattr(agent_app, "JobLoadThread", lambda *args: pytest.fail("Prepared application must not be loaded for another execution"))
    try:
        window._retired_job_ids.add("job_test_123456")
        window.refresh_job()
        assert "already prepared" in window.message.text()
    finally:
        window.close()


def test_authenticated_idle_connection_finishes_startup_loading():
    window = make_window()
    try:
        window.portal_job = None
        window.show_loading('connecting')
        window.on_background_connection_state('READY', 'Ready for applications')
        assert window.connection.text() == '● Connected'
        assert window.heading.text() == 'Ready for applications'
        assert not window.loading_area.isVisible()
        assert 'Connected and ready' in window.message.text()
    finally:
        window.close()


def test_idle_heartbeat_preserves_a_prepared_application_review_card():
    window = make_window()
    try:
        window.portal_job = None
        window._view_command = {'jobId': 'prepared-job'}
        window.heading.setText('Application ready to review')
        window.message.setText('The prepared application is open in your browser.')
        window.on_background_connection_state('READY', 'Ready for applications')
        assert window.heading.text() == 'Application ready to review'
        assert 'open in your browser' in window.message.text()
    finally:
        window.close()


@pytest.mark.parametrize('still_finishing', [False, True])
def test_failed_update_resumes_polling_and_preserves_an_inflight_claim(monkeypatch, still_finishing):
    from gui.services.background_agent import PollingEngine
    class Poller:
        def __init__(self, parent=None, engine=None):
            self.engine = engine or PollingEngine()
            self.running = False
            self.interrupted = False
            self.claimed = SignalStub()
            self.connection_state = SignalStub()
            self.command_received = SignalStub()
            self.finished = SignalStub()
            self.callbacks = []
            self.finished.connect = self.callbacks.append
        def isRunning(self): return self.running
        def isInterruptionRequested(self): return self.interrupted
        def start(self): self.running = True
        def stop(self): pass
        def requestInterruption(self): self.interrupted = True
        def wait(self, _timeout): return not self.running
    window = make_window()
    engine = PollingEngine()
    engine.set_run('claimed-during-update', 'current-run', 'RUNNING')
    old = Poller(engine=engine)
    old.running = still_finishing
    old.interrupted = True
    window.background_thread = old
    window._updating = True
    monkeypatch.setattr(agent_app, 'BackgroundPollThread', Poller)
    try:
        window.on_update_failed('The Agent is finishing a portal request.')
        if still_finishing:
            assert old.callbacks, 'restart must wait for the interrupted poller to finish'
            old.running = False
            for callback in old.callbacks:
                callback()
        assert window.background_thread is not old
        assert window.background_thread.isRunning()
        assert window.background_thread.engine is engine
        assert engine.current_job_id == 'claimed-during-update'
        assert engine.agent_run_id == 'current-run'
    finally:
        window.background_thread = None
        window.close()

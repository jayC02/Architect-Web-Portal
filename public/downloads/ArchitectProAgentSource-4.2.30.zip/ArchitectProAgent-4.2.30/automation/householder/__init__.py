"""Householder planning automation workflow."""

"""Building Warrant automation workflow."""

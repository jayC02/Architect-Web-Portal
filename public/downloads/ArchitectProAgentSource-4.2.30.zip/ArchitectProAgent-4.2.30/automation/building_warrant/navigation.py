# -*- coding: utf-8 -*-
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, yes_no_answer
from automation.common.runtime import wait_for_continue


def wait_for_form_summary_then_open_main_details(driver, timeout=600):
    """
    Reconcile Form Summary or an already-open Main Details page without a GUI.
    """
    form_summary_path = "/eBuildingStandardsClient/CustomPages/Applications/FormSummary.aspx"
    main_details_button_id = "MainContent_FormSections_btnMainDetails"
    wizard_next_button_id = "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnNext"

    print("--------------------------------------------------------------------------------")
    print("Waiting for the newly created Building Warrant Form Summary page.")
    print("The automation will continue automatically when the form is ready.")
    print("--------------------------------------------------------------------------------")
    def page_state(current):
        if current.find_elements(By.ID, wizard_next_button_id):
            return "main_details"
        if form_summary_path in (current.current_url or "") and current.find_elements(By.ID, main_details_button_id):
            return "form_summary"
        return False

    try:
        state = WebDriverWait(driver, timeout, poll_frequency=0.2, ignored_exceptions=(StaleElementReferenceException,)).until(page_state)
        if state == "main_details":
            return "resume"
        click_when_clickable(driver, By.ID, main_details_button_id, timeout=8)
        WebDriverWait(driver, 30, poll_frequency=0.2).until(
            EC.element_to_be_clickable((By.ID, wizard_next_button_id))
        )
        print("Main Details wizard loaded.")
        return "auto"
    except TimeoutException as exc:
        raise RuntimeError(
            "Timed out waiting for Building Warrant Form Summary or Main Details. "
            "Reconcile the saved proposal before retrying."
        ) from exc


def wait_for_step(driver, expected_ids, *, screen_name="next warrant", timeout=30):
    """Observe a destination screen; the shared Next button is not a page marker."""
    ids = (expected_ids,) if isinstance(expected_ids, str) else tuple(expected_ids)

    def displayed(elements):
        for element in elements:
            try:
                if element.is_displayed():
                    return True
            except StaleElementReferenceException:
                continue
        return False

    def visible_destination(current):
        for element_id in ids:
            controls = current.find_elements(By.ID, element_id)
            if displayed(controls):
                return element_id
            # The portal hides its radio inputs and draws the circle on the
            # label, so a radio whose label is showing is on screen too.
            if controls and displayed(current.find_elements(By.XPATH, f"//label[@for='{element_id}']")):
                return element_id
        return False

    try:
        return WebDriverWait(driver, timeout, poll_frequency=0.15).until(visible_destination)
    except TimeoutException as exc:
        raise RuntimeError(
            f"The portal did not confirm the {screen_name} screen. "
            "Review the current draft before continuing; Next was not repeated."
        ) from exc


def click_next(driver, timeout=30, *, expected_ids=None, screen_name="next warrant"):
    click_when_clickable(
        driver,
        By.ID,
        "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnNext",
        timeout=timeout,
    )
    if expected_ids:
        return wait_for_step(driver, expected_ids, screen_name=screen_name, timeout=timeout)


def ensure_follow_up(driver, expected_ids, *, screen_name, inline_timeout=2):
    """A Yes/No may reveal fields in place or require one Next to reach them."""
    try:
        return wait_for_step(driver, expected_ids, screen_name=screen_name, timeout=inline_timeout)
    except RuntimeError:
        return click_next(driver, expected_ids=expected_ids, screen_name=screen_name)


def pause_after_unsupported_yes(user_inputs, key, next_step_hint):
    if yes_no_answer(user_inputs, key, "No") != "Yes":
        return
    wait_for_continue(
        f"'{key}' was answered Yes and may require extra portal details not automated yet.\n"
        f"Complete any extra portal fields manually, navigate to: {next_step_hint}, "
        "then stop and resume from the reconciled proposal."
    )

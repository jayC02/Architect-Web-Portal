# -*- coding: utf-8 -*-
"""Planning Permission answers: parsing, validation and the wizard page plan.

Everything here is pure (no Selenium) so the page routing mapped live on
eplanning.scot can be tested without a browser. Each page is named by the
suffix of its step-specific Next button, e.g. "SiteArea" is the page whose
Next control is MainContent_PlanningPermissionWizard_btnNextSiteArea.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from automation.common.actions import yes_no_answer

FULL = "FULL"
PRINCIPLE = "PPP"
FURTHER = "FURTHER"
MATTERS = "AMSC"
APPLICATION_KINDS = (FULL, PRINCIPLE, FURTHER, MATTERS)

_KIND_ALIASES = {
    "full": FULL, "planning permission": FULL, "full planning permission": FULL,
    "ppp": PRINCIPLE, "principle": PRINCIPLE, "planning permission in principle": PRINCIPLE,
    "further": FURTHER, "further application": FURTHER,
    "amsc": MATTERS, "matters": MATTERS,
    "approval of matters specified in conditions": MATTERS,
}

# Floorspace use classes: friendly name -> the portal's option value.
USE_CLASS_VALUES = {
    "class 1 retail (food)": "15", "class 1 retail (non-food)": "16",
    "class 2": "2", "class 3": "3", "class 4": "4", "class 5": "5", "class 6": "6",
    "class 7": "7", "class 8": "8", "class 8a": "9", "class 10": "11", "class 11": "12",
    "not in a use class": "13", "don't know": "14", "dont know": "14",
}
_USE_CLASS_CODES = set(USE_CLASS_VALUES.values())
_NEEDS_REASON = {"13", "14"}

PRE_APP_FORMATS = ("Meeting", "Telephone", "Letter", "Email")
_DATE = re.compile(r"^\d{2}/\d{2}/\d{4}$")

KEY = "Planning "
OWNERSHIP_NOTICES_ACKNOWLEDGED_KEY = "Planning Ownership Notices Acknowledged"


class PlanningPermissionInputError(ValueError):
    """Answers needed by the Planning Permission form are missing or invalid.

    Raised before the portal is touched, so nothing is half-filled.
    """

    def __init__(self, problems):
        self.problems = tuple(problems)
        super().__init__(
            "Planning Permission answers need attention in Architect Pro before automation can run: "
            + "; ".join(self.problems)
        )


@dataclass(frozen=True)
class FloorspaceEntry:
    use_class: str
    gross: str
    net_trading: str = ""
    non_trading: str = ""
    details: str = ""


@dataclass(frozen=True)
class PlanningAnswers:
    kind: str
    earlier_reference: str
    earlier_date: str
    description: str
    temporary: bool
    temporary_details: str
    change_of_use_taken_place: bool
    works_status: str  # "No" | "Started" | "Completed"
    works_date: str
    works_reason: str
    pre_app_discussed: bool
    pre_app_format: str
    pre_app_feedback: str
    pre_app_officer_first_name: str
    pre_app_officer_last_name: str
    pre_app_reference: str
    pre_app_date: str
    site_area: str
    site_area_unit: str  # "sqm" | "ha"
    existing_use: str
    vehicle_access: bool
    public_paths: bool
    current_parking: str
    proposed_parking: str
    water_or_drainage: bool
    drainage_connection: str  # PUBLIC | PRIVATE | NOT_APPLICABLE
    private_drainage_type: str  # SEPTIC_TANK | TREATMENT | OTHER
    septic_discharge: str  # LAND | WATERCOURSE | COASTAL
    private_drainage_details: str
    suds: bool
    public_water: str  # YES | PRIVATE | NONE
    known_flood_risk: str  # YES | NO | DONT_KNOW
    increases_flood_risk: str
    flood_details: str
    trees: bool
    waste_storage: bool
    waste_details: str
    new_dwellings: bool
    dwelling_units: str
    non_residential_floorspace: bool
    floorspace: tuple = field(default_factory=tuple)
    schedule_3: str = "NO"  # YES | NO | DONT_KNOW
    staff_interest: bool = False
    staff_interest_details: str = ""


def _text(inputs, key):
    value = inputs.get(key)
    return re.sub(r"[ \t]+", " ", "" if value is None else str(value)).strip()


def _choice(inputs, key, allowed, problems, label, default=None):
    raw = _text(inputs, key).upper().replace(" ", "_").replace("'", "")
    if not raw:
        if default is not None:
            return default
        problems.append(f"{label} is required")
        return ""
    if raw not in allowed:
        problems.append(f"{label} must be one of {', '.join(allowed)}")
        return ""
    return raw


def _required_yes_no(inputs, key, problems, label):
    value = inputs.get(key)
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().lower()
    if text in {"yes", "y", "true", "1"}:
        return True
    if text in {"no", "n", "false", "0"}:
        return False
    problems.append(f"{label} (Yes or No) is required")
    return False


def _number(inputs, key, problems, label, *, decimals=False):
    value = _text(inputs, key)
    pattern = r"^\d+(\.\d+)?$" if decimals else r"^\d+$"
    if not re.fullmatch(pattern, value):
        problems.append(f"{label} must be a number")
        return ""
    return value


def _long_text(inputs, key, problems, label):
    value = _text(inputs, key)
    if not value:
        problems.append(f"{label} is required")
    elif len(value) > 500:
        problems.append(f"{label} must be 500 characters or fewer")
    return value


def _date(inputs, key, problems, label):
    value = _text(inputs, key)
    if not _DATE.fullmatch(value):
        problems.append(f"{label} must be a dd/mm/yyyy date")
    return value


def application_kind(inputs) -> str:
    raw = _text(inputs, KEY + "Application Type")
    if not raw:
        return FULL
    if raw.upper() in APPLICATION_KINDS:
        return raw.upper()
    return _KIND_ALIASES.get(raw.lower(), "")


def _use_class_value(value):
    text = str(value or "").strip()
    if text in _USE_CLASS_CODES:
        return text
    lowered = text.lower()
    if lowered in USE_CLASS_VALUES:
        return USE_CLASS_VALUES[lowered]
    match = re.match(r"^class\s+(\d+a?)\b", lowered)
    if match and f"class {match.group(1)}" in USE_CLASS_VALUES:
        return USE_CLASS_VALUES[f"class {match.group(1)}"]
    return ""


def _floorspace_entries(inputs, problems):
    raw = inputs.get(KEY + "Floorspace Entries") or []
    if not isinstance(raw, (list, tuple)) or not raw:
        problems.append("At least one non-residential floorspace entry is required")
        return ()
    entries = []
    for index, item in enumerate(raw, start=1):
        item = item if isinstance(item, dict) else {}
        code = _use_class_value(item.get("useClass"))
        gross = str(item.get("grossFloorspace") or "").strip()
        details = str(item.get("details") or "").strip()
        if not code:
            problems.append(f"Floorspace entry {index}: a valid use class is required")
        if not re.fullmatch(r"\d+(\.\d+)?", gross):
            problems.append(f"Floorspace entry {index}: gross floorspace must be a number")
        if code in _NEEDS_REASON and not details:
            problems.append(f"Floorspace entry {index}: details are required for this use class")
        if len(details) > 500:
            problems.append(f"Floorspace entry {index}: details must be 500 characters or fewer")
        entries.append(FloorspaceEntry(
            use_class=code,
            gross=gross,
            net_trading=_text(item, "netTradingSpace") if code in {"15", "16"} else "",
            non_trading=_text(item, "nonTradingSpace") if code in {"15", "16"} else "",
            details=details,
        ))
    return tuple(entries)


def parse_planning_answers(inputs) -> PlanningAnswers:
    """Read and validate every answer the chosen route through the form needs."""
    problems = []
    kind = application_kind(inputs)
    if not kind:
        problems.append("Planning application type must be FULL, PPP, FURTHER or AMSC")
        kind = FULL

    earlier_reference = earlier_date = ""
    if kind in (FURTHER, MATTERS):
        earlier_reference = _text(inputs, KEY + "Earlier Application Reference")
        if not earlier_reference:
            problems.append("The earlier application reference is required")
        earlier_date = _date(inputs, KEY + "Earlier Application Date", problems, "The earlier application date")

    description = _text(inputs, "Description of Work")
    if not description:
        problems.append("Description of Work is required")
    if not _text(inputs, "Applicant Email"):
        # The portal enforces it even though the page shows no asterisk.
        problems.append("The applicant email address is required")

    temporary = yes_no_answer(inputs, KEY + "Temporary Permission", "No") == "Yes"
    temporary_details = (
        _long_text(inputs, KEY + "Temporary Permission Details", problems, "How long temporary permission is needed, and why")
        if temporary else ""
    )
    change_of_use = yes_no_answer(inputs, KEY + "Change Of Use Taken Place", "No") == "Yes"
    works = _text(inputs, KEY + "Works Started").title() or "No"
    if works not in ("No", "Started", "Completed"):
        problems.append("Works started must be No, Started or Completed")
        works = "No"
    works_date = works_reason = ""
    if works != "No":
        works_date = _date(inputs, KEY + "Works Date", problems, "The works start/completion date")
        works_reason = _long_text(inputs, KEY + "Works Reason", problems, "Why work started before applying")

    discussed = yes_no_answer(inputs, "Householder Discussed With Planning Authority", "No") == "Yes"
    pre_format = pre_feedback = ""
    pre_first = pre_last = pre_ref = pre_date = ""
    if discussed:
        pre_format = _text(inputs, KEY + "Pre-Application Format").title()
        if pre_format not in PRE_APP_FORMATS:
            problems.append("Pre-application feedback format must be Meeting, Telephone, Letter or Email")
        pre_feedback = _long_text(inputs, KEY + "Pre-Application Feedback", problems, "Pre-application feedback")
        pre_first = _text(inputs, KEY + "Pre-Application Officer First Name")
        pre_last = _text(inputs, KEY + "Pre-Application Officer Last Name")
        pre_ref = _text(inputs, KEY + "Pre-Application Reference")
        pre_date = _text(inputs, KEY + "Pre-Application Date")
        if pre_date and not _DATE.fullmatch(pre_date):
            problems.append("The pre-application date must be a dd/mm/yyyy date")

    site_area = _number(inputs, KEY + "Site Area", problems, "Site area", decimals=True)
    unit = _text(inputs, KEY + "Site Area Unit").lower() or "sqm"
    unit = {"sq m": "sqm", "sqm": "sqm", "square metres": "sqm", "m2": "sqm", "ha": "ha", "hectares": "ha"}.get(unit, "")
    if not unit:
        problems.append("Site area unit must be square metres or hectares")
    existing_use = _long_text(inputs, KEY + "Existing Use", problems, "Existing use")

    vehicle_access = yes_no_answer(inputs, "Householder New Or Altered Vehicle Access", "No") == "Yes"
    public_paths = yes_no_answer(inputs, KEY + "Public Paths Changes", "No") == "Yes"
    current_parking = proposed_parking = ""
    if kind != PRINCIPLE:
        current_parking = _number(inputs, "Householder Current Parking Spaces", problems, "Current parking spaces")
        proposed_parking = _number(inputs, "Householder Proposed Parking Spaces", problems, "Proposed parking spaces")

    water = _required_yes_no(inputs, KEY + "New Or Altered Water Supply Or Drainage", problems,
                             "New or altered water supply or drainage")
    connection = private_type = discharge = private_details = ""
    if water:
        connection = _choice(inputs, KEY + "Drainage Connection", ("PUBLIC", "PRIVATE", "NOT_APPLICABLE"),
                             problems, "Drainage connection")
        if connection == "PRIVATE":
            private_type = _choice(inputs, KEY + "Private Drainage Type", ("SEPTIC_TANK", "TREATMENT", "OTHER"),
                                   problems, "Private drainage type")
            if private_type == "SEPTIC_TANK":
                discharge = _choice(inputs, KEY + "Septic Tank Discharge", ("LAND", "WATERCOURSE", "COASTAL"),
                                    problems, "Septic tank discharge")
            private_details = _long_text(inputs, KEY + "Private Drainage Details", problems,
                                         "Private drainage details")
    suds = _required_yes_no(inputs, KEY + "Sustainable Drainage", problems, "Sustainable drainage (SUDS)")
    public_water = _choice(inputs, KEY + "Public Water Supply", ("YES", "PRIVATE", "NONE"), problems,
                           "Public water supply connection")

    known_flood = _choice(inputs, KEY + "Known Flood Risk", ("YES", "NO", "DONT_KNOW"), problems, "Known flood risk")
    increases_flood = _choice(inputs, KEY + "Increases Flood Risk", ("YES", "NO", "DONT_KNOW"), problems,
                              "Increased flood risk elsewhere")
    flood_details = (
        _long_text(inputs, KEY + "Flood Risk Details", problems, "How flood risk might increase")
        if increases_flood == "YES" else ""
    )
    trees = yes_no_answer(inputs, "Householder Trees On Site", "No") == "Yes"

    waste = waste_details = ""
    dwellings = False
    units = ""
    if kind in (FULL, MATTERS):
        waste = _required_yes_no(inputs, KEY + "Waste Storage", problems, "Waste storage and collection")
        waste_details = _long_text(inputs, KEY + "Waste Details", problems, "Waste storage details")
        dwellings = _required_yes_no(inputs, KEY + "New Dwellings", problems, "New houses or flats")
        if dwellings:
            units = _number(inputs, KEY + "Dwelling Units", problems, "Number of units")

    floorspace = False
    entries = ()
    if kind != MATTERS:
        floorspace = _required_yes_no(inputs, KEY + "Non Residential Floorspace", problems,
                                      "Non-residential floorspace")
        if floorspace:
            entries = _floorspace_entries(inputs, problems)

    schedule_3 = _choice(inputs, KEY + "Schedule 3", ("YES", "NO", "DONT_KNOW"), problems, "Schedule 3 development")
    staff = yes_no_answer(inputs, KEY + "Staff Or Member Interest", "No") == "Yes"
    staff_details = (
        _long_text(inputs, KEY + "Staff Or Member Interest Details", problems, "Planning staff or member interest details")
        if staff else ""
    )

    if problems:
        raise PlanningPermissionInputError(problems)
    return PlanningAnswers(
        kind=kind, earlier_reference=earlier_reference, earlier_date=earlier_date,
        description=description[:500], temporary=temporary, temporary_details=temporary_details,
        change_of_use_taken_place=change_of_use, works_status=works, works_date=works_date,
        works_reason=works_reason, pre_app_discussed=discussed, pre_app_format=pre_format,
        pre_app_feedback=pre_feedback, pre_app_officer_first_name=pre_first,
        pre_app_officer_last_name=pre_last, pre_app_reference=pre_ref, pre_app_date=pre_date,
        site_area=site_area, site_area_unit=unit, existing_use=existing_use,
        vehicle_access=vehicle_access, public_paths=public_paths,
        current_parking=current_parking, proposed_parking=proposed_parking,
        water_or_drainage=water, drainage_connection=connection, private_drainage_type=private_type,
        septic_discharge=discharge, private_drainage_details=private_details, suds=suds,
        public_water=public_water, known_flood_risk=known_flood, increases_flood_risk=increases_flood,
        flood_details=flood_details, trees=trees, waste_storage=bool(waste), waste_details=waste_details,
        new_dwellings=dwellings, dwelling_units=units, non_residential_floorspace=floorspace,
        floorspace=entries, schedule_3=schedule_3, staff_interest=staff, staff_interest_details=staff_details,
    )


def planned_steps(answers: PlanningAnswers, *, agent=True) -> list[str]:
    """The Main Details pages, in order, for these answers (live-verified routing)."""
    kind = answers.kind
    steps = ["Welcome", "TypeOfApplication"]
    if kind in (FURTHER, MATTERS):
        steps.append("TypeOfApplicationCont1")
    steps.append("DescriptionOfProposal")
    if answers.temporary:
        steps.append("DescriptionOfProposalCont1")
    steps.append("DescriptionOfProposalCont2")
    if answers.works_status != "No":
        steps.append("DescriptionOfProposalCont3")
    steps.append("TypeOfUserStep")
    if agent:
        steps.append("AgentDetails")
    steps += ["AppellantDetails", "PreApplicationDiscussion"]
    if answers.pre_app_discussed:
        steps.append("PreApplicationDiscussionCont")
    steps += ["SiteArea", "ExistingUse", "AccessAndParking", "AccessAndParkingCont1"]
    if kind != PRINCIPLE:
        steps.append("AccessAndParkingCont2")
    steps.append("WaterSupply")
    if answers.water_or_drainage:
        steps.append("WaterSupplyCont1")
        if answers.drainage_connection == "PRIVATE":
            steps.append("WaterSupplyCont2")
            if answers.private_drainage_type == "SEPTIC_TANK":
                steps.append("WaterSupplyCont3")
            steps.append("WaterSupplyCont4")
    steps += ["WaterSupplyCont5", "WaterSupplyCont6", "AssessmentOfFloodRisk"]
    if answers.increases_flood_risk == "YES":
        steps.append("AssessmentOfFloodRiskCont")
    steps.append("Trees")
    if kind in (FULL, MATTERS):
        steps += ["WasteStorage", "WasteStorageCont", "ResidentialUnits"]
        if answers.new_dwellings:
            steps.append("ResidentialUnitsCont")
    if kind != MATTERS:
        steps.append("AllTypes")
        if answers.non_residential_floorspace:
            steps.append("AllTypeCont")
    steps += ["Schedule3Development", "PlanningServiceInterest"]
    if answers.staff_interest:
        steps.append("PlanningServiceInterestCont")
    steps.append("Review")
    return steps


def validate_supported_ownership(inputs):
    """The shared ownership code covers Certificate A, and C when nobody can be notified.

    Every other route needs owner or tenant lists (names, addresses, notice
    dates) the prepared job does not carry yet, so stop before the portal is
    touched rather than fail half-way through the certificate.
    """
    problems = []
    if yes_no_answer(inputs, "Householder Agricultural Holding", "No") == "Yes":
        problems.append("agricultural holdings (Certificates C/E with tenants) are not supported by the Agent yet")
    elif yes_no_answer(inputs, "Householder Sole Owner", "Yes") == "No":
        if yes_no_answer(inputs, "Householder Identify All Other Owners", "No") == "Yes":
            problems.append("notifying every other owner (Certificate B) is not supported by the Agent yet")
        elif yes_no_answer(inputs, "Householder Notice To One Owner", "No") == "Yes":
            problems.append("notifying some of the other owners (Certificate C owner list) is not supported by the Agent yet")
        elif yes_no_answer(inputs, OWNERSHIP_NOTICES_ACKNOWLEDGED_KEY, "No") != "Yes":
            problems.append("confirm the ownership notice obligations in Architect Pro before continuing with Certificate C")
    if problems:
        raise PlanningPermissionInputError(problems)

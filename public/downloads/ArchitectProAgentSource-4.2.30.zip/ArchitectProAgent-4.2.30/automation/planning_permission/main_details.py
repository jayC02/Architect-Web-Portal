# -*- coding: utf-8 -*-
"""Planning Permission Main Details wizard (PlanningPermissionMainDetails.aspx).

Every page posts back to the same URL, so a page is identified by its
step-specific Next button. The route is fixed by the answers up front
(inputs.planned_steps); after each Next the expected next page must appear,
otherwise the portal's validation message is reported and Next is not repeated.
"""
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_when_clickable, is_detached_node_error, select_option_by_id
from automation.common.forms import select_applicant_title
from automation.common.uploads import get_visible_portal_error
from automation.householder.fields import force_text_by_id
from automation.householder.navigation import click_first_available
from automation.planning_permission.inputs import FULL, FURTHER, MATTERS, PRINCIPLE, planned_steps

P = "MainContent_PlanningPermissionWizard_"
AGENT = P + "AgentDetails_"
APPLICANT = P + "AppelantDetails_"  # sic: the portal spells it "Appelant"
PRE_APP = P + "PreApplicationDiscussion1_"
FORM_SUMMARY_MAIN_DETAILS_ID = "MainContent_FormSections_btnMainDetails"

KIND_RADIOS = {
    FULL: "rbAppForPlanningPermission",
    PRINCIPLE: "rbAppForPlanningPermissionPrinciple",
    FURTHER: "rbFurtherApplication",
    MATTERS: "rbAppForApprovalOfMatters",
}


class PlanningMainDetailsError(RuntimeError):
    pass


def next_id(step):
    return f"{P}btnNext{step}"


def _visible(driver, element_id):
    try:
        return any(element.is_displayed() for element in driver.find_elements(By.ID, element_id))
    except StaleElementReferenceException:
        return False
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return False
        raise


def advance(driver, step, expected_step, timeout=30):
    """Click this page's Next once and wait for the expected next page."""
    click_when_clickable(driver, By.ID, next_id(step), timeout=timeout)
    print(f"Clicked: Planning Permission {step} next")
    target = next_id(expected_step) if expected_step else FORM_SUMMARY_MAIN_DETAILS_ID
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda d: _visible(d, target))
    except TimeoutException as exc:
        still_here = _visible(driver, next_id(step))
        message = get_visible_portal_error(driver) if still_here else ""
        if message:
            raise PlanningMainDetailsError(
                f"The portal rejected the Planning Permission '{step}' page: {message}"
            ) from exc
        raise PlanningMainDetailsError(
            f"Planning Permission Main Details did not reach '{expected_step or 'Form Summary'}' "
            f"after '{step}'. Next was not repeated; review the draft in the portal."
        ) from exc


def _radio(driver, suffix, label):
    select_option_by_id(driver, P + suffix, label)


def _text(driver, element_id, value, label):
    force_text_by_id(driver, element_id, value, label, timeout=20)


def _yes_no(driver, stem, value, label):
    _radio(driver, f"{stem}{'Yes' if value else 'No'}", f"{label}: {'Yes' if value else 'No'}")


def _set_checkbox(driver, element_id, desired, label):
    element = driver.find_element(By.ID, element_id)
    if bool(element.is_selected()) == bool(desired):
        return
    if desired:
        select_option_by_id(driver, element_id, label)
    else:
        click_first_available(driver, [(By.XPATH, f"//label[@for='{element_id}']"), (By.ID, element_id)], timeout=10)


def _fill_agent(driver, user_inputs):
    fields = {
        "Agent First Name": "txtAgentFirstName",
        "Agent Last Name": "txtAgentSurname",
        "Agent Telephone Number": "txtAgentTelNo",
        "Agent Email Address": "txtAgentEmailAddress",
        "Agent Address 1": "txtAgentAddress1",
        "Agent Building Number": "txtAgentBuildingNo",
        "Agent Town/City": "txtAgentTown",
        "Agent Country": "txtAgentCountry",
        "Agent Postcode": "txtAgentPostcode",
    }
    for key, suffix in fields.items():
        value = str(user_inputs.get(key, "United Kingdom" if key == "Agent Country" else "") or "").strip()
        if value:
            _text(driver, AGENT + suffix, value, key)
    # Never filled from the registered account: always set it.
    select_option_by_id(driver, AGENT + "rblIndividualOrOrganisation_0", "Agent individual")


def _fill_applicant(driver, user_inputs, resolver):
    try:
        click_first_available(driver, [(By.ID, P + "btnClearAppellantDetails")], timeout=5)
        WebDriverWait(driver, 20).until(lambda d: _visible(d, APPLICANT + "txtApplicantFirstName"))
    except Exception:
        print("Applicant Details clear was not available; continuing.")
    select_applicant_title(
        driver,
        APPLICANT + "ddlApplicantTitle",
        user_inputs.get("Applicant Title", ""),
        APPLICANT + "txtApplicantFirstName",
        timeout=15,
        other_title=user_inputs.get("Applicant Other Title", ""),
        # Must stay empty unless the title is Other; select_applicant_title only fills it then.
        other_title_element_ids=(APPLICANT + "txtApplicantOtherTitle",),
        resolver=resolver,
        applicant_name=f"{user_inputs.get('Applicant First Name', '')} {user_inputs.get('Applicant Last Name', '')}".strip(),
    )
    fields = {
        "Applicant First Name": "txtApplicantFirstName",
        "Applicant Last Name": "txtApplicantLastName",
        "Applicant Company": "txtApplicantCompany",
        "Applicant Email": "txtApplicantEmailAddr",
        "Applicant Mobile Number": "txtApplicantMobileNumber",
        "Applicant Building Name": "txtApplicantBuildingName",
        "Applicant Building Number": "txtApplicantBuildingNo",
        "Applicant Address 1": "txtApplicantAddress1",
        "Applicant Town/City": "txtApplicantTown",
        "Applicant Country": "txtApplicantCountry",
        "Applicant Postcode": "txtApplicantPostcode",
    }
    for key, suffix in fields.items():
        value = str(user_inputs.get(key, "United Kingdom" if key == "Applicant Country" else "") or "").strip()
        if value:
            _text(driver, APPLICANT + suffix, value, key)


def _fill_floorspace(driver, entries):
    for index, entry in enumerate(entries):
        if index:
            click_when_clickable(driver, By.ID, P + "btnAddFloorspace", timeout=30)
            WebDriverWait(driver, 30).until(lambda d: _visible(d, P + "txtGrossFloorspace"))
        Select(driver.find_element(By.ID, P + "ddlUseTypeOfFloorSpace")).select_by_value(entry.use_class)
        _text(driver, P + "txtGrossFloorspace", entry.gross, f"Floorspace {index + 1} gross")
        if entry.net_trading:
            _text(driver, P + "txtNetTradingSpace", entry.net_trading, f"Floorspace {index + 1} net trading")
        if entry.non_trading:
            _text(driver, P + "txtNonTradingSpace", entry.non_trading, f"Floorspace {index + 1} non-trading")
        if entry.details:
            _text(driver, P + "txtFloorspaceReasons", entry.details, f"Floorspace {index + 1} details")


def fill_page(driver, step, answers, user_inputs, applicant_title_resolution_callback=None):
    a = answers
    if step == "TypeOfApplication":
        _radio(driver, KIND_RADIOS[a.kind], f"Application type: {a.kind}")
    elif step == "TypeOfApplicationCont1":
        _text(driver, P + "txtAppRef", a.earlier_reference, "Earlier application reference")
        _text(driver, "txtAppDate", a.earlier_date, "Earlier application date")  # no MainContent_ prefix
    elif step == "DescriptionOfProposal":
        _text(driver, P + "txtProposalDescription", a.description, "Description of proposal")
        _yes_no(driver, "rbTemporary", a.temporary, "Temporary permission")
    elif step == "DescriptionOfProposalCont1":
        _text(driver, P + "txtPermissionReason", a.temporary_details, "Temporary permission details")
    elif step == "DescriptionOfProposalCont2":
        _yes_no(driver, "rbChangeOfUse", a.change_of_use_taken_place, "Change of use taken place")
        works = {"No": "rbWorkStartedNo", "Started": "rbWorkStartedYesStarted", "Completed": "rbWorkStartedYesCompleted"}
        _radio(driver, works[a.works_status], f"Works started: {a.works_status}")
    elif step == "DescriptionOfProposalCont3":
        _text(driver, "txtCompletionDate", a.works_date, "Works date")  # no MainContent_ prefix
        _text(driver, P + "txtReasonsWorkInAdvance", a.works_reason, "Reason for early works")
    elif step == "TypeOfUserStep":
        _radio(driver, "rbAgent", "Agent")
        _radio(driver, "rbAccountDetailsYes", "Use registered account details")
    elif step == "AgentDetails":
        _fill_agent(driver, user_inputs)
    elif step == "AppellantDetails":
        _fill_applicant(driver, user_inputs, applicant_title_resolution_callback)
    elif step == "PreApplicationDiscussion":
        _radio(driver, f"rbDisccussed{'Yes' if a.pre_app_discussed else 'No'}",  # sic: "Disccussed"
               f"Discussed with planning authority: {'Yes' if a.pre_app_discussed else 'No'}")
    elif step == "PreApplicationDiscussionCont":
        for fmt in ("Meeting", "Telephone", "Letter", "Email"):
            _set_checkbox(driver, PRE_APP + f"cb{fmt}", fmt == a.pre_app_format, f"Feedback format {fmt}")
        _text(driver, PRE_APP + "tbDescription", a.pre_app_feedback, "Pre-application feedback")
        if a.pre_app_officer_first_name:
            _text(driver, PRE_APP + "edtFirstName", a.pre_app_officer_first_name, "Officer first name")
        if a.pre_app_officer_last_name:
            _text(driver, PRE_APP + "edtLastName", a.pre_app_officer_last_name, "Officer last name")
        if a.pre_app_reference:
            _text(driver, PRE_APP + "edtReference", a.pre_app_reference, "Correspondence reference")
        if a.pre_app_date:
            _text(driver, "edtDatePreApp", a.pre_app_date, "Pre-application date")  # no prefix
    elif step == "SiteArea":
        _text(driver, P + "txtSiteArea", a.site_area, "Site area")
        _radio(driver, "rbMeasurementTypeSqM" if a.site_area_unit == "sqm" else "rbMeasurementTypeHa",
               f"Site area unit: {a.site_area_unit}")
    elif step == "ExistingUse":
        _text(driver, P + "txtCurrentUse", a.existing_use, "Existing use")
    elif step == "AccessAndParking":
        _yes_no(driver, "rbVehicleAccess", a.vehicle_access, "New or altered vehicle access")
    elif step == "AccessAndParkingCont1":
        _yes_no(driver, "rbChangesToPublicPaths", a.public_paths, "Changes to public paths")
    elif step == "AccessAndParkingCont2":
        _text(driver, P + "txtVehicleParkingSpacesCurrently", a.current_parking, "Current parking spaces")
        _text(driver, P + "txtVehicleParkingSpacesProposed", a.proposed_parking, "Proposed parking spaces")
    elif step == "WaterSupply":
        _yes_no(driver, "rbNewOrAlteredWaterSupply", a.water_or_drainage, "New or altered water/drainage")
    elif step == "WaterSupplyCont1":
        radio = {"PUBLIC": "rbConnectToPublicDrainageYes", "PRIVATE": "rbConnectToPublicDrainageNo",
                 "NOT_APPLICABLE": "rbConnectToPublicDrainageNA"}[a.drainage_connection]
        _radio(driver, radio, f"Drainage connection: {a.drainage_connection}")
    elif step == "WaterSupplyCont2":
        radio = {"SEPTIC_TANK": "rbNewAltered", "TREATMENT": "rbTreatement",  # sic: "Treatement"
                 "OTHER": "rbOtherPrivateDrainage"}[a.private_drainage_type]
        _radio(driver, radio, f"Private drainage: {a.private_drainage_type}")
    elif step == "WaterSupplyCont3":
        radio = {"LAND": "rbDischargeToLand", "WATERCOURSE": "rbDischargeToWatercourse",
                 "COASTAL": "rbDischargeToCoastal"}[a.septic_discharge]
        _radio(driver, radio, f"Septic tank discharge: {a.septic_discharge}")
    elif step == "WaterSupplyCont4":
        _text(driver, P + "txtPrivateDrainageArrangements", a.private_drainage_details, "Private drainage details")
    elif step == "WaterSupplyCont5":
        _yes_no(driver, "rbSustainableDrainage", a.suds, "Sustainable drainage")
    elif step == "WaterSupplyCont6":
        radio = {"YES": "rbConnectToWaterSupplyYes",
                 "PRIVATE": "rbConnectToWaterSuppplyNo",  # sic: triple p
                 "NONE": "rbConnectToWaterSuppplyNA"}[a.public_water]
        _radio(driver, radio, f"Public water supply: {a.public_water}")
    elif step == "AssessmentOfFloodRisk":
        names = {"YES": "Yes", "NO": "No", "DONT_KNOW": "DontKnow"}
        _radio(driver, f"rbKnownFloodRisk{names[a.known_flood_risk]}", f"Known flood risk: {a.known_flood_risk}")
        _radio(driver, f"rbIncreaseFloodRisk{names[a.increases_flood_risk]}",
               f"Increases flood risk: {a.increases_flood_risk}")
    elif step == "AssessmentOfFloodRiskCont":
        _text(driver, P + "txtFloodingIncreaseDescription", a.flood_details, "Flood risk details")
    elif step == "Trees":
        _yes_no(driver, "rbTrees", a.trees, "Trees on or next to the site")
    elif step == "WasteStorage":
        _yes_no(driver, "rbStoreWaste", a.waste_storage, "Waste storage")
    elif step == "WasteStorageCont":
        _text(driver, P + "txtWasteCollectionDetials", a.waste_details, "Waste details")  # sic: "Detials"
    elif step == "ResidentialUnits":
        _yes_no(driver, "rbAdditionalHouses", a.new_dwellings, "New houses or flats")
    elif step == "ResidentialUnitsCont":
        _text(driver, P + "txtUnitsProposed", a.dwelling_units, "Units proposed")
    elif step == "AllTypes":
        _yes_no(driver, "rbAlterFloorspace", a.non_residential_floorspace, "Non-residential floorspace")
    elif step == "AllTypeCont":
        _fill_floorspace(driver, a.floorspace)
    elif step == "Schedule3Development":
        names = {"YES": "Yes", "NO": "No", "DONT_KNOW": "DontKnow"}
        _radio(driver, f"rbSchedule3{names[a.schedule_3]}", f"Schedule 3: {a.schedule_3}")
    elif step == "PlanningServiceInterest":
        _yes_no(driver, "rbPlanningServiceInterest", a.staff_interest, "Planning staff or member interest")
    elif step == "PlanningServiceInterestCont":
        _text(driver, P + "txtFurtherDetailsPlanningServiceInterestCont", a.staff_interest_details,
              "Interest details")
    # Welcome and Review have nothing to fill.


def complete_planning_main_details(driver, answers, user_inputs, applicant_title_resolution_callback=None):
    """Walk the whole Main Details wizard from Welcome to the Form Summary."""
    steps = planned_steps(answers)
    print("Planning Permission Main Details route: " + " -> ".join(steps))
    WebDriverWait(driver, 30, poll_frequency=0.15).until(lambda d: _visible(d, next_id(steps[0])))
    for index, step in enumerate(steps):
        fill_page(driver, step, answers, user_inputs, applicant_title_resolution_callback)
        expected = steps[index + 1] if index + 1 < len(steps) else None
        # A rejected page (Agent Details included) is reported with the portal's own message.
        advance(driver, step, expected)
    print("Planning Permission Main Details complete.")

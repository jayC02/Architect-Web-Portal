# -*- coding: utf-8 -*-
"""Planning Permission workflow: prepares the whole form up to the fee.

The Agent completes every section, including the certificate and declaration
ticks made on the architect's behalf, enters the calculated fee and stops.
Paying and submitting stay with the user in the portal.
"""
import os

from selenium import webdriver
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.building_warrant.fee import enter_calculated_fee, require_calculated_fee_minor_units
from automation.building_warrant.login import submit_login_and_wait_for_home
from automation.common.actions import click_when_clickable, type_into, yes_no_answer
from automation.common.declaration import complete_declaration, open_fee_and_handoff
from automation.common.driver import create_chrome_driver
from automation.common.proposal_creation import PLANNING_PERMISSION, create_proposal_and_resume
from automation.common.runtime import USER_INPUTS_JSON, clear_checkpoint, load_required_json, record_checkpoint
from automation.common.uploads import dismiss_gdpr_modal_if_present
from automation.householder.documents import load_prepared_householder_documents
from automation.householder.navigation import click_first_available
from automation.householder.ownership import (
    complete_certificate_of_ownership,
    validate_certificate_of_ownership_inputs,
)
from automation.planning_permission.checklist import complete_later_planning_sections
from automation.planning_permission.inputs import (
    OWNERSHIP_NOTICES_ACKNOWLEDGED_KEY, parse_planning_answers, validate_supported_ownership,
)
from automation.planning_permission.main_details import complete_planning_main_details, next_id

# Declaration selectors are shared with Householder (verified live for this form).
DECLARATION_TYPE = "PLANNING_APPLICATION"
FORM_SUMMARY_PATH = "/ePlanningClient/CustomPages/Applications/FormSummary.aspx"
MAIN_DETAILS_BUTTON_ID = "MainContent_FormSections_btnMainDetails"


def wait_for_form_summary_then_open_main_details(driver, timeout=600):
    """Open Main Details from the new form's summary; the wizard starts at Welcome."""
    welcome_next = next_id("Welcome")

    def state(current):
        if current.find_elements(By.ID, welcome_next):
            return "main_details"
        if FORM_SUMMARY_PATH.lower() in (current.current_url or "").lower() and current.find_elements(
            By.ID, MAIN_DETAILS_BUTTON_ID
        ):
            return "form_summary"
        return False

    try:
        found = WebDriverWait(driver, timeout, poll_frequency=0.2,
                              ignored_exceptions=(StaleElementReferenceException,)).until(state)
        if found == "main_details":
            return "resume"
        click_when_clickable(driver, By.ID, MAIN_DETAILS_BUTTON_ID, timeout=8)
        WebDriverWait(driver, 30, poll_frequency=0.2).until(lambda d: d.find_elements(By.ID, welcome_next))
        print("Planning Permission Main Details wizard loaded.")
        return "auto"
    except TimeoutException as exc:
        raise RuntimeError("Timed out waiting for the Planning Permission Form Summary or Main Details page.") from exc


def preflight(user_inputs):
    """Every check that can fail without the portal runs before login."""
    calculated_fee = require_calculated_fee_minor_units(user_inputs)
    # The agent phone is validated by Architect Pro's preflight before a job is released.
    answers = parse_planning_answers(user_inputs)
    validate_supported_ownership(user_inputs)
    validate_certificate_of_ownership_inputs(user_inputs)
    return answers, calculated_fee


def main(
    *,
    user_inputs=None,
    password=None,
    driver=None,
    document_mapping=None,
    progress=None,
    cancellation_token=None,
    address_resolution_callback=None,
    applicant_title_resolution_callback=None,
):
    def stage(name, status, message):
        if progress:
            progress(name, status, message)
        if cancellation_token:
            cancellation_token.raise_if_cancelled()

    clear_checkpoint()
    if user_inputs is None:
        user_inputs = load_required_json(USER_INPUTS_JSON, required_keys=["Email", "PDF Folder Path"])
    answers, calculated_fee_minor_units = preflight(user_inputs)
    username = user_inputs.get("Email", "")
    password = password if password is not None else os.environ.get("BUILDING_PORTAL_RUNTIME_PASSWORD", "")
    pdf_folder_path = user_inputs.get("PDF Folder Path", "")
    if not username or not password:
        raise RuntimeError("Email or runtime password is missing.")
    if not pdf_folder_path or not os.path.isdir(pdf_folder_path):
        raise RuntimeError(f"Invalid PDF folder path in user_inputs.json: '{pdf_folder_path}'")
    prepared_documents = load_prepared_householder_documents(pdf_folder_path, mapping_data=document_mapping)

    if driver is None:
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option("detach", True)
        for argument in ("--disable-extensions", "--disable-default-apps", "--no-first-run", "--disable-notifications"):
            chrome_options.add_argument(argument)
        driver = create_chrome_driver(chrome_options)
        driver.maximize_window()

    try:
        stage("login", "running", "Logging in")
        driver.get("https://www.edevelopment.scot/eDevelopmentClient/default.aspx")
        click_first_available(driver, [(By.ID, "Banner_btnLogin")])
        type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxEmail", username, clear_first=False)
        type_into(driver, By.ID, "MainContent_UclLogin_LoginWizard_TbxPassword", password, clear_first=False)
        submit_login_and_wait_for_home(driver, authenticated_control_name="ctl00$sideBar$ctl13")
        record_checkpoint("login_complete", "login", "Signed in to eDevelopment.")
        stage("login", "completed", "Logged in")

        dismiss_gdpr_modal_if_present(driver)
        click_when_clickable(driver, By.NAME, "ctl00$sideBar$ctl13")
        print("Clicked ePlanning.")

        stage("proposal", "running", "Opening proposal")
        create_proposal_and_resume(
            driver,
            user_inputs,
            lambda: wait_for_form_summary_then_open_main_details(driver, timeout=120),
            application_type=PLANNING_PERMISSION,
            address_resolver=address_resolution_callback,
        )
        record_checkpoint("application_selected", "main_details", "Planning Permission application selected.")
        stage("proposal", "completed", "Proposal opened")

        stage("main_details", "running", "Completing main details")
        complete_planning_main_details(
            driver, answers, user_inputs,
            applicant_title_resolution_callback=applicant_title_resolution_callback,
        )
        record_checkpoint("main_details_complete", "main_details")
        stage("main_details", "completed", "Main details complete")

        stage("ownership", "running", "Completing ownership certificate")
        complete_certificate_of_ownership(
            driver, user_inputs,
            acknowledge_notices=yes_no_answer(user_inputs, OWNERSHIP_NOTICES_ACKNOWLEDGED_KEY, "No") == "Yes",
        )
        record_checkpoint("ownership_complete", "certificate_of_ownership")
        stage("ownership", "completed", "Ownership certificate complete")

        stage("documents", "running", "Uploading documents")
        complete_later_planning_sections(driver, pdf_folder_path, user_inputs, prepared_documents=prepared_documents)
        record_checkpoint("documents_complete", "documents")
        stage("documents", "completed", "Documents complete")

        stage("declaration", "running", "Completing declaration")
        complete_declaration(driver, DECLARATION_TYPE, progress=progress)
        record_checkpoint("declaration_complete", "declaration")
        stage("declaration", "completed", "Declaration completed")

        stage("final_review", "running", "Finalising application")
        fee_handoff = open_fee_and_handoff(driver, DECLARATION_TYPE, declaration_complete=True, progress=progress)
        enter_calculated_fee(driver, calculated_fee_minor_units)
        stage("final_review", "completed", "Planning application fee confirmed")
        record_checkpoint("application_prepared", "final_review")
        print("Planning Permission prepared with the fee entered; payment and submission are left to the user.")
        return fee_handoff
    except Exception as exc:
        print("ERROR encountered:", repr(exc), flush=True)
        raise


if __name__ == "__main__":
    main()

"""Read an existing PDF through the current authenticated portal form."""
import re

from selenium.common.exceptions import WebDriverException


# The View button submits the current ASP.NET form and returns the original PDF.
# Fetch that read-only response in the authenticated browser, without opening a
# download window or exporting session cookies. Return only its content hash.
ATTACHED_PDF_HASH_SCRIPT = r"""
// ARCHPRO_ATTACHED_LOCATION_PLAN_HASH
const viewId = arguments[0], done = arguments[arguments.length - 1];
const objectId = arguments.length > 2 ? arguments[1] : null;
const button = document.getElementById(viewId);
const form = button && button.form;
if (!form || !button.name || button.type !== 'submit' || !button.getClientRects().length ||
    (objectId !== null && (!/_btnView/.test(button.id) || button.getAttribute('objectid') !== objectId)) ||
    form.method.toLowerCase() !== 'post' ||
    new URL(form.action, location.href).origin !== location.origin) {
    done({error: 'view-unavailable'}); return;
}
const body = new URLSearchParams();
for (const [key, value] of new FormData(form)) {
    if (typeof value === 'string') body.append(key, value);
}
body.set(button.name, button.value);
body.set('__EVENTTARGET', '');
body.set('__EVENTARGUMENT', '');
const abort = new AbortController();
const timer = setTimeout(() => abort.abort(), 20000);
(async () => {
    try {
        const response = await fetch(form.action, {
            method: 'POST', body, credentials: 'same-origin', redirect: 'error',
            cache: 'no-store', signal: abort.signal
        });
        if (!response.ok) throw new Error('view-failed');
        const limit = 100 * 1024 * 1024;
        if (Number(response.headers.get('content-length')) > limit || !response.body)
            throw new Error('view-too-large');
        const reader = response.body.getReader();
        const chunks = [];
        let length = 0;
        for (;;) {
            const {done, value} = await reader.read();
            if (done) break;
            length += value.length;
            if (length > limit) {
                abort.abort();
                throw new Error('view-too-large');
            }
            chunks.push(value);
        }
        const bytes = new Uint8Array(length);
        let offset = 0;
        for (const chunk of chunks) {
            bytes.set(chunk, offset);
            offset += chunk.length;
        }
        if (String.fromCharCode(...bytes.subarray(0, 5)) !== '%PDF-')
            throw new Error('not-pdf');
        const digest = await crypto.subtle.digest('SHA-256', bytes);
        done({sha256: Array.from(new Uint8Array(digest), x => x.toString(16).padStart(2, '0')).join('')});
    } catch (_) {
        done({error: 'view-failed'});
    } finally {
        clearTimeout(timer);
    }
})();
"""


def read_attached_pdf_hash(driver, view_id, object_id=None):
    args = (view_id,) if object_id is None else (view_id, object_id)
    try:
        result = driver.execute_async_script(ATTACHED_PDF_HASH_SCRIPT, *args)
    except WebDriverException as exc:
        raise ValueError('The portal View response could not be read.') from exc
    digest = result.get("sha256") if isinstance(result, dict) else None
    if not isinstance(digest, str) or not re.fullmatch(r"[a-f0-9]{64}", digest):
        raise ValueError('The portal View response was not a verifiable PDF.')
    return digest

"""Document identity and reviewed upload metadata, independent of local paths."""
import hashlib
import os

from automation.common.documents import get_paper_size_from_pdf
from automation.common.uploads import DocumentUploadError, document_label_key, reserve_document_label


def prepare_document_metadata(documents):
    result = {}
    for document in documents:
        filename = document.get("localName")
        path = document.get("localPath")
        if not filename or not path:
            continue
        digest = document.get("fileHash")
        if not digest and os.path.isfile(path):
            with open(path, "rb") as handle:
                digest = hashlib.file_digest(handle, "sha256").hexdigest()
        identity = str(document.get("id") or document.get("originalFilename") or document.get("originalName") or filename)
        reference = "AP" + hashlib.sha256((identity + "\0" + digest).encode("utf-8")).hexdigest()[:18] if digest else None
        result[filename] = {
            "documentId": document.get("id"), "fileHash": digest, "uploadReference": reference,
            "originalFilename": document.get("originalFilename") or document.get("originalName") or filename,
            "drawingTitle": document.get("drawingTitle"), "drawingNumber": document.get("drawingNumber"),
            "paperSize": document.get("paperSize"),
        }
    return result


def supporting_document_metadata(entries, folder, metadata=None):
    """Derive references for local/legacy files outside the portal adapter."""
    documents = {filename: dict(details) for filename, details in (metadata or {}).items()}
    for filename, _category in entries:
        details = documents.get(filename, {})
        if details.get("uploadReference"):
            continue
        path = os.path.join(folder, filename)
        if not os.path.isfile(path):
            continue
        result = prepare_document_metadata([{
            "localName": filename, "localPath": path,
            "id": details.get("documentId"), "originalFilename": details.get("originalFilename"),
            "fileHash": details.get("fileHash"), "paperSize": details.get("paperSize"),
            "drawingTitle": details.get("drawingTitle"), "drawingNumber": details.get("drawingNumber"),
        }])
        documents[filename] = {**details, **result[filename]}
    return documents


def document_title(filename, metadata=None):
    details = (metadata or {}).get(filename, {})
    name = details.get("originalFilename") or filename
    return (" ".join(str(details.get("drawingTitle") or "").split())
            or " ".join(os.path.splitext(os.path.basename(name))[0].split())
            or "Supporting Document")


def prepare_portal_titles(entries, metadata, *, clean=None, fallback="Supporting Document", separator=" "):
    """Assign a distinct display name to each prepared document before reading the draft."""
    used = set()
    clean = clean or (lambda value: value)
    for filename, _ in entries:
        details = metadata.setdefault(filename, {})
        title = clean(document_title(filename, metadata))
        original = os.path.splitext(os.path.basename(details.get("originalFilename") or filename))[0]
        alternatives = [title]
        if details.get("drawingNumber"):
            alternatives.append(clean(f'{details["drawingNumber"]} {title}'))
        alternatives.append(clean(original))
        preferred = next((name for name in alternatives if name and document_label_key(name) not in used), title or fallback)
        details["portalTitle"] = reserve_document_label(preferred, used, separator=separator)


def legacy_document_titles(filename, metadata=None):
    details = (metadata or {}).get(filename, {})
    names = {os.path.splitext(os.path.basename(str(value)))[0] for value in
             (filename, details.get("originalFilename")) if value}
    if details.get("titleAlias"):
        names.add(details["titleAlias"])
    return names


def document_paper_size(path, metadata=None):
    details = (metadata or {}).get(os.path.basename(path), {})
    analysis = details.get("paperSize") or {}
    if analysis.get("reviewRequired"):
        raise DocumentUploadError(os.path.basename(path), "Checking document paper size", "PAPER_SIZE_NEEDS_REVIEW",
                                  "Confirm the document's paper size in Architect Pro before preparing this application.")
    if analysis.get("value") in ("A0", "A1", "A2", "A3", "A4", "A5", "A6", "Not Applicable"):
        return analysis["value"]
    # Older prepared jobs have no AI result. Read the physical PDF page instead
    # of guessing from drawing numbers or filenames.
    return get_paper_size_from_pdf(path)

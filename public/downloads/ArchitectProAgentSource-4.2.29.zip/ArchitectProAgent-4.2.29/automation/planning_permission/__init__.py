# -*- coding: utf-8 -*-
"""ePlanning "Planning Permission" form automation.

Page map: Architect-Web-Portal docs/planning-permission-portal-map.md.
"""

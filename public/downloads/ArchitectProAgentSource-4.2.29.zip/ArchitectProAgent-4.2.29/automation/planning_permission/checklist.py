# -*- coding: utf-8 -*-
"""Planning Permission checklist (PlanningPermissionChecklist.aspx) and later sections.

Location Plan, Supporting Documentation and Email Notification are identical
across ePlanning forms, so the Householder implementations are reused.
"""
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, select_option_by_id
from automation.common.runtime import record_checkpoint
from automation.common.uploads import DocumentUploadError, get_visible_portal_error
from automation.householder.documents import (
    _document_step,
    complete_email_notification,
    householder_electronic_document_ids,
    load_prepared_householder_documents,
    upload_location_plan,
    upload_supporting_documents,
)
from automation.householder.navigation import click_by_id, click_first_available

C = "MainContent_PlanningPermissionChecklistWizard_"
NA = "NA"

# Questions a) to f): Yes / No / Not applicable radios.
FIRST_PAGES = (
    ("Checklist1", ("VariationsOfConditions", "CrownInterest", "NationalMajor")),
    ("Checklist2", ("DontBenefit", "LocalDevelopments", "Antenna")),
)
# Documents provided (83%): Yes / N/A radios.
DOCUMENT_GROUPS = (
    "EnviromentalStatement",  # sic: the portal spells it "Enviromental"
    "DesignStatement", "FloodRisk", "DrainageImpact", "DrainageLayout",
    "TransportAssessment", "ContaminatedLandAssessment", "HabitatSurvey", "ProcessingAgreement",
)
# Householder drawing buckets -> Planning Permission "other plans" checkboxes.
PLAN_CHECKBOXES = {
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_0": "cbElevations",
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_1": "cbFloorPlans",
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_2": "cbCrossSections",
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_3": "cbSiteLayout",
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_4": "cbRoofPlan",
    "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_5": "cbPhotographs",
}
ALL_PLAN_CHECKBOXES = (
    "cbSiteLayout", "cbElevations", "cbFloorPlans", "cbCrossSections", "cbRoofPlan",
    "cbMasterPlan", "cbLandscapePlan", "cbPhotographs", "cbOther",
)


def plan_checkboxes(upload_entries, location_plan_file=None, pdf_folder_path=None):
    """Which "other plans or drawings" boxes the prepared documents support."""
    householder_ids = householder_electronic_document_ids(upload_entries, location_plan_file, pdf_folder_path)
    return [PLAN_CHECKBOXES[element_id] for element_id in householder_ids]


def checklist_answers(user_inputs):
    """Checklist answers: "Not applicable" unless Architect Pro supplies one.

    Overrides come from "Planning Checklist Answers", e.g. {"FloodRisk": "YES"}.
    """
    overrides = user_inputs.get("Planning Checklist Answers") or {}
    answers = {}
    for _page, groups in FIRST_PAGES:
        for group in groups:
            value = str(overrides.get(group) or NA).upper()
            answers[group] = {"YES": "Yes", "NO": "No"}.get(value, "NA")
    for group in DOCUMENT_GROUPS:
        value = str(overrides.get(group) or NA).upper()
        answers[group] = "Yes" if value == "YES" else "NA"
    return answers


def _advance(driver, suffix, expected_id, timeout=30):
    click_when_clickable(driver, By.ID, C + "btnNext" + suffix, timeout=timeout)
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(
            lambda d: d.find_elements(By.ID, expected_id)
        )
    except TimeoutException as exc:
        message = get_visible_portal_error(driver)
        raise RuntimeError(
            f"Planning Permission checklist did not move on from '{suffix}'"
            + (f": {message}" if message else ". Next was not repeated.")
        ) from exc


def _set_checkbox(driver, suffix, desired):
    element_id = C + suffix
    element = driver.find_element(By.ID, element_id)
    if bool(element.is_selected()) == bool(desired):
        return
    if desired:
        select_option_by_id(driver, element_id, f"Checklist plan: {suffix}")
    else:
        click_first_available(driver, [(By.XPATH, f"//label[@for='{element_id}']"), (By.ID, element_id)], timeout=10)


def complete_planning_checklist(driver, user_inputs, upload_entries=None, location_plan_file=None,
                                pdf_folder_path=None):
    plans = plan_checkboxes(upload_entries, location_plan_file, pdf_folder_path)
    if not plans:
        raise RuntimeError(
            "Planning Permission checklist: the prepared documents match none of the portal's "
            "plan categories. Review the document mapping before retrying."
        )
    answers = checklist_answers(user_inputs)
    click_by_id(driver, "MainContent_FormSections_btnChecklist", "Checklist section", timeout=30)

    expected_after = {"Checklist1": C + "rbDontBenefitNA", "Checklist2": C + "cbSiteLayout"}
    for suffix, groups in FIRST_PAGES:
        for group in groups:
            select_option_by_id(driver, f"{C}rb{group}{answers[group]}", f"Checklist {group}: {answers[group]}")
        _advance(driver, suffix, expected_after[suffix])

    for suffix in ALL_PLAN_CHECKBOXES:
        # "Other" would add a describe-the-plans page; documents never map to it.
        _set_checkbox(driver, suffix, suffix in plans)
    _advance(driver, "PPChecklist3", C + "rbProcessingAgreementNA")

    for group in DOCUMENT_GROUPS:
        select_option_by_id(driver, f"{C}rb{group}{answers[group]}", f"Checklist {group}: {answers[group]}")
    _advance(driver, "PPChecklist5", C + "btnNextReview")
    _advance(driver, "Review", "MainContent_FormSections_btnSupportingDocumentation")
    print("Planning Permission checklist complete.")


def complete_later_planning_sections(driver, pdf_folder_path, user_inputs, prepared_documents=None):
    (
        upload_entries,
        location_plan_file,
        location_plan_path,
        effective_pdf_folder,
        bucket_labels,
    ) = prepared_documents or load_prepared_householder_documents(pdf_folder_path)

    _document_step(driver, "", "Confirming document email notifications", lambda: complete_email_notification(driver))
    record_checkpoint("email_notification_complete", "email_notification")
    _document_step(driver, "", "Completing the document checklist", lambda: complete_planning_checklist(
        driver, user_inputs, upload_entries, location_plan_file, effective_pdf_folder))
    record_checkpoint("document_checklist_complete", "checklist")
    upload_supporting_documents(driver, upload_entries, effective_pdf_folder, bucket_labels,
                                user_inputs.get("Document Metadata"))
    record_checkpoint("supporting_documents_uploaded", "supporting_documents")
    try:
        metadata = user_inputs.get("Document Metadata")
        _document_step(driver, location_plan_file, "Uploading location plan",
                       lambda: upload_location_plan(driver, location_plan_path, metadata) if metadata
                       else upload_location_plan(driver, location_plan_path))
    except DocumentUploadError as exc:
        exc.uploaded_count = len(upload_entries)
        raise
    record_checkpoint("location_plan_uploaded", "location_plan")

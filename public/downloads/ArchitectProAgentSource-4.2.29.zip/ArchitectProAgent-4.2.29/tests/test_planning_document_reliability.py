import hashlib

import pytest
from selenium.common.exceptions import StaleElementReferenceException
from automation.householder import documents
from automation.planning_permission import checklist
from automation.common.uploads import DocumentUploadError
from completion_fakes import FakeDriver


class PlanningDocuments:
    def __init__(self, saved=(), uncertain_save=False, save_attaches=True):
        self.driver = FakeDriver()
        self.uploaded = list(saved)
        self.page = 'summary'
        self.uncertain_save = uncertain_save
        self.save_attaches = save_attaches
        self.saved_section = False
        d = self.driver
        d.scripts['ARCHPRO_ATTACHMENT_LIST'] = lambda: {
            'recognized': self.page == 'list',
            'titles': self.uploaded,
            'views': {reference: [{'id': f'MainContent_btnView{index}', 'objectId': reference}]
                      for index, reference in enumerate(self.uploaded)},
        }
        d.execute_async_script = lambda _script, _view, _identity: {'sha256': hashlib.sha256(b'%PDF-test').hexdigest()}
        d.scripts['return Boolean(arguments[0].checked'] = lambda element: element.is_selected()
        d.add('MainContent_FormSections_btnSupportingDocumentation', kind='button', on_click=lambda _: self.go('options'))
        d.add_radio('MainContent_rbYes', 'supporting')
        d.add_radio('MainContent_rbNo', 'supporting')
        d.add('MainContent_btnContinue', kind='button', on_click=lambda _: self.go('list' if d.selected('MainContent_rbYes') else 'summary'))
        d.add('MainContent_btnAddDocumentation', kind='button', on_click=lambda _: self.go('attach'))
        d.add_radio('MainContent_rbUploaded', 'upload')
        d.add('MainContent_btnAttachmentContinue', kind='button', on_click=lambda _: self.go('editor'))
        for field in ('edtDocumentTitle', 'edtDescription', 'fuAttachFile'):
            d.add('MainContent_' + field)
        d.add('MainContent_lbPaperSize', kind='select', options=['A3', 'A4'], value='A4')
        d.add('MainContent_lbDocumentType', kind='select', options=['Drawing', 'Other'], value='Other')
        d.add_radio('MainContent_rbReadAndUnderstood', 'read')
        d.add('MainContent_btnSaveDocEdit', kind='button', on_click=lambda _: self.save())
        d.add_radio('MainContent_rbFinished', 'finish')
        d.add('MainContent_btnDocSave', kind='button', on_click=lambda _: self.finish())
        self.go('summary')

    def go(self, page):
        self.page = page
        self.driver.postback()
        self.driver.visible_ids = set({
            'summary': ['FormSections_btnSupportingDocumentation'],
            'options': ['rbYes', 'rbNo', 'btnContinue'],
            'list': ['btnAddDocumentation', 'rbFinished', 'btnDocSave'],
            'attach': ['rbUploaded', 'btnAttachmentContinue'],
            'editor': ['edtDocumentTitle', 'edtDescription', 'fuAttachFile', 'lbPaperSize', 'lbDocumentType', 'rbReadAndUnderstood', 'btnSaveDocEdit'],
        }[page])
        self.driver.visible_ids = {'MainContent_' + value for value in self.driver.visible_ids}

    def save(self):
        if self.save_attaches:
            self.uploaded.append(self.driver.value('MainContent_edtDocumentTitle'))
        self.go('list')
        if self.uncertain_save:
            raise StaleElementReferenceException('Save committed but its response was replaced')

    def finish(self):
        self.saved_section = True
        self.go('summary')


@pytest.fixture
def prepared(monkeypatch, tmp_path):
    monkeypatch.setattr(documents, 'get_document_type_from_pdf', lambda _: 'Drawing')
    for name in ('one.pdf', 'two.pdf'):
        (tmp_path / name).write_bytes(b'%PDF-test' if name == 'one.pdf' else b'%PDF-test second drawing')
    metadata = {name: {'uploadReference': 'AP' + digit * 18, 'originalFilename': name,
                       'paperSize': {'value': 'A3', 'reviewRequired': False}}
                for name, digit in [('one.pdf', '1'), ('two.pdf', '2')]}
    return str(tmp_path), metadata


def test_planning_partial_run_only_uploads_the_missing_file(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(saved=['AP' + '1' * 18])
    documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed'), ('two.pdf', 'proposed')], folder, {'proposed': 'Proposed plans'}, metadata)
    assert portal.uploaded == ['AP' + '1' * 18, 'two']
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 1
    assert portal.saved_section
    assert portal.driver.value('MainContent_lbPaperSize') == 'A3'


def test_planning_completed_uploads_do_not_open_an_empty_editor(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(saved=['AP' + '1' * 18])
    documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed')], folder, {}, metadata)
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 0
    assert portal.saved_section


def test_planning_reads_the_saved_row_after_a_lost_response(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(uncertain_save=True)
    documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed')], folder, {}, metadata)
    assert portal.driver.clicks('MainContent_btnSaveDocEdit') == 1
    assert portal.uploaded == ['one']
    assert portal.saved_section


def test_planning_does_not_repeat_an_uncertain_save(prepared, monkeypatch):
    folder, metadata = prepared
    portal = PlanningDocuments(uncertain_save=True, save_attaches=False)
    verify = documents.wait_for_supporting_doc_upload_result
    monkeypatch.setattr(documents, 'wait_for_supporting_doc_upload_result',
                        lambda driver, filename, **kwargs: verify(driver, filename, timeout=0, expected_title=kwargs['expected_title']))
    with pytest.raises(DocumentUploadError) as caught:
        documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed'), ('two.pdf', 'proposed')], folder, {}, metadata)
    assert caught.value.reason_code == 'UPLOAD_UNCONFIRMED'
    assert caught.value.filename == 'one.pdf'
    assert portal.driver.clicks('MainContent_btnSaveDocEdit') == 1
    assert portal.uploaded == []
    assert not portal.saved_section


def test_planning_accepts_a_unicode_filename_with_a_readable_fallback(prepared, monkeypatch):
    from pathlib import Path

    folder, _metadata = prepared
    name = '中庭.pdf'
    (Path(folder) / name).write_bytes(b'%PDF-fixture')
    portal = PlanningDocuments()
    monkeypatch.setattr(documents, 'document_paper_size', lambda *_: 'A3')
    documents.upload_supporting_documents(portal.driver, [(name, 'proposed')], folder, {'proposed': 'Plans'})
    assert portal.saved_section
    assert portal.uploaded == ['Supporting_Document']


@pytest.mark.parametrize('permission', [False, True], ids=['householder', 'planning-permission'])
def test_application_entry_points_preserve_renamed_rows_and_upload_readable_titles(prepared, monkeypatch, permission):
    folder, metadata = prepared
    existing_title = 'Manually corrected drawing'
    portal = PlanningDocuments(saved=[existing_title])
    metadata['two.pdf']['drawingTitle'] = 'Proposed façade. Rev A'
    sections = checklist if permission else documents
    checklist_method = 'complete_planning_checklist' if permission else 'complete_checklist'
    for name in ('complete_email_notification', checklist_method, 'upload_location_plan', 'record_checkpoint'):
        monkeypatch.setattr(sections, name, lambda *_args, **_kwargs: None)
    enter = checklist.complete_later_planning_sections if permission else documents.complete_later_householder_sections
    enter(portal.driver, folder, {'Document Metadata': metadata}, (
        [('one.pdf', 'proposed'), ('two.pdf', 'proposed')], 'location.pdf', 'location.pdf',
        folder, {'proposed': 'Proposed plans'},
    ))
    assert portal.uploaded == [existing_title, 'Proposed_facade_Rev_A']
    assert portal.driver.clicks('MainContent_btnSaveDocEdit') == 1
    assert portal.driver.value('MainContent_edtDescription') == 'Proposed plans'


def test_planning_location_plan_only_answers_no_supporting_documents(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments()
    documents.upload_supporting_documents(portal.driver, [], folder, {}, metadata)
    assert portal.driver.selected('MainContent_rbNo')
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 0

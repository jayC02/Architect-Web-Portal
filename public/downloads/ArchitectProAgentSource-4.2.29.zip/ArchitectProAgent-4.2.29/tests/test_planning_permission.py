"""Planning Permission workflow: routing mapped live on eplanning.scot (2026-11-27)."""
import pytest

from automation import runner
from automation.common import proposal_creation
from automation.planning_permission import checklist, inputs, main_details
from automation.planning_permission.inputs import (
    PlanningPermissionInputError,
    parse_planning_answers,
    planned_steps,
    validate_supported_ownership,
)
from gui.services import portal_handoff

P = "MainContent_PlanningPermissionWizard_"


def base_inputs(**overrides):
    values = {
        "Description of Work": "Erection of a detached garage",
        "Applicant Email": "client@example.com",
        "Planning Site Area": "250",
        "Planning Existing Use": "Dwellinghouse and garden",
        "Householder Current Parking Spaces": "2",
        "Householder Proposed Parking Spaces": "2",
        "Planning New Or Altered Water Supply Or Drainage": "No",
        "Planning Sustainable Drainage": "Yes",
        "Planning Public Water Supply": "YES",
        "Planning Known Flood Risk": "NO",
        "Planning Increases Flood Risk": "NO",
        "Planning Waste Storage": "Yes",
        "Planning Waste Details": "Bins stored at the side of the house",
        "Planning New Dwellings": "No",
        "Planning Non Residential Floorspace": "No",
        "Planning Schedule 3": "NO",
    }
    values.update(overrides)
    return values


FULL_MINIMAL_ROUTE = [
    "Welcome", "TypeOfApplication", "DescriptionOfProposal", "DescriptionOfProposalCont2",
    "TypeOfUserStep", "AgentDetails", "AppellantDetails", "PreApplicationDiscussion",
    "SiteArea", "ExistingUse", "AccessAndParking", "AccessAndParkingCont1", "AccessAndParkingCont2",
    "WaterSupply", "WaterSupplyCont5", "WaterSupplyCont6", "AssessmentOfFloodRisk", "Trees",
    "WasteStorage", "WasteStorageCont", "ResidentialUnits", "AllTypes",
    "Schedule3Development", "PlanningServiceInterest", "Review",
]


def test_full_planning_permission_minimal_route_matches_the_live_portal():
    assert planned_steps(parse_planning_answers(base_inputs())) == FULL_MINIMAL_ROUTE


def test_every_conditional_page_appears_only_for_its_answer():
    answers = parse_planning_answers(base_inputs(**{
        "Planning Temporary Permission": "Yes",
        "Planning Temporary Permission Details": "12 months for a site cabin",
        "Planning Works Started": "Started",
        "Planning Works Date": "01/11/2026",
        "Planning Works Reason": "Urgent repairs",
        "Householder Discussed With Planning Authority": "Yes",
        "Planning Pre-Application Format": "Email",
        "Planning Pre-Application Feedback": "Officer was supportive",
        "Planning New Or Altered Water Supply Or Drainage": "Yes",
        "Planning Drainage Connection": "PRIVATE",
        "Planning Private Drainage Type": "SEPTIC_TANK",
        "Planning Septic Tank Discharge": "LAND",
        "Planning Private Drainage Details": "New septic tank to soakaway",
        "Planning Increases Flood Risk": "YES",
        "Planning Flood Risk Details": "More hard standing",
        "Planning New Dwellings": "Yes",
        "Planning Dwelling Units": "1",
        "Planning Non Residential Floorspace": "Yes",
        "Planning Floorspace Entries": [{"useClass": "Class 4", "grossFloorspace": "20"}],
        "Planning Staff Or Member Interest": "Yes",
        "Planning Staff Or Member Interest Details": "Applicant's partner is a councillor",
    }))
    steps = planned_steps(answers)
    for page in ("DescriptionOfProposalCont1", "DescriptionOfProposalCont3", "PreApplicationDiscussionCont",
                 "WaterSupplyCont1", "WaterSupplyCont2", "WaterSupplyCont3", "WaterSupplyCont4",
                 "AssessmentOfFloodRiskCont", "ResidentialUnitsCont", "AllTypeCont",
                 "PlanningServiceInterestCont"):
        assert page in steps
    assert steps.index("WaterSupplyCont3") < steps.index("WaterSupplyCont4") < steps.index("WaterSupplyCont5")


@pytest.mark.parametrize("drainage, expected", [
    ({"Planning Drainage Connection": "PUBLIC"}, ["WaterSupplyCont1"]),
    ({"Planning Drainage Connection": "NOT_APPLICABLE"}, ["WaterSupplyCont1"]),
    ({"Planning Drainage Connection": "PRIVATE", "Planning Private Drainage Type": "TREATMENT",
      "Planning Private Drainage Details": "Package plant"}, ["WaterSupplyCont1", "WaterSupplyCont2", "WaterSupplyCont4"]),
    ({"Planning Drainage Connection": "PRIVATE", "Planning Private Drainage Type": "OTHER",
      "Planning Private Drainage Details": "Composting toilet"}, ["WaterSupplyCont1", "WaterSupplyCont2", "WaterSupplyCont4"]),
])
def test_drainage_branches_match_the_live_portal(drainage, expected):
    answers = parse_planning_answers(base_inputs(**{"Planning New Or Altered Water Supply Or Drainage": "Yes", **drainage}))
    steps = planned_steps(answers)
    water = [step for step in steps if step.startswith("WaterSupplyCont")]
    assert water == expected + ["WaterSupplyCont5", "WaterSupplyCont6"]


def test_planning_permission_in_principle_drops_parking_waste_and_residential():
    steps = planned_steps(parse_planning_answers(base_inputs(**{"Planning Application Type": "PPP"})))
    for page in ("AccessAndParkingCont2", "WasteStorage", "WasteStorageCont", "ResidentialUnits"):
        assert page not in steps
    assert steps[steps.index("Trees") + 1] == "AllTypes"


def test_further_application_adds_the_earlier_reference_and_drops_waste_and_residential():
    answers = parse_planning_answers(base_inputs(**{
        "Planning Application Type": "FURTHER",
        "Planning Earlier Application Reference": "26/01234/FUL",
        "Planning Earlier Application Date": "05/03/2026",
    }))
    steps = planned_steps(answers)
    assert steps[:4] == ["Welcome", "TypeOfApplication", "TypeOfApplicationCont1", "DescriptionOfProposal"]
    assert "AccessAndParkingCont2" in steps and "WasteStorage" not in steps and "AllTypes" in steps


def test_matters_specified_in_conditions_keeps_waste_and_residential_but_not_floorspace():
    answers = parse_planning_answers(base_inputs(**{
        "Planning Application Type": "AMSC",
        "Planning Earlier Application Reference": "26/01234/PPP",
        "Planning Earlier Application Date": "05/03/2026",
        "Planning Non Residential Floorspace": None,
    }))
    steps = planned_steps(answers)
    assert "TypeOfApplicationCont1" in steps and "WasteStorageCont" in steps
    assert "AllTypes" not in steps
    assert steps[steps.index("ResidentialUnits") + 1] == "Schedule3Development"


def test_missing_answers_are_all_listed_before_the_portal_is_touched():
    with pytest.raises(PlanningPermissionInputError) as caught:
        parse_planning_answers({"Description of Work": "Garage"})
    text = str(caught.value)
    for expected in ("applicant email", "Site area", "Existing use", "Current parking spaces",
                     "water supply or drainage", "SUDS", "Public water supply", "Known flood risk",
                     "Waste storage", "New houses or flats", "Non-residential floorspace", "Schedule 3"):
        assert expected.lower() in text.lower()


def test_further_application_requires_the_earlier_reference_and_a_real_date():
    with pytest.raises(PlanningPermissionInputError) as caught:
        parse_planning_answers(base_inputs(**{"Planning Application Type": "FURTHER",
                                              "Planning Earlier Application Date": "2026-03-05"}))
    assert "earlier application reference" in str(caught.value)
    assert "dd/mm/yyyy" in str(caught.value)


def test_floorspace_entries_resolve_use_classes_and_require_reasons():
    answers = parse_planning_answers(base_inputs(**{
        "Planning Non Residential Floorspace": "Yes",
        "Planning Floorspace Entries": [
            {"useClass": "Class 1 Retail (food)", "grossFloorspace": "80", "netTradingSpace": "60", "nonTradingSpace": "20"},
            {"useClass": "Class 8a", "grossFloorspace": "4"},
        ],
    }))
    assert [(e.use_class, e.net_trading) for e in answers.floorspace] == [("15", "60"), ("9", "")]
    with pytest.raises(PlanningPermissionInputError, match="details are required"):
        parse_planning_answers(base_inputs(**{
            "Planning Non Residential Floorspace": "Yes",
            "Planning Floorspace Entries": [{"useClass": "Don't Know", "grossFloorspace": "10"}],
        }))


@pytest.mark.parametrize("ownership, supported", [
    ({"Householder Sole Owner": "Yes"}, True),
    ({"Householder Sole Owner": "No", "Householder Identify All Other Owners": "No",
      "Householder Notice To One Owner": "No"}, True),
    ({"Householder Sole Owner": "No", "Householder Identify All Other Owners": "Yes"}, False),
    ({"Householder Sole Owner": "No", "Householder Identify All Other Owners": "No",
      "Householder Notice To One Owner": "Yes"}, False),
    ({"Householder Sole Owner": "Yes", "Householder Agricultural Holding": "Yes"}, False),
])
def test_only_ownership_routes_without_owner_lists_are_attempted(ownership, supported):
    if supported:
        validate_supported_ownership(ownership)
    else:
        with pytest.raises(PlanningPermissionInputError, match="not supported"):
            validate_supported_ownership(ownership)


class _Recorder:
    def __init__(self, monkeypatch):
        self.calls = []
        monkeypatch.setattr(main_details, "select_option_by_id",
                            lambda _driver, element_id, label, **_kw: self.calls.append(("select", element_id)))
        monkeypatch.setattr(main_details, "force_text_by_id",
                            lambda _driver, element_id, value, label, **_kw: self.calls.append(("text", element_id, value)))

    def ids(self):
        return [call[1] for call in self.calls]


def test_pages_use_the_portals_exact_ids_including_typos_and_unprefixed_dates(monkeypatch):
    recorder = _Recorder(monkeypatch)
    answers = parse_planning_answers(base_inputs(**{
        "Planning Application Type": "FURTHER",
        "Planning Earlier Application Reference": "26/01234/FUL",
        "Planning Earlier Application Date": "05/03/2026",
        "Planning Works Started": "Completed",
        "Planning Works Date": "01/11/2026",
        "Planning Works Reason": "Work finished before the application",
        "Planning Public Water Supply": "PRIVATE",
        "Planning New Or Altered Water Supply Or Drainage": "Yes",
        "Planning Drainage Connection": "PRIVATE",
        "Planning Private Drainage Type": "TREATMENT",
        "Planning Private Drainage Details": "Package plant",
    }))
    for step in ("TypeOfApplication", "TypeOfApplicationCont1", "DescriptionOfProposalCont3",
                 "PreApplicationDiscussion", "WaterSupplyCont2", "WaterSupplyCont6", "WasteStorageCont"):
        main_details.fill_page(None, step, answers, {})
    ids = recorder.ids()
    assert P + "rbFurtherApplication" in ids
    assert "txtAppDate" in ids and "txtCompletionDate" in ids
    assert P + "rbDisccussedNo" in ids
    assert P + "rbTreatement" in ids
    assert P + "rbConnectToWaterSuppplyNo" in ids
    assert P + "txtWasteCollectionDetials" in ids


def test_main_details_walks_the_planned_route_and_waits_for_each_next_page(monkeypatch):
    answers = parse_planning_answers(base_inputs())
    filled, advanced = [], []
    monkeypatch.setattr(main_details, "WebDriverWait", lambda *_a, **_k: type("W", (), {"until": lambda self, c: True})())
    monkeypatch.setattr(main_details, "fill_page", lambda _d, step, *_a, **_k: filled.append(step))
    monkeypatch.setattr(main_details, "advance", lambda _d, step, expected, **_k: advanced.append((step, expected)))
    main_details.complete_planning_main_details(object(), answers, {})
    assert filled == FULL_MINIMAL_ROUTE
    assert advanced[0] == ("Welcome", "TypeOfApplication")
    assert advanced[-1] == ("Review", None)
    assert all(advanced[i][1] == advanced[i + 1][0] for i in range(len(advanced) - 1))


def test_checklist_defaults_to_not_applicable_and_accepts_overrides():
    answers = checklist.checklist_answers({"Planning Checklist Answers": {"CrownInterest": "NO", "FloodRisk": "YES"}})
    assert answers["VariationsOfConditions"] == "NA" and answers["CrownInterest"] == "No"
    assert answers["FloodRisk"] == "Yes" and answers["HabitatSurvey"] == "NA"


def test_checklist_plans_follow_the_prepared_drawings():
    entries = [("Proposed_Elevations.pdf", "elevations"), ("Existing_Floor_Plans.pdf", "existing"),
               ("Roof_Plan.pdf", "other")]
    assert checklist.plan_checkboxes(entries) == ["cbElevations", "cbFloorPlans", "cbRoofPlan"]


def test_planning_application_jobs_run_the_planning_permission_workflow():
    from automation.householder.run import main as householder
    from automation.planning_permission.run import main as planning_permission
    assert runner._workflow_for("PLANNING_APPLICATION") is planning_permission
    assert runner._workflow_for("HOUSEHOLDER_PLANNING") is householder


def test_missing_planning_answers_reach_the_user_verbatim():
    error = PlanningPermissionInputError(["The applicant email address is required"])
    message, code = runner.domain_error(error)
    assert code == "JOB_CONFIGURATION_ERROR"
    assert "applicant email address is required" in message


def test_proposal_creation_adds_the_planning_permission_form():
    assert proposal_creation.FORM_LABELS[proposal_creation.PLANNING_PERMISSION] == "Planning Permission"
    assert proposal_creation.PLANNING_PERMISSION in proposal_creation.EPLANNING_APPLICATION_TYPES
    context = proposal_creation.build_context({
        "Site Address": "1 Test Road, Glasgow, G1 1AA", "Site Postcode": "G1 1AA",
        "Description of Work": "Garage", "Automation Job ID": "job-12345678",
    }, proposal_creation.PLANNING_PERMISSION)
    assert context.application_type == proposal_creation.PLANNING_PERMISSION


def test_snapshot_answers_map_to_agent_inputs_without_inventing_missing_ones():
    values = portal_handoff._planning_permission_values({
        "applicationKind": "FULL", "siteArea": 250, "existingUse": " Garden ",
        "waterOrDrainageChanges": False, "sustainableDrainage": True,
        "floorspaceEntries": [{"useClass": "Class 4", "grossFloorspace": "20"}, "bad"],
        "checklistAnswers": {"FloodRisk": "YES"},
    })
    assert values["Planning Application Type"] == "FULL"
    assert values["Planning Site Area"] == "250"
    assert values["Planning Existing Use"] == "Garden"
    assert values["Planning New Or Altered Water Supply Or Drainage"] == "No"
    assert values["Planning Sustainable Drainage"] == "Yes"
    assert values["Planning Floorspace Entries"] == [{"useClass": "Class 4", "grossFloorspace": "20"}]
    assert values["Planning Checklist Answers"] == {"FloodRisk": "YES"}
    assert "Planning Waste Storage" not in values

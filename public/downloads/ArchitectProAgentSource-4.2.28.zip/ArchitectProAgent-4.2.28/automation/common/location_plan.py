"""Verify an already attached plan before resuming either portal workflow."""
import hashlib
import os
from dataclasses import dataclass

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import click_when_clickable, control_on_screen
from automation.common.portal_attachment import ATTACHED_PDF_HASH_SCRIPT as ATTACHED_PLAN_HASH_SCRIPT, read_attached_pdf_hash
from automation.common.uploads import DocumentUploadError


@dataclass(frozen=True)
class LocationPlanControls:
    initial: tuple
    view_id: str
    back_id: str


WARRANT_LOCATION_PLAN = LocationPlanControls(
    (By.XPATH, "//label[@for='MainContent_BlockPlanWizard_rbAttachBlockPlan']"),
    "MainContent_BlockPlanWizard_LinkBtnViewBlockPlan",
    "MainContent_BlockPlanWizard_btnBackToSummary3",
)
PLANNING_LOCATION_PLAN = LocationPlanControls(
    (By.ID, "MainContent_LocationPlanWizard_btnContinueAddLocationPlan"),
    "MainContent_LocationPlanWizard_LinkBtnViewLocationPlan",
    "MainContent_LocationPlanWizard_btnBackToSummary3",
)



def _plan_state(driver, controls):
    try:
        for element in driver.find_elements(By.ID, controls.view_id):
            if element.is_displayed():
                return "attached"
        for element in driver.find_elements(*controls.initial):
            if control_on_screen(driver, element):
                return "initial"
    except (NoSuchElementException, StaleElementReferenceException):
        pass
    return False


def resume_attached_location_plan(driver, path, controls, *, timeout=30):
    """Return False for first upload; return to summary only for identical bytes.

    The caller has opened the location-plan section. An unreadable or different
    attachment is never removed, replaced, or assumed to match by its title.
    """
    filename = os.path.basename(path) if path else ""
    try:
        state = WebDriverWait(driver, timeout, poll_frequency=0.15).until(
            lambda current: _plan_state(current, controls)
        )
    except TimeoutException as exc:
        raise DocumentUploadError(filename, "Checking existing location plan", "LOCATION_PLAN_UNVERIFIED",
                                  "The location plan page could not be identified. Review the existing draft before continuing.") from exc
    if state == "initial":
        return False

    try:
        with open(path, "rb") as handle:
            expected_hash = hashlib.file_digest(handle, "sha256").hexdigest()
    except (OSError, TypeError) as exc:
        raise DocumentUploadError(filename, "Checking existing location plan", "LOCAL_FILE_MISSING",
                                  "The prepared location plan could not be read on the Agent computer.") from exc

    try:
        digest = read_attached_pdf_hash(driver, controls.view_id)
    except ValueError as exc:
        raise DocumentUploadError(filename, "Checking existing location plan", "LOCATION_PLAN_UNVERIFIED",
                                  "The attached location plan could not be verified as a PDF. Review it in the existing draft; no file was replaced.") from exc
    if digest != expected_hash:
        raise DocumentUploadError(filename, "Checking existing location plan", "LOCATION_PLAN_MISMATCH",
                                  "The attached location plan differs from the prepared PDF. Review the file versions in the existing draft; no file was replaced.")

    click_when_clickable(driver, By.ID, controls.back_id, timeout=timeout)
    WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((By.ID, "MainContent_FormSections_btnDeclaration")))
    print("Existing location plan matches the prepared PDF; returned to Form Summary.")
    return True

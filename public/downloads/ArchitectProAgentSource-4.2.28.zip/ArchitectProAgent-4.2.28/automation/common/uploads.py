# -*- coding: utf-8 -*-
import hashlib
import os
import re
from collections import Counter

from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import is_detached_node_error, click_when_clickable, get_when_present
from automation.common.portal_attachment import read_attached_pdf_hash


ATTACHMENT_LIST_SCRIPT = r"""
// ARCHPRO_ATTACHMENT_LIST: only attachment-grid cells establish document presence.
const visible = el => el.getClientRects().length > 0;
const normal = text => (text || '').replace(/\s+/g, ' ').trim().toLowerCase().replace(/[^a-z0-9 ]/g, '');
const titles = []; const unattached = []; const descriptions = []; const legacyRows = [];
const views = Object.create(null);
let recognized = false; let paginated = false; let incomplete = false;
const record = (title, attached, view) => {
    (attached ? titles : unattached).push(title);
    if (attached && view) (views[title] ||= []).push(view);
};
for (const table of document.querySelectorAll('table')) {
    if (!visible(table)) continue;
    const rows = Array.from(table.rows);
    const header = rows.find(row => row.querySelector('th'));
    const known = ['MainContent_tblDocuments', 'MainContent_SupportingDocumentationWizard_tblDocuments'].includes(table.id);
    if (!header) { if (known && table.rows.length === 0) recognized = true; continue; }
    const headings = Array.from(header.cells).map(cell => normal(cell.textContent));
    const column = headings.findIndex(text => /^(unique )?(drawing reference( number)?|document title|title|reference( number)?)$/.test(text) || (known && text === 'description'));
    if (column < 0 || !(/document|attachment/i.test(table.id) || headings.some(text => /file|description|paper size/.test(text)))) continue;
    recognized = true;
    if (table.querySelector('a[href*="Page$"]')) paginated = true;
    for (const row of rows) {
        if (row === header || row.querySelector('th') || !visible(row)) continue;
        if (row.querySelector('a[href*="Page$"]')) continue;
        const cell = row.cells[column];
        if (!cell || cell.colSpan > 1) continue;
        const control = row.querySelector('input[id*="_btnView"][objectid],button[id*="_btnView"][objectid]');
        const view = control && visible(control) && !control.disabled
            ? {id: control.id, objectId: control.getAttribute('objectid')} : null;
        const label = control && cell.contains(control) ? control.value : '';
        const title = (label || cell.textContent || '').replace(/\s+/g, ' ').trim();
        const statusColumn = headings.indexOf('status');
        const attached = statusColumn < 0 ? !known : normal(row.cells[statusColumn]?.textContent) === 'attached';
        if (!title) {
            if (attached || control) incomplete = true;
            continue;
        }
        const descriptionOnly = table.id === 'MainContent_SupportingDocumentationWizard_tblDocuments' && headings[column] === 'description';
        if (descriptionOnly) {
            // References are written as the first word in this grid's description.
            const token = title.match(/^AP[a-f0-9]{18}\b/);
            if (token) record(token[0], attached, view);
            else {
                const edit = row.querySelector('input[id*="_btnEdit"][objectid]');
                if (edit) legacyRows.push({editId: edit.id, attached, view});
                else descriptions.push(title);
            }
        } else record(title, attached, view);
    }
}
if (!recognized) {
    const empty = Array.from(document.querySelectorAll('[id*="Document"], [id*="document"], [id*="Attachment"]'))
      .some(el => visible(el) && /^(no (supporting )?(documents|documentation|attachments)( have been (added|uploaded|attached))?[.!]?|there (are|is) no (supporting )?(documents|documentation|attachments)[.!]?)$/i.test((el.textContent || '').trim()));
    recognized = empty;
}
return {recognized, titles, unattached, descriptions, legacyRows, views, paginated, incomplete};
"""


class AttachmentTitles(set):
    def __init__(self, values=(), unattached=(), descriptions=(), legacy_rows=(), views=None):
        self.counts = Counter(values)
        super().__init__(self.counts)
        self.unattached = set(unattached)
        self.descriptions = set(descriptions)
        self.legacy_rows = list(legacy_rows)
        self.views = views or {}

    def add_legacy_reference(self, value, row):
        if row['attached']:
            self.add(value)
            self.counts[value] += 1
            if row.get('view'):
                self.views.setdefault(value, []).append(row['view'])
        else:
            self.unattached.add(value)


def _attachment_titles(driver):
    try:
        result = driver.execute_script(ATTACHMENT_LIST_SCRIPT)
        if not isinstance(result, dict) or not result.get("recognized"):
            return None
        if result.get("paginated"):
            raise DocumentUploadError("", "Reading attached documents", "DOCUMENT_LIST_UNREADABLE",
                                      "The attachment list spans multiple pages. Review the existing attachments before continuing.")
        if result.get("incomplete"):
            raise DocumentUploadError("", "Reading attached documents", "DOCUMENT_LIST_UNREADABLE",
                                      "An attached document has no readable reference. Review the existing attachments before continuing.")
        return AttachmentTitles((str(title).strip() for title in result.get("titles", []) if str(title).strip()),
                                result.get("unattached", []), result.get("descriptions", []),
                                result.get("legacyRows", []), result.get("views"))
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return None
        raise


def listed_document_titles(driver, timeout=30):
    """Wait for an identified attachment list; an unreadable list is never empty."""
    def read(current):
        titles = _attachment_titles(current)
        return (titles,) if titles is not None else False
    try:
        titles = WebDriverWait(driver, timeout, poll_frequency=0.15).until(read)[0]
        # The warrant grid displays descriptions, not drawing references.
        # Read older entries through Edit, then Cancel without saving changes.
        for row in titles.legacy_rows:
            try:
                click_when_clickable(driver, By.ID, row['editId'], timeout=timeout)
                def reference(current):
                    return current.find_element(By.ID, 'MainContent_SupportingDocumentationWizard_edtUniqueDrawingReferenceNumber').get_attribute('value') or False
                value = WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(reference)
                click_when_clickable(driver, By.ID, 'MainContent_SupportingDocumentationWizard_btnCancelDocEdit', timeout=timeout)
                WebDriverWait(driver, timeout, poll_frequency=0.15).until(read)
                titles.add_legacy_reference(value.strip(), row)
            except (TimeoutException, NoSuchElementException, StaleElementReferenceException) as exc:
                raise DocumentUploadError('', 'Checking an older attached document', 'DOCUMENT_MATCH_AMBIGUOUS',
                                          'The older document reference could not be verified. No upload or Save was repeated.') from exc
        return titles
    except TimeoutException as exc:
        raise DocumentUploadError("", "Reading attached documents", "DOCUMENT_LIST_UNREADABLE",
                                  "The portal's attachment list could not be read. No documents were uploaded again.") from exc


def _confirm_saved_attachment(driver, pdf_file, details, view, pdf_folder):
    operation = 'Reconciling attached documents'
    if driver is None or len(view) != 1:
        raise DocumentUploadError(pdf_file, operation, 'DOCUMENT_MATCH_AMBIGUOUS',
                                  'A matching attachment was listed, but its PDF could not be compared. Review it in the existing draft.')
    try:
        expected = details.get('fileHash')
        if not expected:
            with open(os.path.join(pdf_folder, pdf_file), 'rb') as handle:
                expected = hashlib.file_digest(handle, 'sha256').hexdigest()
    except OSError as exc:
        raise DocumentUploadError(pdf_file, 'Checking prepared PDF', 'LOCAL_FILE_MISSING',
                                  'The prepared PDF could not be read on the Agent computer.') from exc
    try:
        actual = read_attached_pdf_hash(driver, view[0]['id'], view[0]['objectId'])
    except ValueError as exc:
        raise DocumentUploadError(pdf_file, operation, 'DOCUMENT_MATCH_AMBIGUOUS',
                                  'The saved attachment could not be verified as a PDF. Review it in the existing draft.') from exc
    if actual != expected:
        raise DocumentUploadError(pdf_file, operation, 'DOCUMENT_MATCH_AMBIGUOUS',
                                  'The saved attachment matches the name or reference but has different PDF content. Review the file versions in the existing draft.')


def documents_still_to_upload(entries, listed_titles, metadata=None, legacy_title_transform=None,
                              legacy_descriptions=None, *, driver=None, pdf_folder=""):
    """Reconcile the full list before uploading; a name only identifies a candidate."""
    from automation.common.document_metadata import legacy_document_titles

    pending = []
    used = set()
    counts = getattr(listed_titles, 'counts', Counter(listed_titles))
    views = getattr(listed_titles, 'views', {})
    unattached = getattr(listed_titles, 'unattached', set())
    references = set()
    legacy_names = {title: " ".join(title.split()).casefold() for title in listed_titles | unattached}
    for pdf_file, bucket_key in entries:
        details = (metadata or {}).get(pdf_file, {})
        reference = details.get('uploadReference')
        legacy = legacy_document_titles(pdf_file, metadata)
        if legacy_title_transform:
            legacy |= {legacy_title_transform(value + '.pdf') for value in tuple(legacy)}
        normalized = {" ".join(title.split()).casefold() for title in legacy if title}
        candidates = {title for title, name in legacy_names.items() if title == reference or name in normalized}
        matches = candidates & listed_titles

        def needs_review(reason):
            return DocumentUploadError(pdf_file, 'Reconciling attached documents', 'DOCUMENT_MATCH_AMBIGUOUS', reason)

        if reference:
            if reference in references:
                raise needs_review('Two prepared entries have the same document reference. Review the prepared document list.')
            references.add(reference)
        if candidates & unattached:
            raise needs_review('The matching document is listed but is not attached. Review its portal entry before uploading again.')
        if len(matches) > 1 or matches & used or any(counts[title] != 1 for title in matches):
            raise needs_review('Existing attachments cannot be matched uniquely to this document. Review the existing draft.')
        if not matches:
            if (legacy_descriptions or {}).get(pdf_file) in getattr(listed_titles, 'descriptions', set()):
                raise needs_review('An older attachment has the same description but no verifiable reference. Review it before uploading another copy.')
            pending.append((pdf_file, bucket_key))
            continue
        match = next(iter(matches))
        # A portal user can replace the PDF while keeping the saved reference.
        _confirm_saved_attachment(driver, pdf_file, details, views.get(match, []), pdf_folder)
        used.add(match)

    # Earlier Agent references include the hash, so an unmatched one can be an
    # older revision of a pending file. Keep it for human review.
    unmatched = (listed_titles | unattached) - used - references
    if pending and any(re.fullmatch(r'AP[a-f0-9]{18}', title) for title in unmatched):
        raise DocumentUploadError(pending[0][0], 'Reconciling attached documents', 'DOCUMENT_MATCH_AMBIGUOUS',
                                  'An existing Agent attachment is outside the prepared list and may be an older revision. Review the existing attachments before uploading another copy.')
    return pending

class DocumentPreparationError(RuntimeError):
    """A known document step failed; keep the raw Selenium/file error in its cause."""

    def __init__(self, operation):
        self.operation = operation
        super().__init__(
            f"Supporting documents stopped while {operation.lower()}. "
            "Review the existing eBuilding Standards draft before continuing."
        )


def safe_document_text(value, limit=500):
    """Only bounded portal messages/filenames go into callbacks, never tracebacks."""
    value = re.sub(r"(?i)(bearer\s+)[A-Za-z0-9._~+/=-]+", r"\1[REDACTED]", str(value or ""))
    value = re.sub(
        r"(?i)(password|passwd|token|cookie|authorization)(\s*[:=]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;]+)",
        r"\1\2[REDACTED]", value,
    )
    return " ".join(value.split())[:limit]


class DocumentUploadError(DocumentPreparationError):
    """An observed document failure with safe, durable, actionable evidence."""

    def __init__(self, filename, operation, reason_code, reason, *, portal_message="", uploaded_count=0):
        self.operation = operation
        self.filename = safe_document_text(os.path.basename(str(filename).replace("\\", "/")), 255)
        self.reason_code = reason_code
        self.reason = safe_document_text(reason)
        self.portal_message = safe_document_text(portal_message)
        self.uploaded_count = uploaded_count
        message = f"Could not upload '{self.filename}': {self.reason}" if self.filename else f"Document preparation stopped: {self.reason}"
        RuntimeError.__init__(self, message[:500])

    def diagnostic(self):
        return {
            "filename": self.filename,
            "operation": self.operation[:200],
            "reasonCode": self.reason_code,
            "reason": self.reason,
            "portalMessage": self.portal_message or None,
            "uploadedCount": self.uploaded_count,
        }

    def next_action(self, portal_name):
        actions = {
            "DOCUMENT_LIST_UNREADABLE": "Review the existing attachment list. The Agent could not establish which files are attached and did not repeat uploads.",
            "DOCUMENT_MATCH_AMBIGUOUS": "Compare the listed document references and keep the correct file versions before resuming.",
            "LOCATION_PLAN_UNVERIFIED": "View the attached location plan and compare it with the prepared PDF before continuing. The Agent could not verify it and did not replace it.",
            "LOCATION_PLAN_MISMATCH": "Compare the attached location plan with the prepared PDF. Keep the intended version in the existing draft before resuming; the Agent did not replace it.",
            "PAPER_SIZE_NEEDS_REVIEW": "Confirm this document's paper size in Architect Pro, then prepare the application again.",
            "DOWNLOAD_MISMATCH": "Prepare this application again to download the expected file version.",
            "DUPLICATE_DOCUMENT": "Compare this file with the document already attached. Keep the correct copy; replace an older revision manually rather than upload another copy.",
            "FILE_TOO_LARGE": "Reduce or split this PDF to meet the size limit stated by the portal, then attach the corrected file.",
            "PDF_PROTECTED": "Export an unprotected PDF from the original document, then attach the corrected file.",
            "FILE_TYPE_REJECTED": "Export the document in a file format accepted by the portal, then attach the corrected file.",
            "TITLE_INVALID": "Correct the document title or description using the portal's stated character and length rules, then save this file.",
            "LOCAL_FILE_MISSING": "Download this document again from Architect Pro and attach it to the existing draft.",
            "PORTAL_CONTROL_UNAVAILABLE": "Check the indicated document field in the portal. The expected control was unavailable; complete this step manually in the existing draft.",
            "UPLOAD_UNCONFIRMED": (
                "Check whether this file is already attached. Upload it only if it is absent; its previous upload outcome could not be confirmed."
                if self.filename else "Open the existing draft and check whether the supporting documents section was saved before continuing."
            ),
            "PORTAL_VALIDATION_REJECTED": "Correct the fields identified in the portal message, then save this file in the existing draft.",
            "PORTAL_ERROR_UNSPECIFIED": "The portal did not identify the cause. Check whether this file is already attached before trying again. Keep the correct copy; if the same general error persists, complete the document step in the portal or contact portal support.",
        }
        section = "Location Plan" if "location plan" in self.operation.lower() else "Supporting Documents"
        return f"Open {section} in the existing {portal_name} draft. {actions.get(self.reason_code, actions['PORTAL_VALIDATION_REJECTED'])}"[:500]


def rejected_document_error(filename, portal_message, *, operation="Saving supporting document"):
    message = safe_document_text(portal_message)
    lower = message.lower()
    generic = lower.rstrip(" .") == "an issue which requires your attention has occurred on this page"
    if generic:
        code = "PORTAL_ERROR_UNSPECIFIED"
    elif any(word in lower for word in ("already exists", "already been uploaded", "already been attached", "duplicate", "must be unique")):
        code = "DUPLICATE_DOCUMENT"
    elif any(word in lower for word in ("file size", "filesize", "too large", "maximum size", "size limit")):
        code = "FILE_TOO_LARGE"
    elif any(word in lower for word in ("encrypted", "password protected", "password-protected")):
        code = "PDF_PROTECTED"
    elif any(word in lower for word in ("file type", "file format", "extension", "content type")):
        code = "FILE_TYPE_REJECTED"
    elif any(word in lower for word in ("title", "description", "drawing reference")):
        code = "TITLE_INVALID"
    else:
        code = "PORTAL_VALIDATION_REJECTED"
    reason = (f"The portal displayed a general error after Save without identifying the cause: {message}"
              if generic else f"The portal rejected the document: {message}")
    return DocumentUploadError(filename, operation, code, reason[:500], portal_message=message)


def document_step(driver, filename, operation, action, *, retry_detached=False):
    """Reacquire safe preparation fields; never replay an uncertain Save."""
    for attempt in range(3 if retry_detached else 1):
        try:
            return action()
        except DocumentUploadError:
            raise
        except FileNotFoundError as exc:
            raise DocumentUploadError(filename, operation, "LOCAL_FILE_MISSING",
                                      "The downloaded file could not be found on the Agent computer.") from exc
        except WebDriverException as exc:
            if is_detached_node_error(exc) and retry_detached and attempt < 2:
                continue
            if not (is_detached_node_error(exc) or isinstance(exc, (TimeoutException, NoSuchElementException))):
                raise
            error = get_visible_portal_error(driver)
            if error:
                raise rejected_document_error(filename, error, operation=operation) from exc
            code = "UPLOAD_UNCONFIRMED" if operation.startswith("Saving") else "PORTAL_CONTROL_UNAVAILABLE"
            reason = ("The portal did not confirm Save. Check whether the file or section is already saved before continuing."
                      if code == "UPLOAD_UNCONFIRMED" else f"The portal control needed for {operation.lower()} was unavailable or kept being replaced.")
            raise DocumentUploadError(filename, operation, code, reason) from exc


def fit_document_text(driver, element_id, value, filename, *, identity=False, minimum_prefix=0):
    element = get_when_present(driver, By.ID, element_id)
    limit = element.get_attribute('maxlength')
    if not str(limit or '').isdigit() or int(limit) <= 0 or len(value) <= int(limit):
        return value
    if identity or int(limit) < minimum_prefix:
        raise DocumentUploadError(filename, 'Preparing document reference', 'TITLE_INVALID',
                                  'The portal reference field is shorter than the prepared document reference. No upload was attempted.')
    return value[:int(limit)].rstrip()


def show_browser_completion_toast(driver):
    """
    Inject a small, non-blocking completion toast into the current page.
    Idempotent: if already present, it will not create a duplicate.
    """
    driver.execute_script(
        """
        (function () {
            const existing = document.getElementById('bw-automation-complete-toast');
            if (existing) {
                return;
            }

            const toast = document.createElement('div');
            toast.id = 'bw-automation-complete-toast';
            toast.setAttribute('role', 'status');
            toast.setAttribute('aria-live', 'polite');
            toast.style.cssText = [
                'position:fixed',
                'right:16px',
                'bottom:16px',
                'z-index:2147483647',
                'max-width:380px',
                'min-width:280px',
                'padding:12px 14px',
                'border-radius:10px',
                'background:#1f2937',
                'color:#f9fafb',
                'box-shadow:0 10px 26px rgba(0,0,0,0.28)',
                'font-family:Arial, Helvetica, sans-serif',
                'font-size:13px',
                'line-height:1.4',
                'pointer-events:auto',
                'opacity:0',
                'transform:translateY(8px)',
                'transition:opacity .2s ease, transform .2s ease'
            ].join(';');

            const title = document.createElement('div');
            title.textContent = 'Automation complete';
            title.style.cssText = 'font-weight:700;font-size:14px;margin:0 28px 6px 0;';

            const message = document.createElement('div');
            message.textContent = 'Complete any final manual steps here. Then return to the GUI if you want to prepare another application.';
            message.style.cssText = 'margin:0;opacity:0.95;';

            const closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.textContent = '×';
            closeBtn.setAttribute('aria-label', 'Dismiss notification');
            closeBtn.style.cssText = [
                'position:absolute',
                'top:6px',
                'right:8px',
                'width:22px',
                'height:22px',
                'border:none',
                'border-radius:999px',
                'background:transparent',
                'color:#e5e7eb',
                'cursor:pointer',
                'font-size:16px',
                'line-height:20px',
                'padding:0'
            ].join(';');

            function removeToast() {
                if (!toast || !toast.parentNode) return;
                toast.style.opacity = '0';
                toast.style.transform = 'translateY(8px)';
                window.setTimeout(function () {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 180);
            }

            closeBtn.addEventListener('click', removeToast);

            toast.appendChild(title);
            toast.appendChild(message);
            toast.appendChild(closeBtn);

            document.body.appendChild(toast);

            window.requestAnimationFrame(function () {
                toast.style.opacity = '1';
                toast.style.transform = 'translateY(0)';
            });

            window.setTimeout(removeToast, 12000);
        })();
        """
    )


def dismiss_gdpr_modal_if_present(driver, timeout=2):
    """
    Safely closes the GDPR modal if it appears.
    Returns quickly when the modal is not present.
    Safe to call multiple times.
    """
    modal_selector = ".gdprModalWrapper.show"

    try:
        # Fast check first: if modal is not already present/visible, leave immediately.
        modals = driver.find_elements(By.CSS_SELECTOR, modal_selector)
        visible_modals = [m for m in modals if m.is_displayed()]
        if not visible_modals:
            return

        # Modal is present, now handle it properly.
        possible_xpaths = [
            "//button[contains(.,'Accept')]",
            "//button[contains(.,'I Agree')]",
            "//button[contains(.,'Agree')]",
            "//button[contains(.,'OK')]",
            "//a[contains(.,'Accept')]"
        ]

        clicked = False
        for xp in possible_xpaths:
            try:
                btn = WebDriverWait(driver, 1).until(
                    EC.element_to_be_clickable((By.XPATH, xp))
                )
                btn.click()
                clicked = True
                break
            except Exception:
                continue

        # If we clicked something, wait briefly for the modal to disappear.
        if clicked:
            WebDriverWait(driver, timeout).until(
                EC.invisibility_of_element_located((By.CSS_SELECTOR, modal_selector))
            )
            print("Dismissed GDPR modal.")

    except Exception:
        # Stay non-fatal: this helper should never block the main flow.
        pass


def get_visible_portal_error(driver):
    """Return visible ASP.NET-style validation text if the portal exposes it."""
    if hasattr(driver, "execute_script"):
        try:
            messages = driver.execute_script("""
                return Array.from(window.Page_Validators || []).filter(v => {
                    const control = document.getElementById(v.controltovalidate);
                    return v.isvalid === false && v.enabled !== false && document.contains(v)
                        && (!control || control.getClientRects().length > 0);
                }).map(v => v.errormessage || v.textContent || '').filter(Boolean);
            """)
            if isinstance(messages, list) and messages:
                return " ".join(str(value) for value in messages if value).strip()
        except WebDriverException as exc:
            if not is_detached_node_error(exc):
                raise
    selectors = [
        "#MainContent_validationSummary",
        ".alert-error",
        ".validation-summary-errors",
        ".field-validation-error",
        "[id*='ValidationSummary']",
        "[id*='validationSummary']",
        "[aria-invalid='true'][role='alert']",
        "[role='alert']",
    ]
    messages = []
    for selector in selectors:
        try:
            for element in driver.find_elements(By.CSS_SELECTOR, selector):
                if element.is_displayed():
                    # Alerts also carry success/information notices. These are
                    # not evidence that an upload was rejected.
                    classes = str(element.get_attribute("class") or "").lower() if hasattr(element, "get_attribute") else ""
                    if any(name in classes for name in ("alert-success", "alert-info")):
                        continue
                    text = element.text.strip()
                    if text and text not in messages:
                        messages.append(text)
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                continue
            raise
    detailed = [message for message in messages if message.lower().rstrip(" .") !=
                "an issue which requires your attention has occurred on this page"]
    return " ".join((detailed or messages)[:10])


def click_supporting_document_save(driver, filename, action, *, operation="Saving supporting document"):
    """Send Save once; the caller checks the resulting portal state."""
    try:
        document_step(driver, filename, operation, action)
    except DocumentUploadError as exc:
        if exc.reason_code != "UPLOAD_UNCONFIRMED":
            raise


def wait_for_supporting_doc_upload_result(
    driver,
    pdf_file,
    timeout=30,
    expected_title=None,
):
    """
    Wait for the supporting-doc upload to either return to the add-document
    state or show an obvious validation error.
    """
    add_doc_ids = (
        "MainContent_SupportingDocumentationWizard_btnAddDocumentation",
        "MainContent_btnAddDocumentation",
    )

    def upload_finished_or_failed(d):
        error_text = get_visible_portal_error(d)
        if error_text:
            return ("error", error_text)
        try:
            # An Add button can coexist with an unsaved editor. It does not
            # establish success until the upload editor has closed.
            for editor_id in ("MainContent_fuAttachFile", "MainContent_SupportingDocumentationWizard_fuAttachFile"):
                if any(element.is_displayed() for element in d.find_elements(By.ID, editor_id)):
                    return False
            for add_doc_id in add_doc_ids:
                add_buttons = d.find_elements(By.ID, add_doc_id)
                for add_btn in add_buttons:
                    if add_btn.is_displayed() and add_btn.is_enabled():
                        if expected_title is not None:
                            titles = _attachment_titles(d)
                            if titles is None or expected_title not in titles:
                                return False
                            if titles.counts[expected_title] != 1 or expected_title in titles.unattached:
                                raise DocumentUploadError(
                                    pdf_file, "Confirming supporting document upload", "DOCUMENT_MATCH_AMBIGUOUS",
                                    "The portal lists conflicting entries for the saved reference. Review them before continuing.",
                                )
                        return ("ready", add_btn)
        except StaleElementReferenceException:
            return False
        except WebDriverException as exc:
            if is_detached_node_error(exc):
                return False
            raise
        return False

    try:
        result_type, result_value = WebDriverWait(driver, timeout).until(upload_finished_or_failed)
    except TimeoutException as exc:
        error_text = get_visible_portal_error(driver)
        if error_text:
            raise rejected_document_error(pdf_file, error_text) from exc
        raise DocumentUploadError(
            pdf_file, "Waiting for supporting document upload confirmation", "UPLOAD_UNCONFIRMED",
            f"The portal did not confirm the saved attachment within {timeout} seconds. Review the existing draft before retrying.",
        ) from exc
    if result_type == "error":
        raise rejected_document_error(pdf_file, result_value)
    return result_value

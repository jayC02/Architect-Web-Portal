"""Agent-contact preflight and validation at the Agent Details transition."""
import re

from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By

from automation.common.uploads import get_visible_portal_error, safe_document_text


class AgentDetailsValidationError(ValueError):
    def __init__(self, message, *, portal_message="", recovery_fields=()):
        super().__init__(message)
        self.portal_message = safe_document_text(portal_message)
        self.recovery_fields = tuple(recovery_fields)


class AgentDetailsConfirmationError(RuntimeError):
    pass


def validate_agent_phone(user_inputs):
    value = str(user_inputs.get("Agent Telephone Number") or "").strip()
    if not value:
        raise AgentDetailsValidationError(
            "Enter the agent telephone number required by eDevelopment before running this application.",
            recovery_fields=("agentPhone",),
        )
    compact = re.sub(r"\s", "", value)
    if len(value) > 30 or not re.fullmatch(r"(?:\+44\d{9,10}|0\d{9,10})", compact):
        raise AgentDetailsValidationError(
            "Enter a valid UK agent telephone number before running this application.",
            recovery_fields=("agentPhone",),
        )


def advance_from_agent_details(driver, action, first_name_id):
    """Run Next once; a failed destination wait does not blame the applicant."""
    try:
        return action()
    except (RuntimeError, TimeoutException) as exc:
        # Only a validation message on the still-visible Agent Details screen
        # establishes an agent-data problem. A timeout alone does not.
        try:
            agent_visible = any(element.is_displayed() for element in driver.find_elements(By.ID, first_name_id))
        except StaleElementReferenceException:
            agent_visible = False
        if agent_visible:
            message = get_visible_portal_error(driver)
            if message:
                message = safe_document_text(message)
                raise AgentDetailsValidationError(
                    f"The portal rejected Agent Details: {message}", portal_message=message,
                ) from exc
        raise AgentDetailsConfirmationError(
            "The portal did not confirm the next step after Agent Details. "
            "Review the existing draft before continuing; Next was not repeated."
        ) from exc

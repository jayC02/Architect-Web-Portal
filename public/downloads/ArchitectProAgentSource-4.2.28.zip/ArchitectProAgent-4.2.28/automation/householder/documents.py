# -*- coding: utf-8 -*-
import os
import re
import hashlib

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from automation.common.actions import (
    is_detached_node_error,
    select_by_text,
    select_option_by_id,
    type_into,
    wait_dom_ready,
)
from automation.common.documents import (
    _extract_pdf_first_page_text,
    extract_title_and_description,
    get_document_type_from_pdf,
    get_paper_size_from_pdf,
    load_supporting_docs_upload_list,
)
from automation.common.document_metadata import document_title, document_paper_size, supporting_document_metadata
from automation.common.uploads import (
    DocumentUploadError,
    dismiss_gdpr_modal_if_present,
    get_visible_portal_error,
    rejected_document_error,
    wait_for_supporting_doc_upload_result,
    click_supporting_document_save,
    listed_document_titles, documents_still_to_upload, document_step,
)
from automation.common.runtime import record_checkpoint
from automation.common.location_plan import PLANNING_LOCATION_PLAN, resume_attached_location_plan
from automation.householder.navigation import (
    click_by_id,
    click_checklist_next,
    click_label_for_any,
)

HOUSEHOLDER_CHECKLIST_YES_IDS = [
    "MainContent_HouseholderApplicationChecklistWizard_rblWrittenDescription_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblPostalAddress_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblApplicantName_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblLocationPlan_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblCertificateOwnership_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblFeeProvided_0",
    "MainContent_HouseholderApplicationChecklistWizard_rblOtherPlans_0",
]

HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS = {
    "elevations": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_0",
    "floor_plans": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_1",
    "sections": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_2",
    "site_or_block_plan": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_3",
    "roof_plan": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_4",
    "photos": "MainContent_HouseholderApplicationChecklistWizard_cblElectronicDocuments_5",
}

LOCATION_PLAN_SECTION_ID = "MainContent_FormSections_btnLocationPlan"
LOCATION_PLAN_CONTINUE_ID = "MainContent_LocationPlanWizard_btnContinueAddLocationPlan"
LOCATION_PLAN_UPLOADED_ID = "MainContent_LocationPlanWizard_rbUploaded"
LOCATION_PLAN_OPTIONS_CONTINUE_ID = "MainContent_LocationPlanWizard_btnContinueLocationPlanOptions"
LOCATION_PLAN_FILE_ID = "MainContent_LocationPlanWizard_LocPlanFileUpload"
LOCATION_PLAN_PAPER_SIZE_ID = "MainContent_LocationPlanWizard_ddlPaperSizeUploadLocPlan"
LOCATION_PLAN_DOCUMENT_TYPE_ID = "MainContent_LocationPlanWizard_ddlDocTypeUploadLocPlan"
LOCATION_PLAN_PRINTED_ID = "MainContent_LocationPlanWizard_cbFilePrinted"
LOCATION_PLAN_ANNOTATED_ID = "MainContent_LocationPlanWizard_cbFileAnnotated"
LOCATION_PLAN_SAVE_ID = "MainContent_LocationPlanWizard_btnUploadUploadLocationPlan"
LOCATION_PLAN_CONFIRM_ID = "MainContent_btnConfirm"


def _filename_has_any(filename, keywords):
    text = str(filename or "").lower()
    return any(keyword in text for keyword in keywords)


def normalise_supporting_document_title(filename, *, allow_empty=False):
    base = os.path.splitext(os.path.basename(str(filename or "")))[0]
    title = re.sub(r"[^A-Za-z0-9]+", "_", base).strip("_")
    if not title:
        if allow_empty:
            return ""
        raise RuntimeError(
            "Supporting document upload: the filename does not contain an alphanumeric title."
        )
    if not title[0].isalpha():
        title = f"D_{title}"
    return title


def normalise_supporting_document_description(description):
    value = re.sub(r"[^A-Za-z0-9 _]+", " ", str(description or ""))
    value = re.sub(r"\s+", " ", value).strip()
    if not value:
        raise RuntimeError(
            "Supporting document upload: the description does not contain alphanumeric text."
        )
    return value


def _document_step(driver, filename, operation, action, *, retry_detached=False):
    return document_step(driver, filename, operation, action, retry_detached=retry_detached)


def _fit_document_field(driver, element_id, value, *, unique=False, filename=""):
    """Use the actual portal limit; keep long titles distinct after shortening."""
    elements = driver.find_elements(By.ID, element_id)
    limit = elements[0].get_attribute("maxlength") if elements else None
    if not str(limit or "").isdigit() or int(limit) <= 0 or len(value) <= int(limit):
        return value
    limit = int(limit)
    if unique and re.fullmatch(r'AP[a-f0-9]{18}', value):
        raise DocumentUploadError(filename, "Preparing document reference", "TITLE_INVALID",
                                  "The portal reference field is shorter than the prepared document reference. No upload was attempted.")
    if unique:
        if limit < 10:
            raise DocumentUploadError(filename, "Preparing document title", "TITLE_INVALID",
                                      "The portal title limit is too short to create a distinct reference safely.")
        suffix = hashlib.sha256(value.encode("utf-8")).hexdigest()[:8]
        value = f"{value[:limit - 9]}_{suffix}"
    else:
        value = value[:limit].rstrip()
    print(f"Adjusted document field to the portal's {limit}-character limit.")
    return value


def householder_electronic_document_ids(
    upload_entries,
    location_plan_file=None,
    pdf_folder_path=None,
):
    """
    Map the saved PDF buckets to the second Householder checklist page.
    Returns checkbox element IDs that should be selected.
    """
    entries = list(upload_entries or [])
    if location_plan_file:
        entries.append((location_plan_file, "location_plan"))

    bucket_files = {}
    for filename, bucket_key in entries:
        bucket_files.setdefault(str(bucket_key or ""), []).append(str(filename or ""))

    all_files = [filename for filenames in bucket_files.values() for filename in filenames]
    drawing_text = ""
    if pdf_folder_path:
        drawing_buckets = {"existing", "proposed", "elevations", "sections", "details", "other"}
        drawing_text = " ".join(
            _extract_pdf_first_page_text(os.path.join(pdf_folder_path, filename))
            for filename, bucket_key in entries
            if bucket_key in drawing_buckets
        ).lower()

    selected_keys = []

    if (
        bucket_files.get("elevations")
        or any(_filename_has_any(name, ["elevation"]) for name in all_files)
        or re.search(r"\belevations?\b", drawing_text)
    ):
        selected_keys.append("elevations")

    if (
        bucket_files.get("existing")
        or bucket_files.get("proposed")
        or any(_filename_has_any(name, ["floor", "existing plan", "proposed plan"]) for name in all_files)
    ):
        selected_keys.append("floor_plans")

    if (
        bucket_files.get("sections")
        or any(_filename_has_any(name, ["section"]) for name in all_files)
        or re.search(r"\b(?:cross\s+)?sections?\b", drawing_text)
    ):
        selected_keys.append("sections")

    if (
        any(_filename_has_any(name, ["site", "block", "layout", "access"]) for name in all_files)
        or re.search(r"\bsite\s+(?:layout\s+)?plans?\b|\bblock\s+plans?\b", drawing_text)
    ):
        selected_keys.append("site_or_block_plan")

    if (
        any(_filename_has_any(name, ["roof"]) for name in all_files)
        or re.search(r"\broof\s+plans?\b", drawing_text)
    ):
        selected_keys.append("roof_plan")

    if (
        bucket_files.get("photos")
        or any(_filename_has_any(name, ["photo", "photomontage"]) for name in all_files)
        or re.search(r"\bphotos?\b|\bphotomontages?\b", drawing_text)
    ):
        selected_keys.append("photos")

    return [HOUSEHOLDER_ELECTRONIC_DOCUMENT_IDS[key] for key in selected_keys]


def _optional_email_copy_state(driver):
    try:
        checkboxes = driver.find_elements(By.ID, "MainContent_cbUseEmail")
        if not checkboxes:
            return None
        return "selected" if checkboxes[0].is_selected() else "unselected"
    except StaleElementReferenceException:
        return None
    except WebDriverException as exc:
        if is_detached_node_error(exc):
            return None
        raise


def complete_email_notification(driver):
    click_by_id(driver, "MainContent_FormSections_btnEmailNotification", "Email Notification section", timeout=30)
    state = WebDriverWait(driver, 30, poll_frequency=0.1).until(_optional_email_copy_state)
    if state == "selected":
        click_label_for_any(
            driver,
            ["MainContent_cbUseEmail"],
            "Disable additional notification email copies",
        )
        WebDriverWait(driver, 5, poll_frequency=0.1).until(
            lambda current: _optional_email_copy_state(current) == "unselected"
        )
    click_by_id(driver, "MainContent_btnConfirm", "Email notification confirm", timeout=30)
    print("Email Notification complete.")


def complete_checklist(
    driver,
    upload_entries=None,
    location_plan_file=None,
    pdf_folder_path=None,
):
    click_by_id(driver, "MainContent_FormSections_btnChecklist", "Checklist section", timeout=30)

    for element_id in HOUSEHOLDER_CHECKLIST_YES_IDS:
        select_option_by_id(driver, element_id, f"Householder checklist yes: {element_id}", timeout=30)

    click_checklist_next(driver)

    electronic_document_ids = householder_electronic_document_ids(
        upload_entries,
        location_plan_file,
        pdf_folder_path,
    )
    if len(electronic_document_ids) < 2:
        raise RuntimeError(
            "Householder checklist: the prepared documents support fewer than two "
            "portal drawing categories. Review the document mapping before retrying."
        )

    for element_id in electronic_document_ids:
        select_option_by_id(driver, element_id, f"Householder electronic document: {element_id}", timeout=30)

    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationChecklistWizard_rblAdditionalSurveys_1",
        "Additional surveys: No",
        timeout=30,
    )
    select_option_by_id(
        driver,
        "MainContent_HouseholderApplicationChecklistWizard_rblSupportingStatement_1",
        "Supporting statement: No",
        timeout=30,
    )

    click_checklist_next(driver)
    click_checklist_next(driver, finish=True)
    try:
        WebDriverWait(driver, 30).until(
            lambda current: current.find_elements(
                By.ID,
                "MainContent_FormSections_btnSupportingDocumentation",
            )
        )
    except TimeoutException as exc:
        raise RuntimeError(
            "Householder checklist: the exact Finish Next control did not return to Form Summary."
        ) from exc
    print("Checklist complete.")


def prepare_supporting_document_upload(driver, *, open_editor=True):
    click_by_id(driver, "MainContent_FormSections_btnSupportingDocumentation", "Supporting Documentation section", timeout=30)
    click_label_for_any(driver, ["MainContent_rbYes"], "Supporting documents: Yes")
    click_by_id(driver, "MainContent_btnContinue", "Supporting documents continue", timeout=30)
    if open_editor:
        choose_next_supporting_document_upload(driver)


def choose_next_supporting_document_upload(driver):
    click_by_id(driver, "MainContent_btnAddDocumentation", "Add another supporting document", timeout=30)
    click_label_for_any(driver, ["MainContent_rbUploaded"], "Supporting document already uploaded")
    click_by_id(driver, "MainContent_btnAttachmentContinue", "Supporting document attachment continue", timeout=30)


def _upload_supporting_document_entry(driver, pdf_file, bucket_key, effective_pdf_folder, bucket_labels, metadata=None):
    """Fill one editor and submit once, retaining the exact failing operation."""
    attach_path = os.path.join(effective_pdf_folder, pdf_file)
    print(f"Uploading supporting document '{pdf_file}' from category '{bucket_key}'.")
    try:
        title = document_title(pdf_file, metadata) if metadata else normalise_supporting_document_title(pdf_file)
    except RuntimeError as exc:
        raise DocumentUploadError(pdf_file, "Preparing document title", "TITLE_INVALID",
                                  "The filename does not contain an alphanumeric document title. Rename the file in Architect Pro.") from exc
    if bucket_key != "other":
        description = bucket_labels.get(bucket_key, bucket_key)
    else:
        _, description = extract_title_and_description(pdf_file, attach_path)
    try:
        description = normalise_supporting_document_description(description)
    except RuntimeError as exc:
        raise DocumentUploadError(pdf_file, "Preparing document description", "TITLE_INVALID",
                                  "The document description does not contain alphanumeric text. Correct its document category or description.") from exc

    title = _fit_document_field(driver, "MainContent_edtDocumentTitle", title, unique=True, filename=pdf_file)
    _document_step(driver, pdf_file, "Entering document title", lambda: type_into(
        driver, By.ID, "MainContent_edtDocumentTitle",
        title), retry_detached=True)
    _document_step(driver, pdf_file, "Entering document description", lambda: type_into(
        driver, By.ID, "MainContent_edtDescription",
        _fit_document_field(driver, "MainContent_edtDescription", description)), retry_detached=True)
    _document_step(driver, pdf_file, "Selecting document paper size", lambda: select_by_text(
        driver, By.ID, "MainContent_lbPaperSize", document_paper_size(attach_path, metadata) if metadata else get_paper_size_from_pdf(attach_path)), retry_detached=True)
    _document_step(driver, pdf_file, "Selecting document type", lambda: select_by_text(
        driver, By.ID, "MainContent_lbDocumentType", get_document_type_from_pdf(attach_path)), retry_detached=True)

    attach_input = _document_step(driver, pdf_file, "Finding document file selector", lambda: WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, "MainContent_fuAttachFile"))))
    _document_step(driver, pdf_file, "Selecting document file", lambda: attach_input.send_keys(attach_path))
    _document_step(driver, pdf_file, "Confirming document declaration", lambda: select_option_by_id(
        driver, "MainContent_rbReadAndUnderstood", "Supporting document read and understood", timeout=30))
    click_supporting_document_save(driver, pdf_file, lambda: click_by_id(
        driver, "MainContent_btnSaveDocEdit", "Save supporting document", timeout=30, submit_fallback=False))
    wait_for_supporting_doc_upload_result(driver, pdf_file, timeout=60, expected_title=title)
    print(f"Uploaded '{pdf_file}' successfully.")


def upload_supporting_document_entries(driver, upload_entries, effective_pdf_folder, bucket_labels, metadata=None):
    for index, (pdf_file, bucket_key) in enumerate(upload_entries):
        try:
            if metadata is None:
                _upload_supporting_document_entry(driver, pdf_file, bucket_key, effective_pdf_folder, bucket_labels)
            else:
                _upload_supporting_document_entry(driver, pdf_file, bucket_key, effective_pdf_folder, bucket_labels, metadata)
        except DocumentUploadError as exc:
            exc.uploaded_count = index
            if not exc.filename:
                exc.filename = os.path.basename(pdf_file)
            raise
        if index < len(upload_entries) - 1:
            try:
                _document_step(driver, upload_entries[index + 1][0], "Opening the next supporting document",
                               lambda: choose_next_supporting_document_upload(driver))
            except DocumentUploadError as exc:
                exc.uploaded_count = index + 1
                raise

    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    try:
        _document_step(driver, "", "Confirming the supporting documents section", lambda: click_label_for_any(
            driver, ["MainContent_rbFinished"], "Supporting documentation finished"))
        _document_step(driver, "", "Saving the supporting documents section", lambda: click_by_id(
            driver, "MainContent_btnDocSave", "Save supporting documentation section", timeout=30, submit_fallback=False))
    except DocumentUploadError as exc:
        exc.uploaded_count = len(upload_entries)
        raise
    print("Supporting Documentation complete.")


def upload_supporting_documents(driver, upload_entries, effective_pdf_folder, bucket_labels, metadata=None):
    if not upload_entries:
        _document_step(driver, '', 'Opening supporting documents', lambda: click_by_id(driver, 'MainContent_FormSections_btnSupportingDocumentation', 'Supporting Documentation section', timeout=30))
        _document_step(driver, '', 'Confirming no additional supporting documents', lambda: click_label_for_any(driver, ['MainContent_rbNo'], 'Supporting documents: No'))
        _document_step(driver, '', 'Saving the supporting documents section', lambda: click_by_id(driver, 'MainContent_btnContinue', 'Supporting documents continue', timeout=30))
        return
    _document_step(driver, upload_entries[0][0] if upload_entries else "", "Opening supporting document upload",
                   lambda: prepare_supporting_document_upload(driver, open_editor=False))
    upload_metadata = supporting_document_metadata(upload_entries, effective_pdf_folder, metadata)
    pending = documents_still_to_upload(
        upload_entries, listed_document_titles(driver), upload_metadata,
        legacy_title_transform=lambda name: normalise_supporting_document_title(name, allow_empty=True),
        driver=driver, pdf_folder=effective_pdf_folder,
    )
    if pending:
        _document_step(driver, pending[0][0], "Opening supporting document editor", lambda: choose_next_supporting_document_upload(driver))
    upload_supporting_document_entries(
        driver,
        pending,
        effective_pdf_folder,
        bucket_labels,
        upload_metadata or metadata,
    )


def load_prepared_householder_documents(pdf_folder_path, mapping_data=None):
    prepared = load_supporting_docs_upload_list(pdf_folder_path, mapping_data=mapping_data)
    upload_entries, location_plan_file, effective_pdf_folder, bucket_labels = prepared
    if not location_plan_file:
        raise FileNotFoundError(
            "A Location Plan is required before Householder automation can continue."
        )

    location_plan_path = os.path.join(effective_pdf_folder, location_plan_file)
    if not os.path.isfile(location_plan_path):
        raise FileNotFoundError(
            f"The Location Plan mapped for Householder automation was not found: {location_plan_path}"
        )
    return (
        upload_entries,
        location_plan_file,
        location_plan_path,
        effective_pdf_folder,
        bucket_labels,
    )


def prepare_location_plan_upload(driver, location_plan_path=None):
    click_by_id(driver, LOCATION_PLAN_SECTION_ID, "Location Plan section", timeout=30)
    if resume_attached_location_plan(driver, location_plan_path, PLANNING_LOCATION_PLAN):
        return True
    click_by_id(driver, LOCATION_PLAN_CONTINUE_ID, "Location plan continue", timeout=30)
    click_label_for_any(driver, [LOCATION_PLAN_UPLOADED_ID], "Location plan already uploaded")
    click_by_id(
        driver,
        LOCATION_PLAN_OPTIONS_CONTINUE_ID,
        "Location plan upload options continue",
        timeout=30,
    )


def upload_location_plan(driver, location_plan_path, metadata=None):
    dismiss_gdpr_modal_if_present(driver)
    wait_dom_ready(driver)
    if prepare_location_plan_upload(driver, location_plan_path):
        return

    file_input = WebDriverWait(driver, 30).until(
        EC.presence_of_element_located((By.ID, LOCATION_PLAN_FILE_ID))
    )
    file_input.send_keys(location_plan_path)
    print("Location Plan file selected.")

    select_by_text(driver, By.ID, LOCATION_PLAN_PAPER_SIZE_ID, document_paper_size(location_plan_path, metadata) if metadata else get_paper_size_from_pdf(location_plan_path))
    select_by_text(driver, By.ID, LOCATION_PLAN_DOCUMENT_TYPE_ID, "OS Extract")
    select_option_by_id(driver, LOCATION_PLAN_PRINTED_ID, "Location plan printed and verified")
    select_option_by_id(driver, LOCATION_PLAN_ANNOTATED_ID, "Location plan file annotated")
    click_by_id(
        driver,
        LOCATION_PLAN_SAVE_ID,
        "Save location plan",
        timeout=30,
        submit_fallback=False,
    )
    try:
        WebDriverWait(driver, 60).until(EC.staleness_of(file_input))
    except TimeoutException as exc:
        error = get_visible_portal_error(driver)
        if error:
            raise rejected_document_error(os.path.basename(location_plan_path), error, operation="Saving location plan") from exc
        raise DocumentUploadError(
            os.path.basename(location_plan_path), "Waiting for location plan upload confirmation", "UPLOAD_UNCONFIRMED",
            "The portal did not confirm the location plan upload within 60 seconds. The file may already be attached; its upload outcome is unknown."
        ) from exc

    error = get_visible_portal_error(driver)
    if error:
        raise rejected_document_error(os.path.basename(location_plan_path), error, operation="Saving location plan")
    click_by_id(driver, LOCATION_PLAN_CONFIRM_ID, "Confirm saved location plan", timeout=30)
    WebDriverWait(driver, 30).until(
        lambda current: current.find_elements(By.ID, "MainContent_FormSections_btnDeclaration")
    )
    print("Location Plan complete.")


def open_declaration(driver):
    click_by_id(driver, "MainContent_FormSections_btnDeclaration", "Declaration section", timeout=30)
    print("Declaration opened.")


def complete_later_householder_sections(
    driver,
    pdf_folder_path,
    user_inputs,
    prepared_documents=None,
):
    (
        upload_entries,
        location_plan_file,
        location_plan_path,
        effective_pdf_folder,
        bucket_labels,
    ) = prepared_documents or load_prepared_householder_documents(pdf_folder_path)

    _document_step(driver, "", "Confirming document email notifications", lambda: complete_email_notification(driver))
    record_checkpoint("email_notification_complete", "email_notification")
    _document_step(driver, "", "Completing the document checklist", lambda: complete_checklist(
        driver, upload_entries, location_plan_file, effective_pdf_folder))
    record_checkpoint("document_checklist_complete", "checklist")
    upload_supporting_documents(driver, upload_entries, effective_pdf_folder, bucket_labels, user_inputs.get("Document Metadata"))
    record_checkpoint("supporting_documents_uploaded", "supporting_documents")
    try:
        metadata = user_inputs.get("Document Metadata")
        _document_step(driver, location_plan_file, "Uploading location plan", lambda: upload_location_plan(driver, location_plan_path, metadata) if metadata else upload_location_plan(driver, location_plan_path))
    except DocumentUploadError as exc:
        exc.uploaded_count = len(upload_entries)
        raise
    record_checkpoint("location_plan_uploaded", "location_plan")

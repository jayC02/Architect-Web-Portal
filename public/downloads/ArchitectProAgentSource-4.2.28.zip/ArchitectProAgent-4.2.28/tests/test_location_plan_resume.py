"""Saved-plan identity, postbacks and failure paths for both portal flows."""
import hashlib

import pytest
from selenium.common.exceptions import StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By

from automation.common import location_plan
from automation.common.uploads import DocumentUploadError
from automation.householder import documents as planning
from completion_fakes import FakeDriver


SUMMARY_ID = 'MainContent_FormSections_btnDeclaration'


@pytest.fixture(params=[location_plan.WARRANT_LOCATION_PLAN, location_plan.PLANNING_LOCATION_PLAN],
                ids=['warrant', 'planning'])
def saved_plan(request, tmp_path):
    controls = request.param
    path = tmp_path / 'location.pdf'
    path.write_bytes(b'%PDF-1.4\nlocation plan bytes\n%%EOF')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    driver = FakeDriver()
    driver.add(controls.view_id, kind='button')
    driver.add(controls.back_id, kind='button', on_click=lambda d: summary(d))
    driver.add(SUMMARY_ID, kind='button')
    driver.visible_ids = {controls.view_id, controls.back_id}
    driver.download_calls = []

    def summary(current):
        current.visible_ids = {SUMMARY_ID}
        current.postback()

    def download(script, view_id):
        driver.download_calls.append(view_id)
        assert script == location_plan.ATTACHED_PLAN_HASH_SCRIPT
        # View produces a PDF response; it does not navigate the current page.
        return {'sha256': digest}

    driver.execute_async_script = download
    return driver, str(path), controls


def test_identical_saved_pdf_returns_to_summary_without_upload_or_remove(saved_plan):
    driver, path, controls = saved_plan
    assert location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1)
    assert driver.download_calls == [controls.view_id]
    assert driver.clicks(controls.back_id) == 1
    assert driver.visible_ids == {SUMMARY_ID}
    assert driver.generation == 1
    assert [entry[1] for entry in driver.log if entry[0] == 'click'] == [controls.back_id]


def test_first_upload_is_left_for_the_existing_upload_flow(saved_plan):
    driver, path, controls = saved_plan
    by, value = controls.initial
    if by == By.XPATH:
        value = value.split("'")[1]
        driver.add_radio(value, 'plan')
    else:
        driver.add(value, kind='button')
    driver.visible_ids = {value}
    assert location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1) is False
    assert driver.download_calls == []
    assert driver.clicks(controls.back_id) == 0


def test_different_saved_pdf_stops_without_changing_the_attachment(saved_plan):
    driver, path, controls = saved_plan
    driver.execute_async_script = lambda *_: {'sha256': '0' * 64}
    with pytest.raises(DocumentUploadError) as caught:
        location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1)
    assert caught.value.reason_code == 'LOCATION_PLAN_MISMATCH'
    assert caught.value.filename == 'location.pdf'
    assert 'Location Plan' in caught.value.next_action('portal')
    assert driver.log == []


@pytest.mark.parametrize('response', [None, {}, {'error': 'view-failed'}, {'sha256': 'invalid'}, {'sha256': None}])
def test_unreadable_or_non_pdf_view_never_counts_as_a_match(saved_plan, response):
    driver, path, controls = saved_plan
    driver.execute_async_script = lambda *_: response
    with pytest.raises(DocumentUploadError) as caught:
        location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1)
    assert caught.value.reason_code == 'LOCATION_PLAN_UNVERIFIED'
    assert driver.log == []


def test_view_timeout_never_repeats_or_removes_a_saved_plan(saved_plan):
    driver, path, controls = saved_plan
    calls = []

    def timed_out(*_):
        calls.append(True)
        raise TimeoutException('private browser diagnostic')

    driver.execute_async_script = timed_out
    with pytest.raises(DocumentUploadError) as caught:
        location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1)
    assert caught.value.reason_code == 'LOCATION_PLAN_UNVERIFIED'
    assert 'private browser diagnostic' not in str(caught.value)
    assert calls == [True]
    assert driver.log == []


def test_missing_prepared_file_does_not_fetch_or_change_the_saved_plan(saved_plan):
    driver, path, controls = saved_plan
    with pytest.raises(DocumentUploadError) as caught:
        location_plan.resume_attached_location_plan(driver, path + '.missing', controls, timeout=.1)
    assert caught.value.reason_code == 'LOCAL_FILE_MISSING'
    assert driver.download_calls == []
    assert driver.log == []


def test_reading_plan_state_reacquires_after_a_postback(saved_plan):
    driver, path, controls = saved_plan
    original = driver.find_elements
    replaced = []

    def find(by, value):
        if not replaced:
            replaced.append(True)
            raise StaleElementReferenceException('postback')
        return original(by, value)

    driver.find_elements = find
    assert location_plan.resume_attached_location_plan(driver, path, controls, timeout=.5)


def test_unknown_location_page_does_not_start_a_new_upload(saved_plan):
    driver, path, controls = saved_plan
    driver.visible_ids = set()
    with pytest.raises(DocumentUploadError) as caught:
        location_plan.resume_attached_location_plan(driver, path, controls, timeout=.1)
    assert caught.value.reason_code == 'LOCATION_PLAN_UNVERIFIED'
    assert driver.download_calls == []
    assert driver.log == []


def test_verified_planning_plan_bypasses_every_upload_control(monkeypatch):
    calls = []
    monkeypatch.setattr(planning, 'dismiss_gdpr_modal_if_present', lambda _: None)
    monkeypatch.setattr(planning, 'wait_dom_ready', lambda _: None)
    monkeypatch.setattr(planning, 'click_by_id', lambda _d, element_id, *_a, **_k: calls.append(element_id))
    monkeypatch.setattr(planning, 'resume_attached_location_plan', lambda _d, path, controls:
                        calls.append((path, controls)) or True)
    planning.upload_location_plan(object(), 'location.pdf')
    assert calls == [planning.LOCATION_PLAN_SECTION_ID, ('location.pdf', location_plan.PLANNING_LOCATION_PLAN)]

import pytest
from selenium.common.exceptions import StaleElementReferenceException

from automation.completion_certificate import submission

from completion_submission_fake import SD, STATEMENTS, FakeSubmission

DOCUMENTS = [
    {"path": "C:/jobs/job/EPC.pdf", "fileHash": "a" * 64, "title": "EPC", "description": "Energy Performance Certificate", "role": "ENERGY_PERFORMANCE_CERTIFICATE"},
    {"path": "C:/jobs/job/CC-100 signed.pdf", "fileHash": "b" * 64, "title": "CC-100 signed", "description": "Certificate of Construction", "role": "CONSTRUCTION_CERTIFICATE"},
]


@pytest.fixture(autouse=True)
def pdf_details(monkeypatch):
    monkeypatch.setattr(submission, "record_checkpoint", lambda *_args, **_kwargs: None)
    monkeypatch.setattr(submission, "get_paper_size_from_pdf", lambda path: "A4")
    monkeypatch.setattr(submission, "get_document_type_from_pdf", lambda path: "Report")


def test_uploads_each_document_with_its_description():
    portal = FakeSubmission()
    submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=2)
    assert portal.uploaded == [
        {"title": "EPC", "description": "Energy Performance Certificate", "paper": "A4", "type": "Report", "file": "C:/jobs/job/EPC.pdf"},
        {"title": "CC-100 signed", "description": "Certificate of Construction", "paper": "A4", "type": "Report", "file": "C:/jobs/job/CC-100 signed.pdf"},
    ]
    assert portal.supporting_saved == "documents"
    assert portal.page == "summary"


def test_add_document_screen_does_not_confirm_a_missing_saved_row():
    portal = FakeSubmission(save_attaches=False)
    with pytest.raises(submission.DocumentUploadError) as caught:
        submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=0)
    assert caught.value.reason_code == "UPLOAD_UNCONFIRMED"
    assert caught.value.filename == "EPC.pdf"
    assert portal.driver.clicks(SD + "btnSaveDocEdit") == 1
    assert portal.supporting_saved is None


def test_an_uncertain_certificate_save_is_never_clicked_again():
    portal = FakeSubmission()

    def lost_save_response(_driver):
        raise StaleElementReferenceException("Save response was lost")

    portal.driver.fields[SD + "btnSaveDocEdit"].on_click = lost_save_response
    with pytest.raises(submission.DocumentUploadError) as caught:
        submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=0)
    assert caught.value.reason_code == "UPLOAD_UNCONFIRMED"
    assert portal.driver.clicks(SD + "btnSaveDocEdit") == 1
    assert portal.supporting_saved is None


@pytest.mark.parametrize('saved', [False, True], ids=['unconfirmed', 'committed'])
def test_completion_section_save_checks_summary_without_clicking_again(saved):
    portal = FakeSubmission()

    def lose_section_save_response(_driver):
        if saved:
            portal._doc_save()
        raise StaleElementReferenceException("Section Save response was lost")

    portal.driver.fields[SD + "btnDocSave"].on_click = lose_section_save_response
    if saved:
        assert submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=0) == 2
        assert portal.supporting_saved == "documents"
    else:
        with pytest.raises(submission.DocumentUploadError) as caught:
            submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=0)
        assert caught.value.reason_code == "UPLOAD_UNCONFIRMED"
        assert caught.value.uploaded_count == 2
        assert portal.supporting_saved is None
    assert portal.driver.clicks(SD + "btnDocSave") == 1


def test_changed_legacy_pdf_stops_before_opening_the_upload_editor():
    portal = FakeSubmission(already_uploaded=["EPC"])
    newer = {**DOCUMENTS[0], "fileHash": "f" * 64}
    with pytest.raises(submission.DocumentUploadError, match="different PDF content"):
        submission.upload_supporting_documents(portal.driver, [newer], timeout=0)
    assert portal.driver.clicks(SD + "btnAddDocumentation") == 0
    assert portal.supporting_saved is None


def test_no_documents_answers_no():
    portal = FakeSubmission()
    submission.upload_supporting_documents(portal.driver, [], timeout=2)
    assert portal.supporting_saved == "none"
    assert portal.uploaded == []
    assert portal.driver.selected(SD + "rbNo")


def test_rerun_skips_documents_already_uploaded():
    portal = FakeSubmission(already_uploaded=["EPC"])
    submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=2)
    assert [item["title"] for item in portal.uploaded] == ["EPC", "CC-100 signed"], "EPC is not uploaded twice"
    assert portal.supporting_saved == "documents"


def test_rerun_with_everything_uploaded_only_saves_the_section():
    portal = FakeSubmission(already_uploaded=["EPC", "CC-100 signed"])
    submission.upload_supporting_documents(portal.driver, DOCUMENTS, timeout=2)
    assert [item["title"] for item in portal.uploaded] == ["EPC", "CC-100 signed"]
    assert portal.driver.clicks(SD + "btnAddDocumentation") == 0
    assert portal.supporting_saved == "documents"


def test_email_notification_is_switched_off_and_confirmed():
    portal = FakeSubmission(email_checked=True)
    submission.complete_email_notification(portal.driver, timeout=2)
    assert portal.email_confirmed == {"notifications": False}
    portal = FakeSubmission(email_checked=False)
    submission.complete_email_notification(portal.driver, timeout=2)
    assert portal.email_confirmed == {"notifications": False}, "an already-unticked box is left alone"


def test_declaration_answers_and_moves_on():
    portal = FakeSubmission()
    submission.complete_declaration(portal.driver, timeout=2)
    assert portal.declaration == {"who": "I", "statement": STATEMENTS[0], "notice": "No", "accepted": True}
    assert portal.page == "after_declaration"


def test_declaration_not_confirmed_fails_without_repeating_next():
    portal = FakeSubmission(declaration_moves_on=False)
    with pytest.raises(RuntimeError, match="Next was not repeated"):
        submission.complete_declaration(portal.driver, timeout=0.5)
    assert portal.driver.clicks(submission.DECLARATION_NEXT_ID) == 1


def test_whole_submission_in_order():
    portal = FakeSubmission()
    stages = []
    submission.complete_submission(portal.driver, DOCUMENTS, stage=lambda name, status, message: stages.append((name, status)), timeout=2)
    assert stages == [("documents", "running"), ("documents", "completed"), ("declaration", "running"), ("declaration", "completed")]
    assert portal.supporting_saved == "documents" and portal.email_confirmed and portal.declaration["accepted"]

"""The warrant's design-certificate register: dropdowns reload after Scheme Type is chosen."""

import pytest

from automation.building_warrant import certificates

from completion_fakes import FakeDriver

PART1 = certificates.REGISTER + "ddlCertifierRegNo1"


class SlowReload(FakeDriver):
    """The prefix options arrive a few looks after the page is first read, as after a postback."""

    def __init__(self, looks_before_loaded):
        super().__init__()
        self.looks_before_loaded = looks_before_loaded
        self.add(PART1, kind="select", options=["..."], value="...")

    def find_elements(self, by, value):
        if value == PART1 and self.looks_before_loaded > 0:
            self.looks_before_loaded -= 1
            if self.looks_before_loaded == 0:
                self.fields[PART1].options = ["...", "BRE1", "NIC1"]
        return super().find_elements(by, value)


def test_waits_for_the_prefix_to_load_after_the_scheme_postback():
    driver = SlowReload(looks_before_loaded=3)
    certificates._select_text(driver, PART1, "BRE1", timeout=2)
    assert driver.value(PART1) == "BRE1"


def test_a_prefix_the_portal_never_offers_names_what_it_does_offer():
    driver = SlowReload(looks_before_loaded=1)
    with pytest.raises(RuntimeError, match=r"'SEL1'.*BRE1, NIC1"):
        certificates._select_text(driver, PART1, "SEL1", timeout=0.5)


# ---- The register pages, as captured from the portal ------------------------------------
# "Following this application" (73%) uses the CertificatesRegister1_ prefix and
# asks for the certifier's and approved body's names. "With this application"
# (71%) uses CertificatesRegister_ and asks for the certificate number and both
# signature dates instead. On both, choosing Scheme Type or the certifier's
# Part 1 prefix posts the page back (onchange setTimeout __doPostBack); the
# reload renders what the server received, so anything typed in between is lost.

import time

PREFIXES = ["...", "BRE1", "BRE2", "RIA1", "RIA2", "SER1"]
POSTBACK = "javascript:setTimeout('__doPostBack(...)', 0)"
FOLLOWING_PREFIX = certificates.PREFIX + "CertificatesRegister1_"
WITH_PREFIX = certificates.PREFIX + "CertificatesRegister_"

INPUTS = {
    "Approved Certifier Design": "Yes",
    "Design Certificate With Application": "No", "Design Certificate Following Application": "Yes",
    "Registration Number (A) Part 1": "SER1", "Registration Number (A) Part 2": "1234", "Name of Certifier": "A Certifier",
    "Registration Number (B) Part 1": "RIA2", "Registration Number (B) Part 2": "5678", "Name of Approved Body": "A Body",
}
WITH_INPUTS = dict(INPUTS, **{
    "Design Certificate With Application": "Yes", "Design Certificate Following Application": "No",
    "Design Certificate Number": "DC-77", "Design Certifier Signature Date": "2026-11-02",
    "Design Approved Body Signature Date": "2026-11-03",
})


def register_ids(prefix, with_application):
    ids = {"scheme": prefix + "ddlSchemeType", "a1": prefix + "ddlCertifierRegNo1", "a2": prefix + "ddlCertifierRegNo2",
           "a_number": prefix + "txtCertifierRegNo", "b1": prefix + "ddlApprovedBodyRegNo1",
           "b2": prefix + "ddlApprovedBodyRegNo2", "b_number": prefix + "txtApprovedBodyRegNo", "validate": prefix + "btnValidate"}
    if with_application:
        ids.update(number=prefix + "txtCertificateNumber", a_date="txtCertifierSignatureDate", b_date="txtApprovedBodySignatureDate")
    else:
        ids.update(a_name="txtCertifierName", b_name="txtCertificateANameOfApprovedBody")
    return ids


class RegisterPage(FakeDriver):
    def __init__(self, with_application=False, reload_seconds=0.3, shown=True,
                 validation="There was an issue validating the approved certifier and approved body details."):
        super().__init__()
        self._generation = 0
        self.reload_seconds = reload_seconds
        self.pending = None
        self.reloads = 0
        self.validation = validation
        self.with_application = with_application
        self.ids = register_ids(WITH_PREFIX if with_application else FOLLOWING_PREFIX, with_application)
        if shown:
            self.show_register()

    def show_register(self):
        ids = self.ids
        self.add(ids["scheme"], kind="select", options=["Please select Scheme Type...", "Design"],
                 value="Please select Scheme Type...", on_change=self.schedule_reload)
        self.fields[ids["scheme"]].attributes = {"onchange": POSTBACK}
        self.add(ids["a1"], kind="select", options=PREFIXES, value="...", on_change=self.schedule_reload)
        self.fields[ids["a1"]].attributes = {"onchange": POSTBACK}
        self.add(ids["a2"], kind="select", options=["...", "D"], value="...")
        self.add(ids["b1"], kind="select", options=PREFIXES, value="...")
        self.add(ids["b2"], kind="select", options=["...", "DB"], value="...")
        for key in ("a_number", "b_number", "number", "a_date", "b_date", "a_name", "b_name"):
            if key in ids:
                self.add(ids[key])
        self.add(ids["validate"], kind="button", value="Validation Check", on_click=self.validate)
        for key, element_id in ids.items():   # the details appear once Design is chosen
            if key != "scheme":
                self.fields[element_id].visible = False

    @property
    def generation(self):
        if self.pending and time.monotonic() >= self.pending[0]:
            _due, saved = self.pending
            self.pending = None
            for element_id, value in saved.items():
                self.fields[element_id].value = value
            if self.fields[self.ids["scheme"]].value == "Design":
                for element_id in self.ids.values():
                    self.fields[element_id].visible = True
            self._generation += 1
            self.reloads += 1
        return self._generation

    @generation.setter
    def generation(self, value):
        self._generation = value

    def schedule_reload(self, _driver):
        saved = {element_id: field.value for element_id, field in self.fields.items() if field.kind in ("select", "text")}
        self.pending = (time.monotonic() + self.reload_seconds, saved)

    def validate(self, _driver):
        self.add(self.ids["validate"].replace("btnValidate", "validationErrorMessage"), kind="message", text=self.validation)
        self._generation += 1


def filled(page):
    return {key: page.value(element_id) for key, element_id in page.ids.items() if key != "validate"}


EXPECTED = {"scheme": "Design", "a1": "SER1", "a2": "D", "a_number": "1234", "a_name": "A Certifier",
            "b1": "RIA2", "b2": "DB", "b_number": "5678", "b_name": "A Body"}
WITH_EXPECTED = {"scheme": "Design", "number": "DC-77", "a1": "SER1", "a2": "D", "a_number": "1234", "a_date": "02/11/2026",
                 "b1": "RIA2", "b2": "DB", "b_number": "5678", "b_date": "03/11/2026"}


def test_every_detail_survives_both_reloads():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    assert page.reloads == 2, "Design and the certifier prefix each reload the page"
    assert filled(page) == EXPECTED


def test_the_with_application_register_gets_the_number_and_both_dates():
    page = RegisterPage(with_application=True)
    certificates.fill_design_register(page, WITH_INPUTS, timeout=5, register=certificates.WITH_APPLICATION)
    assert page.reloads == 2
    assert filled(page) == WITH_EXPECTED


def test_a_rerun_over_a_filled_page_changes_nothing():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    page.log.clear()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    assert page.reloads == 2 and filled(page) == EXPECTED
    assert not [entry for entry in page.log if entry[0] in ("click", "select", "type")]


def test_the_portals_validation_problem_message_is_a_failure():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    with pytest.raises(certificates.CertificateValidationError, match="issue validating"):
        certificates.check_certificate_validation(page, timeout=2)


# ---- From the timing question to the right register ---------------------------------------

NEXT = "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnNext"
TIMING = {
    "with": certificates.PREFIX + "rbUploadCertificateOfDesignWithApplication",
    "following": certificates.PREFIX + "rbUploadCertificateOfDesignFollowingApplication",
}


class TimingThenRegister(RegisterPage):
    """The timing question; Next opens the register the portal picks from the answers."""

    def __init__(self, opens=None):
        super().__init__(with_application=False, shown=False, validation="Certifier details validated successfully.")
        self.opens = opens
        for key, element_id in TIMING.items():
            self.add_radio(element_id + "Yes", group=key)
            self.add_radio(element_id + "No", group=key)
        self.add(NEXT, kind="button", value="Next", on_click=self.next)

    def next(self, _driver):
        with_application = self.selected(TIMING["with"] + "Yes") if self.opens is None else self.opens == "with"
        self.with_application = with_application
        self.ids = register_ids(WITH_PREFIX if with_application else FOLLOWING_PREFIX, with_application)
        self.show_register()
        self._generation += 1


@pytest.mark.parametrize("inputs,expected,opens", [(INPUTS, EXPECTED, "following"), (WITH_INPUTS, WITH_EXPECTED, "with")])
def test_the_warrants_timing_answer_decides_which_register_is_filled(inputs, expected, opens):
    page = TimingThenRegister()
    certificates.fill_design_certificate(page, inputs, timeout=5)
    assert page.with_application is (opens == "with")
    assert filled(page) == expected


def test_an_unexpected_register_is_named_instead_of_waiting_for_nothing():
    page = TimingThenRegister(opens="with")    # the warrant says "following", the portal disagrees
    with pytest.raises(RuntimeError, match="supplied with the application"):
        certificates.fill_design_certificate(page, INPUTS, timeout=5)


def test_with_application_needs_the_certificate_number_and_dates():
    missing = dict(WITH_INPUTS, **{"Design Certificate Number": ""})
    with pytest.raises(ValueError, match="Design Certificate Number"):
        certificates.validate_design_certificate(missing)
    certificates.validate_design_certificate(WITH_INPUTS)
    certificates.validate_design_certificate(INPUTS)   # "following" needs neither


def test_names_are_needed_only_for_the_register_that_asks_for_them():
    no_names = {key: value for key, value in WITH_INPUTS.items() if key not in ("Name of Certifier", "Name of Approved Body")}
    certificates.validate_design_certificate(no_names)        # 71% page: number and dates, no names
    following = {key: value for key, value in INPUTS.items() if key != "Name of Certifier"}
    with pytest.raises(ValueError, match="Name of Certifier"):
        certificates.validate_design_certificate(following)   # 73% page: names


def test_the_with_application_register_is_filled_without_names():
    page = RegisterPage(with_application=True)
    no_names = {key: value for key, value in WITH_INPUTS.items() if key not in ("Name of Certifier", "Name of Approved Body")}
    certificates.fill_design_register(page, no_names, timeout=5, register=certificates.WITH_APPLICATION)
    assert filled(page) == WITH_EXPECTED

"""Explicit Chrome regression test; uses an isolated local HTML portal, never eDevelopment.

Run: python -m pytest tests/browser_proposal_location.py -q
"""
from pathlib import Path
from urllib.parse import quote

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By

from automation.common.proposal_creation import (
    BUILDING_WARRANT, HOUSEHOLDER, ProposalCreationError, SeleniumProposalPortal, build_context,
)
from automation.common.driver import create_chrome_driver
from tests.test_proposal_creation import inputs


PORTAL = r"""<!doctype html><html><head><meta charset="utf-8"><title>Local proposal fixture</title></head><body>
<script>
const prefix = 'MainContent_CreateProposalWizard_';
window.fixture = {mode:'manual', council:'', address:'', actions:[], pending:false, skipAddress:false, skipAuthority:false, wrongAddress:false, wrongAuthority:false, omitAddressLabel:false};
window.Sys = {WebForms:{PageRequestManager:{getInstance:()=>({get_isInAsyncPostBack:()=>fixture.pending})}}};
function button(id, value, action) { return `<input type="button" id="${prefix+id}" value="${value}" onclick="${action}">`; }
function render(stage) {
  fixture.stage = stage;
  const address = fixture.wrongAddress ? fixture.address.replace('12 Rowan', '99 Other') : fixture.address;
  if(stage==='home') document.body.innerHTML='<button id="MainContent_newProposal" onclick="fixture.actions.push(\'new\');render(fixture.mode===\'direct\'?\'manual\':[\'postcode\',\'tab\',\'unavailableManual\'].includes(fixture.mode)?\'postcode\':\'entry\')">New Proposal</button>';
  if(stage==='entry') document.body.innerHTML='<h1>Create a New Proposal - Step 1 of 5</h1>'+button('btnContinueNoExact','Continue',"fixture.actions.push('continue');render('manual')");
  if(stage==='postcode') document.body.innerHTML=`<h1>Create a New Proposal</h1><input id="${prefix}txtPostcode1">`+button('btnPostcodeSearch','Postcode Search',"fixture.address='12 Rowan Road, Glasgow, G1 1AA';render('results')")+(fixture.mode==='tab'?button('ProposalLocationTab4_btnNoExact','Enter Address',"fixture.actions.push('tab');render('entry')"):fixture.mode==='unavailableManual'?button('ProposalLocationTab4_btnNoExact','Enter Address',"fixture.actions.push('unavailable-tab')"):'');
  if(stage==='results') document.body.innerHTML=`<table id="${prefix}dgAddressResults"><tr><td><input type="button" name="ctl00$MainContent$CreateProposalWizard$dgAddressResults$ctl02$lnkBtnAddress" id="row-1" value="12 ROWAN ROAD" onclick="render('confirm')"></td><td>Glasgow</td><td>G1 1AA</td></tr></table>`;
  if(stage==='manual') {
    document.body.innerHTML=`<h1>Site Location and Planning Authority</h1><label for="${prefix}SelectAuthorityNameDropdownList">Select Authority Name:</label><select id="${prefix}SelectAuthorityNameDropdownList" onchange="choose(this.value)"><option value="0">Please Select Planning Authority</option><option value="GLA">Glasgow City Council</option><option value="NL">North Lanarkshire Council</option></select><label for="${prefix}txtLocDescEntry">Detailed Location Description: *</label><textarea maxlength="250" id="${prefix}txtLocDescEntry"></textarea><p>Max 240 characters</p>`+button('btnContinueNoExact3','Use as Site Location','useSite()');
    document.getElementById(prefix+'SelectAuthorityNameDropdownList').value=fixture.council||'0';
  }
  if(stage==='confirm') document.body.innerHTML=(fixture.omitAddressLabel?'<h1>Confirm Address</h1>':`<p>Postal Address:</p><p>${address}</p><p>Easting: 123456</p>`)+button('btnConfirmAddr','Confirm Address',"fixture.actions.push('confirm-address');render(fixture.skipAuthority?'details':'authority')");
  if(stage==='authority') document.body.innerHTML=`<p>Local Authority:</p><p>${fixture.wrongAuthority?'North Lanarkshire Council':'Glasgow City Council'}</p>`+button('btnNext2','Next',"fixture.actions.push('confirm-authority');render('details')");
  if(stage==='details') document.body.innerHTML=`<h1>Proposal Name and Details</h1><p>Site Location:</p><p>${address}</p><input id="${prefix}txtProposalName"><textarea id="${prefix}txtProposalDetails"></textarea>`;
}
function useSite() { fixture.address=document.getElementById(prefix+'txtLocDescEntry').value; fixture.actions.push('use'); render(fixture.skipAddress?(fixture.skipAuthority?'details':'authority'):'confirm'); }
function choose(value) { fixture.council=value; fixture.pending=true; setTimeout(()=>{fixture.pending=false;render('manual')},50); }
render('home');
</script></body></html>"""


@pytest.fixture(scope="module")
def browser():
    root = Path(__file__).resolve().parents[1]
    options = webdriver.ChromeOptions()
    options.add_argument('--headless=new')
    options.add_argument('--no-first-run')
    options.add_argument('--disable-background-networking')
    options.add_argument('--disable-extensions')
    driver = create_chrome_driver(options)
    try:
        yield driver
    finally:
        driver.quit()


def setup_portal(browser, application_type=HOUSEHOLDER, **configuration):
    browser.get('data:text/html;charset=utf-8,' + quote(PORTAL))
    browser.execute_script('Object.assign(fixture, arguments[0]); render("home");', configuration)
    return SeleniumProposalPortal(browser, application_type, timeout=3), build_context(inputs(application_type, **{'Local Authority': 'Glasgow City Council'}))


@pytest.mark.parametrize('application_type', [HOUSEHOLDER, BUILDING_WARRANT])
@pytest.mark.parametrize('mode', ['manual', 'direct', 'tab'])
def test_real_dom_manual_route_and_aspnet_style_authority_postback(browser, application_type, mode):
    portal, context = setup_portal(browser, application_type, mode=mode)
    portal.open_new_proposal()
    assert portal.manual_address_available()
    assert portal.enter_manual_site_location(context) == context.site_address
    assert browser.find_element(By.ID, 'MainContent_CreateProposalWizard_txtProposalName').is_displayed()
    data = browser.execute_script('return fixture')
    assert data['council'] == 'GLA'
    assert data['address'] == context.site_address
    assert data['actions'].count('use') == 1
    assert data['actions'][-2:] == ['confirm-address', 'confirm-authority']


def test_existing_proposal_location_editor_does_not_create_a_new_proposal(browser):
    portal, context = setup_portal(browser)
    browser.execute_script('render("manual")')
    assert portal.enter_manual_site_location(context) == context.site_address
    assert 'new' not in browser.execute_script('return fixture.actions')


@pytest.mark.parametrize('skip', ['skipAddress', 'skipAuthority', 'omitAddressLabel'])
def test_versions_that_skip_a_confirmation_still_verify_final_site_location(browser, skip):
    portal, context = setup_portal(browser, **{skip: True})
    portal.open_new_proposal()
    assert portal.enter_manual_site_location(context) == context.site_address


@pytest.mark.parametrize('wrong,blocked', [('wrongAddress', 'confirm-address'), ('wrongAuthority', 'confirm-authority')])
def test_changed_confirmation_stops_before_accepting_wrong_site_or_council(browser, wrong, blocked):
    portal, context = setup_portal(browser, **{wrong: True})
    portal.open_new_proposal()
    with pytest.raises(ProposalCreationError, match='does not match'):
        portal.enter_manual_site_location(context)
    assert blocked not in browser.execute_script('return fixture.actions')


def test_unmatched_authority_uses_only_a_fresh_explicit_user_choice(browser):
    from dataclasses import replace
    portal, context = setup_portal(browser)
    portal.open_new_proposal()
    requests = []
    def choose(request):
        requests.append(request)
        assert request['kind'] == 'authority'
        assert len(request['candidates']) == 2
        return {'action': 'select', 'candidate_id': request['candidates'][0]['candidate_id']}
    assert portal.enter_manual_site_location(replace(context, local_authority=''), address_resolver=choose) == context.site_address
    assert len(requests) == 1


def test_portal_length_limit_never_truncates_the_full_address(browser):
    from dataclasses import replace
    portal, context = setup_portal(browser)
    portal.open_new_proposal()
    with pytest.raises(ProposalCreationError, match='240 character limit'):
        portal.enter_manual_site_location(replace(context, site_address='12 ' + 'Long Road ' * 25 + ', Glasgow, G1 1AA'))
    assert 'use' not in browser.execute_script('return fixture.actions')


@pytest.mark.parametrize('application_type', [HOUSEHOLDER, BUILDING_WARRANT])
@pytest.mark.parametrize('mode', ['postcode', 'unavailableManual'])
def test_original_postcode_search_and_verified_result_remain_available(browser, application_type, mode):
    portal, context = setup_portal(browser, application_type, mode=mode)
    portal.open_new_proposal()
    if mode == 'unavailableManual':
        assert portal.manual_address_available()
        assert portal.enter_manual_site_location(context) == ''
    else:
        assert not portal.manual_address_available()
    portal.search_postcode(context.postcode)
    options, match = portal.collect_address_options(context.site_address)
    assert len(options) == 1 and match.status in {'exact', 'equivalent'}
    assert portal.select_address(match.option, context.site_address) == match.option.display
    assert browser.find_element(By.ID, 'MainContent_CreateProposalWizard_txtProposalName').is_displayed()

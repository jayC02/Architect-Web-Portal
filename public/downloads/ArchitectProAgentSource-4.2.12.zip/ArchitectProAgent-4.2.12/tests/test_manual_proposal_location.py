from dataclasses import replace

import pytest

from automation.common.proposal_creation import (
    BUILDING_WARRANT, HOUSEHOLDER, AddressLookupNeedsChoice, AddressOption,
    ProposalCreationError, authority_key, build_context, create_proposal_and_resume,
    manual_address_readback, manual_site_address,
)
from gui.services.portal_handoff import portal_job_to_values
from tests.test_proposal_creation import FakePortal, MemoryStore, inputs


@pytest.mark.parametrize("left,right", [
    ("Glasgow City Council", "Glasgow City"), ("Glasgow", "Glasgow City Council"),
    ("City of Edinburgh Council", "Edinburgh"), ("Argyll & Bute Council", "Argyll and Bute"),
    ("The Scottish Borders Council", "Scottish Borders"),
    ("Comhairle nan Eilean Siar", "Western Isles Council"),
])
def test_authorities_allow_only_known_name_variants(left, right):
    assert authority_key(left) == authority_key(right)


@pytest.mark.parametrize("left,right", [
    ("North Lanarkshire", "South Lanarkshire"), ("Aberdeen City", "Aberdeenshire"),
    ("East Dunbartonshire", "West Dunbartonshire"), ("Renfrewshire", "East Renfrewshire"),
])
def test_neighbouring_authorities_are_never_fuzzy_matched(left, right):
    assert authority_key(left) != authority_key(right)


def test_full_manual_address_includes_postcode_without_duplicate_or_lost_flat():
    context = build_context(inputs(**{"Site Address": "Flat 2, 12 Rowan Road, Glasgow", "Local Authority": "Glasgow City Council"}))
    assert manual_site_address(context) == "Flat 2, 12 Rowan Road, Glasgow, G1 1AA"
    assert manual_site_address(replace(context, site_address="Flat 2, 12 Rowan Road, Glasgow, G1 1AA")) == "Flat 2, 12 Rowan Road, Glasgow, G1 1AA"
    assert context.local_authority == "Glasgow City Council"
    with pytest.raises(ProposalCreationError, match="disagree"):
        manual_site_address(replace(context, site_address="12 Rowan Road, Glasgow, G2 2BB"))


@pytest.mark.parametrize("label", ["Site Location", "Postal Address", "Detailed Location Description"])
def test_manual_confirmation_and_proposal_details_readback(label):
    assert manual_address_readback(f"{label}:\nFlat 2, 12 Rowan Road,\nGlasgow, G1 1AA\nProposal Name: other data") == "Flat 2, 12 Rowan Road,\nGlasgow, G1 1AA"
    assert manual_address_readback("Proposal Name: not a site address") == ""


class ManualPortal(FakePortal):
    def __init__(self, application_type, fallback=None):
        super().__init__(application_type)
        self.fallback = fallback
        self.offered = fallback is None

    def manual_address_available(self):
        return self.offered

    def search_postcode(self, postcode):
        super().search_postcode(postcode)
        self.offered = True
        if self.fallback == "timeout":
            raise ProposalCreationError("Postcode search", "The portal did not finish updating")

    def read_addresses(self):
        if self.fallback == "incomplete":
            raise AddressLookupNeedsChoice([])
        return []

    def enter_manual_site_location(self, context, *, address_resolver=None):
        self.events.extend([("manual-authority", context.local_authority), ("manual-address", manual_site_address(context)), "confirm-address", "confirm-authority"])
        return manual_site_address(context)


@pytest.mark.parametrize("application_type", [BUILDING_WARRANT, HOUSEHOLDER])
@pytest.mark.parametrize("fallback", [None, "timeout", "empty", "incomplete"])
def test_new_manual_route_and_postcode_failover_resume_without_duplicate_creation(application_type, fallback):
    portal = ManualPortal(application_type, fallback)
    store = MemoryStore()
    values = inputs(application_type, **{"Local Authority": "Glasgow City Council"})
    original = dict(values)
    assert create_proposal_and_resume(object(), values, lambda: "resumed", portal=portal, state_store=store) == "resumed"
    assert ("manual-authority", "Glasgow City Council") in portal.events
    assert portal.events.count("create-proposal") == 1
    assert not any(event[0] == "select-address" for event in portal.events if isinstance(event, tuple))
    if fallback is None:
        assert not any(event[0] == "postcode-search" for event in portal.events if isinstance(event, tuple))
    assert store.resolved == [values["Site Address"]]
    assert values == original, "the immutable job inputs are not rewritten by address recovery"


def test_snapshot_handoff_carries_site_authority_and_project_fallback():
    import json
    from pathlib import Path
    snapshot = json.loads((Path(__file__).parent / "fixtures/automation-job-v2-building-warrant.json").read_text())
    job = {"id": snapshot["metadata"]["jobId"], "projectId": snapshot["metadata"]["projectId"], "type": snapshot["metadata"]["applicationType"], "dataSnapshot": snapshot}
    assert portal_job_to_values(job)["Local Authority"] == "Glasgow City Council"
    snapshot["site"]["localAuthority"] = ""
    snapshot["project"]["localAuthority"] = "North Lanarkshire Council"
    assert portal_job_to_values(job)["Local Authority"] == "North Lanarkshire Council"


@pytest.mark.parametrize('application_type', [BUILDING_WARRANT, HOUSEHOLDER])
def test_restored_postcode_form_can_be_used_when_manual_navigation_is_unavailable(application_type):
    class RestoredPortal(FakePortal):
        def manual_address_available(self):
            return True

        def enter_manual_site_location(self, _context, **_kwargs):
            self.events.append('manual-route-unavailable')
            return ''

    portal = RestoredPortal(application_type)
    assert create_proposal_and_resume(object(), inputs(application_type), lambda: 'resumed', portal=portal, state_store=MemoryStore()) == 'resumed'
    assert 'manual-route-unavailable' in portal.events
    assert portal.events.count('create-proposal') == 1
    assert ('postcode-search', 'G1 1AA') in portal.events


def test_authority_dialog_requires_a_choice_and_does_not_offer_postcode_correction(monkeypatch, tmp_path):
    from PySide6.QtWidgets import QApplication, QPushButton
    from gui.agent_app import AddressResolutionDialog
    application = QApplication.instance() or QApplication([])
    dialog = AddressResolutionDialog({"kind": "authority", "configured_authority": "", "project_address": inputs()["Site Address"], "candidates": [{"candidate_id": "portal-authority-1", "display_text": "Glasgow City Council"}]})
    try:
        assert dialog.windowTitle() == "Select the local authority"
        assert not dialog.continue_button.isEnabled()
        assert not any(button.text() == "Change postcode" and not button.isHidden() for button in dialog.findChildren(QPushButton))
        dialog.candidate_group.buttons()[0].setChecked(True)
        assert dialog.continue_button.isEnabled()
        dialog.use_selected_candidate()
        assert dialog.response == {"action": "select", "candidate_id": "portal-authority-1"}
    finally:
        dialog.close()

"""Architect Pro API snapshot adapter; intentionally outside the runner core."""

from __future__ import annotations

import os

from automation.models import RuntimeJob


def _completion_documents(form_values, downloaded):
    """Completion Certificate uploads, in order, with the local file the Agent downloaded."""
    completion = form_values.get("Completion")
    if not isinstance(completion, dict):
        return None
    by_id = {str(item.get("id") or ""): item for item in downloaded if item.get("localPath")}
    documents, missing = [], []
    for entry in completion.get("documents") or []:
        local = by_id.get(str(entry.get("documentId") or ""))
        filename = str(entry.get("filename") or "document")
        if not local:
            missing.append(filename)
            continue
        documents.append({
            "path": str(local["localPath"]),
            "title": os.path.splitext(filename)[0][:100],
            "description": str(entry.get("description") or "Supporting Document")[:200],
            "role": str(entry.get("role") or "OTHER"),
        })
    if missing:
        raise ValueError("Prepared job is incomplete: these completion documents were not downloaded: " + ", ".join(missing))
    return documents


def runtime_job_from_portal(job, downloaded_documents, download_failures, *, login_email):
    # Portal transport/mapping remains an integration adapter. Selenium and the
    # runner never import this GUI-era service module.
    from gui.services import portal_handoff

    state = portal_handoff.normalise_portal_job(job, downloaded_documents, download_failures)
    if state.blocking_issues:
        raise ValueError("Prepared job is incomplete: " + "; ".join(state.blocking_issues))
    completion_documents = _completion_documents(state.form_values, state.documents)
    local_paths = [str(item.get("localPath") or "") for item in state.documents if item.get("localPath")]
    pdf_folder = os.path.dirname(local_paths[0]) if local_paths else ""
    inputs = dict(state.form_values)
    inputs["Email"] = str(login_email or "").strip()
    if completion_documents is not None:
        inputs["Completion Documents"] = completion_documents
    inputs["PDF Folder Path"] = pdf_folder
    labels = {
        "location_plan": "Location Plan", "proposed": "Proposed Plans",
        "existing": "Existing Plans", "elevations": "Elevations",
        "sections": "Sections", "details": "Details", "calcs": "Calculations",
        "specs": "Specifications", "photos": "Photos", "other": "Other",
    }
    identity = portal_handoff.application_identity_from_job(job)
    return RuntimeJob.from_mapping({
        "job_id": identity["job_id"],
        "application_type": job.get("type") or identity["application_type"],
        "site_label": inputs.get("Site Address") or job.get("title") or "Prepared application",
        "user_inputs": inputs,
        "document_mapping": {
            "pdf_folder_path": pdf_folder,
            "buckets": state.document_buckets,
            "bucket_labels": labels,
        },
        "metadata": {**identity, "state_model": dict(job.get("stateModel") or {})},
    })

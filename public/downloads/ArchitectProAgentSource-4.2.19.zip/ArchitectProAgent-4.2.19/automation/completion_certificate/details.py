"""Completion Certificate → Main Details, screen by screen, in portal order.

Every answer is compared with what the portal already holds and changed only
when it differs, so a rerun steps through saved screens with Next. After each
Next the destination screen is confirmed by one of its own controls; Next is
never repeated.

Fixed answers in this version (see FOLLOW-UPS): a warrant was obtained, the
three notice references are N/A, no dangerous-building notice, acting as agent with registered account details,
the relevant person is an individual who owns the building, the building
address is the warrant's, and the submission covers all the warrant work.

FOLLOW-UPS, not yet supported: relevant person is not the owner; relevant
person is an organisation; a different building address; partial completion.
"""

from __future__ import annotations

from collections.abc import Mapping
from datetime import date

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.support.ui import WebDriverWait

from automation.building_warrant.agent import fill_agent_details
from automation.building_warrant.applicant import fill_applicant_details
from automation.common.actions import click_when_clickable
from automation.common.runtime import record_checkpoint
from automation.completion_certificate.certificates import CONSTRUCTION, DESIGN, fill_register, validate_entries
from automation.completion_certificate.fields import PREFIX, choose, choose_yes_no, portal_date, set_text
from automation.completion_certificate.navigation import (
    FINISH_NEXT_BUTTON_ID,
    NEXT_BUTTON_ID,
    SUPPORTING_DOCUMENTATION_BUTTON_ID,
    _visible,
    click_next,
    ensure_step,
    wait_for_step,
)
from selenium.webdriver.common.by import By

TEXT_LIMIT = 750

WORK_COMPLETED_DATE_ID = "txtDateWorkCompleted"
WARRANT_REFERENCE_ID = PREFIX + "BuildingWarrantDetails_txtBuildingWarrantRefNumber"
WARRANT_DATE_ID = "txtBuildingWarrantDate"
AMENDMENT_DATES_ID = PREFIX + "BuildingWarrantDetails_txtAmendmentDates"
NOTICE_REFERENCE_IDS = (
    PREFIX + "txtBuildingRegComplianceNotice",
    PREFIX + "txtBuildingWarrantEnforcementNotice",
    PREFIX + "txtDefectiveBuildingsNotice",
)
# For now every notice reference is answered N/A, as the warrant workflow does.
NOTICE_REFERENCE_ANSWER = "N/A"
DANGEROUS_NO_ID = PREFIX + "rbDangerousBuildingNo"
AGENT_ID = PREFIX + "ApplicantOrAgent_rbAgent"
ACCOUNT_YES_ID = PREFIX + "ApplicantOrAgent_rbAccountYes"
AGENT_DETAILS_ID = PREFIX + "AgentDetails_txtAgentFirstName"
RELEVANT_PERSON_ID = PREFIX + "ApplicantDetails_txtApplicantFirstName"
OWNER_YES_ID = PREFIX + "rbApplicantOwnerYes"
DIFFERENT_ADDRESS_NO_ID = PREFIX + "rbDifferentAddressNo"
COVERS_ALL_YES_ID = PREFIX + "rbSumissionCoverYes"          # the portal's own spelling
RELAXATION_YES_ID = PREFIX + "rbRelaxationDirectionYes"
RELAXATION_NO_ID = PREFIX + "rbRelaxationDirectionNo"
RELAXATION_REFERENCE_ID = PREFIX + "RelaxationDirections_txtReferenceNumber"
RELAXATION_DATE_ID = "txtRelaxDirDate"
CONSTRUCTION_YES_ID = PREFIX + "CertificatesRegisterQuestion_rbCertificatesAccompanyYes"
CONSTRUCTION_NO_ID = PREFIX + "CertificatesRegisterQuestion_rbCertificatesAccompanyNo"
DESIGN_YES_ID = PREFIX + "rbDesignCertificatesAccompanyYes"
DESIGN_NO_ID = PREFIX + "rbDesignCertificatesAccompanyNo"
FORM_Q_YES_ID = PREFIX + "rbNoticeOfDesignDetailsYes"
FORM_Q_NO_ID = PREFIX + "rbNoticeOfDesignDetailsNo"
EPC_YES_ID = PREFIX + "rbEnergyPerformanceYes"
EPC_NO_ID = PREFIX + "rbEnergyPerformanceNo"
SUSTAINABILITY_YES_ID = PREFIX + "rbSustainabilityYes"
SUSTAINABILITY_NO_ID = PREFIX + "rbSustainabilityNo"
FIRE_SAFETY_YES_ID = PREFIX + "rbFireSafetyYes"
FIRE_SAFETY_NO_ID = PREFIX + "rbFireSafetyNo"
CONTINUING_YES_ID = PREFIX + "rbContinuingRequirementsYes"
CONTINUING_NO_ID = PREFIX + "rbContinuingRequirementsNo"
CONTINUING_TEXT_ID = PREFIX + "txtContinuingRequirements"


def _mapping(value):
    return value if isinstance(value, Mapping) else {}


def _past_date(value, label):
    try:
        portal_date(value)
    except ValueError as exc:
        raise ValueError(f"Enter {label} in Architect Pro before running this completion certificate.") from exc
    if date.fromisoformat(value) > date.today():
        raise ValueError(f"{label[0].upper()}{label[1:]} cannot be in the future. Correct it in Architect Pro.")


def _answered(value, question):
    if not isinstance(value, bool):
        raise ValueError(f"Answer the {question} question in Architect Pro before running this completion certificate.")
    return value


def validate_completion(completion):
    """Refuse incomplete or out-of-range answers before anything touches the portal."""
    if not isinstance(completion, Mapping):
        raise ValueError("Prepare this completion certificate again in Architect Pro.")
    _past_date(completion.get("workCompletedDate"), "the date the work was completed")
    if not str(completion.get("warrantReference") or "").strip():
        raise ValueError("Enter the building warrant reference in Architect Pro before running this completion certificate.")
    _past_date(completion.get("warrantDate"), "the date of the building warrant")
    if len(str(completion.get("amendmentDates") or "")) > TEXT_LIMIT:
        raise ValueError(f"Shorten the amendment dates in Architect Pro to {TEXT_LIMIT} characters or fewer.")

    relaxation = _mapping(completion.get("relaxation"))
    if _answered(relaxation.get("applies"), "relaxation direction"):
        if not str(relaxation.get("reference") or "").strip():
            raise ValueError("Enter the relaxation direction reference in Architect Pro.")
        try:
            portal_date(relaxation.get("date"))
        except ValueError as exc:
            raise ValueError("Enter a valid relaxation direction date in Architect Pro.") from exc

    construction = _mapping(completion.get("constructionCertificates"))
    if _answered(construction.get("accompany"), "certificate of construction"):
        validate_entries(construction.get("entries"), CONSTRUCTION)

    design = _mapping(completion.get("designCertificates"))
    if _answered(design.get("accompaniedWarrant"), "certificates of design"):
        if _answered(design.get("formQRequired"), "Form Q"):
            validate_entries(design.get("entries"), DESIGN)

    _answered(completion.get("energyPerformanceCertificate"), "Energy Performance Certificate")
    _answered(completion.get("sustainabilityStatement"), "statement of sustainability")
    _answered(completion.get("fireSafetyDesignSummary"), "Fire Safety Design Summary")

    continuing = _mapping(completion.get("continuingRequirements"))
    if _answered(continuing.get("applies"), "continuing requirements"):
        text = str(continuing.get("details") or "")
        if not text.strip():
            raise ValueError("List the continuing requirements in full in Architect Pro.")
        if len(text) > TEXT_LIMIT:
            raise ValueError(f"Shorten the continuing requirements in Architect Pro to {TEXT_LIMIT} characters or fewer.")


class _Wizard:
    """Timeouts for one run, so every step waits consistently."""

    def __init__(self, driver, timeout, inline_timeout):
        self.driver = driver
        self.timeout = timeout
        self.inline_timeout = inline_timeout

    def next(self, expected_ids, screen_name):
        return click_next(self.driver, expected_ids=expected_ids, screen_name=screen_name, timeout=self.timeout)

    def reach(self, expected_ids, screen_name):
        return ensure_step(self.driver, expected_ids, screen_name=screen_name,
                           inline_timeout=self.inline_timeout, timeout=self.timeout)

    def text(self, element_id, value):
        return set_text(self.driver, element_id, value, self.timeout)

    def choose(self, radio_id):
        return choose(self.driver, radio_id, self.timeout)

    def yes_no(self, answer, yes_id, no_id):
        return choose_yes_no(self.driver, answer, yes_id, no_id, self.timeout)


def fill_completion_and_warrant(wizard, completion):
    wait_for_step(wizard.driver, WORK_COMPLETED_DATE_ID, screen_name="completion details", timeout=wizard.timeout)
    wizard.text(WORK_COMPLETED_DATE_ID, portal_date(completion["workCompletedDate"]))
    wizard.choose(PREFIX + "rbObtainBWYes")
    wizard.reach(WARRANT_REFERENCE_ID, "building warrant details")
    wizard.text(WARRANT_REFERENCE_ID, str(completion["warrantReference"]).strip())
    wizard.text(WARRANT_DATE_ID, portal_date(completion["warrantDate"]))
    wizard.text(AMENDMENT_DATES_ID, completion.get("amendmentDates") or "")
    # The first notice box confirms the screen, as on the warrant's Notices screen.
    wizard.next(NOTICE_REFERENCE_IDS[0], "notices")


def fill_notices(wizard, _completion):
    for element_id in NOTICE_REFERENCE_IDS:
        wizard.text(element_id, NOTICE_REFERENCE_ANSWER)
    wizard.choose(DANGEROUS_NO_ID)
    wizard.next(AGENT_ID, "relevant person or agent")


def fill_applicant_or_agent(wizard, _completion):
    wizard.choose(AGENT_ID)
    wizard.reach(ACCOUNT_YES_ID, "registered account details")
    wizard.choose(ACCOUNT_YES_ID)
    wizard.next(AGENT_DETAILS_ID, "agent details")


def fill_agent(wizard, user_inputs):
    fill_agent_details(wizard.driver, user_inputs, prefix=PREFIX)
    record_checkpoint("agent_complete", "agent_details")
    wizard.next(RELEVANT_PERSON_ID, "relevant person details")


def fill_relevant_person(wizard, user_inputs, applicant_title_resolution_callback):
    fill_applicant_details(wizard.driver, user_inputs, applicant_title_resolution_callback, prefix=PREFIX)
    record_checkpoint("applicant_complete", "applicant_details")
    wizard.next(OWNER_YES_ID, "building ownership")


def fill_ownership_and_address(wizard, _completion):
    wizard.choose(OWNER_YES_ID)
    wizard.reach(DIFFERENT_ADDRESS_NO_ID, "building address")
    wizard.choose(DIFFERENT_ADDRESS_NO_ID)
    wizard.next(COVERS_ALL_YES_ID, "extent of completion")


def fill_extent_and_relaxation(wizard, completion):
    wizard.choose(COVERS_ALL_YES_ID)
    wizard.reach((RELAXATION_YES_ID, RELAXATION_NO_ID), "relaxation direction")
    relaxation = completion["relaxation"]
    wizard.yes_no(relaxation["applies"], RELAXATION_YES_ID, RELAXATION_NO_ID)
    if relaxation["applies"]:
        wizard.reach(RELAXATION_REFERENCE_ID, "relaxation direction details")
        wizard.text(RELAXATION_REFERENCE_ID, str(relaxation["reference"]).strip())
        wizard.text(RELAXATION_DATE_ID, portal_date(relaxation["date"]))
    wizard.next(CONSTRUCTION_YES_ID, "certificates of construction")


def fill_construction_certificates(wizard, completion):
    construction = completion["constructionCertificates"]
    wizard.yes_no(construction["accompany"], CONSTRUCTION_YES_ID, CONSTRUCTION_NO_ID)
    if construction["accompany"]:
        wizard.next(CONSTRUCTION.prefix + "ddlSchemeType", "certificate of construction details")
        fill_register(wizard.driver, construction["entries"], CONSTRUCTION, timeout=wizard.timeout)
    wizard.next(DESIGN_YES_ID, "certificates of design")


def fill_design_certificates(wizard, completion):
    design = completion["designCertificates"]
    wizard.yes_no(design["accompaniedWarrant"], DESIGN_YES_ID, DESIGN_NO_ID)
    if design["accompaniedWarrant"]:
        wizard.next(FORM_Q_YES_ID, "Notice of Finalisation of Design Details")
        wizard.yes_no(design["formQRequired"], FORM_Q_YES_ID, FORM_Q_NO_ID)
        if design["formQRequired"]:
            wizard.next(DESIGN.prefix + "ddlSchemeType", "Form Q certificate details")
            fill_register(wizard.driver, design["entries"], DESIGN, timeout=wizard.timeout)
    wizard.next(EPC_YES_ID, "Energy Performance Certificate")


def fill_epc(wizard, completion):
    wizard.yes_no(completion["energyPerformanceCertificate"], EPC_YES_ID, EPC_NO_ID)
    wizard.next(SUSTAINABILITY_YES_ID, "statement of sustainability")


def fill_sustainability(wizard, completion):
    wizard.yes_no(completion["sustainabilityStatement"], SUSTAINABILITY_YES_ID, SUSTAINABILITY_NO_ID)
    wizard.next(FIRE_SAFETY_YES_ID, "Fire Safety Design Summary")


def fill_fire_safety(wizard, completion):
    wizard.yes_no(completion["fireSafetyDesignSummary"], FIRE_SAFETY_YES_ID, FIRE_SAFETY_NO_ID)
    wizard.next(CONTINUING_YES_ID, "continuing requirements")


def fill_continuing_requirements(wizard, completion):
    continuing = completion["continuingRequirements"]
    wizard.yes_no(continuing["applies"], CONTINUING_YES_ID, CONTINUING_NO_ID)
    if continuing["applies"]:
        wizard.reach(CONTINUING_TEXT_ID, "continuing requirements details")
        wizard.text(CONTINUING_TEXT_ID, continuing["details"])


def _supporting_documentation_ready(driver):
    for element in driver.find_elements(By.ID, SUPPORTING_DOCUMENTATION_BUTTON_ID):
        try:
            if element.is_displayed() and element.is_enabled():
                return True
        except Exception:  # a postback replaced it; look again on the next poll
            continue
    return False


def confirm_main_details_completed(driver, timeout=60):
    """Main Details is complete once Supporting Documentation can be opened. It is not opened here."""
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.2).until(_supporting_documentation_ready)
    except TimeoutException as exc:
        raise RuntimeError(
            "The portal did not confirm Main Details as completed. "
            "Review the completion certificate in the portal."
        ) from exc


def finish_main_details(wizard, last_screen_ids):
    """Leave the last question screen, click Next on the Review page, and confirm completion.

    The Review page ("Form section complete") has its own Next button from the
    wizard's finish template, with a different id from every other screen's Next.
    """
    click_when_clickable(wizard.driver, By.ID, NEXT_BUTTON_ID, timeout=wizard.timeout)

    def left_last_screen(current):
        if _supporting_documentation_ready(current):
            return "completed"
        if _visible(current, FINISH_NEXT_BUTTON_ID):
            return "review"
        if not any(_visible(current, element_id) for element_id in last_screen_ids) and _visible(current, NEXT_BUTTON_ID):
            return "final"
        return False

    try:
        state = WebDriverWait(wizard.driver, wizard.timeout, poll_frequency=0.15).until(left_last_screen)
    except TimeoutException as exc:
        raise RuntimeError(
            "The portal did not confirm Main Details as completed. "
            "Review the completion certificate in the portal; Next was not repeated."
        ) from exc
    if state == "review":
        click_when_clickable(wizard.driver, By.ID, FINISH_NEXT_BUTTON_ID, timeout=wizard.timeout)
    elif state == "final":
        # An unexpected extra question screen: its own single Next finishes the section.
        click_when_clickable(wizard.driver, By.ID, NEXT_BUTTON_ID, timeout=wizard.timeout)
    confirm_main_details_completed(wizard.driver, timeout=max(wizard.timeout, 1))


def complete_main_details(driver, user_inputs, completion, applicant_title_resolution_callback=None,
                          *, timeout=30, inline_timeout=2):
    """Run the wizard from its introduction screen to Main Details completed."""
    wizard = _Wizard(driver, timeout, inline_timeout)
    wait_for_step(driver, NEXT_BUTTON_ID, screen_name="Main Details", timeout=timeout)
    wizard.next(WORK_COMPLETED_DATE_ID, "completion details")
    fill_completion_and_warrant(wizard, completion)
    fill_notices(wizard, completion)
    fill_applicant_or_agent(wizard, completion)
    fill_agent(wizard, user_inputs)
    fill_relevant_person(wizard, user_inputs, applicant_title_resolution_callback)
    fill_ownership_and_address(wizard, completion)
    fill_extent_and_relaxation(wizard, completion)
    fill_construction_certificates(wizard, completion)
    fill_design_certificates(wizard, completion)
    fill_epc(wizard, completion)
    fill_sustainability(wizard, completion)
    fill_fire_safety(wizard, completion)
    fill_continuing_requirements(wizard, completion)
    finish_main_details(wizard, (CONTINUING_YES_ID, CONTINUING_NO_ID, CONTINUING_TEXT_ID))
    record_checkpoint("main_details_complete", "main_details", "Completion Certificate Main Details completed.")

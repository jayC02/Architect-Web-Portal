"""After Main Details: Supporting Documentation, Email Notification and the Declaration.

Supporting Documentation and Email Notification use the same portal screens as
the Building Warrant workflow. The Declaration is the Completion Certificate's
own. The run stops after the Declaration's Next, leaving submission to the
architect.

Fixed declaration answers in this version: "I", the work was carried out and
made in accordance with the building warrant, and No to "submitted for work
done in response to a notice where no warrant was required".
"""

from __future__ import annotations

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_when_clickable, get_when_present, wait_dom_ready
from automation.common.documents import get_document_type_from_pdf, get_paper_size_from_pdf
from automation.common.runtime import record_checkpoint
from automation.common.uploads import wait_for_supporting_doc_upload_result
from automation.completion_certificate.fields import choose, is_selected, set_text
from automation.completion_certificate.navigation import _visible, wait_for_step

SUPPORTING_SECTION_ID = "MainContent_FormSections_btnSupportingDocumentation"
EMAIL_SECTION_ID = "MainContent_FormSections_btnEmailNotification"
DECLARATION_SECTION_ID = "MainContent_FormSections_btnDeclaration"

SD = "MainContent_SupportingDocumentationWizard_"
EMAIL_CHECKBOX_ID = "MainContent_cbUseEmail"
EMAIL_CONFIRM_ID = "MainContent_btnConfirm"

DW = "MainContent_DeclarationWizard_"
DECLARATION_WHO_ID = DW + "ddlCompletionCert1"
DECLARATION_STATEMENT_ID = DW + "ddlCompletionCert2"
DECLARATION_NOTICE_NO_ID = DW + "RbnCompletionCertNoticeNo"
DECLARATION_ACCEPT_ID = DW + "cbAcceptCompletionCert"
DECLARATION_NEXT_ID = DW + "btnNextCompletionCert"
DECLARATION_WHO = "I"
DECLARATION_STATEMENT = "the work was carried out and made in accordance with the building warrant."


def _select(driver, element_id, text, timeout):
    """Choose a dropdown option by its text, only when it is not already chosen."""
    def current(current_driver):
        try:
            return Select(current_driver.find_element(By.ID, element_id)).first_selected_option.text.strip()
        except (NoSuchElementException, StaleElementReferenceException):
            return None

    if current(driver) == text:
        return
    for _attempt in range(3):
        try:
            Select(get_when_present(driver, By.ID, element_id, timeout=timeout)).select_by_visible_text(text)
            break
        except StaleElementReferenceException:
            continue
    wait_dom_ready(driver, timeout)
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda current_driver: current(current_driver) == text)


def _tick(driver, checkbox_id, wanted, timeout):
    if is_selected(driver, checkbox_id) != wanted:
        click_when_clickable(driver, By.XPATH, f"//label[@for='{checkbox_id}']", timeout=timeout)
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda current: is_selected(current, checkbox_id) == wanted)


def _listed_titles(driver):
    try:
        text = driver.find_element(By.TAG_NAME, "body").text
    except (NoSuchElementException, StaleElementReferenceException):
        return set()
    return {line.strip() for line in str(text).splitlines() if line.strip()}


def _upload_one(driver, document, timeout):
    click_when_clickable(driver, By.ID, SD + "btnAddDocumentation", timeout=timeout)
    wait_for_step(driver, SD + "rbUploaded", screen_name="add supporting document", timeout=timeout)
    choose(driver, SD + "rbUploaded", timeout)
    click_when_clickable(driver, By.ID, SD + "btnAttachmentContinue", timeout=timeout)
    wait_for_step(driver, SD + "edtUniqueDrawingReferenceNumber", screen_name="supporting document details", timeout=timeout)
    set_text(driver, SD + "edtUniqueDrawingReferenceNumber", document["title"], timeout)
    set_text(driver, SD + "edtDescription", document["description"], timeout)
    _select(driver, SD + "lbPaperSize", get_paper_size_from_pdf(document["path"]), timeout)
    _select(driver, SD + "lbDocumentType", get_document_type_from_pdf(document["path"]), timeout)
    get_when_present(driver, By.ID, SD + "fuAttachFile", timeout=timeout).send_keys(document["path"])
    if _visible(driver, SD + "rbReadAndUnderstood"):
        choose(driver, SD + "rbReadAndUnderstood", timeout)
    click_when_clickable(driver, By.ID, SD + "btnSaveDocEdit", timeout=timeout)
    wait_for_supporting_doc_upload_result(driver, document["title"], timeout=timeout)


def upload_supporting_documents(driver, documents, timeout=30):
    """Upload each document once. A rerun skips documents the portal already lists."""
    click_when_clickable(driver, By.ID, SUPPORTING_SECTION_ID, timeout=timeout)
    wait_for_step(driver, (SD + "rbYes", SD + "rbNo"), screen_name="Supporting Documentation", timeout=timeout)
    if not documents:
        choose(driver, SD + "rbNo", timeout)
        click_when_clickable(driver, By.ID, SD + "btnContinueOptions", timeout=timeout)
        wait_for_step(driver, EMAIL_SECTION_ID, screen_name="application summary", timeout=timeout)
        record_checkpoint("supporting_documents_not_required", "supporting_documents")
        return 0
    choose(driver, SD + "rbYes", timeout)
    click_when_clickable(driver, By.ID, SD + "btnContinueOptions", timeout=timeout)
    wait_for_step(driver, SD + "btnAddDocumentation", screen_name="supporting documents list", timeout=timeout)
    already = _listed_titles(driver)
    uploaded = 0
    for document in documents:
        if document["title"] in already:
            continue
        _upload_one(driver, document, timeout)
        uploaded += 1
    choose(driver, SD + "rbFinished", timeout)
    click_when_clickable(driver, By.ID, SD + "btnDocSave", timeout=timeout)
    wait_for_step(driver, EMAIL_SECTION_ID, screen_name="application summary", timeout=timeout)
    record_checkpoint("supporting_documents_uploaded", "supporting_documents", f"{uploaded} document(s) uploaded.")
    return uploaded


def complete_email_notification(driver, timeout=30):
    """Same answer as the warrant workflow: no email notifications."""
    click_when_clickable(driver, By.ID, EMAIL_SECTION_ID, timeout=timeout)
    wait_for_step(driver, EMAIL_CONFIRM_ID, screen_name="Email Notification", timeout=timeout)
    _tick(driver, EMAIL_CHECKBOX_ID, False, timeout)
    click_when_clickable(driver, By.ID, EMAIL_CONFIRM_ID, timeout=timeout)
    wait_for_step(driver, DECLARATION_SECTION_ID, screen_name="application summary", timeout=timeout)
    record_checkpoint("email_notification_confirmed", "email_notification")


def complete_declaration(driver, timeout=30):
    """Answer the Completion Certificate declaration and click Next once. Submission is left to the architect."""
    click_when_clickable(driver, By.ID, DECLARATION_SECTION_ID, timeout=timeout)
    wait_for_step(driver, DECLARATION_WHO_ID, screen_name="Declaration", timeout=timeout)
    _select(driver, DECLARATION_WHO_ID, DECLARATION_WHO, timeout)
    _select(driver, DECLARATION_STATEMENT_ID, DECLARATION_STATEMENT, timeout)
    choose(driver, DECLARATION_NOTICE_NO_ID, timeout)
    _tick(driver, DECLARATION_ACCEPT_ID, True, timeout)
    click_when_clickable(driver, By.ID, DECLARATION_NEXT_ID, timeout=timeout)
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(
            lambda current: not _visible(current, DECLARATION_WHO_ID) and not _visible(current, DECLARATION_NEXT_ID)
        )
    except TimeoutException as exc:
        raise RuntimeError(
            "The portal did not confirm the Declaration. Review it in eBuilding Standards; Next was not repeated."
        ) from exc
    record_checkpoint("declaration_complete", "declaration", "Completion Certificate declaration completed.")


def complete_submission(driver, documents, *, stage, timeout=30):
    stage("documents", "running", "Uploading supporting documents")
    upload_supporting_documents(driver, documents, timeout)
    complete_email_notification(driver, timeout)
    stage("documents", "completed", "Supporting documents complete")
    stage("declaration", "running", "Completing the declaration")
    complete_declaration(driver, timeout)
    stage("declaration", "completed", "Declaration complete")

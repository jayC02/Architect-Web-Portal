import copy
import json
from pathlib import Path

import pytest

from automation.portal_adapter import runtime_job_from_portal
from gui.services import portal_handoff

FIXTURES = Path(__file__).parent / "fixtures"


def _job(name="automation-job-v2-completion-certificate.json"):
    snapshot = json.loads((FIXTURES / name).read_text(encoding="utf-8"))
    return {
        "id": snapshot["metadata"]["jobId"],
        "projectId": snapshot["metadata"]["projectId"],
        "type": snapshot["metadata"]["applicationType"],
        "title": "Completion Certificate - 4 Willow Court",
        "dataSnapshot": snapshot,
    }


def test_completion_job_is_supported():
    job = _job()
    assert job["type"] == "COMPLETION_CERTIFICATE"
    assert portal_handoff.validate_portal_job(job) == 2


def test_completion_values():
    values = portal_handoff.portal_job_to_values(_job())
    assert values["Application Type"] == "Completion Certificate"
    assert values["Application Record ID"] == "warrant_1"
    assert values["Automation Job ID"] == "job_fixture_completion"
    assert values["Project ID"] == "project_fixture"
    assert values["Site Address"]
    assert values["Site Postcode"]
    assert values["Local Authority"] == "Glasgow City Council"
    completion = values["Completion"]
    assert completion["workCompletedDate"] == "2026-10-30"
    assert completion["warrantReference"] == "26/01234/WARR"
    assert completion["warrantDate"] == "2026-03-05"
    assert completion["amendmentDates"] == "01/06/2026\n09/07/2026"
    assert completion["relaxation"] == {"applies": True, "reference": "RD/1", "date": "2026-02-01"}
    assert completion["constructionCertificates"]["entries"][0]["certifierRegistration"] == {
        "part1": "SEL1", "part2": "C", "number": "12345",
    }
    assert completion["designCertificates"]["formQRequired"] is True
    assert completion["continuingRequirements"]["details"] == "Maintain the fire door."
    assert values["Applicant First Name"] and values["Applicant Last Name"]
    assert values["Agent First Name"] and values["Agent Email Address"]


def test_completion_values_carry_no_warrant_application_answers():
    values = portal_handoff.portal_job_to_values(_job())
    for warrant_only in ("Description of Work", "Estimated Work Value", "Work Started", "Calculated Fee Minor Units", "Proposed Work"):
        assert warrant_only not in values


def test_identity_is_the_source_warrant():
    identity = portal_handoff.application_identity_from_job(_job())
    assert identity["application_id"] == "warrant_1"
    assert identity["application_type"] == "COMPLETION_CERTIFICATE"
    assert identity["selected_automation"] == "COMPLETION_CERTIFICATE"
    assert identity["job_id"] == "job_fixture_completion"


@pytest.mark.parametrize("answer,value", [
    ("coversAllWork", False),
    ("relevantPersonIsOwner", False),
    ("differentBuildingAddress", True),
    ("actingAs", "APPLICANT"),
    ("relevantPersonType", "ORGANISATION"),
    ("dangerousBuildingNotice", True),
])
def test_rejects_changed_fixed_answer(answer, value):
    job = _job()
    job["dataSnapshot"]["completionCertificate"]["fixedAnswers"][answer] = value
    with pytest.raises(portal_handoff.PortalHandoffError, match="completion certificate"):
        portal_handoff.validate_portal_job(job)


def test_rejects_missing_fixed_answer():
    job = _job()
    del job["dataSnapshot"]["completionCertificate"]["fixedAnswers"]["warrantObtained"]
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.validate_portal_job(job)


def test_rejects_missing_completion_section():
    job = _job()
    job["dataSnapshot"]["completionCertificate"] = None
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.validate_portal_job(job)


def test_rejects_missing_source_warrant():
    job = _job()
    job["dataSnapshot"]["completionCertificate"]["sourceWarrantId"] = ""
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.validate_portal_job(job)


@pytest.mark.parametrize("section", ["buildingWarrant", "planning"])
def test_rejects_other_application_record(section):
    job = _job()
    job["dataSnapshot"][section] = {"recordId": "another_record"}
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.validate_portal_job(job)


def test_rejects_type_mismatch():
    job = _job()
    job["type"] = "BUILDING_WARRANT"
    with pytest.raises(portal_handoff.PortalHandoffError):
        portal_handoff.validate_portal_job(job)


def test_no_blocking_issues_without_documents():
    state = portal_handoff.normalise_portal_job(_job())
    assert state.blocking_issues == []
    assert state.documents == []


def test_runtime_job_from_portal_without_documents():
    job = _job()
    job["dataSnapshot"]["completionCertificate"]["documents"] = []
    job["dataSnapshot"]["documents"] = []
    runtime = runtime_job_from_portal(job, [], [], login_email="agent@example.com")
    assert runtime.application_type == "COMPLETION_CERTIFICATE"
    assert runtime.job_id == "job_fixture_completion"
    assert runtime.user_inputs["Email"] == "agent@example.com"
    assert runtime.user_inputs["Completion"]["warrantReference"] == "26/01234/WARR"
    assert runtime.metadata["application_id"] == "warrant_1"
    # The runtime job is a frozen copy: editing the source job cannot change it.
    assert runtime.mutable_inputs()["Completion"]["workCompletedDate"] == "2026-10-30"


def test_application_type_label():
    assert portal_handoff.application_type_from_job(_job()) == "Completion Certificate"


def test_warrant_fixture_mapping_unchanged():
    job = _job("automation-job-v2-building-warrant.json")
    before = copy.deepcopy(job)
    values = portal_handoff.portal_job_to_values(job)
    assert job == before
    assert values["Application Type"] == "Building Warrant"
    assert values["Description of Work"] == "Snapshot Integration Description"
    assert values["Applicant First Name"] == "Integration"
    assert values["Agent First Name"] == "Avery"
    assert "Completion" not in values


def _downloaded():
    return [
        {"id": "doc_epc", "localPath": "C:/jobs/job/EPC.pdf", "localName": "EPC.pdf", "type": "ENERGY"},
        {"id": "doc_cc", "localPath": "C:/jobs/job/CC-100 signed.pdf", "localName": "CC-100 signed.pdf", "type": "CERTIFICATE"},
        {"id": "doc_fq", "localPath": "C:/jobs/job/Form Q.pdf", "localName": "Form Q.pdf", "type": "CERTIFICATE"},
    ]


def test_completion_documents_reach_the_run_with_local_paths():
    runtime = runtime_job_from_portal(_job(), _downloaded(), [], login_email="a@example.com")
    documents = runtime.user_inputs["Completion Documents"]
    assert [(item["path"], item["title"], item["description"]) for item in documents] == [
        ("C:/jobs/job/EPC.pdf", "EPC", "Energy Performance Certificate"),
        ("C:/jobs/job/CC-100 signed.pdf", "CC-100 signed", "Certificate of Construction"),
        ("C:/jobs/job/Form Q.pdf", "Form Q", "Notice of Finalisation of Design Details (Form Q)"),
    ]


def test_missing_completion_document_blocks_before_the_portal():
    with pytest.raises(ValueError, match="Form Q.pdf"):
        runtime_job_from_portal(_job(), _downloaded()[:2], [], login_email="a@example.com")


def test_completion_without_documents_has_an_empty_list():
    job = _job()
    job["dataSnapshot"]["completionCertificate"]["documents"] = []
    job["dataSnapshot"]["documents"] = []
    runtime = runtime_job_from_portal(job, [], [], login_email="a@example.com")
    assert runtime.user_inputs["Completion Documents"] == []


def test_agent_advertises_the_completion_contract():
    from gui.services import background_agent

    assert background_agent.CAPABILITIES["completionContractVersions"] == [2]

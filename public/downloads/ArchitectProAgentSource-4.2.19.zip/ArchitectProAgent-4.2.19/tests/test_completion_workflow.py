import copy
from datetime import date, timedelta

import pytest

from automation.completion_certificate import details, run
from automation.completion_certificate.fields import PREFIX as P
from automation.completion_certificate.navigation import SUPPORTING_DOCUMENTATION_BUTTON_ID
from automation.completion_certificate.proposal import COMPLETION_FORM
from automation.runner import AutomationCancelled, CancellationToken

from completion_wizard_fake import FakeWizard

FIXED = {
    "warrantObtained": True, "dangerousBuildingNotice": False, "actingAs": "AGENT", "useAccountDetails": True,
    "relevantPersonType": "INDIVIDUAL", "relevantPersonIsOwner": True, "differentBuildingAddress": False, "coversAllWork": True,
}


def cert(number, part1, part2, body2):
    return {"certificateNumber": number, "certifierRegistration": {"part1": part1, "part2": part2, "number": "12345"},
            "certifierSignatureDate": "2026-10-01", "approvedBodyRegistration": {"part1": part1, "part2": body2, "number": "678"},
            "approvedBodySignatureDate": "2026-10-02", "documentId": None}


def completion(**change):
    value = {
        "sourceWarrantId": "warrant_1", "workCompletedDate": "2026-10-30", "warrantReference": "26/01234/WARR",
        "warrantDate": "2026-03-05", "amendmentDates": None,
        "relaxation": {"applies": False, "reference": None, "date": None},
        "constructionCertificates": {"accompany": False, "entries": []},
        "designCertificates": {"accompaniedWarrant": False, "formQRequired": None, "entries": []},
        "energyPerformanceCertificate": False, "sustainabilityStatement": False, "fireSafetyDesignSummary": False,
        "continuingRequirements": {"applies": False, "details": None},
    }
    value.update(change)
    return value


ALL_YES = dict(
    amendmentDates="01/06/2026\n09/07/2026",
    relaxation={"applies": True, "reference": "RD/1", "date": "2026-02-01"},
    constructionCertificates={"accompany": True, "entries": [cert("CC-100", "SEL1", "C", "CB")]},
    designCertificates={"accompaniedWarrant": True, "formQRequired": True, "entries": [cert("FQ-200", "SER1", "D", "DB")]},
    energyPerformanceCertificate=True, sustainabilityStatement=True, fireSafetyDesignSummary=True,
    continuingRequirements={"applies": True, "details": "Maintain the fire door."},
)
INPUTS = {"Email": "agent@example.com", "Project ID": "project", "Site Address": "112 Ralston Avenue, Glasgow, G52 3NB",
          "Site Postcode": "G52 3NB", "Applicant First Name": "Sam", "Agent First Name": "Alex"}


@pytest.fixture(autouse=True)
def party_screens(monkeypatch):
    """The agent and relevant-person screens are filled by shared, separately tested code."""
    calls = []
    monkeypatch.setattr(details, "fill_agent_details", lambda driver, inputs, prefix: calls.append(("agent", prefix)))
    monkeypatch.setattr(details, "fill_applicant_details",
                        lambda driver, inputs, callback, prefix: calls.append(("relevant_person", prefix, callback)))
    monkeypatch.setattr(details, "record_checkpoint", lambda *args, **kwargs: None)
    monkeypatch.setattr(run, "record_checkpoint", lambda *args, **kwargs: None)
    monkeypatch.setattr(run, "clear_checkpoint", lambda: None)
    return calls


def complete(wizard, answers, callback=None):
    details.complete_main_details(wizard.driver, INPUTS, answers, callback, timeout=3, inline_timeout=0.2)


# ---- the Main Details path --------------------------------------------------

def test_all_no_path(party_screens):
    wizard = FakeWizard()
    complete(wizard, completion())
    assert wizard.screens_visited == [
        "intro", "completion_warrant", "notices", "applicant_or_agent", "agent", "relevant_person", "ownership",
        "extent_relaxation", "construction_question", "design_question", "epc", "sustainability", "fire_safety",
        "continuing", "final", "form_summary",
    ]
    assert wizard.value("txtDateWorkCompleted") == "30/10/2026"
    assert wizard.value("BuildingWarrantDetails_txtBuildingWarrantRefNumber") == "26/01234/WARR"
    assert wizard.value("txtBuildingWarrantDate") == "05/03/2026"
    assert wizard.value("BuildingWarrantDetails_txtAmendmentDates") == ""
    for radio in ("rbObtainBWYes", "rbDangerousBuildingNo", "ApplicantOrAgent_rbAgent", "ApplicantOrAgent_rbAccountYes",
                  "rbApplicantOwnerYes", "rbDifferentAddressNo", "rbSumissionCoverYes", "rbRelaxationDirectionNo",
                  "CertificatesRegisterQuestion_rbCertificatesAccompanyNo", "rbDesignCertificatesAccompanyNo",
                  "rbEnergyPerformanceNo", "rbSustainabilityNo", "rbFireSafetyNo", "rbContinuingRequirementsNo"):
        assert wizard.selected(radio), radio
    for notice in ("txtBuildingRegComplianceNotice", "txtBuildingWarrantEnforcementNotice", "txtDefectiveBuildingsNotice"):
        assert wizard.value(notice) == "N/A", "each notice reference is answered N/A, as on the warrant"
    assert [call[:2] for call in party_screens] == [("agent", P), ("relevant_person", P)]
    assert wizard.next_clicks() == len(wizard.screens_visited) - 1, "one Next per screen, never repeated"
    assert wizard.driver.clicks(SUPPORTING_DOCUMENTATION_BUTTON_ID) == 0, "supporting documents are a later phase"


def test_all_yes_path():
    wizard = FakeWizard()
    complete(wizard, completion(**ALL_YES))
    assert wizard.screens_visited == [
        "intro", "completion_warrant", "notices", "applicant_or_agent", "agent", "relevant_person", "ownership",
        "extent_relaxation", "construction_question", "construction_register", "design_question", "form_q_question",
        "form_q_register", "epc", "sustainability", "fire_safety", "continuing", "final", "form_summary",
    ]
    assert wizard.value("BuildingWarrantDetails_txtAmendmentDates") == "01/06/2026\n09/07/2026"
    assert wizard.value("RelaxationDirections_txtReferenceNumber") == "RD/1"
    assert wizard.value("txtRelaxDirDate") == "01/02/2026"
    assert wizard.value("txtContinuingRequirements") == "Maintain the fire door."
    assert wizard.construction.entries[0]["number"] == "CC-100" and wizard.construction.entries[0]["a2"] == "C"
    assert wizard.form_q.entries[0]["number"] == "FQ-200" and wizard.form_q.entries[0]["b2"] == "DB"
    assert wizard.construction.validated == [1] and wizard.form_q.validated == [1]
    for radio in ("rbRelaxationDirectionYes", "CertificatesRegisterQuestion_rbCertificatesAccompanyYes",
                  "rbDesignCertificatesAccompanyYes", "rbNoticeOfDesignDetailsYes", "rbEnergyPerformanceYes",
                  "rbSustainabilityYes", "rbFireSafetyYes", "rbContinuingRequirementsYes"):
        assert wizard.selected(radio), radio


def test_design_no_skips_form_q():
    wizard = FakeWizard()
    complete(wizard, completion(designCertificates={"accompaniedWarrant": False, "formQRequired": None, "entries": []}))
    assert "form_q_question" not in wizard.screens_visited and "form_q_register" not in wizard.screens_visited


def test_form_q_no_skips_register():
    wizard = FakeWizard()
    complete(wizard, completion(designCertificates={"accompaniedWarrant": True, "formQRequired": False, "entries": []}))
    assert "form_q_question" in wizard.screens_visited and "form_q_register" not in wizard.screens_visited
    assert wizard.selected("rbNoticeOfDesignDetailsNo")


@pytest.mark.parametrize("inline", [True, False])
def test_follow_ups_inline_or_behind_next(inline):
    wizard = FakeWizard(inline=inline)
    complete(wizard, completion(**ALL_YES))
    assert wizard.screens_visited[-1] == "form_summary"
    assert wizard.value("BuildingWarrantDetails_txtBuildingWarrantRefNumber") == "26/01234/WARR"
    assert wizard.value("RelaxationDirections_txtReferenceNumber") == "RD/1"
    assert wizard.value("txtContinuingRequirements") == "Maintain the fire door."
    assert ("warrant_details" in wizard.screens_visited) is (not inline)
    assert wizard.next_clicks() == len(wizard.screens_visited) - 1, "no extra Next when a follow-up is already showing"


def test_amendment_dates_at_the_portal_limit():
    wizard = FakeWizard()
    complete(wizard, completion(amendmentDates="x" * 750))
    assert len(wizard.value("BuildingWarrantDetails_txtAmendmentDates")) == 750


# ---- reruns over saved answers ---------------------------------------------

def saved_answers():
    first = FakeWizard()
    details.complete_main_details(first.driver, INPUTS, completion(**ALL_YES), None, timeout=3, inline_timeout=0.2)
    saved = {}
    for element_id, field in first.driver.fields.items():
        if field.kind == "radio" and field.selected:
            saved[element_id] = True
        elif field.kind in ("text", "textarea") and field.value and "CertificatesRegister" not in element_id and "Signature" not in element_id:
            saved[element_id] = field.value
    return saved, first.construction.entries, first.form_q.entries


def test_rerun_over_saved_answers_changes_nothing():
    saved, construction, form_q = saved_answers()
    wizard = FakeWizard(saved=saved, construction_saved=construction, form_q_saved=form_q)
    complete(wizard, completion(**ALL_YES))
    assert wizard.screens_visited[-1] == "form_summary"
    assert wizard.driver.typed() == [], "matching saved text is left alone"
    assert wizard.radio_clicks() == [], "matching saved answers are left alone"
    assert wizard.driver.clicks(P + "CertificatesRegister_btnAddCertificate") == 0


def test_rerun_corrects_a_changed_answer():
    saved, construction, form_q = saved_answers()
    saved["txtBuildingWarrantDate"] = "01/01/2026"
    saved[P + "rbEnergyPerformanceNo"] = True
    del saved[P + "rbEnergyPerformanceYes"]
    wizard = FakeWizard(saved=saved, construction_saved=construction, form_q_saved=form_q)
    complete(wizard, completion(**ALL_YES))
    assert [entry[1] for entry in wizard.driver.typed()] == ["txtBuildingWarrantDate"]
    assert wizard.value("txtBuildingWarrantDate") == "05/03/2026"
    assert [entry[1] for entry in wizard.radio_clicks()] == [f"label:{P}rbEnergyPerformanceYes"]


# ---- completion signal ------------------------------------------------------

def test_review_page_uses_the_finish_next_button():
    from completion_wizard_fake import FINISH_NEXT_ID

    wizard = FakeWizard()
    complete(wizard, completion())
    assert wizard.screens_visited[-2:] == ["final", "form_summary"]
    assert wizard.driver.clicks(FINISH_NEXT_ID) == 1, "the Review page's own Next is clicked once"


def test_rerun_that_stopped_on_the_review_page_finishes():
    """The run before this fix reached Review and stopped; a rerun starts the wizard again."""
    saved, construction, form_q = saved_answers()
    wizard = FakeWizard(saved=saved, construction_saved=construction, form_q_saved=form_q)
    complete(wizard, completion(**ALL_YES))
    assert wizard.screens_visited[-1] == "form_summary"


def test_completion_not_confirmed_fails():
    wizard = FakeWizard(completes=False)
    with pytest.raises(RuntimeError, match="did not confirm Main Details as completed"):
        complete(wizard, completion())
    assert wizard.driver.clicks(SUPPORTING_DOCUMENTATION_BUTTON_ID) == 0


# ---- refusals before any portal action -------------------------------------

@pytest.mark.parametrize("change,message", [
    ({"workCompletedDate": None}, "date the work was completed"),
    ({"workCompletedDate": "30/10/2026"}, "date the work was completed"),
    ({"workCompletedDate": (date.today() + timedelta(days=1)).isoformat()}, "future"),
    ({"warrantDate": (date.today() + timedelta(days=1)).isoformat()}, "future"),
    ({"warrantReference": "  "}, "warrant reference"),
    ({"amendmentDates": "x" * 751}, "750"),
    ({"continuingRequirements": {"applies": True, "details": "x" * 751}}, "750"),
    ({"continuingRequirements": {"applies": True, "details": ""}}, "continuing requirements"),
    ({"relaxation": {"applies": True, "reference": "", "date": "2026-02-01"}}, "relaxation"),
    ({"relaxation": {"applies": True, "reference": "RD/1", "date": None}}, "relaxation"),
    ({"energyPerformanceCertificate": None}, "Energy Performance"),
    ({"constructionCertificates": {"accompany": True, "entries": []}}, "certificate of construction"),
    ({"constructionCertificates": {"accompany": True, "entries": [cert("CC", "SER1", "C", "CB")]}}, "certificate of construction 1"),
    ({"designCertificates": {"accompaniedWarrant": True, "formQRequired": None, "entries": []}}, "Form Q"),
    ({"designCertificates": {"accompaniedWarrant": True, "formQRequired": True, "entries": []}}, "Form Q"),
])
def test_validate_completion_refuses(change, message):
    with pytest.raises(ValueError, match=message):
        details.validate_completion(completion(**change))


def test_validate_completion_accepts_complete_answers():
    details.validate_completion(completion())
    details.validate_completion(completion(**ALL_YES))


def test_validate_completion_requires_a_mapping():
    with pytest.raises(ValueError):
        details.validate_completion(None)


# ---- the whole run ----------------------------------------------------------

class Portal:
    def __init__(self, wizard):
        self.wizard = wizard
        self.calls = []

    def proposals_named(self, _address):
        return [("500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")]

    def open_existing_proposal(self, reference, name=""):
        self.calls.append(("open", reference))

    def wait_for_summary(self, timeout=None):
        pass

    def summary_text(self):
        return "Summary\n112 RALSTON AVENUE, GLASGOW, G52 3NB\nProposal Reference 500816704\nSubmitted Forms\nNo Submitted Forms"

    def draft_form_count(self, _text):
        return 1

    def submitted_forms_include(self, _text):
        return False

    def open_draft_form(self, text):
        self.calls.append(("open_form", text))


class Store:
    def find_for_project(self, *_args):
        return None

    def remember_for_project(self, *_args):
        pass


def run_main(wizard, answers, *, token=None, events=None, login_calls=None, portal=None, submitted=None, documents=None):
    events = events if events is not None else []
    login_calls = login_calls if login_calls is not None else []
    submitted = submitted if submitted is not None else []

    def submit(driver, documents, *, stage, timeout):
        submitted.append(documents)
        stage("documents", "running", "Uploading supporting documents")
        stage("documents", "completed", "Supporting documents complete")
        stage("declaration", "running", "Completing the declaration")
        stage("declaration", "completed", "Declaration complete")

    inputs = {**INPUTS, "Completion": answers}
    if documents is not None:
        inputs["Completion Documents"] = documents
    return run.main(
        user_inputs=inputs, password="secret", driver=wizard.driver, submit=submit,
        progress=lambda name, status, message: events.append((name, status)), cancellation_token=token,
        portal=portal or Portal(wizard), state_store=Store(),
        login=lambda driver, username, password: login_calls.append((username, password)),
        timeout=3, inline_timeout=0.2,
    )


def test_stage_events_in_order():
    wizard, events, logins = FakeWizard(), [], []
    portal = Portal(wizard)
    assert run_main(wizard, completion(), events=events, login_calls=logins, portal=portal) is None
    assert events == [
        ("login", "running"), ("login", "completed"), ("proposal", "running"), ("proposal", "completed"),
        ("completion_form", "running"), ("completion_form", "completed"),
        ("main_details", "running"), ("main_details", "completed"),
        ("documents", "running"), ("documents", "completed"), ("declaration", "running"), ("declaration", "completed"),
    ]
    assert logins == [("agent@example.com", "secret")]
    assert portal.calls == [("open", "500816704"), ("open_form", COMPLETION_FORM)]
    assert wizard.screens_visited[-1] == "form_summary"


@pytest.mark.parametrize("change", [
    {"workCompletedDate": (date.today() + timedelta(days=1)).isoformat()},
    {"amendmentDates": "x" * 751},
])
def test_invalid_answers_are_refused_before_login(change):
    wizard, logins = FakeWizard(), []
    with pytest.raises(ValueError):
        run_main(wizard, completion(**change), login_calls=logins)
    assert logins == [] and wizard.driver.log == []


def test_missing_credentials_are_refused_before_login():
    wizard = FakeWizard()
    with pytest.raises(RuntimeError, match="login"):
        run.main(user_inputs={**INPUTS, "Completion": completion(), "Email": ""}, password="secret", driver=wizard.driver,
                 portal=Portal(wizard), state_store=Store(), login=lambda *args: pytest.fail("must not sign in"))


def test_cancel_between_stages():
    wizard = FakeWizard()
    token = CancellationToken()
    events = []

    class CancellingPortal(Portal):
        def open_existing_proposal(self, reference, name=""):
            token.cancel()

    with pytest.raises(AutomationCancelled):
        run_main(wizard, completion(), token=token, events=events, portal=CancellingPortal(wizard))
    assert ("main_details", "running") not in events
    assert wizard.driver.log == [], "nothing was entered after cancellation"


def test_inputs_are_not_modified():
    wizard = FakeWizard()
    answers = completion(**ALL_YES)
    before = copy.deepcopy(answers)
    run_main(wizard, answers)
    assert answers == before


def test_documents_are_uploaded_after_main_details():
    wizard, submitted = FakeWizard(), []
    documents = [{"path": "C:/jobs/EPC.pdf", "title": "EPC", "description": "Energy Performance Certificate", "role": "ENERGY_PERFORMANCE_CERTIFICATE"}]
    run_main(wizard, completion(energyPerformanceCertificate=True), submitted=submitted, documents=documents)
    assert submitted == [documents]
    assert wizard.screens_visited[-1] == "form_summary", "the documents start once Main Details is complete"


def test_no_documents_still_runs_the_submission_steps():
    wizard, submitted = FakeWizard(), []
    run_main(wizard, completion(), submitted=submitted)
    assert submitted == [[]]

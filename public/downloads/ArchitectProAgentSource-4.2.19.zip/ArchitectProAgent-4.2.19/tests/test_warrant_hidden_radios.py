"""The portal draws its Yes/No circles on the labels and hides the radio inputs.

The warrant workflow confirms each screen by one of its radios, so a radio whose
label is showing must count as on screen (as in the completion workflow).
"""

import pytest

from automation.building_warrant import navigation

from completion_fakes import FakeDriver

WARRANT_NEXT = "MainContent_BuildingWarrantAppWizard_StepNavigationTemplateContainerID_btnNext"
WORK_COMPLETED_NO = "MainContent_BuildingWarrantAppWizard_rbWorkCompletedNo"


def _state_of_work_screen(input_visible=False, label_visible=True):
    driver = FakeDriver()
    driver.add_radio(WORK_COMPLETED_NO, "work_completed")
    driver.fields[WORK_COMPLETED_NO].visible = input_visible
    driver.fields[f"label:{WORK_COMPLETED_NO}"].visible = label_visible
    return driver


def test_screen_with_hidden_radio_and_visible_label_is_recognised():
    driver = _state_of_work_screen()
    assert navigation.wait_for_step(driver, WORK_COMPLETED_NO, screen_name="work completed", timeout=0.5) == WORK_COMPLETED_NO


def test_click_next_reaches_the_state_of_work_screen():
    driver = _state_of_work_screen()
    driver.fields[WORK_COMPLETED_NO].visible = False
    driver.visible_ids = {WARRANT_NEXT}
    driver.add(WARRANT_NEXT, kind="button", value="Next",
               on_click=lambda current: setattr(current, "visible_ids", {WORK_COMPLETED_NO, WARRANT_NEXT}))
    assert navigation.click_next(driver, expected_ids=WORK_COMPLETED_NO, screen_name="work completed", timeout=0.5) == WORK_COMPLETED_NO
    assert driver.clicks(WARRANT_NEXT) == 1


def test_hidden_radio_without_a_visible_label_is_not_a_screen():
    driver = _state_of_work_screen(label_visible=False)
    with pytest.raises(RuntimeError, match="Next was not repeated"):
        navigation.wait_for_step(driver, WORK_COMPLETED_NO, screen_name="work completed", timeout=0.3)


def test_missing_control_is_not_a_screen():
    driver = FakeDriver()
    with pytest.raises(RuntimeError):
        navigation.wait_for_step(driver, WORK_COMPLETED_NO, screen_name="work completed", timeout=0.3)

"""A model of the Completion Certificate form after Main Details: Supporting
Documentation, Email Notification and the Declaration, with ids from the portal."""

from __future__ import annotations

from completion_fakes import FakeDriver

SD = "MainContent_SupportingDocumentationWizard_"
DW = "MainContent_DeclarationWizard_"
SECTION_SUPPORTING = "MainContent_FormSections_btnSupportingDocumentation"
SECTION_EMAIL = "MainContent_FormSections_btnEmailNotification"
SECTION_DECLARATION = "MainContent_FormSections_btnDeclaration"
STATEMENTS = [
    "the work was carried out and made in accordance with the building warrant.",
    "the work was carried out and conversion was made in accordance with the building warrant.",
    "the conversion was made in accordance with the building warrant.",
    "the work done in response to a notice has been completed in accordance with the requirements of the notice.",
]
EDITOR = [SD + "edtUniqueDrawingReferenceNumber", SD + "edtDescription", SD + "lbPaperSize", SD + "lbDocumentType",
          SD + "fuAttachFile", SD + "rbReadAndUnderstood", SD + "btnSaveDocEdit", SD + "btnCancelDocEdit"]


class FakeSubmission:
    def __init__(self, *, already_uploaded=(), declaration_moves_on=True, email_checked=True):
        self.driver = FakeDriver()
        self.uploaded = [dict(title=title) for title in already_uploaded]
        self.declaration_moves_on = declaration_moves_on
        self.supporting_saved = None      # "documents" or "none" once the section is saved
        self.email_confirmed = None
        self.declaration = None
        self.page = "summary"
        d = self.driver
        d.add(SECTION_SUPPORTING, kind="button", value="Supporting Documentation", on_click=lambda _d: self._go("sd_options"))
        d.add(SECTION_EMAIL, kind="button", value="Email Notification", on_click=lambda _d: self._go("email"))
        d.add(SECTION_DECLARATION, kind="button", value="Declaration", on_click=lambda _d: self._go("declaration"))
        d.add_radio(SD + "rbYes", "sd")
        d.add_radio(SD + "rbNo", "sd")
        d.add(SD + "btnContinueOptions", kind="button", value="Continue", on_click=lambda _d: self._continue_options())
        d.add(SD + "btnAddDocumentation", kind="button", value="Add", on_click=lambda _d: self._go("sd_attach"))
        d.add_radio(SD + "rbUploaded", "attach")
        d.add(SD + "btnAttachmentContinue", kind="button", value="Continue", on_click=lambda _d: self._attach_continue())
        d.add(SD + "edtUniqueDrawingReferenceNumber")
        d.add(SD + "edtDescription")
        d.add(SD + "lbPaperSize", kind="select", options=["", "A4", "A3", "A1"], value="")
        d.add(SD + "lbDocumentType", kind="select", options=["", "Drawing", "Report", "Photo", "Other"], value="")
        d.add(SD + "fuAttachFile")
        d.add_radio(SD + "rbReadAndUnderstood", "read")
        d.add(SD + "btnSaveDocEdit", kind="button", value="Save", on_click=lambda _d: self._save_document())
        d.add(SD + "btnCancelDocEdit", kind="button", value="Cancel", on_click=lambda _d: self._go("sd_list"))
        d.add_radio(SD + "rbFinished", "finished")
        d.add(SD + "btnDocSave", kind="button", value="Save", on_click=lambda _d: self._doc_save())
        d.add_checkbox("MainContent_cbUseEmail", checked=email_checked)
        d.add("MainContent_btnConfirm", kind="button", value="Confirm", on_click=lambda _d: self._confirm_email())
        d.add(DW + "ddlCompletionCert1", kind="select", options=["", "I", "We"], value="")
        d.add(DW + "ddlCompletionCert2", kind="select", options=[""] + STATEMENTS, value="")
        d.add_radio(DW + "RbnCompletionCertNoticeYes", "notice")
        d.add_radio(DW + "RbnCompletionCertNoticeNo", "notice")
        d.add_checkbox(DW + "cbAcceptCompletionCert")
        d.add(DW + "btnNextCompletionCert", kind="button", value="Next", on_click=lambda _d: self._declaration_next())
        self._show()

    # ---- screens --------------------------------------------------------
    def _show(self):
        visible = {
            "summary": [SECTION_SUPPORTING, SECTION_EMAIL, SECTION_DECLARATION],
            "sd_options": [SD + "rbYes", SD + "rbNo", SD + "btnContinueOptions"],
            "sd_list": [SD + "btnAddDocumentation", SD + "rbFinished", SD + "btnDocSave"],
            "sd_attach": [SD + "rbUploaded", SD + "btnAttachmentContinue"],
            "sd_editor": EDITOR,
            "email": ["MainContent_cbUseEmail", "MainContent_btnConfirm"],
            "declaration": [DW + "ddlCompletionCert1", DW + "ddlCompletionCert2", DW + "RbnCompletionCertNoticeYes",
                            DW + "RbnCompletionCertNoticeNo", DW + "cbAcceptCompletionCert", DW + "btnNextCompletionCert"],
            "after_declaration": [],
        }[self.page]
        self.driver.visible_ids = set(visible)
        listed = "\n".join(item["title"] for item in self.uploaded)
        self.driver.body_text = f"Supporting Documentation\n{listed}" if self.page.startswith("sd_") else ""

    def _go(self, page):
        self.page = page
        self.driver.postback()
        self._show()

    def _continue_options(self):
        if self.driver.selected(SD + "rbNo"):
            self.supporting_saved = "none"
            self._go("summary")
        elif self.driver.selected(SD + "rbYes"):
            self._go("sd_list")

    def _attach_continue(self):
        if self.driver.selected(SD + "rbUploaded"):
            for element_id in (SD + "edtUniqueDrawingReferenceNumber", SD + "edtDescription", SD + "fuAttachFile"):
                self.driver.fields[element_id].value = ""
            self._go("sd_editor")

    def _save_document(self):
        f = self.driver.fields
        self.uploaded.append(dict(
            title=f[SD + "edtUniqueDrawingReferenceNumber"].value, description=f[SD + "edtDescription"].value,
            paper=f[SD + "lbPaperSize"].value, type=f[SD + "lbDocumentType"].value, file=f[SD + "fuAttachFile"].value,
        ))
        self._go("sd_list")

    def _doc_save(self):
        if self.driver.selected(SD + "rbFinished"):
            self.supporting_saved = "documents"
            self._go("summary")

    def _confirm_email(self):
        self.email_confirmed = {"notifications": self.driver.selected("MainContent_cbUseEmail")}
        self._go("summary")

    def _declaration_next(self):
        f = self.driver.fields
        self.declaration = {
            "who": f[DW + "ddlCompletionCert1"].value, "statement": f[DW + "ddlCompletionCert2"].value,
            "notice": "No" if f[DW + "RbnCompletionCertNoticeNo"].selected else "Yes" if f[DW + "RbnCompletionCertNoticeYes"].selected else None,
            "accepted": f[DW + "cbAcceptCompletionCert"].selected,
        }
        if self.declaration_moves_on:
            self._go("after_declaration")

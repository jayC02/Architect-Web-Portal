import pytest

from automation import runner
from automation.building_warrant.certificates import CertificateValidationError
from automation.common import existing_application
from automation.common.driver import BrowserMode
from automation.common.proposal_creation import ADD_ADDITIONAL_FORMS_ID
from automation.completion_certificate.certificates import (
    CONSTRUCTION,
    CompletionCertificateValidationError,
    RegisterStateError,
)
from automation.completion_certificate.proposal import COMPLETION_FORM, CompletionFormError, ProposalSelectionRequired
from automation.runner import ProgressStatus, describe_failure, domain_error, run_automation
from gui.services import background_agent


def job(application_type="COMPLETION_CERTIFICATE"):
    return {
        "job_id": "job_test_123456", "application_type": application_type, "site_label": "112 Ralston Avenue",
        "user_inputs": {"Email": "test@example.com", "PDF Folder Path": ""},
        "document_mapping": {"pdf_folder_path": "", "buckets": {}, "bucket_labels": {}},
    }


class Browser:
    """Stands in for Chrome: the Proposal Summary appears after ``appears_after`` looks."""

    def __init__(self, appears_after=None):
        self.appears_after = appears_after
        self.looks = 0
        self.session_id = "session"

    def find_elements(self, _by, value):
        assert value == ADD_ADDITIONAL_FORMS_ID
        self.looks += 1
        return [object()] if self.appears_after is not None and self.looks > self.appears_after else []


class Managed:
    def __init__(self, browser=None):
        self.driver = browser or Browser()
        self.closed = []
        self.handoffs = 0

    def start(self):
        return self.driver

    def close(self, *, preserve_visible=False):
        self.closed.append(preserve_visible)

    def handoff_to_user(self):
        self.handoffs += 1


def run(workflow, *, application_type="COMPLETION_CERTIFICATE", managed=None, events=None):
    managed = managed or Managed()
    return run_automation(
        job(application_type), browser_mode=BrowserMode.AUTO, password="secret",
        progress_callback=(events.append if events is not None else None),
        driver_factory=lambda _mode: managed, workflow_registry={application_type: workflow},
    ), managed


def test_success_result():
    result, managed = run(lambda **kwargs: None)
    assert result.outcome == "success"
    assert result.message == "Completion Certificate ready for submission"
    assert result.last_stage == "final_review"
    assert managed.handoffs == 1, "the completed form is revealed for review"


def test_warrant_success_message_unchanged():
    result, _managed = run(lambda **kwargs: None, application_type="BUILDING_WARRANT")
    assert result.message == "Application prepared"


def test_proposal_callback_only_for_completion():
    seen = {}
    run(lambda **kwargs: seen.update(completion=kwargs))
    run(lambda **kwargs: seen.update(warrant=kwargs), application_type="BUILDING_WARRANT")
    assert callable(seen["completion"]["proposal_selection_callback"])
    assert "proposal_selection_callback" not in seen["warrant"]


def test_architect_selects_the_proposal():
    events = []
    managed = Managed(Browser(appears_after=2))
    result, _ = run(lambda **kwargs: kwargs["proposal_selection_callback"]("Open the correct proposal."),
                    managed=managed, events=events)
    assert result.outcome == "success"
    proposal = [(event.stage, event.status) for event in events if event.stage == "proposal"]
    assert proposal == [("proposal", ProgressStatus.USER_ACTION_REQUIRED), ("proposal", ProgressStatus.RUNNING)]
    assert managed.handoffs >= 1, "the browser is shown so the architect can choose"
    assert managed.closed == [True], "a browser the architect has used is never closed"


def test_proposal_selection_times_out_without_changing_anything(monkeypatch):
    monkeypatch.setattr(runner, "PROPOSAL_SELECTION_TIMEOUT", 0.4)
    result, managed = run(lambda **kwargs: kwargs["proposal_selection_callback"]("Open the correct proposal."),
                          managed=Managed(Browser(appears_after=None)))
    assert result.outcome == "cancelled"
    assert "proposal" in result.message.lower()


@pytest.mark.parametrize("error,stage,category", [
    (CompletionFormError("The open proposal is for 9 Other Road, but this completion certificate is for 112 Ralston Avenue."), "proposal", "COMPLETION_FORM_NEEDS_REVIEW"),
    (CompletionFormError("This proposal has 2 Completion Certificate forms."), "completion_form", "COMPLETION_FORM_NEEDS_REVIEW"),
    (RegisterStateError("The portal already holds 3 certificate of construction entries but this job has 2."), "main_details", "COMPLETION_FORM_NEEDS_REVIEW"),
    (ProposalSelectionRequired("Architect Pro could not identify this warrant's proposal."), "proposal", "PROPOSAL_NOT_IDENTIFIED"),
])
def test_form_state_errors_need_portal_review(error, stage, category):
    message, code = domain_error(error)
    assert code == category
    assert message == str(error), "the specific reason reaches the architect"
    details = describe_failure(error, stage, "COMPLETION_CERTIFICATE")
    assert details.category == category
    assert details.recovery_action == "review_portal"
    assert details.retry_safe is False
    assert details.recovery_fields == ()
    assert details.stage == stage


def test_stage_labels_for_completion():
    assert describe_failure(RuntimeError("x"), "completion_form", "COMPLETION_CERTIFICATE").stage_description == "Opening the completion certificate"
    assert describe_failure(RuntimeError("x"), "proposal", "COMPLETION_CERTIFICATE").stage_description == "Finding the warrant proposal"
    assert describe_failure(RuntimeError("x"), "proposal", "BUILDING_WARRANT").stage_description == "Creating the portal proposal"


def test_certificate_rejection_points_at_the_completion_page():
    error = CompletionCertificateValidationError(CONSTRUCTION, 2, "The certifier registration number is invalid.")
    assert isinstance(error, CertificateValidationError)
    assert "certificate of construction 2" in str(error)
    assert "warrant again" not in str(error)
    details = describe_failure(error, "main_details", "COMPLETION_CERTIFICATE")
    assert details.category == "CERTIFICATE_VALIDATION_FAILED"
    assert "completion certificate" in details.next_action.lower()
    assert "warrant again" not in details.next_action
    assert details.recovery_fields == ()


def test_warrant_certificate_rejection_unchanged():
    details = describe_failure(CertificateValidationError("bad"), "main_details", "BUILDING_WARRANT")
    assert "registrationAPart1" in details.recovery_fields
    assert "prepare the warrant again" in details.next_action


def test_login_failure_stays_an_authentication_failure():
    details = describe_failure(TimeoutError(""), "login", "COMPLETION_CERTIFICATE")
    assert details.category == "AUTHENTICATION_FAILED"
    assert details.retry_safe is True


def test_capabilities_and_version():
    assert background_agent.CAPABILITIES["workflows"] == ["HOUSEHOLDER_PLANNING", "BUILDING_WARRANT", "COMPLETION_CERTIFICATE"]
    assert background_agent.AGENT_VERSION == "4.2.19"


def test_release_files_carry_the_same_version():
    from pathlib import Path

    root = Path(__file__).parent.parent
    assert '#define MyAppVersion "4.2.19"' in (root / "installer/ArchitectProAgent.iss").read_text(encoding="utf-8")
    info = (root / "version_info.txt").read_text(encoding="utf-8")
    assert "filevers=(4, 2, 19, 0)" in info and "prodvers=(4, 2, 19, 0)" in info
    assert "'FileVersion', '4.2.19.0'" in info and "'ProductVersion', '4.2.19.0'" in info
    assert (root / "AGENT_README.md").read_text(encoding="utf-8").startswith("# Architect Pro Agent 4.2.19")


def test_application_label():
    from gui.agent_app import application_label

    assert application_label("COMPLETION_CERTIFICATE") == "Completion Certificate"
    assert application_label("BUILDING_WARRANT") == "Building Warrant"
    assert application_label("HOUSEHOLDER_PLANNING") == "Householder Planning"


class ReviewPortal:
    def __init__(self, drafts=1):
        self.drafts = drafts
        self.calls = []

    def proposals_named(self, _address):
        return [("500816704", "112 RALSTON AVENUE, GLASGOW, G52 3NB")]

    def open_existing_proposal(self, reference, name=""):
        self.calls.append(("open", reference))

    def wait_for_summary(self, timeout=None):
        pass

    def summary_text(self):
        return "Summary\n112 RALSTON AVENUE, GLASGOW, G52 3NB\nProposal Reference 500816704"

    def draft_form_count(self, _text):
        return self.drafts

    def open_draft_form(self, text):
        self.calls.append(("open_form", text))

    def add_standard_form(self, _text):
        raise AssertionError("opening for review must never add a form")


class ReviewStore:
    def find_for_project(self, *_args):
        return None

    def remember_for_project(self, *_args):
        pass


REVIEW_INPUTS = {"Email": "agent@example.com", "Project ID": "project",
                 "Site Address": "112 Ralston Avenue, Glasgow, G52 3NB", "Site Postcode": "G52 3NB"}


def test_open_for_review_opens_the_completion_form():
    portal = ReviewPortal()
    reference = existing_application.open_existing_application(
        object(), "COMPLETION_CERTIFICATE", REVIEW_INPUTS, password="secret", portal=portal, state_store=ReviewStore(),
    )
    assert reference == "500816704"
    assert portal.calls == [("open", "500816704"), ("open_form", COMPLETION_FORM)]


def test_open_for_review_never_adds_a_form():
    portal = ReviewPortal(drafts=0)
    with pytest.raises(existing_application.ExistingApplicationNotFound):
        existing_application.open_existing_application(
            object(), "COMPLETION_CERTIFICATE", REVIEW_INPUTS, password="secret", portal=portal, state_store=ReviewStore(),
        )
    assert portal.calls == [("open", "500816704")]

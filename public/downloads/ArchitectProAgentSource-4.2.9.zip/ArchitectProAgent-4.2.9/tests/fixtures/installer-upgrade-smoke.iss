#define MyAppName "Architect Pro Upgrade Test"
#define MyAppExeName "ArchitectPortalAutomation.exe"

[Setup]
AppId=ArchitectProIsolatedUpgradeFixture
AppName={#MyAppName}
AppVersion=1.0.0
DefaultDirName={param:TARGET}
PrivilegesRequired=lowest
Uninstallable=no
CreateUninstallRegKey=no
DisableWelcomePage=yes
DisableDirPage=yes
DisableProgramGroupPage=yes
DisableReadyPage=yes
DisableFinishedPage=yes
CloseApplications=yes
RestartApplications=no
CloseApplicationsFilter=*
Compression=none
OutputBaseFilename=upgrade-smoke

[Files]
Source: "{#SmokePayload}"; DestDir: "{app}\versions\new"; DestName: "{#MyAppExeName}"; Flags: ignoreversion

[Tasks]
Name: "desktopicon"; Description: "Test fixture task"

[Run]
Filename: "{cmd}"; Parameters: "/D /C echo launched>>""{app}\launches.txt"""; Flags: runhidden waituntilterminated; Check: StartAgentAfterInstall

[Code]
#include "../../installer/agent-upgrade.iss"

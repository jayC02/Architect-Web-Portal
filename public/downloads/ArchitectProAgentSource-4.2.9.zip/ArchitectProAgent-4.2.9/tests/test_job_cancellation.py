from types import SimpleNamespace
import pytest

from PySide6.QtWidgets import QApplication
from gui import agent_app
from gui.services.background_agent import PollingEngine
from tests.test_agent_gui import make_window, runtime_job, ThreadStub, JobThreadStub


@pytest.fixture(autouse=True)
def isolate_live_agent(monkeypatch):
    monkeypatch.setattr(agent_app.callback_outbox, 'pending_events', lambda: [])
    monkeypatch.setattr(agent_app.secure_credentials, 'get_agent_credential', lambda: (None, True, ''))
    monkeypatch.setattr(agent_app.secure_credentials, 'get_login_password', lambda _email: (None, True, ''))
    monkeypatch.setattr(agent_app.AutomationAgent, 'start_background_agent', lambda self: None)


def attach_claim(window):
    engine = PollingEngine()
    engine.set_run('job_test_123456', 'run-1', 'RUNNING')
    window.background_thread = SimpleNamespace(engine=engine, set_run=engine.set_run)
    return engine


def cleanup(window):
    window.background_thread = None
    window.load_thread = None
    window.automation_thread = None
    window.cancel_thread = None
    window.close()


def test_cancelling_a_loading_claim_invalidates_old_results_and_waits_for_release(monkeypatch):
    window = make_window()
    engine = attach_claim(window)
    monkeypatch.setattr(agent_app, 'JobLoadThread', JobThreadStub)
    window.portal_client = 'client'
    window._auto_start_claimed = True
    try:
        window.refresh_job()
        old = window.load_thread
        interrupted = []
        old.requestInterruption = lambda: interrupted.append(True)
        window.on_background_command({'type': 'CANCEL_JOB', 'jobId': 'job_test_123456', 'agentRunId': 'run-1'})
        assert interrupted == [True], 'cancel stops the outstanding download batch as well as ignoring its results'
        assert engine.current_job_id is None
        assert engine.pending_release == ('job_test_123456', 'run-1')
        assert not window._auto_start_claimed
        old.loaded.emit({'id': 'job_test_123456'}, 'client', [], [])
        old.failed.emit('Old download failed')
        assert window.portal_job is None
        assert window.runtime_job is None
        assert 'Job cancelled' in window.message.text()
        old.running = False
        old.finished.emit()
        assert window.load_thread is None
    finally:
        cleanup(window)


def test_running_cancellation_keeps_claim_until_worker_stops():
    window = make_window()
    engine = attach_claim(window)
    worker = ThreadStub(); worker.running = True
    window.automation_thread = worker
    window.runtime_job = runtime_job()
    try:
        window.on_background_command({'type': 'CANCEL_JOB', 'jobId': engine.current_job_id, 'agentRunId': 'run-1'})
        assert worker.cancelled
        assert engine.current_job_id == 'job_test_123456'
        assert engine.pending_release is None
        assert not window.stop_button.isEnabled()
        assert 'safe boundary' in window.current_task.text()
    finally:
        cleanup(window)


def test_stale_or_foreign_cancellation_never_stops_current_attempt():
    window = make_window(); engine = attach_claim(window)
    worker = ThreadStub(); worker.running = True
    window.automation_thread = worker; window.runtime_job = runtime_job()
    try:
        for job, run in [('another-job', 'run-1'), ('job_test_123456', 'old-run')]:
            window.on_background_command({'type': 'CANCEL_JOB', 'jobId': job, 'agentRunId': run})
        assert not worker.cancelled
        assert engine.current_job_id == 'job_test_123456'
    finally:
        cleanup(window)


def test_restarted_idle_agent_releases_cancelled_attempt_without_loading_it(monkeypatch):
    window = make_window()
    engine = PollingEngine()
    window.background_thread = SimpleNamespace(engine=engine, set_run=engine.set_run)
    monkeypatch.setattr(agent_app, 'JobLoadThread', lambda *args: pytest.fail('Cancelled work must never be resumed'))
    try:
        window.on_background_command({'type': 'CANCEL_JOB', 'jobId': 'old-cancelled-job', 'agentRunId': 'old-run'})
        assert engine.current_job_id is None
        assert engine.pending_release == ('old-cancelled-job', 'old-run')
        assert window.runtime_job is None
        assert not window._auto_start_claimed
    finally:
        cleanup(window)


def test_stuck_claim_has_visible_cancel_and_scoped_request(monkeypatch):
    window = make_window(); engine = attach_claim(window)
    requests = []
    class CancelThread(JobThreadStub):
        def __init__(self, command, parent):
            super().__init__()
            self.command = command
            self.completed = SimpleNamespace(connect=lambda callback: setattr(self, 'done', callback))
        def start(self):
            requests.append(self.command)
            self.done(self.command)
    monkeypatch.setattr(agent_app, 'JobCancelThread', CancelThread)
    try:
        window.show_load_error('Failed download')
        QApplication.processEvents()
        assert window.stop_button.isVisible()
        assert window.stop_button.text() == 'Cancel job'
        window.stop_button.click()
        assert requests == [{'type': 'CANCEL_JOB', 'jobId': 'job_test_123456', 'agentRunId': 'run-1'}]
        assert engine.current_job_id is None
    finally:
        cleanup(window)


def test_update_progress_and_installed_version_remain_visible():
    window = make_window()
    try:
        window.set_update_status('Downloading Agent 4.2.3: 57%')
        assert window.update_progress.isVisible()
        assert window.update_progress.value() == 57
        assert window.version_label.text() == f'Agent {agent_app.background_agent.AGENT_VERSION}'
        window.message.setText('Other application status')
        assert '57%' in window.update_status.text()
        window.on_update_failed('Download failed. Try again.')
        assert not window.update_progress.isVisible()
        assert 'Download failed' in window.update_status.text()
    finally:
        cleanup(window)

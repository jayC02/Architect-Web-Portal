// Shared upgrade behaviour, also compiled by the isolated installer smoke test.
var
  ExistingAgentAtInstall: Boolean;
  KeepAgentStartup: Boolean;

function AgentExistsInInstallDir: Boolean;
var
  Version: TFindRec;
begin
  Result := FileExists(ExpandConstant('{app}\{#MyAppExeName}'));
  if not Result and FindFirst(ExpandConstant('{app}\versions\*'), Version) then
  begin
    try
      repeat
        if ((Version.Attributes and $10) <> 0) and
           ((Version.Attributes and $400) = 0) and
           (Version.Name <> '.') and (Version.Name <> '..') then
          Result := FileExists(ExpandConstant('{app}\versions\') + Version.Name + '\{#MyAppExeName}');
      until Result or not FindNext(Version);
    finally
      FindClose(Version);
    end;
  end;
end;

procedure RegisterAgentForClose(const Filename: String);
begin
  if FileExists(Filename) then
  begin
    Log('Checking an existing Agent executable for upgrade: ' + Filename);
    if not RegisterExtraCloseApplicationsResource(False, Filename) then
      RaiseException('Windows could not prepare the existing Architect Pro Agent for this update.');
  end;
end;

procedure RegisterExtraCloseApplicationsResources;
var
  Version: TFindRec;
begin
  // Versioned releases do not overwrite the previous executable. Register the
  // old executable explicitly so Restart Manager still closes that process.
  RegisterAgentForClose(ExpandConstant('{app}\{#MyAppExeName}'));
  if FindFirst(ExpandConstant('{app}\versions\*'), Version) then
  begin
    try
      repeat
        if ((Version.Attributes and $10) <> 0) and
           ((Version.Attributes and $400) = 0) and
           (Version.Name <> '.') and (Version.Name <> '..') then
          RegisterAgentForClose(ExpandConstant('{app}\versions\') + Version.Name + '\{#MyAppExeName}');
      until not FindNext(Version);
    finally
      FindClose(Version);
    end;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  ExistingAgentAtInstall := AgentExistsInInstallDir;
  KeepAgentStartup := not ExistingAgentAtInstall or
    RegValueExists(HKCU, 'Software\Microsoft\Windows\CurrentVersion\Run', 'ArchitectProAgent');
  Result := '';
end;

function ShouldSkipPage(PageID: Integer): Boolean;
begin
  Result := (PageID = wpSelectTasks) and AgentExistsInInstallDir;
end;

function RegisterAgentStartup: Boolean;
begin
  Result := KeepAgentStartup;
end;

function CreateAgentDesktopShortcut: Boolean;
begin
  Result := WizardIsTaskSelected('desktopicon') or
    FileExists(ExpandConstant('{autodesktop}\{#MyAppName}.lnk'));
end;

function StartAgentAfterInstall: Boolean;
begin
  // Download-and-run and in-app updates both start the new version once.
  // Diagnostics can explicitly opt out without changing normal user behaviour.
  Result := ExpandConstant('{param:RESTARTAGENT|1}') <> '0';
end;

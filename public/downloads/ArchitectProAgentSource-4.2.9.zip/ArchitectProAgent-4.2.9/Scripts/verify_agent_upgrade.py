"""Exercise real Inno/Restart Manager upgrade handover in an isolated fixture.

Only disposable child processes and a temporary directory under Releases are
changed. No installed Agent, real connection, credentials or registry entry is
opened or replaced.
"""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]


def fixture_process(resource):
    # Qt's tray-close behaviour is deliberately retained. A normal WM_CLOSE
    # hides an Agent, while Restart Manager's end-session closes the process.
    from PySide6.QtWidgets import QApplication, QWidget
    from PySide6.QtCore import QTimer
    app = QApplication([])
    app.setQuitOnLastWindowClosed(False)

    class Window(QWidget):
        def closeEvent(self, event):
            event.ignore()

    window = Window()
    window.winId()
    with open(resource, 'rb'):
        print('ready', flush=True)
        QTimer.singleShot(120000, app.quit)
        app.exec()


def main():
    compiler = Path(os.environ['LOCALAPPDATA']) / 'Programs/Inno Setup 6/ISCC.exe'
    if not compiler.is_file():
        compiler = Path(os.environ.get('ProgramFiles(x86)', 'C:/Program Files (x86)')) / 'Inno Setup 6/ISCC.exe'
    releases = ROOT / 'Releases'
    releases.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='upgrade-smoke-', dir=releases) as directory:
        folder = Path(directory).resolve()
        assert folder.is_relative_to(releases.resolve())
        target = folder / 'installed-agent'
        old_resources = [target / 'ArchitectPortalAutomation.exe',
                         target / 'versions/4.2.3/ArchitectPortalAutomation.exe']
        unrelated_resource = folder / 'another-installation/ArchitectPortalAutomation.exe'
        for resource in [*old_resources, unrelated_resource]:
            resource.parent.mkdir(parents=True, exist_ok=True)
            resource.write_bytes(b'old test executable resource')
        settings = target / 'saved-connection-fixture.json'
        settings.write_bytes(b'{"connection":"test-connection","login":"test-login","startup":false}')
        original_settings = settings.read_bytes()
        payload = folder / 'new-agent.txt'
        payload.write_bytes(b'new test executable resource')
        subprocess.run([str(compiler), f'/DSmokePayload={payload}', f'/O{folder}',
                        str(ROOT / 'tests/fixtures/installer-upgrade-smoke.iss')],
                       cwd=ROOT, check=True, capture_output=True, text=True)
        children = []
        env = dict(os.environ)
        env.pop('QT_QPA_PLATFORM', None)
        try:
            for resource in [*old_resources, unrelated_resource]:
                child = subprocess.Popen([sys.executable, __file__, '--fixture', str(resource)],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env,
                    creationflags=subprocess.CREATE_NO_WINDOW)
                children.append(child)
                assert child.stdout.readline().strip() == 'ready'
            log_path = folder / 'installer.log'
            installation = subprocess.run([str(folder / 'upgrade-smoke.exe'), '/VERYSILENT',
                '/SUPPRESSMSGBOXES', '/NORESTART', '/CLOSEAPPLICATIONS', f'/TARGET={target}',
                f'/LOG={log_path}'], timeout=60, capture_output=True, text=True)
            log = log_path.read_text(encoding='utf-8-sig', errors='replace')
            (releases / 'upgrade-smoke-installer.log').write_text(log, encoding='utf-8')
            assert installation.returncode == 0, log[-6000:]
            deadline = time.monotonic() + 10
            while any(child.poll() is None for child in children[:2]) and time.monotonic() < deadline:
                time.sleep(.1)
            assert all(child.poll() is not None for child in children[:2]), 'An old Agent was left running.'
            assert children[2].poll() is None, 'An unrelated installation was closed.'
            assert settings.read_bytes() == original_settings, 'The saved connection/settings changed.'
            assert (target / 'versions/new/ArchitectPortalAutomation.exe').read_bytes() == payload.read_bytes()
            assert (target / 'launches.txt').read_text().splitlines() == ['launched'], 'New Agent must start exactly once.'
            print('PASS real installer: closes legacy and versioned Agents, preserves settings, starts new version once; unrelated installation stays running.')
        finally:
            for child in children:
                if child.poll() is None:
                    child.terminate()
                child.wait(timeout=10)


if __name__ == '__main__':
    if '--fixture' in sys.argv:
        fixture_process(sys.argv[-1])
    else:
        main()

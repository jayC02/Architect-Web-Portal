"""The warrant's design-certificate register: dropdowns reload after Scheme Type is chosen."""

import pytest

from automation.building_warrant import certificates

from completion_fakes import FakeDriver

PART1 = certificates.REGISTER + "ddlCertifierRegNo1"


class SlowReload(FakeDriver):
    """The prefix options arrive a few looks after the page is first read, as after a postback."""

    def __init__(self, looks_before_loaded):
        super().__init__()
        self.looks_before_loaded = looks_before_loaded
        self.add(PART1, kind="select", options=["..."], value="...")

    def find_elements(self, by, value):
        if value == PART1 and self.looks_before_loaded > 0:
            self.looks_before_loaded -= 1
            if self.looks_before_loaded == 0:
                self.fields[PART1].options = ["...", "BRE1", "NIC1"]
        return super().find_elements(by, value)


def test_waits_for_the_prefix_to_load_after_the_scheme_postback():
    driver = SlowReload(looks_before_loaded=3)
    certificates._select_text(driver, PART1, "BRE1", timeout=2)
    assert driver.value(PART1) == "BRE1"


def test_a_prefix_the_portal_never_offers_names_what_it_does_offer():
    driver = SlowReload(looks_before_loaded=1)
    with pytest.raises(RuntimeError, match=r"'SEL1'.*BRE1, NIC1"):
        certificates._select_text(driver, PART1, "SEL1", timeout=0.5)

"""Postback-safe design certification and observed portal validation results."""
import re
from dataclasses import dataclass

from selenium.common.exceptions import NoSuchElementException, StaleElementReferenceException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait

from automation.common.actions import click_yes_no_answer, get_when_clickable, type_into, wait_dom_ready, yes_no_answer
from automation.building_warrant.navigation import click_next
from automation.completion_certificate.fields import portal_date

PREFIX = "MainContent_BuildingWarrantAppWizard_"


@dataclass(frozen=True)
class DesignRegister:
    """One of the portal's two registers of design certificates.

    "Following this application" (CertificatesRegister1_) asks for the
    certifier's and approved body's names; "With this application"
    (CertificatesRegister_) asks for the certificate number and both
    signature dates instead.
    """
    description: str
    prefix: str
    with_application: bool

    def id(self, suffix):
        return self.prefix + suffix

    @property
    def scheme_type_id(self):
        return self.id("ddlSchemeType")


FOLLOWING_APPLICATION = DesignRegister("to be submitted following the application", PREFIX + "CertificatesRegister1_", False)
WITH_APPLICATION = DesignRegister("supplied with the application", PREFIX + "CertificatesRegister_", True)
REGISTER = FOLLOWING_APPLICATION.prefix
SCHEME_TYPE_ID = FOLLOWING_APPLICATION.scheme_type_id
CERTIFIER_NAME_ID = "txtCertifierName"
APPROVED_BODY_NAME_ID = "txtCertificateANameOfApprovedBody"
CERTIFIER_DATE_ID = "txtCertifierSignatureDate"
APPROVED_BODY_DATE_ID = "txtApprovedBodySignatureDate"
UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
LOWER = "abcdefghijklmnopqrstuvwxyz"
VALIDATION_BUTTON = (
    f"//input[(@type='submit' or @type='button' or @type='image') and (contains(translate(@value,'{UPPER}','{LOWER}'),'validation check') "
    f"or contains(translate(@alt,'{UPPER}','{LOWER}'),'validation check'))] | "
    f"//button[contains(translate(normalize-space(.),'{UPPER}','{LOWER}'),'validation check')] | "
    f"//a[contains(translate(normalize-space(.),'{UPPER}','{LOWER}'),'validation check')]"
)
VALIDATION_MESSAGES = (
    "[role='alert'],[role='status'],.alert,.validation-summary-errors,.field-validation-error,"
    "span[id*='valid' i],div[id*='valid' i],p[id*='valid' i],"
    "span[id*='result' i],div[id*='result' i],span[id*='message' i],div[id*='message' i]"
)


class CertificateValidationError(ValueError):
    def __init__(self, portal_message):
        # The existing callback errorSummary is limited to 500 characters.
        # Leave room for the actionable explanation instead of losing it at transport.
        self.portal_message = " ".join(str(portal_message).split())[:320]
        super().__init__(f"Certificate validation failed: {self.portal_message} Correct the saved certifier details in Architect Pro and prepare the warrant again.")


def validate_design_certificate(user_inputs):
    if yes_no_answer(user_inputs, "Approved Certifier Design") != "Yes":
        return
    for key in ("Registration Number (A) Part 1", "Registration Number (A) Part 2", "Name of Certifier",
                "Registration Number (B) Part 1", "Registration Number (B) Part 2", "Name of Approved Body"):
        if not str(user_inputs.get(key) or "").strip():
            raise ValueError(f"Complete {key} in Architect Pro before running this warrant.")
    with_application = yes_no_answer(user_inputs, "Design Certificate With Application", "No") == "Yes"
    following = yes_no_answer(user_inputs, "Design Certificate Following Application", "Yes") == "Yes"
    if not with_application and not following:
        raise ValueError("Choose when the design certificate will be provided in Architect Pro before running this warrant.")
    if with_application:
        if not str(user_inputs.get("Design Certificate Number") or "").strip():
            raise ValueError("Complete Design Certificate Number in Architect Pro before running this warrant.")
        for key in ("Design Certifier Signature Date", "Design Approved Body Signature Date"):
            try:
                portal_date(user_inputs.get(key))
            except ValueError as exc:
                raise ValueError(f"Complete {key} in Architect Pro before running this warrant.") from exc


def design_register_for(user_inputs):
    """The register the portal opens for this warrant's timing answers."""
    with_application = yes_no_answer(user_inputs, "Design Certificate With Application", "No") == "Yes"
    return WITH_APPLICATION if with_application else FOLLOWING_APPLICATION


def _option_texts(driver, element_id):
    try:
        return [option.text.strip() for option in Select(driver.find_element(By.ID, element_id)).options]
    except (NoSuchElementException, StaleElementReferenceException):
        return []


def _selected(driver, element_id):
    try:
        return Select(driver.find_element(By.ID, element_id)).first_selected_option.text.strip()
    except (NoSuchElementException, StaleElementReferenceException):
        return None


def _text_value(driver, element_id):
    try:
        return driver.find_element(By.ID, element_id).get_attribute("value") or ""
    except (NoSuchElementException, StaleElementReferenceException):
        return None


def _posts_back(element):
    """Scheme Type and the certifier's Part 1 prefix reload the whole page when changed."""
    return "__doPostBack" in str(element.get_attribute("onchange") or "")


def _select_text(driver, element_id, value, timeout=30):
    """Choose ``value``; when the dropdown reloads the page, wait for the reloaded page."""
    # The option may still be loading after an earlier reload.
    try:
        WebDriverWait(driver, timeout, poll_frequency=0.15).until(
            lambda current: value in _option_texts(current, element_id)
        )
    except TimeoutException as exc:
        offered = [option for option in _option_texts(driver, element_id) if option and set(option) != {"."}]
        raise RuntimeError(
            f"The portal does not offer {value!r} on the design-certificate screen. "
            f"It offers: {', '.join(offered) or 'no options'}. Check the certifier details in Architect Pro."
        ) from exc
    for _attempt in range(3):
        try:
            element = get_when_clickable(driver, By.ID, element_id, timeout=timeout)
            dropdown = Select(element)
            if dropdown.first_selected_option.text.strip() == value:
                return False
            reloads = _posts_back(element)
            dropdown.select_by_visible_text(value)
            break
        except StaleElementReferenceException:
            continue
    else:
        raise RuntimeError(f"The design-certificate screen kept reloading before {value!r} could be chosen.")
    if reloads:
        # Anything filled before this reload finishes would be lost, so wait for it.
        try:
            WebDriverWait(driver, timeout, poll_frequency=0.15).until(EC.staleness_of(element))
        except TimeoutException as exc:
            raise RuntimeError(f"The portal did not reload the design-certificate screen after {value!r} was chosen.") from exc
    wait_dom_ready(driver, timeout)
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda current: _selected(current, element_id) == value)
    return True


def _enter_text(driver, element_id, value, timeout=30):
    if _text_value(driver, element_id) == value:
        return
    type_into(driver, By.ID, element_id, value, timeout=timeout)
    WebDriverWait(driver, timeout, poll_frequency=0.15).until(lambda current: _text_value(current, element_id) == value)


def fill_design_register(driver, user_inputs, timeout=30, register=FOLLOWING_APPLICATION):
    """Complete one register of design certificates.

    Scheme Type reveals the certifier details and the certifier's Part 1 prefix
    reloads the page, so both are chosen first and each reload is waited for.
    Every value is checked at the end and anything a late reload dropped is
    entered again.
    """
    value = lambda key: str(user_inputs[key]).strip()
    scheme = (register.scheme_type_id, "Design")
    certifier_prefix = (register.id("ddlCertifierRegNo1"), value("Registration Number (A) Part 1"))
    selects = (
        (register.id("ddlCertifierRegNo2"), "D"),
        (register.id("ddlApprovedBodyRegNo1"), value("Registration Number (B) Part 1")),
        (register.id("ddlApprovedBodyRegNo2"), "DB"),
    )
    texts = [
        (register.id("txtCertifierRegNo"), value("Registration Number (A) Part 2")),
        (register.id("txtApprovedBodyRegNo"), value("Registration Number (B) Part 2")),
    ]
    if register.with_application:
        texts += [
            (register.id("txtCertificateNumber"), value("Design Certificate Number")),
            (CERTIFIER_DATE_ID, portal_date(user_inputs.get("Design Certifier Signature Date"))),
            (APPROVED_BODY_DATE_ID, portal_date(user_inputs.get("Design Approved Body Signature Date"))),
        ]
    else:
        texts += [
            (CERTIFIER_NAME_ID, value("Name of Certifier")),
            (APPROVED_BODY_NAME_ID, value("Name of Approved Body")),
        ]
    _select_text(driver, *scheme, timeout)
    _select_text(driver, *certifier_prefix, timeout)
    for _attempt in range(2):
        for element_id, wanted in (scheme, certifier_prefix, *selects):
            _select_text(driver, element_id, wanted, timeout)
        for element_id, wanted in texts:
            _enter_text(driver, element_id, wanted, timeout)
        lost = [element_id for element_id, wanted in texts if _text_value(driver, element_id) != wanted]
        lost += [element_id for element_id, wanted in (scheme, certifier_prefix, *selects) if _selected(driver, element_id) != wanted]
        if not lost:
            return
    raise RuntimeError(
        "The portal did not keep the design-certificate details after reloading the screen: "
        + ", ".join(element_id.replace(register.prefix, "") for element_id in lost) + "."
    )


def _messages(driver):
    found = []
    for element in driver.find_elements(By.CSS_SELECTOR, VALIDATION_MESSAGES):
        try:
            text = " ".join(element.text.split())
            if not element.is_displayed() or not text:
                continue
            invalid = re.search(
                r"\b(invalid|unsuccessful|failed|failure|error|incorrect|unable|cannot)\b"
                r"|\b(?:not|never)\b.{0,40}\b(valid|validated|verified|registered|found|match|successful)\b"
                r"|\b(no|zero)\s+(matching|valid|registered)\b|\bcould\s+not\b"
                r"|\bissues?\s+validating\b",
                text, re.I,
            )
            valid = re.search(r"\b(valid|validated|verified|successful|successfully)\b", text, re.I)
            if invalid or valid:
                found.append((element.id, text, not bool(invalid)))
        except StaleElementReferenceException:
            continue
    return found


def check_certificate_validation(driver, timeout=30):
    def visible_button(current):
        for button in current.find_elements(By.XPATH, VALIDATION_BUTTON):
            try:
                if button.is_displayed() and button.is_enabled():
                    return button
            except StaleElementReferenceException:
                continue
        return False
    try:
        button = WebDriverWait(driver, timeout).until(visible_button)
    except TimeoutException as exc:
        raise RuntimeError("The portal has changed on the design-certificate screen: the Validation Check button was not found.") from exc
    previous = {(element_id, text) for element_id, text, _success in _messages(driver)}
    button.click()  # A validation request is never blindly clicked twice.
    def fresh_result(current):
        replaced = EC.staleness_of(button)(current)
        messages = _messages(current)
        fresh = [(text, success) for element_id, text, success in messages if replaced or (element_id, text) not in previous]
        # A positive panel must not mask an adjacent field-level rejection.
        if fresh:
            failures = [text for _element_id, text, success in messages if not success]
            if failures:
                return failures[0], False
            return fresh[0]
        return False
    try:
        message, success = WebDriverWait(driver, timeout, ignored_exceptions=(StaleElementReferenceException,)).until(fresh_result)
    except TimeoutException as exc:
        raise RuntimeError("The portal did not confirm the design-certificate validation result. Review the saved certifier details before retrying; Validation Check was not repeated.") from exc
    if not success:
        raise CertificateValidationError(message)
    return message


def fill_design_certificate(driver, user_inputs, timeout=30):
    validate_design_certificate(user_inputs)
    for key, suffix, default in (
        ("Design Certificate With Application", "rbUploadCertificateOfDesignWithApplication", "No"),
        ("Design Certificate Following Application", "rbUploadCertificateOfDesignFollowingApplication", "Yes"),
    ):
        click_yes_no_answer(driver, user_inputs, key, PREFIX + suffix + "Yes", PREFIX + suffix + "No", default=default, timeout=timeout)
    register = design_register_for(user_inputs)
    other = WITH_APPLICATION if register is FOLLOWING_APPLICATION else FOLLOWING_APPLICATION
    # Either register counts as arriving, so the wrong one is named rather than waited for.
    found = click_next(driver, timeout=timeout, expected_ids=(register.scheme_type_id, other.scheme_type_id),
                       screen_name="design-certificate details")
    if found == other.scheme_type_id:
        raise RuntimeError(
            f"The portal opened the register for design certificates {other.description}, but this warrant says the "
            f"certificate will be {register.description}. Check the design certificate timing in Architect Pro."
        )
    fill_design_register(driver, user_inputs, timeout, register=register)
    check_certificate_validation(driver, timeout=timeout)

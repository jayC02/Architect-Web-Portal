"""Document identity and reviewed upload metadata, independent of local paths."""
import hashlib
import os

from automation.common.documents import get_paper_size_from_pdf
from automation.common.uploads import DocumentUploadError


def prepare_document_metadata(documents):
    result = {}
    for document in documents:
        filename = document.get("localName")
        path = document.get("localPath")
        if not filename or not path:
            continue
        digest = document.get("fileHash")
        if not digest and os.path.isfile(path):
            with open(path, "rb") as handle:
                digest = hashlib.file_digest(handle, "sha256").hexdigest()
        identity = str(document.get("id") or document.get("originalFilename") or document.get("originalName") or filename)
        reference = "AP" + hashlib.sha256((identity + "\0" + digest).encode("utf-8")).hexdigest()[:18] if digest else None
        result[filename] = {
            "documentId": document.get("id"), "fileHash": digest, "uploadReference": reference,
            "originalFilename": document.get("originalFilename") or document.get("originalName") or filename,
            "paperSize": document.get("paperSize"),
        }
    return result


def document_title(filename, metadata=None):
    return (metadata or {}).get(filename, {}).get("uploadReference") or os.path.splitext(os.path.basename(filename))[0]


def legacy_document_titles(filename, metadata=None):
    details = (metadata or {}).get(filename, {})
    return {os.path.splitext(os.path.basename(str(value)))[0] for value in
            (filename, details.get("originalFilename")) if value}


def document_paper_size(path, metadata=None):
    details = (metadata or {}).get(os.path.basename(path), {})
    analysis = details.get("paperSize") or {}
    if analysis.get("reviewRequired"):
        raise DocumentUploadError(os.path.basename(path), "Checking document paper size", "PAPER_SIZE_NEEDS_REVIEW",
                                  "Confirm the document's paper size in Architect Pro before preparing this application.")
    if analysis.get("value") in ("A0", "A1", "A2", "A3", "A4", "A5", "A6", "Not Applicable"):
        return analysis["value"]
    # Older prepared jobs have no AI result. Read the physical PDF page instead
    # of guessing from drawing numbers or filenames.
    return get_paper_size_from_pdf(path)

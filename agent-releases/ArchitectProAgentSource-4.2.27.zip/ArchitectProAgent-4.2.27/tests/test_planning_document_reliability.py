import pytest
from selenium.common.exceptions import StaleElementReferenceException
from automation.householder import documents
from automation.common.uploads import DocumentUploadError
from completion_fakes import FakeDriver


class PlanningDocuments:
    def __init__(self, saved=(), uncertain_save=False):
        self.driver = FakeDriver()
        self.uploaded = list(saved)
        self.page = 'summary'
        self.uncertain_save = uncertain_save
        self.saved_section = False
        d = self.driver
        d.scripts['ARCHPRO_ATTACHMENT_LIST'] = lambda: {'recognized': self.page == 'list', 'titles': self.uploaded, 'paginated': False}
        d.scripts['return Boolean(arguments[0].checked'] = lambda element: element.is_selected()
        d.add('MainContent_FormSections_btnSupportingDocumentation', kind='button', on_click=lambda _: self.go('options'))
        d.add_radio('MainContent_rbYes', 'supporting')
        d.add_radio('MainContent_rbNo', 'supporting')
        d.add('MainContent_btnContinue', kind='button', on_click=lambda _: self.go('list' if d.selected('MainContent_rbYes') else 'summary'))
        d.add('MainContent_btnAddDocumentation', kind='button', on_click=lambda _: self.go('attach'))
        d.add_radio('MainContent_rbUploaded', 'upload')
        d.add('MainContent_btnAttachmentContinue', kind='button', on_click=lambda _: self.go('editor'))
        for field in ('edtDocumentTitle', 'edtDescription', 'fuAttachFile'):
            d.add('MainContent_' + field)
        d.add('MainContent_lbPaperSize', kind='select', options=['A3', 'A4'], value='A4')
        d.add('MainContent_lbDocumentType', kind='select', options=['Drawing', 'Other'], value='Other')
        d.add_radio('MainContent_rbReadAndUnderstood', 'read')
        d.add('MainContent_btnSaveDocEdit', kind='button', on_click=lambda _: self.save())
        d.add_radio('MainContent_rbFinished', 'finish')
        d.add('MainContent_btnDocSave', kind='button', on_click=lambda _: self.finish())
        self.go('summary')

    def go(self, page):
        self.page = page
        self.driver.postback()
        self.driver.visible_ids = set({
            'summary': ['FormSections_btnSupportingDocumentation'],
            'options': ['rbYes', 'rbNo', 'btnContinue'],
            'list': ['btnAddDocumentation', 'rbFinished', 'btnDocSave'],
            'attach': ['rbUploaded', 'btnAttachmentContinue'],
            'editor': ['edtDocumentTitle', 'edtDescription', 'fuAttachFile', 'lbPaperSize', 'lbDocumentType', 'rbReadAndUnderstood', 'btnSaveDocEdit'],
        }[page])
        self.driver.visible_ids = {'MainContent_' + value for value in self.driver.visible_ids}

    def save(self):
        self.uploaded.append(self.driver.value('MainContent_edtDocumentTitle'))
        self.go('list')
        if self.uncertain_save:
            raise StaleElementReferenceException('Save committed but its response was replaced')

    def finish(self):
        self.saved_section = True
        self.go('summary')


@pytest.fixture
def prepared(monkeypatch, tmp_path):
    monkeypatch.setattr(documents, 'get_document_type_from_pdf', lambda _: 'Drawing')
    for name in ('one.pdf', 'two.pdf'):
        (tmp_path / name).write_bytes(b'%PDF-test')
    metadata = {name: {'uploadReference': 'AP' + digit * 18, 'originalFilename': name,
                       'paperSize': {'value': 'A3', 'reviewRequired': False}}
                for name, digit in [('one.pdf', '1'), ('two.pdf', '2')]}
    return str(tmp_path), metadata


def test_planning_partial_run_only_uploads_the_missing_file(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(saved=['AP' + '1' * 18])
    documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed'), ('two.pdf', 'proposed')], folder, {'proposed': 'Proposed plans'}, metadata)
    assert portal.uploaded == ['AP' + '1' * 18, 'AP' + '2' * 18]
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 1
    assert portal.saved_section
    assert portal.driver.value('MainContent_lbPaperSize') == 'A3'


def test_planning_completed_uploads_do_not_open_an_empty_editor(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(saved=['AP' + '1' * 18])
    documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed')], folder, {}, metadata)
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 0
    assert portal.saved_section


def test_planning_does_not_repeat_an_uncertain_save(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments(uncertain_save=True)
    with pytest.raises(DocumentUploadError) as caught:
        documents.upload_supporting_documents(portal.driver, [('one.pdf', 'proposed'), ('two.pdf', 'proposed')], folder, {}, metadata)
    assert caught.value.reason_code == 'UPLOAD_UNCONFIRMED'
    assert caught.value.filename == 'one.pdf'
    assert portal.driver.clicks('MainContent_btnSaveDocEdit') == 1
    assert portal.uploaded == ['AP' + '1' * 18]


def test_planning_location_plan_only_answers_no_supporting_documents(prepared):
    folder, metadata = prepared
    portal = PlanningDocuments()
    documents.upload_supporting_documents(portal.driver, [], folder, {}, metadata)
    assert portal.driver.selected('MainContent_rbNo')
    assert portal.driver.clicks('MainContent_btnAddDocumentation') == 0

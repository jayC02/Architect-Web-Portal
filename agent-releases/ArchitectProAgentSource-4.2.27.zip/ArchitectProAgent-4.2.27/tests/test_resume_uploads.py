"""A resumed run uploads only the supporting documents the portal does not already list."""

from automation.common.uploads import documents_still_to_upload, listed_document_titles

from completion_fakes import FakeDriver


ENTRIES = [("A-100 Existing Plan.pdf", "existing"), ("A-200 Proposed Plan.pdf", "proposed"), ("Report.pdf", "other")]


def test_documents_already_in_the_portal_are_skipped():
    assert documents_still_to_upload(ENTRIES, {"A-100 Existing Plan", "Some other line"}) == ENTRIES[1:]


def test_nothing_listed_means_everything_uploads():
    assert documents_still_to_upload(ENTRIES, set()) == ENTRIES


def test_only_attachment_rows_are_read_not_page_headings():
    driver = FakeDriver()
    driver.body_text = "Supporting documents\n  A-100 Existing Plan  \nAdd Documentation\n"
    driver.scripts['ARCHPRO_ATTACHMENT_LIST'] = lambda: {'recognized': True, 'titles': ['A-100 Existing Plan'], 'paginated': False}
    assert listed_document_titles(driver) == {"A-100 Existing Plan"}
    assert documents_still_to_upload([('Supporting documents.pdf', 'other')], listed_document_titles(driver)) == [('Supporting documents.pdf', 'other')]


def test_agent_advertises_resume_runs():
    from gui.services import background_agent

    assert background_agent.CAPABILITIES["resumeContractVersions"] == [1]

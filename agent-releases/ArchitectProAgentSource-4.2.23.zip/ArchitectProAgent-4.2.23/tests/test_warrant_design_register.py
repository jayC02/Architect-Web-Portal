"""The warrant's design-certificate register: dropdowns reload after Scheme Type is chosen."""

import pytest

from automation.building_warrant import certificates

from completion_fakes import FakeDriver

PART1 = certificates.REGISTER + "ddlCertifierRegNo1"


class SlowReload(FakeDriver):
    """The prefix options arrive a few looks after the page is first read, as after a postback."""

    def __init__(self, looks_before_loaded):
        super().__init__()
        self.looks_before_loaded = looks_before_loaded
        self.add(PART1, kind="select", options=["..."], value="...")

    def find_elements(self, by, value):
        if value == PART1 and self.looks_before_loaded > 0:
            self.looks_before_loaded -= 1
            if self.looks_before_loaded == 0:
                self.fields[PART1].options = ["...", "BRE1", "NIC1"]
        return super().find_elements(by, value)


def test_waits_for_the_prefix_to_load_after_the_scheme_postback():
    driver = SlowReload(looks_before_loaded=3)
    certificates._select_text(driver, PART1, "BRE1", timeout=2)
    assert driver.value(PART1) == "BRE1"


def test_a_prefix_the_portal_never_offers_names_what_it_does_offer():
    driver = SlowReload(looks_before_loaded=1)
    with pytest.raises(RuntimeError, match=r"'SEL1'.*BRE1, NIC1"):
        certificates._select_text(driver, PART1, "SEL1", timeout=0.5)


# ---- The whole register page, as captured from the portal ------------------------------
# Choosing Scheme Type or the certifier's Part 1 prefix posts the page back
# (onchange setTimeout __doPostBack). The reload renders what the server
# received, so anything typed between the choice and the reload is lost.

import time

R = certificates.REGISTER
SCHEME = R + "ddlSchemeType"
A1, A2, A_NUMBER = R + "ddlCertifierRegNo1", R + "ddlCertifierRegNo2", R + "txtCertifierRegNo"
B1, B2, B_NUMBER = R + "ddlApprovedBodyRegNo1", R + "ddlApprovedBodyRegNo2", R + "txtApprovedBodyRegNo"
A_NAME, B_NAME = "txtCertifierName", "txtCertificateANameOfApprovedBody"
PREFIXES = ["...", "BRE1", "BRE2", "RIA1", "RIA2", "SER1"]
POSTBACK = "javascript:setTimeout('__doPostBack(...)', 0)"
DETAILS = (A1, A2, A_NUMBER, A_NAME, B1, B2, B_NUMBER, B_NAME, R + "btnValidate")

INPUTS = {
    "Approved Certifier Design": "Yes",
    "Registration Number (A) Part 1": "SER1", "Registration Number (A) Part 2": "1234", "Name of Certifier": "A Certifier",
    "Registration Number (B) Part 1": "RIA2", "Registration Number (B) Part 2": "5678", "Name of Approved Body": "A Body",
}


class RegisterPage(FakeDriver):
    def __init__(self, reload_seconds=0.3, validation="There was an issue validating the approved certifier and approved body details."):
        super().__init__()
        self._generation = 0
        self.reload_seconds = reload_seconds
        self.pending = None
        self.reloads = 0
        self.add(SCHEME, kind="select", options=["Please select Scheme Type...", "Design"], value="Please select Scheme Type...",
                 on_change=self.schedule_reload)
        self.fields[SCHEME].attributes = {"onchange": POSTBACK}
        self.add(A1, kind="select", options=PREFIXES, value="...", on_change=self.schedule_reload)
        self.fields[A1].attributes = {"onchange": POSTBACK}
        self.add(A2, kind="select", options=["...", "D"], value="...")
        self.add(B1, kind="select", options=PREFIXES, value="...")
        self.add(B2, kind="select", options=["...", "DB"], value="...")
        for element_id in (A_NUMBER, A_NAME, B_NUMBER, B_NAME):
            self.add(element_id)
        self.add(R + "btnValidate", kind="button", value="Validation Check", on_click=self.validate)
        self.validation = validation
        for element_id in DETAILS:          # the details appear once Design is chosen
            self.fields[element_id].visible = False

    @property
    def generation(self):
        if self.pending and time.monotonic() >= self.pending[0]:
            _due, saved = self.pending
            self.pending = None
            for element_id, value in saved.items():
                self.fields[element_id].value = value
            if self.fields[SCHEME].value == "Design":
                for element_id in DETAILS:
                    self.fields[element_id].visible = True
            self._generation += 1
            self.reloads += 1
        return self._generation

    @generation.setter
    def generation(self, value):
        self._generation = value

    def schedule_reload(self, _driver):
        saved = {element_id: field.value for element_id, field in self.fields.items() if field.kind in ("select", "text")}
        self.pending = (time.monotonic() + self.reload_seconds, saved)

    def validate(self, _driver):
        self.add(R + "validationErrorMessage", kind="message", text=self.validation)
        self._generation += 1


def filled(page):
    return {element_id: page.value(element_id) for element_id in (SCHEME, A1, A2, A_NUMBER, A_NAME, B1, B2, B_NUMBER, B_NAME)}


EXPECTED = {SCHEME: "Design", A1: "SER1", A2: "D", A_NUMBER: "1234", A_NAME: "A Certifier",
            B1: "RIA2", B2: "DB", B_NUMBER: "5678", B_NAME: "A Body"}


def test_every_detail_survives_both_reloads():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    assert page.reloads == 2, "Design and the certifier prefix each reload the page"
    assert filled(page) == EXPECTED


def test_a_rerun_over_a_filled_page_changes_nothing():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    page.log.clear()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    assert page.reloads == 2 and filled(page) == EXPECTED
    assert not [entry for entry in page.log if entry[0] in ("click", "select", "type")]


def test_the_portals_validation_problem_message_is_a_failure():
    page = RegisterPage()
    certificates.fill_design_register(page, INPUTS, timeout=5)
    with pytest.raises(certificates.CertificateValidationError, match="issue validating"):
        certificates.check_certificate_validation(page, timeout=2)
